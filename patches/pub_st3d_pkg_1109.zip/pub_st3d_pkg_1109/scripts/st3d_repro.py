"""ST3DUNet（Xie 等，IEEE TGRS 2026）官方代码复现（11-03 写）。模型、数据集类、损失、指标、优化器全部直接 import 官方仓库
（code\\ST3DUNet，提交 840f76e），只改下面几处：

1. 官方 train_epochs 写日志时引用了不存在的 self.best_score，第 1 轮结束就会报错 → 本脚本自己写训练循环，逐步调用官方 train_one_epoch。
2. 官方代码建了 CosineAnnealingLR 却从未调用 scheduler.step()，实际是恒定学习率（main.py 默认 1e-3，权重衰减 1e-3）；
   论文写的是 1e-4 余弦降到 1e-6、250 轮。用 --sched 选：code = 与公开代码行为一致（恒定）；paper = 每轮 step 一次余弦。
3. 评测加载器加多进程读图（官方 num_workers=0；评测无随机性，数值不变）；训练加载器 persistent_workers（Windows 下每轮不重新拷数据）。
3a. 官方损失把 MUDS 的类别权重写死在 cuda:2 上（单卡机器报错），改建在 CPU，数值不变。
3b. 官方 LTAE3D.forward 引用了从未赋值的 self.attn_mode（第一次前向就报错）；只有 "ltae" 分支的输出形状与下游一致，故设为 "ltae"。
3c. 从解码缓存读（den_st3d_cache.py / muds_st3d_cache.py 解码，再由 st3d_blockify.py 转成 128² 分块布局，机械盘上随机裁块也快；
    官方类每个 128 小块要解码 16 张 1024² JPEG，只有 2.6 步/秒）。缓存类继承官方类，
    日期扰动、裁剪、翻转、旋转、缩放裁剪的随机数调用顺序与官方逐个相同，只是先裁剪再转浮点；st3d_cache_check.py 逐样本核对与官方完全相等。
    cudnn 用 benchmark 模式（官方是 deterministic；纯模型 8.8 对 6.1 步/秒），不影响方法本身。
4. 官方只在 split="val" 上评测（同区域 = 训练区右下角 (7,7)(6,6) 两块；跨区域 = 10 个验证区全图），并在同一集合上按 mIoU 选最好的一轮
   报告。本脚本照做（val 逐轮记录、存 best_in / best_out），另外训练结束后用这两个检查点和最后一轮在官方测试集
   （split="test"：同区域 (7,6)(6,7) 两块；跨区域 = 10 个测试区）上再评一次，即“验证集选、测试集报”。
用法：python -X utf8 st3d_repro.py --data dynamicearthnet --seed 42 --sched paper --epochs 250 --lr 1e-4 --out <目录>
     加 --bench 200 只跑 200 步训练 + 一次完整评测，用来测速和显存。
"""
import argparse
import json
import os
import random
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

REPO = os.environ.get("ST3D_REPO", r"D:\Railway_project\work\公开数据_1102\code\ST3DUNet")  # 路径可用环境变量覆盖（云服务器）
DATA_ROOT = os.environ.get("ST3D_DATA", r"D:\sitsscd_data")
CACHE_ROOT = os.environ.get("ST3D_CACHE", r"D:\st3d_cache")
sys.path.insert(0, REPO)
from data.data import DynamicEarthNet, Muds, collate_fn  # noqa: E402
from data.transforms import random_fliph, random_flipv, random_resize_crop, random_rotate  # noqa: E402
from metrics.scd_metrics import SCDMetric  # noqa: E402
from models.losses import Losses  # noqa: E402
from models.ltae3d import LTAE3D  # noqa: E402
from train import SitsScdWrapper  # noqa: E402
from utils.wrapper import load_model, load_yaml  # noqa: E402

LTAE3D.attn_mode = "ltae"

import models.losses as _official_losses  # noqa: E402

_ce_init = _official_losses.CrossEntropyLoss.__init__


def _ce_init_fixed(self, ignore_index=None):
    """官方把 MUDS（ignore_index=2）的类别权重 [0.25, 0.75] 写死在 cuda:2 上，单卡机器直接报错；
    改建在 CPU 上（forward 里本来就会搬到 logits 所在设备），数值不变。DEN 走官方原逻辑。"""
    if ignore_index != 2:
        return _ce_init(self, ignore_index)
    torch.nn.Module.__init__(self)
    self.ignore_index = ignore_index
    self.register_buffer("class_weights", torch.tensor([0.25, 0.75], dtype=torch.float32))
    self.loss = torch.nn.CrossEntropyLoss(weight=self.class_weights, ignore_index=ignore_index)


_official_losses.CrossEntropyLoss.__init__ = _ce_init_fixed

DATA = {"dynamicearthnet": (DynamicEarthNet, os.path.join(DATA_ROOT, "DynamicEarthNet")), "muds": (Muds, os.path.join(DATA_ROOT, "Muds"))}
CACHE = {"dynamicearthnet": os.path.join(CACHE_ROOT, "DynamicEarthNet"), "muds": os.path.join(CACHE_ROOT, "Muds")}


class _Lazy:
    def __init__(self, mm, rows, keep=None):
        self.mm, self.rows, self.keep = mm, rows, keep


_GT = {}


class _CachedCrop:
    """官方数据集类只把读图换成从解码缓存裁小块：随机数调用顺序与官方 load_data → transform 相同，只是先裁剪再转浮点。
    另外同一组区域的标签只载入一份（官方类载两遍，同区域验证/测试又各存一份训练区标签，单进程 12 GB，两个进程就把提交内存用完）。"""

    def load_ground_truth(self, split):
        key = (self.path, split if self.domain_shift else "train")
        if key not in _GT:
            _GT[key] = super().load_ground_truth(split)
        return _GT[key]

    def _open(self, cache_root, sits_id):  # 分块布局 [8, 8, 期, 128, 128, 通道]（st3d_blockify.py；机械盘上随机裁块快）
        if not hasattr(self, "_mm"):
            self._mm, self.cache_dir = {}, os.path.join(cache_root, self.split if self.domain_shift else "train")
        if sits_id not in self._mm:
            self._mm[sits_id] = np.load(os.path.join(self.cache_dir, sits_id + ".blk.npy"), mmap_mode="r")
        return self._mm[sits_id]

    def __getstate__(self):  # 传给读数子进程时不带已打开的内存映射（否则会整块拷贝）
        st = self.__dict__.copy()
        st.pop("_mm", None)
        return st

    @staticmethod
    def _crop(mm, rows, i, j, s):
        b = mm.shape[3]
        bi, bj = range(i // b, (i + s - 1) // b + 1), range(j // b, (j + s - 1) // b + 1)
        region = np.empty((len(rows), len(bi) * b, len(bj) * b, mm.shape[5]), dtype=mm.dtype)  # Planet uint8；S2 int16（11-07）
        for a, r in enumerate(bi):
            for c, q in enumerate(bj):
                region[:, a * b:(a + 1) * b, c * b:(c + 1) * b] = mm[r, q, rows]
        y0, x0 = i - bi[0] * b, j - bj[0] * b
        return region[:, y0:y0 + s, x0:x0 + s].transpose(0, 3, 1, 2)  # T C H W

    def transform(self, data, gt=None, patch_loc_i=None, patch_loc_j=None):
        s, n = self.img_size, self.true_size
        if self.split == "train":  # 同官方 random_crop 的两次 randint
            i = random.randint(0, n - s - 1)
            j = random.randint(0, n - (1 + 2 * int(i >= n - 3 * s)) * s - 1)
        else:
            i, j = patch_loc_i * s, patch_loc_j * s
        x = torch.from_numpy(np.ascontiguousarray(self._crop(data.mm, data.rows, i, j, s))).float()
        def _crop_up(mm, f=4, sel=None, lead=None):  # 粗格（f 倍）：多取一圈邻格、放大、按像元偏移切回（--s2align 1；与整图放大逐像元一致）
            Hc, Wc = mm.shape[1], mm.shape[2]
            a0, a1 = max(i // f - 1, 0), min(-(-(i + s) // f) + 1, Hc)
            b0, b1 = max(j // f - 1, 0), min(-(-(j + s) // f) + 1, Wc)
            arr = np.asarray(mm[lead, a0:a1, b0:b1] if lead is not None else mm[:, a0:a1, b0:b1], np.float32)
            if sel is not None:
                arr = arr[..., sel]
            up = torch.nn.functional.interpolate(torch.from_numpy(arr).permute(0, 3, 1, 2), scale_factor=f, mode="bilinear", align_corners=False)
            return up[:, :, i - f * a0:i - f * a0 + s, j - f * b0:j - f * b0 + s]

        def _crop4(mm, sel=None, lead=None):
            return _crop_up(mm, 4, sel, lead)

        def _valid_up(mm, sel, lead):  # 11-09：S2 原生 12 米格上“选用波段不全为零”= 有观测；按同样的裁剪 / 放大方式到 3 米，边缘掺了缺测即算无效
            if self.s2align:
                Hc, Wc = mm.shape[1], mm.shape[2]
                a0, a1 = max(i // 4 - 1, 0), min(-(-(i + s) // 4) + 1, Hc)
                b0, b1 = max(j // 4 - 1, 0), min(-(-(j + s) // 4) + 1, Wc)
                v = (np.asarray(mm[lead, a0:a1, b0:b1][..., sel]) != 0).any(-1).astype(np.float32)
                up = torch.nn.functional.interpolate(torch.from_numpy(v)[:, None], scale_factor=4, mode="bilinear", align_corners=False)
                return up[:, :, i - 4 * a0:i - 4 * a0 + s, j - 4 * b0:j - 4 * b0 + s]
            v = (np.asarray(mm[lead, i // 4:i // 4 + s // 4, j // 4:j // 4 + s // 4][..., sel]) != 0).any(-1).astype(np.float32)
            return torch.nn.functional.interpolate(torch.from_numpy(v)[:, None], scale_factor=4, mode="bilinear", align_corners=False)
        if getattr(data, "mm2", None) is not None and self.s2align:
            x = torch.cat([x, _crop4(data.mm2, self.s2_sel, data.months)], 1)
        elif getattr(data, "mm2", None) is not None:  # --s2：同月 Sentinel-2（12 米小缓存）裁同一块、双线性放大到 3 米，拼在 Planet 后面再一起增强（11-07）
            i4, j4, s4 = i // 4, j // 4, s // 4
            x2 = np.asarray(data.mm2[data.months, i4:i4 + s4, j4:j4 + s4][..., self.s2_sel], np.float32)  # [T, s4, s4, C]
            x2 = torch.nn.functional.interpolate(torch.from_numpy(x2).permute(0, 3, 1, 2), scale_factor=4, mode="bilinear", align_corners=False)
            x = torch.cat([x, x2], 1)
        if getattr(data, "mm3", None) is not None and self.s2align:
            x = torch.cat([x, _crop_up(data.mm3, 12, None, data.months)], 1)
        elif getattr(data, "mm3", None) is not None:  # --oe：OlmoEarth 32 维特征（36 米格 = 3 米下 12×12 像元），按格裁、放大、按像元偏移对齐（11-07）
            t0, t1, u0, u1 = i // 12, -(-(i + s) // 12), j // 12, -(-(j + s) // 12)
            f = np.asarray(data.mm3[data.months, t0:t1, u0:u1], np.float32)  # [T, h, w, 32]
            f = torch.nn.functional.interpolate(torch.from_numpy(f).permute(0, 3, 1, 2), scale_factor=12, mode="bilinear", align_corners=False)
            x = torch.cat([x, f[:, :, i - 12 * t0:i - 12 * t0 + s, j - 12 * u0:j - 12 * u0 + s]], 1)
        if getattr(data, "mm4", None) is not None and self.s2align:
            x = torch.cat([x, _crop4(data.mm4, None, data.months)], 1)
        elif getattr(data, "mm4", None) is not None:  # --dw：当月 Dynamic World 9 类概率 + 无景指示（12 米，den_prior_cache.py；11-07 晚）
            i4, j4, s4 = i // 4, j // 4, s // 4
            x4 = np.asarray(data.mm4[data.months, i4:i4 + s4, j4:j4 + s4], np.float32)  # [T, s4, s4, 10]
            x = torch.cat([x, torch.nn.functional.interpolate(torch.from_numpy(x4).permute(0, 3, 1, 2), scale_factor=4, mode="bilinear", align_corners=False)], 1)
        if getattr(data, "mm5", None) is not None:  # --aef：AlphaEarth 年度嵌入，按月份选年（prev = 上一年；prev2 = 上一年 + 上两年 + 缺年指示；same = 当年，只作离线参照）
            i4, j4, s4 = i // 4, j // 4, s // 4
            blk = np.asarray(data.mm5[:, i4:i4 + s4, j4:j4 + s4], np.float32)  # [3 年(2017—2019), s4, s4, 64]
            parts = []
            for m in data.months:
                k = m // 12  # 0 = 2018 年，1 = 2019 年；缓存下标 0/1/2 = 2017/2018/2019
                if data.aef_mode == "same":
                    f = blk[k + 1]
                elif data.aef_mode == "prev":
                    f = blk[k]
                else:
                    older = blk[k - 1] if k - 1 >= 0 else np.zeros_like(blk[0])
                    f = np.concatenate([blk[k], older, np.full(blk[0].shape[:2] + (1,), float(k - 1 < 0), np.float32)], -1)
                parts.append(f)
            x5 = torch.from_numpy(np.stack(parts)).permute(0, 3, 1, 2)
            x = torch.cat([x, torch.nn.functional.interpolate(x5, scale_factor=4, mode="bilinear", align_corners=False)], 1)
        if getattr(data, "mm6", None) is not None and self.s2align:
            x = torch.cat([x, _crop_up(data.mm6, 16, None, data.months)], 1)
        elif getattr(data, "mm6", None) is not None:  # --dn：DINOv3 逐月特征（48 米格 = 3 米下 16×16 像元），按格裁、放大、按像元偏移对齐（11-09）
            t0, t1, u0, u1 = i // 16, -(-(i + s) // 16), j // 16, -(-(j + s) // 16)
            f = np.asarray(data.mm6[data.months, t0:t1, u0:u1], np.float32)  # [T, h, w, 32]
            f = torch.nn.functional.interpolate(torch.from_numpy(f).permute(0, 3, 1, 2), scale_factor=16, mode="bilinear", align_corners=False)
            x = torch.cat([x, f[:, :, i - 16 * t0:i - 16 * t0 + s, j - 16 * u0:j - 16 * u0 + s]], 1)
        if getattr(self, "valid", False):  # 11-09：追加“S2 同源观测有效”通道（1 = 有效）；无效处的 S2/OE/DW 在 normalize 里置为均值
            T_ = x.shape[0]
            if getattr(data, "s2_missing", False) or getattr(data, "mm2", None) is None:
                vm = torch.zeros(T_, 1, s, s)
            else:
                vm = (_valid_up(data.mm2, self.s2_sel or list(range(12)), data.months) >= 0.999).float()
            if self.split == "train" and self.valid_aug > 0 and random.random() < self.valid_aug:  # 同源缺测增强：持久的边缘带（类似 4666 的覆盖边缘），30% 概率再整月缺
                w = int(s * random.uniform(0.15, 0.6)); side = random.randint(0, 3)
                band = torch.ones(s, s)
                if side == 0: band[:w] = 0
                elif side == 1: band[-w:] = 0
                elif side == 2: band[:, :w] = 0
                else: band[:, -w:] = 0
                vm = vm * band
                if random.random() < 0.3:
                    vm[random.randrange(T_)] = 0
            x = torch.cat([x, vm], 1)
        if data.keep is not None:  # MUDS：不在可用月份表里的月份，官方类留 0
            x[~torch.tensor(data.keep)] = 0
        gt = gt[..., i:i + s, j:j + s]
        if self.split == "train" and not getattr(self, "no_aug", False):  # 11-09：no_aug = 保留训练区随机裁块位置、关掉翻转/旋转/缩放（冻结特征探针用）
            x, gt = random_fliph(x, gt)
            x, gt = random_flipv(x, gt)
            x, gt = random_rotate(x, gt)
            x, gt = random_resize_crop(x, gt)
        return x, gt


class DENCached(_CachedCrop, DynamicEarthNet):
    def __init__(self, cache_root, **kw):
        super().__init__(**kw)
        self.cache_root = cache_root
        d = os.path.join(cache_root, self.split if self.domain_shift else "train")
        self.day_pos = {x: k for k, x in enumerate(json.load(open(os.path.join(d, "index.json")))["days"])}

    def load_data(self, sits_number, sits_id, months, curr_sits_path):
        days = [self.random_date_augmentation(month) for month in months]
        mm = self._open(self.cache_root, sits_id)
        return _Lazy(mm, [self.day_pos[x] for x in days]), days, [f"{sits_id}_{x}_rgb.jpeg" for x in days]


S2_SEL = {"all": list(range(12)), "swir": [4, 5, 6, 7, 8, 9]}  # 12 波段顺序 B2 B3 B4 B8 B5 B6 B7 B8A B11 B12 B1 B9；swir = 红边 + 短波红外
S2_MEAN = torch.tensor([1161.5256, 1399.3857, 1455.7269, 2761.0648, 1815.2145, 2465.5625, 2722.3400, 2867.8205, 2336.8220, 1742.1495, 1069.3466, 3128.7744])
OE_DIM = 32  # den_oe_pca_cache.py 的 PCA 维数
DN_DIM = 32  # dino_cache.py 的 PCA 维数（11-09）
DW_CH = 10  # Dynamic World 9 类概率 + 无景指示
AEF_CH = {"prev": 64, "prev2": 129, "same": 64}  # AlphaEarth：上一年 / 上一年 + 上两年 + 缺年指示 / 当年（离线参照）
OE_CACHE = {"pca32": "DynamicEarthNetOE", "pca32_v13": "DynamicEarthNetOE13"}  # --oe 取值 → 缓存目录（v1.2 / v1.3 Base，抽法与 PCA 做法相同；11-07 17:3x 加 v1.3）
S2_STD = torch.tensor([1541.3866, 1459.2290, 1528.1924, 1405.8515, 1518.5338, 1386.2684, 1405.3624, 1410.5013, 1377.1001, 1296.2761, 1609.3568, 2166.7642])


class DENS2Cached(DENCached):
    """Planet + 同月 Sentinel-2（--s2，11-07 数据改进原型）。S2 来自 den_s2_small_cache.py 的 12 米整图缓存（由与 Planet、标签同网格的 3 米缓存 4×4 取均值），
    按所取月份读；通道拼在 Planet 后面，与 Planet 一起裁剪、增强；归一化统计量用 ST3DUNet 的 DynamicEarthNetMSI。"""

    def __init__(self, cache_root, s2_sel, oe="none", dw="none", aef="none", dn="none", s2align=False, valid=0, valid_aug=0.0, **kw):
        super().__init__(cache_root, **kw)
        self.s2align = bool(s2align)
        self.valid, self.valid_aug = bool(valid), float(valid_aug)
        self.s2_sel, self.oe, self.dw, self.aef, self.dn = list(s2_sel), oe, dw, aef, dn
        self.dn_dir = os.path.join(CACHE_ROOT, "DynamicEarthNetDN", self.split if self.domain_shift else "train")
        folder = self.split if self.domain_shift else "train"
        self.s2_dir = os.path.join(CACHE_ROOT, "DynamicEarthNetS2", folder)
        self.oe_dir = os.path.join(CACHE_ROOT, OE_CACHE.get(oe, "DynamicEarthNetOE"), folder)
        self.dw_dir = os.path.join(CACHE_ROOT, "DynamicEarthNetDW", folder)
        self.aef_dir = os.path.join(CACHE_ROOT, "DynamicEarthNetAEF", folder)
        mean, std = [self.mean.reshape(-1)], [self.std.reshape(-1)]
        if self.s2_sel:
            sel = torch.tensor(self.s2_sel)
            mean.append(S2_MEAN[sel])
            std.append(S2_STD[sel])
        if oe != "none":  # 缓存里已标准化
            mean.append(torch.zeros(OE_DIM))
            std.append(torch.ones(OE_DIM))
        for extra in ((DW_CH if dw != "none" else 0), AEF_CH.get(aef, 0)):  # DW 概率原值、AlphaEarth 已在缓存里标准化
            if extra:
                mean.append(torch.zeros(extra))
                std.append(torch.ones(extra))
        if dn != "none":  # 缓存里已标准化
            mean.append(torch.zeros(DN_DIM))
            std.append(torch.ones(DN_DIM))
        n_s2 = len(self.s2_sel)
        self.inv_lo, self.inv_hi = 4, 4 + n_s2 + (OE_DIM if oe != "none" else 0) + (DW_CH if dw != "none" else 0)  # 与 S2 同源的通道（S2、OE、DW）
        if self.valid:
            mean.append(torch.zeros(1))
            std.append(torch.ones(1))
        self.mean, self.std = torch.cat(mean).reshape(-1, 1, 1), torch.cat(std).reshape(-1, 1, 1)

    def normalize(self, data):
        out = (data - self.mean) / self.std
        if self.valid:  # 无效处同源通道置 0（= 标准化后的均值），有效通道保留原值 0/1
            m = (data[:, -1:] > 0.5).to(out.dtype)
            out = torch.cat([out[:, :self.inv_lo], out[:, self.inv_lo:self.inv_hi] * m, out[:, self.inv_hi:-1], data[:, -1:]], 1)
        return out

    def load_data(self, sits_number, sits_id, months, curr_sits_path):
        lazy, days, names = super().load_data(sits_number, sits_id, months, curr_sits_path)
        if not hasattr(self, "_mm2"):
            self._mm2, self._mm3 = {}, {}
        lazy.months = [int(m) for m in months]
        if self.s2_sel:
            if sits_id not in self._mm2:
                self._mm2[sits_id] = np.load(os.path.join(self.s2_dir, sits_id + ".s2small.npy"), mmap_mode="r")  # [24, 256, 256, 12]
            lazy.mm2 = self._mm2[sits_id]
            lazy.s2_missing = os.path.exists(os.path.join(self.s2_dir, sits_id + ".s2blk.npy.缺S2_用均值填充"))  # 整区没有 S2（训练区 2029），缓存是均值填充
        if self.oe != "none":
            if sits_id not in self._mm3:
                self._mm3[sits_id] = np.load(os.path.join(self.oe_dir, sits_id + ".oe32.npy"), mmap_mode="r")  # [24, 86, 86, 32]
            lazy.mm3 = self._mm3[sits_id]
        if not hasattr(self, "_mm45"):
            self._mm45 = {}
        if self.dw != "none":
            key = ("dw", sits_id)
            if key not in self._mm45:
                self._mm45[key] = np.load(os.path.join(self.dw_dir, sits_id + ".dw.npy"), mmap_mode="r")  # [24, 256, 256, 10]
            lazy.mm4 = self._mm45[key]
        if self.aef != "none":
            key = ("aef", sits_id)
            if key not in self._mm45:
                self._mm45[key] = np.load(os.path.join(self.aef_dir, sits_id + ".aef.npy"), mmap_mode="r")  # [3, 256, 256, 64]
            lazy.mm5, lazy.aef_mode = self._mm45[key], self.aef
        if self.dn != "none":
            key = ("dn", sits_id)
            if key not in self._mm45:
                self._mm45[key] = np.load(os.path.join(self.dn_dir, sits_id + ".dn32.npy"), mmap_mode="r")  # [24, 64, 64, 32]
            lazy.mm6 = self._mm45[key]
        return lazy, days, names

    def __getstate__(self):
        st = super().__getstate__()
        st.pop("_mm2", None)
        st.pop("_mm3", None)
        st.pop("_mm45", None)
        return st


class MudsCached(_CachedCrop, Muds):
    def __init__(self, cache_root, **kw):
        super().__init__(**kw)
        self.cache_root = cache_root

    def load_data(self, sits_number, sits_id, months, curr_sits_path):
        keep = [m in self.month_list[sits_number] for m in months]
        days = [self.monthly_dates[m] for m in months]
        return _Lazy(self._open(self.cache_root, sits_id), list(months), keep), days, [f"{sits_id}_{self.month_string[m]}.jpg" for m in months]


def seed_all(seed, deterministic=False):  # 同官方 main.seed_all；cudnn 模式见文件头 3c
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = deterministic
    torch.backends.cudnn.benchmark = not deterministic


def make_set(cfg, split, domain_shift=None, cache=True):
    d = cfg["dataset"]
    name = d["name"].lower()
    kw = dict(path=d["path"], split=split, num_channels=d["num_channels"], num_classes=d["num_classes"], img_size=d["image_size"],
              true_size=d["true_size"], train_length=d["seq_len"], date_aug_range=d["data_aug_range"], sampling_mode=d["sampling_mode"])
    if domain_shift is not None:
        kw["domain_shift"] = domain_shift
    if cache and name in CACHE:
        if any(d.get(k, "none") != "none" for k in ("s2", "oe", "dw", "aef", "dn")):
            assert name == "dynamicearthnet", "--s2 / --oe / --dw / --aef 只用于 DynamicEarthNet"
            return DENS2Cached(CACHE[name], S2_SEL.get(d.get("s2", "none"), []), oe=d.get("oe", "none"),
                               dw=d.get("dw", "none"), aef=d.get("aef", "none"), dn=d.get("dn", "none"), s2align=bool(d.get("s2align", 0)),
                               valid=int(d.get("valid", 0)), valid_aug=float(d.get("valid_aug", 0.0)), **kw)
        return {"dynamicearthnet": DENCached, "muds": MudsCached}[name](CACHE[name], **kw)
    return DATA[name][0](**kw)


class CtxDrop(torch.utils.data.Dataset):
    """训练时随机去掉时间上下文（11-04 加；方法原型）：每个样本以概率 p 换成“第 j 期影像重复 T 次、标签也取第 j 期”，
    日期保持原样。这样同一个网络既学会带上下文判，也学会只凭一期判（推理时 st3d_dump.py 的 static 方式即对应后者）。
    p=0 时与原训练完全相同；随机数用 Python random（读数子进程各自独立播种）。
    只从有有效标签的期里抽 j：MUDS 缺测月份整期标签都是忽略值，抽中它会让整个样本没有监督，一批全是这样时损失为 nan
    （11-04 实测 1 轮 loss=nan、模型塌成全判背景，即此原因）；一期有效标签都没有时不替换。"""

    def __init__(self, base, p, ignore_index):
        self.base, self.p, self.ign = base, p, ignore_index

    def __len__(self):
        return len(self.base)

    def __getitem__(self, i):
        out = self.base[i]
        if self.p > 0 and random.random() < self.p:
            T = out["data"].shape[0]
            ok = [t for t in range(T) if bool((out["gt"][t] != self.ign).any())]
            if not ok:
                return out
            j = random.choice(ok)
            out["data"] = out["data"][j:j + 1].expand(T, *out["data"].shape[1:]).clone()
            out["gt"] = out["gt"][j:j + 1].expand(T, *out["gt"].shape[1:]).clone()
        return out


class TempPaste(torch.utils.data.Dataset):
    """时间维剪贴增强（11-05 加；方法原型）：以概率 p，从**同一训练区、同一批月份**的另一个随机裁块 B 里，
    取某一期 t0 上某个地类的形状（B 的真值里该类在一个随机窗口内的像元），把 B 在这些像元上的影像和真值贴到当前样本 A：
    70% 贴到 t0 及以后各期（持续变化），30% 只贴 t0 起的 1—2 期（往返变化）。
    同区域同月份，光照和季节一致，模型难以靠拼贴痕迹偷懒；目的是让训练中出现更多、更多样的真实外观变化，
    避免学到“这里几乎不变”的僵硬时间先验（诊断：跨区域时上下文把真实变化压掉）。只用于训练集；p=0 时与原训练相同。"""

    def __init__(self, base, p, ignore_index, per_tile):
        self.base, self.p, self.ign, self.per = base, p, ignore_index, per_tile

    def __len__(self):
        return len(self.base)

    def __getitem__(self, i):
        out = self.base[i]
        if self.p <= 0 or random.random() >= self.p:
            return out
        tile = i // self.per
        b = self.base[tile * self.per + random.randrange(self.per)]  # 同一区、同一批月份的另一个随机裁块（含它自己的随机增强）
        T, H, W = out["gt"].shape
        t0 = random.randrange(1, T)
        frames = list(range(t0, T)) if random.random() < 0.7 else list(range(t0, min(T, t0 + random.randint(1, 2))))
        s = random.randint(H // 8, H // 2)
        y0, x0 = random.randrange(0, H - s + 1), random.randrange(0, W - s + 1)
        win = b["gt"][t0, y0:y0 + s, x0:x0 + s]
        cls = [int(c) for c in torch.unique(win) if int(c) != self.ign]
        if not cls:
            return out
        k = random.choice(cls)
        mask = torch.zeros(H, W, dtype=torch.bool)
        mask[y0:y0 + s, x0:x0 + s] = win == k
        if mask.sum() < 16:
            return out
        data, gt = out["data"].clone(), out["gt"].clone()
        for t in frames:
            data[t][:, mask] = b["data"][t][:, mask]
            gt[t][mask] = b["gt"][t][mask]
        out["data"], out["gt"] = data, gt
        return out


def apply_s2(cfg, s2, oe="none", dw="none", aef="none", dn="none", valid=0):
    """--s2 / --oe：模型输入通道数加上 S2 波段数、OlmoEarth 特征维数（11-07）。11-09：记下各来源的通道区间（绝对下标），--valid 时末尾加 1 个有效通道。"""
    n = 4
    sl = {}
    if s2 and s2 != "none":
        cfg["dataset"]["s2"] = s2
        sl["s2"] = [n, n + len(S2_SEL[s2])]
        n += len(S2_SEL[s2])
    if oe and oe != "none":
        cfg["dataset"]["oe"] = oe
        sl["oe"] = [n, n + OE_DIM]
        n += OE_DIM
    if dw and dw != "none":
        cfg["dataset"]["dw"] = dw
        n += DW_CH
    if aef and aef != "none":
        cfg["dataset"]["aef"] = aef
        n += AEF_CH[aef]
    if dn and dn != "none":
        cfg["dataset"]["dn"] = dn
        sl["dn"] = [n, n + DN_DIM]
        n += DN_DIM
    if valid:
        if not (s2 and s2 != "none"):
            raise SystemExit("--valid 需要 --s2（有效性由 S2 是否有观测判断）")
        cfg["dataset"]["valid"] = 1
        sl["valid"] = [n, n + 1]
        n += 1
    cfg["dataset"]["src_slices"] = sl
    if n != 4:
        cfg["dataset"]["num_channels"] = n
        cfg["ST3DUNET"]["INPUT_CHANNELS"] = n
    return cfg


class RegionSubset(torch.utils.data.Dataset):
    """11-09：空间交叉拟合用。训练时去掉第 hold 折的区（按区在 sits_ids 里的序号 % n_folds 分折），
    其余属性（sits_ids 等）照原数据集转发，验证集不变；被去掉区的同区域保留块对这个模型就是“没见过的区”。"""

    def __init__(self, base, hold, n_folds):
        self.base = base
        per = len(base) // len(base.sits_ids)
        self.keep_regions = [r for r in range(len(base.sits_ids)) if r % n_folds != hold]
        self.idx = [r * per + k for r in self.keep_regions for k in range(per)]

    def __len__(self):
        return len(self.idx)

    def __getitem__(self, i):
        return self.base[self.idx[i]]

    def __getattr__(self, k):
        if k in ("base", "idx", "keep_regions"):
            raise AttributeError(k)
        return getattr(self.base, k)


class TStatWrap(torch.nn.Module):
    """11-09 早：ST3DUNet 的“序列摘要”输入（与新模型 qstat=1 对照）：外援通道（Planet 之后的通道）在整条序列上的
    均值、标准差、最小、最大拼到每一期输入后面，再进原网络。"""

    def __init__(self, inner, n_planet):
        super().__init__()
        self.inner, self.ip = inner, int(n_planet)

    def forward(self, x, *a, **k):
        q = x[:, :, self.ip:]
        st = torch.cat([q.mean(1), q.std(1, unbiased=False), q.amin(1), q.amax(1)], 1)
        return self.inner(torch.cat([x, st[:, None].expand(-1, x.shape[1], -1, -1, -1)], 2), *a, **k)


def build_model(cfg, arch="st3d", opts=None, tstat=0):
    if tstat and arch in ("st3d", "st3d_gn"):
        ip, n = int(cfg["model"]["num_channels"]), int(cfg["ST3DUNET"]["INPUT_CHANNELS"])
        cfg["ST3DUNET"]["INPUT_CHANNELS"] = n + 4 * (n - ip)
        return TStatWrap(build_model(cfg, arch, opts, 0), ip)
    if arch == "pse":  # 先验引导的状态—事件时序网络（pse_net.py，11-07 新模型原型）
        from pse_net import make_pse
        return make_pse(cfg, opts)
    model = load_model(cfg)
    if arch == "st3d_gn":  # 11-08 晚：所有 BatchNorm 换成 GroupNorm（组数同 pse_net：min(8, C/8)），其余不动
        def _to_gn(m):
            for n, ch in m.named_children():
                if isinstance(ch, torch.nn.modules.batchnorm._BatchNorm):
                    c = ch.num_features
                    setattr(m, n, torch.nn.GroupNorm(max(1, min(8, c // 8)), c))
                else:
                    _to_gn(ch)
        _to_gn(model)
    if arch == "mono":
        from st3d_mono import make_mono
        model = make_mono(model)
    return model


def load_run_model(ckpt_path, device="cuda"):
    """按运行目录里的 config.json 建模（数据集、原版 / 单期）并载入检查点；返回 (model, cfg, data, 轮次)。"""
    conf = json.load(open(os.path.join(os.path.dirname(os.path.abspath(ckpt_path)), "config.json"), encoding="utf-8"))
    args = conf["args"]
    cfg = load_yaml(os.path.join(REPO, "configs", f"{args['data']}.yaml"))
    cfg["dataset"]["path"] = DATA[args["data"]][1]
    apply_s2(cfg, args.get("s2", "none"), args.get("oe", "none"), args.get("dw", "none"), args.get("aef", "none"), args.get("dn", "none"), int(args.get("valid", 0) or 0))
    cfg["dataset"]["s2align"] = int(args.get("s2align", 0))
    model = build_model(cfg, args.get("arch", "st3d"), args.get("pse_opts"), int(args.get("tstat", 0) or 0)).to(device)
    ck = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(ck["model"])
    model.eval()
    return model, cfg, args["data"], ck.get("epoch")


@torch.no_grad()
def run_eval(model, loader, metric, device):
    """与官方 SitsScdWrapper.evaluate 的单个集合部分逐行一致，只是把指标返回出来。"""
    model.eval()
    metric.reset()
    for batch in loader:
        x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
        pred = model(x, date).argmax(2).view_as(y)
        metric.update(pred.cpu(), y.cpu())
    return {k: float(v) for k, v in metric.compute().items()}


def rb_logits(model, x, date, rb, idx):
    """区当标注者（--rbias）：每个训练区一组类别偏置，减去各区平均后加到输出上（平均标法由主干承担）。"""
    out = model(x, date)  # [B, T, K, H, W]
    b = rb - rb.mean(0, keepdim=True)
    return out + b[idx][:, None, :, None, None], b


def train_epoch_pse(model, loader, wrapper, optimizer, device, epoch, max_steps=None, w_prior=0.3, w_event=1.0, ema=None, ema_decay=0.9998):
    """新模型（--arch pse）的一轮训练：官方主损失 + 先验支路交叉熵（同类别加权）+ 变化头二值交叉熵。"""
    model.train()
    sums, n = {}, 0
    lf = lambda pred, gt: wrapper.compute_loss(pred=pred, batch=gt, average=True)["loss"]  # noqa: E731
    for step, batch in enumerate(loader):
        if max_steps and step >= max_steps:
            break
        x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
        logits = model(x, date)
        losses = wrapper.compute_loss(pred=logits, batch=y, average=True)
        aux, parts = model.aux_loss(y, lf, w_prior, w_event)
        loss = losses["loss"] + aux
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if ema is not None:  # 11-08：权重滑动平均（SWAD / EMA 思路，针对跨区域成绩早早见顶后来回波动）
            with torch.no_grad():
                for pe, pm in zip(ema.parameters(), model.parameters()):
                    pe.mul_(ema_decay).add_(pm.detach(), alpha=1 - ema_decay)
                for be, bm in zip(ema.buffers(), model.buffers()):
                    be.copy_(bm)
        for k, v in {**losses, **parts}.items():
            sums[k] = sums.get(k, 0.0) + float(v.detach())
        n += 1
        if (step + 1) % max(1, len(loader) // 3) == 0:
            print(f"[Epoch {epoch}] Step [{step + 1}/{len(loader)}], loss: {float(loss):.4f}，" +
                  "，".join(f"{k} {float(v):.4f}" for k, v in parts.items()), flush=True)
    return {k: v / max(n, 1) for k, v in sums.items()}


_f = torch.tensor([7.1, 10.3, 44.9, 0.7, 28, 8.0]); _f = _f / _f.sum()
CLS_W_DEN = (1 / torch.sqrt(_f + 1e-6)); CLS_W_DEN = CLS_W_DEN / CLS_W_DEN.sum() * 6  # 同官方 losses.py


def train_epoch_cw(model, loader, wrapper, optimizer, device, epoch, chgw, ignore, max_steps=None, cwnorm=False, mdrop=0.0, n_planet=4):
    """11-08：ST3DUNet 加变化像元加权（与 pse_net 的 chgw 同一写法，供公平对照）：官方损失 + chgw × 只在变化像元上的官方损失。
    变化像元 = 与前一期或后一期真值不同的像元。"""
    model.train()
    sums, n = {}, 0
    for step, batch in enumerate(loader):
        if max_steps and step >= max_steps:
            break
        x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
        if mdrop > 0:  # 11-08 晚（审稿意见：基线也给同样的模态丢弃）：整段样本的 Planet 通道置零（已标准化，0 = 均值）
            keep = (torch.rand(x.shape[0], 1, 1, 1, 1, device=device) >= mdrop).to(x.dtype)
            x = torch.cat([x[:, :, :n_planet] * keep, x[:, :, n_planet:]], 2)
        logits = model(x, date)
        losses = wrapper.compute_loss(pred=logits, batch=y, average=True)
        v = (y != ignore)
        c = torch.zeros_like(v)
        d = (y[:, 1:] != y[:, :-1]) & v[:, 1:] & v[:, :-1]
        c[:, 1:] |= d
        c[:, :-1] |= d
        loss = losses["loss"]
        lc = torch.zeros((), device=device)
        if chgw > 0 and c.any():
            if cwnorm:  # 固定倍率版：变化像元加权交叉熵之和 ÷ 批内全部有效像元的类别权重和（倍率恒为 1 + chgw）
                cw_ = CLS_W_DEN.to(logits.dtype).to(device) if logits.shape[2] == 6 else torch.tensor([0.25, 0.75], device=device, dtype=logits.dtype)
                tgt = torch.where(c, y, torch.full_like(y, ignore)).flatten(0, 1)
                lmap = torch.nn.functional.cross_entropy(logits.flatten(0, 1), tgt, weight=cw_, ignore_index=ignore, reduction="none")
                lc = lmap.sum() / cw_[y.clamp(0, cw_.numel() - 1)][v].sum().clamp_min(1.0)
            else:
                lc = wrapper.compute_loss(pred=logits, batch=torch.where(c, y, torch.full_like(y, ignore)), average=True)["loss"]
            loss = loss + chgw * lc
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        for k, val in {**losses, "change_ce": lc}.items():
            sums[k] = sums.get(k, 0.0) + float(val.detach())
        n += 1
        if (step + 1) % max(1, len(loader) // 3) == 0:
            print(f"[Epoch {epoch}] Step [{step + 1}/{len(loader)}], loss: {float(loss):.4f}，change_ce {float(lc):.4f}", flush=True)
    return {k: val / max(n, 1) for k, val in sums.items()}


def train_epoch_rb(model, loader, wrapper, optimizer, rb, lam, device, epoch, max_steps=None):
    """同官方 train_one_epoch，只多了区偏置与其 L2 惩罚。"""
    model.train()
    sums, n = {}, 0
    for step, batch in enumerate(loader):
        if max_steps and step >= max_steps:
            break
        x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
        idx = torch.as_tensor(batch["idx"], device=device).long()
        logits, b = rb_logits(model, x, date, rb, idx)
        losses = wrapper.compute_loss(pred=logits, batch=y, average=True)
        pen = lam * (b ** 2).sum(1).mean()
        loss = losses["loss"] + pen
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        for k, v in {**losses, "rb_pen": pen}.items():
            sums[k] = sums.get(k, 0.0) + float(v.detach())
        n += 1
        if (step + 1) % max(1, len(loader) // 3) == 0:
            print(f"[Epoch {epoch}] Step [{step + 1}/{len(loader)}], loss: {float(loss):.4f}, 区偏置幅度 {float(b.abs().mean()):.3f}", flush=True)
    return {k: v / max(n, 1) for k, v in sums.items()}


@torch.no_grad()
def run_eval_rb(model, loader, metric, device, b):
    """同 run_eval，但给每个样本加上它所在训练区学到的偏置（只用于同区域验证集）。"""
    model.eval()
    metric.reset()
    for batch in loader:
        x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
        idx = torch.as_tensor(batch["idx"], device=device).long()
        pred = (model(x, date) + b[idx][:, None, :, None, None]).argmax(2).view_as(y)
        metric.update(pred.cpu(), y.cpu())
    return {k: float(v) for k, v in metric.compute().items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="dynamicearthnet")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=None, help="默认用官方配置（DEN 500、MUDS 100）")
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--wd", type=float, default=1e-3)
    ap.add_argument("--sched", choices=["code", "paper"], default="code")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--eval_workers", type=int, default=0)
    ap.add_argument("--eval_batch", type=int, default=1, help="评测批大小（推理时 BatchNorm 用固定统计量，结果与批大小无关）")
    ap.add_argument("--bench", type=int, default=0)
    ap.add_argument("--test_every", type=int, default=1, help="每几轮顺带在测试集上评一次（只记录，不参与选模）")
    ap.add_argument("--no_cache", action="store_true")
    ap.add_argument("--deterministic", action="store_true")
    ap.add_argument("--valid", type=int, default=0, help="11-09：追加 S2 同源观测有效通道，无效处 S2/OE/DW 置均值（需 --s2）")
    ap.add_argument("--valid_aug", type=float, default=0.0, help="11-09：训练时同源缺测增强的概率（持久边缘带 + 30%% 整月缺）")
    ap.add_argument("--hold_fold", type=int, default=-1, help="空间交叉拟合：训练时去掉第 k 折的区（区序号 %% n_folds == k），-1 = 不去（11-09）")
    ap.add_argument("--n_folds", type=int, default=2)
    ap.add_argument("--tstat", type=int, default=0, help="ST3DUNet：外援通道的整序列均值/标准差/最小/最大拼到每期输入（与新模型 qstat=1 对照；11-09）")
    ap.add_argument("--arch", choices=["st3d", "st3d_gn", "mono", "pse"], default="st3d", help="mono = 同网络去掉一切时间运算（st3d_mono.py，论文图 12 的单期版）；pse = 先验引导的状态—事件时序网络（pse_net.py）")
    ap.add_argument("--pse_opts", default="", help="pse 的开关，如 event=1,gate=1,pgate=1,causal=0,film=1（默认全开、双向）")
    ap.add_argument("--pse_wprior", type=float, default=0.3, help="pse 先验支路交叉熵的权重")
    ap.add_argument("--pse_wevent", type=float, default=1.0, help="pse 变化头二值交叉熵的权重")
    ap.add_argument("--ctx_drop", type=float, default=0.0, help="训练时以此概率把样本换成单期重复（CtxDrop，方法原型）；0 = 原训练")
    ap.add_argument("--tpaste", type=float, default=0.0, help="训练时以此概率做时间维剪贴增强（TempPaste，方法原型）；0 = 原训练")
    ap.add_argument("--rbias", type=float, default=0.0, help="区当标注者：每个训练区一组类别偏置的 L2 惩罚系数；0 = 不用（11-07 方法原型）")
    ap.add_argument("--rbias_lr_mult", type=float, default=10.0, help="区偏置的学习率倍数")
    ap.add_argument("--max_steps", type=int, default=0, help="冒烟测试：每轮只跑这么多步")
    ap.add_argument("--chgw", type=float, default=0.0, help="st3d：变化像元额外损失的权重（同 pse_opts chgw，11-08 公平对照）；0 = 不用")
    ap.add_argument("--chgw_norm", type=int, default=0, help="st3d：1 = 固定倍率版变化加权（同 pse_opts cwnorm=1，11-08 晚）")
    ap.add_argument("--mdrop_st3d", type=float, default=0.0, help="st3d：训练时以此概率整段遮掉 Planet 通道（同 pse_opts mdrop，11-08 晚公平对照）")
    ap.add_argument("--ema", type=float, default=0.0, help="pse 训练时权重滑动平均的衰减（如 0.9998）；0 = 不用（11-08）。另存 last_ema.pth，每轮多评一次")
    ap.add_argument("--s2align", type=int, default=0, help="1 = 训练时 S2/DW 裁剪补上 i%%4、j%%4 的像元偏移（11-09 修正，Codex 审阅）；0 = 旧写法")
    ap.add_argument("--dn", choices=["none", "pca32"], default="none", help="DEN 加同月 DINOv3 卫星版特征（Planet RGB，48 米格，PCA 32 维，dino_cache.py；11-09）")
    ap.add_argument("--oe", choices=["none", "pca32", "pca32_v13"], default="none", help="DEN 加同月 OlmoEarth 特征（PCA 32 维，den_oe_pca_cache.py；pca32 = v1.2 Base，pca32_v13 = v1.3 Base；11-07 基础模型融合原型）")
    ap.add_argument("--s2", choices=["none", "all", "swir"], default="none", help="DEN 加同月 Sentinel-2：all = 12 波段，swir = 红边 + 短波红外 6 波段（11-07 数据改进原型）")
    ap.add_argument("--dw", choices=["none", "month"], default="none", help="DEN 加当月 Dynamic World 9 类概率（den_prior_cache.py；11-07 晚）")
    ap.add_argument("--aef", choices=["none", "prev", "prev2", "same"], default="none",
                    help="DEN 加 AlphaEarth 年度嵌入：prev = 上一年，prev2 = 上一年 + 上两年，same = 当年（含当月之后的影像，只作离线参照）")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    cfg = load_yaml(os.path.join(REPO, "configs", f"{a.data}.yaml"))
    cfg["dataset"]["path"] = DATA[a.data][1]
    apply_s2(cfg, a.s2, a.oe, a.dw, a.aef, a.dn, a.valid)
    cfg["dataset"]["valid_aug"] = float(a.valid_aug)
    cfg["dataset"]["s2align"] = int(a.s2align)
    epochs = a.epochs or cfg["trainer"]["max_epochs"]
    device = "cuda:0"
    os.makedirs(a.out, exist_ok=True)
    json.dump({"args": vars(a), "epochs": epochs, "cfg": cfg}, open(os.path.join(a.out, "config.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    seed_all(a.seed, a.deterministic)

    t0 = time.time()
    cache = not a.no_cache
    trainset = make_set(cfg, "train", cache=cache)
    if a.hold_fold >= 0:
        trainset = RegionSubset(trainset, a.hold_fold, a.n_folds)
        print(f"空间交叉拟合：去掉第 {a.hold_fold}/{a.n_folds} 折，训练用 {len(trainset.keep_regions)} 个区", flush=True)
    if a.tpaste > 0:
        trainset = TempPaste(trainset, a.tpaste, cfg["dataset"]["ignore_index"], len(trainset) // len(trainset.sits_ids))
    if a.ctx_drop > 0:
        trainset = CtxDrop(trainset, a.ctx_drop, cfg["dataset"]["ignore_index"])
    sets = {"val_in": make_set(cfg, "val", False, cache), "val_out": make_set(cfg, "val", True, cache),
            "test_in": make_set(cfg, "test", False, cache), "test_out": make_set(cfg, "test", True, cache)}
    print(f"数据载入 {time.time() - t0:.0f} 秒；训练 {len(trainset)}，" + "，".join(f"{k} {len(v)}" for k, v in sets.items()), flush=True)
    bs = cfg["dataset"]["global_batch_size"]
    train_loader = DataLoader(trainset, batch_size=bs, shuffle=True, drop_last=True, pin_memory=False, num_workers=a.workers,
                              collate_fn=collate_fn, persistent_workers=a.workers > 0)
    loaders = {k: DataLoader(v, batch_size=a.eval_batch, shuffle=False, pin_memory=False, num_workers=a.eval_workers, collate_fn=collate_fn,
                             persistent_workers=a.eval_workers > 0) for k, v in sets.items()}

    model = build_model(cfg, a.arch, a.pse_opts, a.tstat)
    print(f"参数量 {sum(p.numel() for p in model.parameters() if p.requires_grad) / 1e6:.2f} M", flush=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=a.wd)
    ema = None
    if a.ema > 0:
        assert a.arch == "pse", "--ema 目前只接在 --arch pse 的训练循环上"
        import copy
        ema = copy.deepcopy(model).to(device)
        ema.requires_grad_(False)
        ema.eval()
        print(f"权重滑动平均：衰减 {a.ema}", flush=True)
    rb = None
    if a.rbias > 0:
        rb = torch.nn.Parameter(torch.zeros(len(trainset.sits_ids), cfg["dataset"]["num_classes"], device=device))
        optimizer.add_param_group({"params": [rb], "lr": a.lr * a.rbias_lr_mult, "weight_decay": 0.0})
        print(f"区当标注者：{len(trainset.sits_ids)} 个训练区 × {cfg['dataset']['num_classes']} 类偏置，λ={a.rbias}", flush=True)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=a.lr * 0.01, last_epoch=-1)
    metric = SCDMetric(num_classes=cfg["dataset"]["num_classes"], ignore_index=cfg["dataset"]["ignore_index"],
                       class_names=cfg["dataset"]["class_names"])
    wrapper = SitsScdWrapper(model=model, loss_fn=Losses(mix=cfg["loss"]["mix"], ignore_index=cfg["loss"]["ignore_index"]),
                             val_metrics=metric, trainloader=train_loader, testloader_in=loaders["val_in"],
                             testloader_out=loaders["val_out"], optimizer=optimizer, scheduler=scheduler, device=device,
                             seq_len=cfg["dataset"]["seq_len"], save_ckpt_path=a.out, save_log_path=a.out)

    if a.bench:
        torch.cuda.reset_peak_memory_stats()
        it = iter(train_loader)
        model.train()
        t1 = time.time()
        for step in range(a.bench):
            batch = next(it)
            x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
            loss = wrapper.compute_loss(pred=model(x, date), batch=y, average=True)["loss"]
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            if step == 19:
                torch.cuda.synchronize()
                t1 = time.time()
        torch.cuda.synchronize()
        sps = (a.bench - 20) / (time.time() - t1)
        res = {"训练 步/秒": round(sps, 2), "每轮步数": len(train_loader), "每轮训练分钟": round(len(train_loader) / sps / 60, 1),
               "训练显存峰值 GB": round(torch.cuda.max_memory_allocated() / 2 ** 30, 2), "loss": float(loss)}
        for k in ("val_in", "val_out"):
            t2 = time.time()
            m = run_eval(model, loaders[k], metric, device)
            res[f"{k} 评测分钟"] = round((time.time() - t2) / 60, 2)
            res[f"{k} miou"] = round(m["miou"], 2)
        print(json.dumps(res, ensure_ascii=False), flush=True)
        json.dump(res, open(os.path.join(a.out, "bench.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        return

    log = open(os.path.join(a.out, "epochs.jsonl"), "a", encoding="utf-8")
    best, start = {"in": -1.0, "out": -1.0}, 1
    if os.path.exists(os.path.join(a.out, "last.pth")):  # 断点续跑（Python random 状态不恢复）
        ck = torch.load(os.path.join(a.out, "last.pth"), map_location=device)
        model.load_state_dict(ck["model"])
        optimizer.load_state_dict(ck["optimizer"])
        scheduler.load_state_dict(ck["scheduler"])
        best, start = ck["best"], ck["epoch"] + 1
        if rb is not None and "rb" in ck:
            rb.data.copy_(ck["rb"])
        if ema is not None and "ema" in ck:
            ema.load_state_dict(ck["ema"])
        print(f"从第 {start} 轮接着跑", flush=True)
    for epoch in range(start, epochs + 1):
        t1 = time.time()
        if rb is not None:
            model.to(device)
            losses = train_epoch_rb(model, train_loader, wrapper, optimizer, rb, a.rbias, device, epoch, a.max_steps or None)
        elif a.arch == "pse":
            model.to(device)
            losses = train_epoch_pse(model, train_loader, wrapper, optimizer, device, epoch, a.max_steps or None, a.pse_wprior, a.pse_wevent,
                                     ema, a.ema)
        elif a.chgw > 0 or a.mdrop_st3d > 0:
            model.to(device)
            losses = train_epoch_cw(model, train_loader, wrapper, optimizer, device, epoch, a.chgw, cfg["dataset"]["ignore_index"], a.max_steps or None,
                                    cwnorm=bool(a.chgw_norm), mdrop=a.mdrop_st3d, n_planet=int(cfg["model"]["num_channels"]))
        else:
            losses = wrapper.train_one_epoch(epoch)  # 官方训练一轮
        if a.sched == "paper":
            scheduler.step()
        rec = {"epoch": epoch, "lr": optimizer.param_groups[0]["lr"], "loss": losses.get("loss"), "train_min": round((time.time() - t1) / 60, 2)}
        if rb is not None:
            rec["rb_pen"] = losses.get("rb_pen")
            rec["rb_abs"] = float((rb - rb.mean(0)).abs().mean())
        for io in ("in", "out"):  # 官方选模规则：val 上 mIoU 创新高就存 best_{io}
            m = run_eval(model, loaders[f"val_{io}"], metric, device)
            rec[f"val_{io}"] = m
            if ema is not None:
                rec[f"val_{io}_ema"] = run_eval(ema, loaders[f"val_{io}"], metric, device)
            if m["miou"] > best[io]:
                best[io] = m["miou"]
                torch.save({"model": model.state_dict(), "epoch": epoch, "val": m}, os.path.join(a.out, f"best_{io}.pth"))
        if a.test_every and epoch % a.test_every == 0:
            for io in ("in", "out"):
                rec[f"test_{io}"] = run_eval(model, loaders[f"test_{io}"], metric, device)
        if epoch % cfg["trainer"]["ckpt_interval"] == 0:  # 同官方每 10 轮存一次
            torch.save({"model": model.state_dict(), "epoch": epoch}, os.path.join(a.out, f"epoch{epoch}.pth"))
        rec["min"] = round((time.time() - t1) / 60, 2)
        log.write(json.dumps(rec, ensure_ascii=False) + "\n")
        log.flush()
        print(f"第 {epoch} 轮 loss {rec['loss']:.4f} val_in mIoU {rec['val_in']['miou']:.2f} SCS {rec['val_in']['scs']:.2f} | "
              f"val_out mIoU {rec['val_out']['miou']:.2f} SCS {rec['val_out']['scs']:.2f} | {rec['min']} 分钟", flush=True)
        torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(), "scheduler": scheduler.state_dict(),
                    "epoch": epoch, "best": best, **({"rb": rb.detach().cpu()} if rb is not None else {}),
                    **({"ema": ema.state_dict()} if ema is not None else {})}, os.path.join(a.out, "last.pth"))
        if ema is not None:
            print(f"  滑动平均 val_in mIoU {rec['val_in_ema']['miou']:.2f} SCS {rec['val_in_ema']['scs']:.2f} | val_out mIoU {rec['val_out_ema']['miou']:.2f} SCS {rec['val_out_ema']['scs']:.2f}", flush=True)

    final = {}
    if ema is not None:  # 滑动平均权重另存一份，格式同 last.pth 的 model 部分，可直接给精确 BN / 导出脚本用
        torch.save({"model": ema.state_dict(), "epoch": epochs}, os.path.join(a.out, "last_ema.pth"))
    # --test_every 0（方法开发阶段，评价规范第 6 条）：结束时也只评验证集，测试集等冻结后用 st3d_dump.py 显式跑一次
    final_sets = ("val_in", "val_out", "test_in", "test_out") if a.test_every else ("val_in", "val_out")
    for name in ("best_in", "best_out", "last") + (("last_ema",) if ema is not None else ()):
        ck = torch.load(os.path.join(a.out, f"{name}.pth"), map_location=device)
        model.load_state_dict(ck["model"])
        final[name] = {"epoch": ck["epoch"]}
        for k in final_sets:
            final[name][k] = run_eval(model, loaders[k], metric, device)
        if rb is not None and name == "last":  # 同区域：再用本区学到的偏置评一次（区已知时的上限）
            assert list(sets["val_in"].sits_ids) == list(trainset.sits_ids), "同区域验证集的区顺序与训练集不同"
            b = (rb - rb.mean(0)).detach()
            final[name]["val_in_rb"] = run_eval_rb(model, loaders["val_in"], metric, device, b)
            torch.save(b.cpu(), os.path.join(a.out, "rbias.pt"))
    json.dump(final, open(os.path.join(a.out, "final.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("完成", flush=True)


if __name__ == "__main__":
    main()
