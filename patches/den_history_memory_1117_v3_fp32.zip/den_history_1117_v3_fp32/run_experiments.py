"""Sequential identity-aware runner; filename avoids shadowing stdlib queue."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import psutil
from train import atomic_json

HERE = Path(__file__).resolve().parent
ARMS = ["memory", "current", "identity", "mean", "last", "null", "fusion", "auxmemory"]


def gpu_sample():
    p = subprocess.run(["nvidia-smi", "--query-gpu=utilization.gpu,memory.used,memory.total",
                        "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=15)
    fields = p.stdout.strip().splitlines()[0].split(",")
    return {"utilization": int(fields[0]), "used_MiB": int(fields[1]), "total_MiB": int(fields[2])}


def training_processes():
    values = []
    for p in psutil.process_iter(["pid", "name", "cmdline", "create_time"]):
        try:
            cmd = p.info["cmdline"] or []
            script = " ".join(cmd).lower()
            ours = "den_history_1117" in script and any(str(a).endswith("train.py") for a in cmd)
            if (p.info["name"] or "").lower().startswith("python") and (ours or any(
                    s in script for s in ["train_t24.py", "run_t24_queue.py", "train_conturban.py",
                                          "train_chead.py"])):
                if p.pid != os.getpid():
                    values.append(p.info)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return values


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-root", required=True)
    ap.add_argument("--cache-root", required=True)
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--steps", type=int, default=3000)
    ap.add_argument("--eval-every", type=int, default=3000)
    ap.add_argument("--arms", nargs="+", default=ARMS)
    ap.add_argument("--wait-for-existing", action="store_true")
    ap.add_argument("--wait-identity-json")
    ap.add_argument("--coexist-max-used-MiB", type=int, default=0,
                    help="Only coexist with the explicitly recorded existing tasks, after memory benchmarking")
    args = ap.parse_args()
    root = Path(args.out_root)
    root.mkdir(parents=True, exist_ok=True)
    lock = root / ("queue_seed" + str(args.seed) + ".lock")
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        old = json.loads(lock.read_text(encoding="utf-8"))
        if psutil.pid_exists(old["pid"]) and abs(psutil.Process(old["pid"]).create_time() - old["created"]) < 1:
            raise RuntimeError("Existing queue owns this seed")
        # Old lock is retained separately rather than overwritten silently.
        lock.rename(lock.with_suffix(".stale_" + str(int(time.time())) + ".json"))
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump({"pid": os.getpid(), "created": psutil.Process().create_time()}, f)
    identity = None
    if args.wait_identity_json:
        identity = json.loads(Path(args.wait_identity_json).read_text(encoding="utf-8"))
    completed, failed = [], []
    stopfile = root / "STOP"
    env = dict(os.environ, PYTHONUNBUFFERED="1", OMP_NUM_THREADS="2", MKL_NUM_THREADS="2",
               OPENBLAS_NUM_THREADS="2", PYTHONIOENCODING="utf-8")
    for arm in args.arms:
        if arm not in ARMS:
            raise ValueError(arm)
        out = root / (arm + "_s" + str(args.seed))
        if (out / "completed.json").exists():
            completed.append(arm)
            continue
        while True:
            sample = gpu_sample()
            current = training_processes() if args.wait_for_existing else []
            identity_alive = False
            if identity:
                for saved in identity:
                    try:
                        p = psutil.Process(saved["pid"])
                        if abs(p.create_time() - saved["created"]) < 1:
                            identity_alive = True
                    except psutil.NoSuchProcess:
                        pass
            state = {"at": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "queue_pid": os.getpid(),
                     "seed": args.seed, "arm_next": arm, "gpu": sample,
                     "RAM_available_GiB": psutil.virtual_memory().available / 2**30,
                     "completed": completed, "failed": failed, "waiting_processes": current,
                     "waiting_identity_alive": identity_alive, "state": "waiting"}
            atomic_json(root / ("queue_seed" + str(args.seed) + ".json"), state)
            if stopfile.exists():
                return
            allow = {p["pid"]: p["created"] for p in (identity or [])}
            known_only = all(p["pid"] in allow and abs(p["create_time"] - allow[p["pid"]]) < 1 for p in current)
            coexist = (args.coexist_max_used_MiB > 0 and known_only and
                       sample["used_MiB"] < args.coexist_max_used_MiB)
            if (((not current and not identity_alive and sample["used_MiB"] < 4500) or coexist)
                    and psutil.virtual_memory().available > 8 * 2**30):
                break
            time.sleep(30)
        out.mkdir(exist_ok=True)
        cmd = [sys.executable, "-u", str(HERE / "train.py"), "--raw-root", args.raw_root,
               "--cache-root", args.cache_root, "--arm", arm, "--seed", str(args.seed),
               "--steps", str(args.steps), "--eval-every", str(args.eval_every), "--out", str(out)]
        for attempt in range(2):
            with open(out / "train.log", "a", encoding="utf-8") as log:
                log.write("\nSTART " + time.strftime("%Y-%m-%dT%H:%M:%S%z") + " " + json.dumps(cmd) + "\n")
                log.flush()
                process = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, env=env)
                created = psutil.Process(process.pid).create_time()
                while process.poll() is None:
                    sample = gpu_sample()
                    state.update({"at": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "state": "training",
                                  "arm": arm, "trainer_pid": process.pid, "trainer_created": created,
                                  "command": cmd, "gpu": sample,
                                  "RAM_available_GiB": psutil.virtual_memory().available / 2**30,
                                  "steps_log_mtime": (out / "steps.jsonl").stat().st_mtime if (out / "steps.jsonl").exists() else None})
                    atomic_json(root / ("queue_seed" + str(args.seed) + ".json"), state)
                    with open(root / ("gpu_seed" + str(args.seed) + ".jsonl"), "a", encoding="utf-8") as samples:
                        samples.write(json.dumps({"at": state["at"], **sample, "pid": process.pid}) + "\n")
                    if stopfile.exists():
                        # Stop request is honored at a durable checkpoint boundary:
                        # leave the trainer running, do not launch another arm.
                        state["stop_after_current"] = True
                    time.sleep(30)
            if process.returncode == 0 and (out / "completed.json").exists():
                completed.append(arm)
                break
            failed.append({"arm": arm, "attempt": attempt + 1, "returncode": process.returncode})
            if attempt == 1:
                state.update({"state": "failed", "failed": failed})
                atomic_json(root / ("queue_seed" + str(args.seed) + ".json"), state)
                return
        if stopfile.exists():
            return
    state.update({"at": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "state": "completed",
                  "completed": completed, "failed": failed})
    atomic_json(root / ("queue_seed" + str(args.seed) + ".json"), state)


if __name__ == "__main__":
    main()
