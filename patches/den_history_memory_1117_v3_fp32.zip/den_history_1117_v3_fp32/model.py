"""E014: compare current observations with a distribution of transported history.

Continuous-time linear operators are an empirical prediction model, not a
claim about radiative physics, causal mechanisms, or a new Koopman theorem.
"""
import math
import torch
from torch import nn
import torch.nn.functional as F
from backbone import SpatialEncoder


class HistoryModel(nn.Module):
    ARMS = ("current", "memory", "identity", "mean", "last", "auxmemory", "null", "fusion")

    def __init__(self, arm="memory", width=24, classes=6):
        super().__init__()
        if arm not in self.ARMS:
            raise ValueError(arm)
        self.arm, self.width, self.classes = arm, width, classes
        # Same initialization sequence as E013's discriminative backbone.
        self.encoder = SpatialEncoder(4, width)
        self.unary = nn.Conv2d(width, classes, 1)
        self.generator = nn.Parameter(torch.randn(classes, 4, 4) * .01)
        self.center_raw = nn.Parameter(torch.zeros(classes, 4))
        self.phase = nn.Parameter(torch.zeros(classes))
        self.age = nn.Parameter(torch.zeros(classes))
        self.log_scale = nn.Parameter(torch.tensor(-2.0))
        # Ordinary-fusion control receives the SAME transported references,
        # current features/bands and auxiliary likelihood supervision.
        self.fusion = nn.Sequential(nn.Conv2d(width + classes * 4 + classes + 4, width, 1),
                                    nn.GELU(), nn.Conv2d(width, classes, 1))
        nn.init.zeros_(self.fusion[-1].weight)
        nn.init.zeros_(self.fusion[-1].bias)
        if arm == "identity":
            self.generator.requires_grad_(False)
        self.progress = 1.

    def forward(self, x, days, history_mode="normal"):
        B, T, C, H, W = x.shape
        f = self.encoder(x.reshape(B * T, C, H, W))
        unary = self.unary(f).reshape(B, T, self.classes, H, W)
        if self.arm == "current":
            return {"logits": unary, "unary": unary}
        h, w = H // 4, W // 4
        observed = F.avg_pool2d(x.reshape(B * T, C, H, W), 4).reshape(B, T, C, h, w)
        p = F.avg_pool2d(unary.detach().float().softmax(2).reshape(B * T, self.classes, H, W), 4).reshape(B, T, self.classes, h, w)
        scores, masses, means = [], [], []
        # Constant covariance is fixed across classes and all controls.
        sigma = .2
        log_normalizer = -4 * math.log(math.sqrt(2 * math.pi) * sigma)
        # A skew generator gives bounded rotations in this measured 4-D space.
        # No irreversible/unchanged-class rule is imposed on semantic labels.
        generator = .5 * (self.generator.float() - self.generator.float().transpose(-1, -2))
        if self.arm == "identity":
            generator = generator * 0.
        center = self.center_raw.float().sigmoid()
        if self.arm != "identity":
            with torch.autocast(device_type=x.device.type, enabled=False):
                all_dt = (days[:, :, None] - days[:, None, :]).float() / 90.
                all_flow = torch.matrix_exp(all_dt[:, :, :, None, None, None] * generator[None, None, None])
        for q in range(T):
            first = max(0, q - 1) if self.arm == "last" else 0
            n = q - first
            if self.arm == "null" and q > 0:
                mass = observed.new_ones(B, self.classes, h, w)
                mean = center[None, :, :, None, None].expand(B, -1, -1, h, w)
                sq = (mean - observed[:, q, None]).square().sum(2)
                ll = log_normalizer - sq / (2 * sigma * sigma)
                log_density = torch.logaddexp(torch.zeros_like(ll), ll) - math.log(2.)
            elif n and history_mode != "none":
                op, pp = observed[:, first:q], p[:, first:q]
                if history_mode == "reverse":
                    op, pp = op.flip(1), pp.flip(1)
                elif history_mode == "other_sample":
                    op, pp = op.roll(1, 0), pp.roll(1, 0)
                delta_days = (days[:, q:q + 1] - days[:, first:q]).float()
                delta_years = delta_days / 365.25
                log_kernel = (F.softplus(self.phase.float())[None, None, :, None, None]
                              * (2 * math.pi * delta_years).cos()[:, :, None, None, None]
                              - F.softplus(self.age.float())[None, None, :, None, None]
                              * delta_years[:, :, None, None, None])
                weight = pp * log_kernel.clamp(-12, 4).exp()
                mass = weight.sum(1)
                # Force the small continuous-time operator into float32; matrix
                # exponentials do not support fp16 and need not dominate memory.
                with torch.autocast(device_type=x.device.type, enabled=False):
                    flow = (torch.eye(4, device=x.device).expand(B, n, self.classes, 4, 4)
                            if self.arm == "identity" else all_flow[:, q, first:q])
                    centered = op.float()[:, :, None] - center[None, None, :, :, None, None]
                    moved = torch.einsum("bskij,bskjhw->bskihw", flow, centered)
                    moved = moved + center[None, None, :, :, None, None]
                    # References are individually transported BEFORE averaging
                    # or density comparison. Renewal has unit density on [0,1]^4.
                    mean = (moved * weight[:, :, :, None]).sum(1) / mass[:, :, None].clamp_min(1e-6)
                    if self.arm == "mean":
                        sq = (mean - observed[:, q, None]).square().sum(2)
                        log_likelihood = log_normalizer - sq / (2 * sigma * sigma)
                        log_density = torch.logaddexp(torch.zeros_like(mass),
                                                     mass.clamp_min(1e-12).log() + log_likelihood) - torch.log1p(mass)
                    else:
                        sq = (moved - observed[:, q, None, None]).square().sum(3)
                        per_reference = log_normalizer - sq / (2 * sigma * sigma)
                        mixture = torch.logsumexp(weight.clamp_min(1e-12).log() + per_reference, 1)
                        log_density = torch.logaddexp(torch.zeros_like(mass), mixture) - torch.log1p(mass)
            else:
                mass = observed.new_zeros(B, self.classes, h, w)
                mean = observed.new_zeros(B, self.classes, C, h, w)
                log_density = observed.new_zeros(B, self.classes, h, w)
            scores.append(log_density)
            masses.append(mass)
            means.append(mean)
        score = torch.stack(scores, 1)
        scale = 2 * self.log_scale.sigmoid() * float(self.progress)
        correction = F.interpolate(score.reshape(B * T, self.classes, h, w), size=(H, W),
                                   mode="bilinear", align_corners=False).reshape(B, T, self.classes, H, W)
        logits = unary if self.arm == "auxmemory" else unary + scale * correction
        if self.arm == "fusion":
            mean = torch.stack(means, 1)
            mass = torch.stack(masses, 1)
            raw = torch.cat([mean.flatten(2, 3), torch.log1p(mass), observed], 2)
            raw = F.interpolate(raw.reshape(B * T, -1, h, w), size=(H, W), mode="bilinear", align_corners=False)
            delta = self.fusion(torch.cat([f, raw], 1)).reshape(B, T, self.classes, H, W)
            available = (torch.arange(T, device=x.device) > 0)[None, :, None, None, None]
            logits = unary + float(self.progress) * delta * available
        return {"logits": logits, "unary": unary, "log_density_coarse": score,
                "support": torch.stack(masses, 1), "predicted_observation": torch.stack(means, 1),
                "observed": observed, "score": score, "evidence_scale": scale}


def losses(out, y, aux_weight=.2, ignore=6):
    logits = out["logits"]
    B, T, K, H, W = logits.shape
    ce = (F.cross_entropy(logits.reshape(B * T, K, H, W), y.reshape(B * T, H, W), ignore_index=ignore)
          if (y < K).any() else logits.sum() * 0.)
    if "log_density_coarse" not in out:
        return ce, {"ce": ce.detach(), "prediction": ce.detach() * 0}
    logp = out["log_density_coarse"]
    onehot = F.one_hot(y.clamp_max(K), K + 1)[..., :K].permute(0, 1, 4, 2, 3).float()
    fraction = F.avg_pool2d(onehot.reshape(B * T, K, H, W), 4).reshape(B, T, K, H // 4, W // 4)
    valid = (torch.arange(T, device=y.device) > 0)[None, :, None, None, None]
    weights = fraction * valid
    nll = -(logp * weights).sum() / weights.sum().clamp_min(1)
    return ce + aux_weight * nll, {"ce": ce.detach(), "prediction": nll.detach()}
