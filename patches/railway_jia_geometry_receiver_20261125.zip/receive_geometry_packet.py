"""Receive and verify the eight observation-only railway geometry pairs."""
import argparse
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np

from receive_spatial_development import access_token, digest, request


NAME = "rail_geometry_observations.zip"
CODES = tuple(f"C{i:02d}" for i in range(1,9))
FIELDS = ("s2_before","s2_after","s2_valid_before","s2_valid_after",
          "s1_before","s1_after","s1_valid_before","s1_valid_after")


def check(path, out=None):
    with ZipFile(path) as archive:
        if archive.testzip() is not None or set(archive.namelist()) != {"index.json",*(c+".npz" for c in CODES)}:
            raise ValueError("Unexpected geometry archive members")
        entries = json.loads(archive.read("index.json"))
        if tuple(r["id"] for r in entries) != CODES:
            raise ValueError("Unexpected case identifiers")
        for code in CODES:
            with np.load(BytesIO(archive.read(code+".npz")),allow_pickle=False) as item:
                if set(item.files) != set(FIELDS):
                    raise ValueError(f"Unexpected geometry fields for {code}")
                for key in FIELDS:
                    channels = 4 if key.startswith("s2") else 2
                    expected = (200,200) if "valid" in key else (channels,200,200)
                    if item[key].shape != expected:
                        raise ValueError(f"Unexpected array dimensions for {code} {key}")
        if out:
            archive.extractall(out)
    print("Verified geometry data",len(entries),path.stat().st_size,digest(path),flush=True)


def main(args):
    args.out.mkdir(parents=True,exist_ok=True)
    endpoint = args.endpoint.rstrip("/")+"/"+access_token(args.key_data,args.nonce)
    probe = args.out/"route_probe.bin"
    manifest = args.out/"manifest.json"
    request(endpoint+"/route_probe.bin",probe,args.interface,15)
    request(endpoint+"/manifest.json",manifest,args.interface,15)
    if probe.stat().st_size!=4096 or digest(probe)!=args.probe or digest(manifest)!=args.manifest:
        raise ValueError("The small campus route probe or signed manifest did not match")
    info = json.loads(manifest.read_text(encoding="utf-8"))["assets"][NAME]
    if not 0 < info["bytes"] < 30_000_000 or info["sha256"] != args.package:
        raise ValueError("The dataset manifest does not match the active task")
    target = args.out/NAME
    if not target.exists():
        interim = target.with_suffix(".part")
        if not interim.exists() or interim.stat().st_size!=info["bytes"]:
            request(endpoint+"/"+NAME,interim,args.interface,180,offset=True)
        if interim.stat().st_size!=info["bytes"] or digest(interim)!=args.package:
            raise ValueError("The downloaded archive differs from the send record")
        interim.replace(target)
    if target.stat().st_size!=info["bytes"] or digest(target)!=args.package:
        raise ValueError("The saved archive differs from the send record")
    check(target,args.out/"images")


if __name__=="__main__":
    p = argparse.ArgumentParser(description=__doc__)
    for key in ("endpoint","interface","nonce","probe","manifest","package"):
        p.add_argument("--"+key,required=True)
    p.add_argument("--key-data",type=Path,required=True)
    p.add_argument("--out",type=Path,required=True)
    main(p.parse_args())
