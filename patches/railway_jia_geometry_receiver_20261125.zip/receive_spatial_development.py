"""Receive the development grids through the existing campus connection."""
import argparse
from hashlib import sha256
import hmac
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
from urllib.parse import urlsplit
from zipfile import ZipFile


DATA_NAME = "jia_spatial_development.zip"
STRATA_NAME = "jia_spatial_strata.zip"
REPORTED_ENDPOINT = r"peer=([^\s]+) local=([^\s]+) bytes=([0-9]+)"


def access_token(prior_pack, nonce):
    with prior_pack.open("rb") as stream:
        stream.seek(262_144)
        seed = stream.read(65_536)
    if len(seed) != 65_536:
        raise ValueError("The previously verified railway training file is required")
    return hmac.new(sha256(seed).digest(), b"railway-spatial-v1:" + nonce.encode("ascii"), "sha256").hexdigest()


def digest(path):
    value = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def request(url, target, interface, timeout, offset=False):
    curl = ["curl", "--fail", "--silent", "--show-error", "--noproxy", "*", "--interface", interface,
            "--connect-timeout", "8", "--max-time", str(timeout), "--output", str(target),
            "--write-out", "peer=%{remote_ip} local=%{local_ip} bytes=%{size_download}"]
    if offset and target.exists():
        curl.extend(["--continue-at", "-"])
    reply = subprocess.run([*curl, url], check=True, text=True, capture_output=True, timeout=timeout+3)
    match = re.fullmatch(REPORTED_ENDPOINT, reply.stdout.strip())
    if not match or match[1] != urlsplit(url).hostname or match[2] != interface:
        raise RuntimeError("The request did not report the assigned campus source and destination")
    print(target.name, reply.stdout.strip(), flush=True)
    return int(match[3])


def extract_verified(archive, out, *, strata=False):
    with ZipFile(archive) as bundle:
        root = "strata_manifest.json" if strata else "bundle_manifest.json"
        manifest = json.loads(bundle.read(root))
        entries = manifest["members"]
        assert set(bundle.namelist()) == {root, *entries.keys()}
        for key in entries:
            name = PurePosixPath(key)
            frame = r"[A-Z]{2}_\d{4}-\d{2}-\d{2}(?:_box\d+)?\.npz"
            allowed = (rf"r3_2023[ab]/val/{frame}" if strata else
                       rf"r3_2023[ab]/(train|val)/(index\.json|{frame})")
            if not re.fullmatch(allowed, name.as_posix()):
                raise ValueError(f"Unexpected archive member: {key}")
            target = out.joinpath(*name.parts) if not strata else out / "semantic_strata" / name.parts[0] / name.name
            target.parent.mkdir(exist_ok=True, parents=True)
            record = entries[key]
            if target.is_file() and target.stat().st_size == record["bytes"] and digest(target) == record["sha256"]:
                continue
            if target.exists():
                raise FileExistsError(f"Different existing data retained at {target}")
            buf = bundle.read(key)
            assert len(buf) == record["bytes"] and sha256(buf).hexdigest() == record["sha256"]
            temp = target.with_suffix(".part")
            temp.write_bytes(buf)
            temp.replace(target)
        (out / root).write_bytes(bundle.read(root))
    print("verified_members", len(entries), "strata" if strata else "grids", flush=True)


def main(args):
    args.out.mkdir(exist_ok=True, parents=True)
    root = f"http://{args.address}:{args.port}/{access_token(args.prior_pack, args.nonce)}"
    probe = args.out / "route_probe.bin"
    assert request(f"{root}/route_probe.bin", probe, args.interface, 18) == 4096
    assert probe.stat().st_size == 4096 and digest(probe) == args.probe
    manifest = args.out / "transfer_manifest.json"
    request(f"{root}/manifest.json", manifest, args.interface, 18)
    assert digest(manifest) == args.manifest
    items = json.loads(manifest.read_text(encoding="utf-8"))["assets"]
    assert set(items) == {"route_probe.bin", DATA_NAME, STRATA_NAME}
    for name in (DATA_NAME, STRATA_NAME):
        spec = items[name]
        assert 0 < spec["bytes"] < 4_000_000_000
        target = args.out / name
        staging = target.with_suffix(".part")
        if not target.exists():
            if not staging.exists() or staging.stat().st_size != spec["bytes"]:
                request(f"{root}/{name}", staging, args.interface, 1600, offset=True)
            assert staging.stat().st_size == spec["bytes"] and digest(staging) == spec["sha256"]
            staging.replace(target)
        assert target.stat().st_size == spec["bytes"] and digest(target) == spec["sha256"]
        extract_verified(target, args.out, strata=name == STRATA_NAME)
    print("Railway two-fold spatial development data ready", args.out, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--address", required=True)
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--interface", required=True)
    parser.add_argument("--nonce", required=True)
    parser.add_argument("--prior-pack", type=Path, required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--probe", required=True)
    parser.add_argument("--out", type=Path, default=Path("rail-spatial-development"))
    main(parser.parse_args())
