"""Portable CUDA experiments for asymmetric auxiliary corrections on railway data."""
import argparse
import itertools
import json
import os
from pathlib import Path
import time

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F


ARMS = {
    "optical_context": ((), "both"),
    "dem_suppress": (("terrain",), "negative"),
    "dem_shift_suppress": (("wrong_terrain",), "negative"),
    "dem_bidirectional": (("terrain",), "both"),
    "s1_confirm": (("sar",), "positive"),
    "s1_confirm_history": (("sar", "sar_history"), "positive"),
    "s1_refute": (("sar", "sar_history"), "negative"),
    "s1_quality_both": (("sar", "sar_history"), "both"),
    "coherence_confirm": (("coherence",), "positive"),
    "joint_asymmetric": (("terrain", "sar", "sar_history", "coherence"), "split"),
    "s1_no_quality_weight": (("sar", "sar_history"), "positive"),
    "dem_hydro_suppress": (("terrain",), "negative"),
}
GROUPS = {
    "local": ("optical_context", "dem_suppress", "dem_shift_suppress", "s1_confirm", "s1_confirm_history", "joint_asymmetric"),
    "jia": ("optical_context", "s1_confirm", "s1_no_quality_weight", "s1_confirm_history", "s1_refute",
            "s1_quality_both", "coherence_confirm"),
    "yi": ("optical_context", "dem_suppress", "dem_shift_suppress", "dem_bidirectional", "dem_hydro_suppress", "joint_asymmetric"),
    "cloud": tuple(ARMS),
    "all": tuple(ARMS),
}


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path, value):
    temporary = path.with_suffix(".pending")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def indices(bands):
    start, groups = 0, {}
    for key, widths in bands.items():
        groups[key] = slice(start, start + widths)
        start += widths
    return groups


def mean_scale(x):
    known = np.isfinite(x)
    n = known.sum(axis=0).clip(1)
    zero = np.where(known, x, 0)
    m = zero.sum(axis=0, dtype=np.float64) / n
    sq = np.square(np.where(known, x - m, 0)).sum(axis=0) / n
    return m.astype(np.float32), np.sqrt(sq).clip(.02).astype(np.float32)


class Adapter(nn.Module):
    def __init__(self, arm, groups, magnitude):
        super().__init__()
        self.arm, self.groups, self.magnitude = arm, groups, magnitude
        self.sources, self.mode = ARMS[arm]
        self.channels = {k: kk.stop - kk.start for k, kk in groups.items()}
        self.terrain_name = "terrain" if "terrain" in self.sources else "wrong_terrain"
        self.project = nn.Sequential(nn.Linear(52, 36), nn.LayerNorm(36), nn.SiLU())
        self.evidence = nn.ModuleDict({})
        for key in ("terrain", "sar", "coherence"):
            selectors = self.selected_channels(key)
            if selectors:
                width = sum(self.channels[s] for s in selectors)
                self.evidence[key] = self.head(width + 36)
        if not self.sources:
            self.evidence["optical"] = self.head(36)

    @staticmethod
    def head(width):
        seq = nn.Sequential(nn.Linear(width, 28), nn.SiLU(), nn.Linear(28, 1))
        nn.init.normal_(seq[-1].weight, std=.008)
        nn.init.zeros_(seq[-1].bias)
        return seq

    def selected_channels(self, key):
        if key == "terrain":
            return (self.terrain_name,) if self.terrain_name in self.sources else ()
        if key == "sar":
            return tuple(k for k in ("sar", "sar_history") if k in self.sources)
        return (key,) if key in self.sources else ()

    def forward(self, x, q, anchor):
        logit = torch.logit(anchor.clamp(.001, .999))
        context = self.project(torch.cat((x[:, :51], anchor[:, None]), dim=1))
        soft_near = torch.exp(-((anchor - .5) / .24).square())
        direction = {"positive": 1, "negative": -1, "both": 0}
        deltas = []
        for key, net in self.evidence.items():
            gate = torch.ones_like(anchor)
            evidence = [context]
            for group in self.selected_channels(key):
                data = x[:, self.groups[group]]
                if group == "sar_history":
                    data = data * q[:, 1:2]
                if group in ("terrain", "wrong_terrain") and self.arm != "dem_hydro_suppress":
                    data = torch.cat((data[:, 1:8], torch.zeros_like(data[:, :3])), dim=1)
                evidence.append(data)
            if key == "sar":
                gate = q[:, 0]
                if self.arm != "s1_no_quality_weight":
                    gate = gate * q[:, 3].clamp(.1, 1)
            elif key == "coherence":
                gate = q[:, 2] * q[:, 4].clamp(.1, 1)
            elif key == "terrain" and self.mode in ("negative", "split"):
                gate = .25 + .75 * q[:, 6].clamp(0, 1)
            d = net(torch.cat(evidence, dim=1)).squeeze(1)
            sign = (-1 if key == "terrain" else 1) if self.mode == "split" else direction[self.mode]
            bounded = torch.tanh(d) if sign == 0 else sign * torch.tanh(F.softplus(d - 2.6))
            deltas.append(bounded * gate)
        return logit + self.magnitude * soft_near * torch.stack(deltas).sum(dim=0)


def load_pack(path, role, groups, norm=None, device="cuda"):
    with np.load(path / f"{role}.npz") as z:
        arrays = {k: z[k] for k in z.files}
    x = arrays["x"].astype(np.float32)
    if norm is None:
        norm = mean_scale(x)
    normalized = np.nan_to_num(((x - norm[0]) / norm[1]).clip(-8, 8))
    q = np.nan_to_num(x[:, groups["quality"]].copy()).astype(np.float32)
    tensors = (
        torch.as_tensor(normalized, device=device), torch.as_tensor(q, device=device),
        torch.as_tensor(arrays["anchor"].astype(np.float32), device=device),
        torch.as_tensor(arrays["y"].astype(np.float32), device=device),
    )
    return tensors, arrays, norm


def evaluate(probability, arrays, labels):
    y = arrays["y"]
    p = probability >= .5
    flags = arrays["flags"]
    scene = arrays["scene"]
    positives = (y == 1)
    negatives = (y == 0)
    size = len(arrays["outside"])
    output = {"strata": {}}
    bins = (probability.clip(0, 1) * 1023).astype(np.int32)
    for i, key in enumerate(labels):
        mask = (flags & (1 << i)) != 0
        tp = int((p & positives & mask).sum())
        fp = int((p & negatives & mask).sum())
        npos = int((positives & mask).sum() + arrays["outside"][:, i].sum())
        nneg = int(arrays["negatives"][:, i].sum())
        hist_p = np.bincount(bins[positives & mask], minlength=1024)
        hist_n = np.bincount(bins[negatives & mask], minlength=1024)
        hist_p[0] += int(arrays["outside"][:, i].sum())
        hist_n[0] += max(nneg - int((negatives & mask).sum()), 0)
        cp, cn = np.cumsum(hist_p[::-1]), np.cumsum(hist_n[::-1])
        m = metric(tp, fp, npos - tp, nneg)
        m["ap"] = float(np.dot(cp / np.maximum(cp + cn, 1), hist_p[::-1]) / npos) if npos else None
        if key == "small_change":
            m["f1"] = m["precision"] = m["fp_per_10000"] = m["ap"] = None
        output["strata"][key] = m
    columns = [np.bincount(scene[sel], minlength=size) for sel in (positives & p, negatives & p, positives & ~p)]
    columns[2] += arrays["outside"][:, 0]
    output["scene_counts"] = np.stack(columns, axis=1).tolist()
    return output


def metric(tp, fp, fn, nneg):
    npos = tp + fn
    return {"tp": tp, "fp": fp, "fn": fn, "positive": npos, "negative": nneg,
            "f1": 2 * tp / max(2 * tp + fp + fn, 1) if npos else None,
            "recall": tp / npos if npos else None, "precision": tp / (tp + fp) if tp + fp else None,
            "fp_per_10000": 10000 * fp / nneg if nneg else None}


@torch.inference_mode()
def infer(model, data):
    parts = [torch.sigmoid(model(x, q, a)).float().cpu().numpy()
             for x, q, a in zip(*(tensor.split(8192) for tensor in data[:3]))]
    assert parts
    return np.concatenate(parts)


def fit(arm, seed, groups, train, out, epochs, magnitude, status, info):
    torch.manual_seed(seed)
    model = Adapter(arm, groups, magnitude).cuda()
    optimizer = torch.optim.AdamW(model.parameters(), lr=.0017, weight_decay=.01)
    save = out.with_name(out.name + ".pt")
    x, q, a, y = train
    positive_weight = ((len(y) - y.sum()) / y.sum().clamp_min(1.)).pow(.3).clamp(1, 6)
    initial_epoch = 0
    history = []
    steps = 0
    if save.exists():
        ckpt = torch.load(save, map_location="cuda", weights_only=True)
        assert ckpt["epochs"] == epochs and ckpt["magnitude"] == magnitude and ckpt["arm"] == arm
        model.load_state_dict(ckpt["model"])
        optimizer.load_state_dict(ckpt["optimizer"])
        initial_epoch, history, steps = ckpt["epoch"], ckpt["history"], ckpt["steps"]
    for epoch in range(initial_epoch, epochs):
        torch.manual_seed(seed + 7919 * epoch)
        model.train()
        total = torch.zeros((), device="cuda")
        for n in torch.randperm(len(y), device="cuda").split(4096):
            optimizer.zero_grad(set_to_none=True)
            anchor = a[n]
            reference = torch.logit(anchor.clamp(.001, .999))
            output = model(x[n], q[n], anchor)
            priority = .45 + .55 * torch.exp(-((anchor - .5) / .29).square())
            loss = (F.binary_cross_entropy_with_logits(output,y[n],pos_weight=positive_weight,reduction="none") * priority).mean()
            loss = loss + .06 * (output - reference).square().mean()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 2.)
            optimizer.step()
            total += loss.detach() * len(n)
            steps += 1
        value = float(total.item() / len(y))
        if not np.isfinite(value):
            raise RuntimeError(f"Nonfinite objective in {arm}, epoch {epoch + 1}")
        history.append(value)
        write(status, {**info, "arm": arm, "epoch": epoch+1, "expected_epochs": epochs,
                       "optimizer_steps": steps, "loss": value, "updated_unix": time.time()})
        if (epoch + 1) % 3 == 0 or epoch + 1 == epochs:
            temp = save.with_suffix(".partial")
            torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(), "epoch": epoch+1,
                        "history": history, "steps": steps, "epochs": epochs, "magnitude": magnitude, "arm": arm}, temp)
            temp.replace(save)
    return model.eval(), history, steps


def summarize(out, folds):
    jobs = {}
    for path in sorted(out.glob("*.metrics.json")):
        r = read(path)
        jobs.setdefault((r["arm"],r["seed"],r["epochs"],r["magnitude"]), {})[r["fold"]] = r
    rows = []
    for (name, seed, epochs, magnitude), by_fold in jobs.items():
        if set(by_fold) != set(folds):
            continue
        primary = [r["strata"]["all"] for r in by_fold.values()]
        metrics = metric(*(sum(r[k] for r in primary) for k in ("tp", "fp", "fn", "negative")))
        macro = np.mean([r["f1"] for r in primary if r["f1"] is not None])
        rows.append({"arm": name,"seed": seed,"epochs": epochs,"magnitude": magnitude,
                     "micro": metrics,"mean_fold_f1": float(macro),"rank": .5 * (metrics["f1"] + macro)})
    ranks = sorted(rows,key=lambda r:r["rank"],reverse=True)
    write(out / "validation_summary.json", {"folds":list(folds),"completed_fits":sum(len(x) for x in jobs.values()), "ranked":ranks})
    return ranks


def main(args):
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable")
    torch.set_num_threads(2)
    torch.set_float32_matmul_precision("high")
    torch.cuda.set_per_process_memory_fraction(.2)
    schema = read(args.data / "schema.json")
    groups = indices(schema["bands"])
    folds = tuple(schema["development_folds"])
    args.output.mkdir(parents=True, exist_ok=True)
    jobs = tuple(dict.fromkeys(args.arms or GROUPS[args.group]))
    status = args.output / "latest.json"
    print("CUDA", torch.cuda.get_device_name(0), "group", args.group, "jobs", jobs, flush=True)

    def batch(arms, seeds, epochs, magnitude):
        for fold in folds:
            train, _, norm = load_pack(args.data,fold+"_train",groups)
            valid, val_arrays, _ = load_pack(args.data,fold+"_val",groups,norm)
            if args.qualified_fit:
                used = train[1][:, 0] > .5
                train = tuple(tensor[used] for tensor in train)
                assert train[-1].sum() > 0 and len(train[-1]) > 100
            reference = args.output / f"{fold}_archive.metrics.json"
            if not reference.exists():
                write(reference, {"fold": fold,"arm":"archive","seed":0,"epochs":0,"magnitude":0.,
                                  **evaluate(val_arrays["anchor"].astype(np.float32), val_arrays, schema["strata"])})
            for arm, seed in itertools.product(arms, seeds):
                base = args.output / f"{fold}_{arm}_s{seed}_e{epochs}_m{magnitude:.2f}"
                result = base.with_name(base.name+".metrics.json")
                if result.exists():
                    continue
                info = {"phase":"training", "pid":os.getpid(),"fold":fold,"seed":seed}
                start = time.monotonic()
                model, loss, steps = fit(arm,seed,groups,train,base,epochs,magnitude,status,info)
                probability = infer(model,valid)
                if args.qualified_fit:
                    available = (val_arrays["flags"] & (1 << schema["strata"].index("same_track"))) != 0
                    probability = np.where(available,probability,val_arrays["anchor"].astype(np.float32))
                score = evaluate(probability, val_arrays, schema["strata"])
                write(result, {"arm":arm,"fold":fold,"seed":seed,"epochs":epochs,"magnitude":magnitude,
                               "qualified_fit":args.qualified_fit,"optimizer_steps":steps,"training_loss":loss,
                               "seconds":time.monotonic()-start,**score})
                summarize(args.output, folds)
                print(fold, arm, seed, epochs, score["strata"]["all"], flush=True)
                del model
            del train, valid

    batch(jobs, [args.seed], args.epochs, args.magnitude)
    if args.refine:
        rankings = summarize(args.output, folds)
        top = [r["arm"] for r in rankings if r["arm"] in jobs and r["arm"] != "optical_context"
               and r["seed"] == args.seed and r["epochs"] == args.epochs][:3]
        follow = ["optical_context", *top]
        write(args.output/"validation_followups.json",{"rule":"top three fusion arms on two development folds only",
                    "arms":follow,"epochs":args.epochs * 2,"seeds":[17,73],"magnitudes":[.7,2.5]})
        for magnitude in (.7,2.5):
            batch(follow,[17,73],args.epochs * 2,magnitude)
    ranks = summarize(args.output, folds)
    write(status, {"phase":"complete","pid":os.getpid(),"updated_unix":time.time(),"groups":len(ranks)})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--group",choices=tuple(GROUPS),default="local")
    parser.add_argument("--arms", choices=tuple(ARMS), nargs="+")
    parser.add_argument("--epochs", default=14, type=int)
    parser.add_argument("--seed", default=17, type=int)
    parser.add_argument("--magnitude", default=1.6, type=float)
    parser.add_argument("--refine", action="store_true")
    parser.add_argument("--qualified-fit", action="store_true")
    main(parser.parse_args())
