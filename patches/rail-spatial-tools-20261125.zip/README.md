# 甲组铁路候选外补漏

本轮使用原 A255 两个开发折的完整像元网格。训练和验证均包含候选内外的光学、同轨 S1、地形、归档分数、逐像元标签及场景和事件索引。另附按 C23 正确流程生成的验证地类分层位掩码。

## 校内接收

复用已收齐的原铁路开发文件和物理网卡。接收脚本先验证固定校内接口、4 KiB 探针、传输清单及两个文件的 SHA256，再验证归档成员、解包。

    python -u receive_spatial_development.py --address 10.102.21.27 --port 41990 --interface 10.102.21.82 --nonce 321b0cf13cca42a48a81ad7bec285828 --prior-pack /home/user/work_st3d/rail_multisource_ops_1125/rail-development/r3_2023a_train.npz --manifest 82de9f8cb5b7f82f89fa0957d832f4c4f47bf794f9e0a4465147b4b6c268e9bd --probe 662bc245fa337eb5f94d88e5e7043875e26e4027b7fd4ebed58aa6edfc6f881c --out rail-spatial-development

## 训练和预算评估

直接运行新种子 73 的两折空间光学和 S1 候选外分支，并固定归档的候选内判定。

    python -u spatial_worker.py --data rail-spatial-development --output rail-jia-outer-s73 --seed 73 --epochs 16 --steps 80 --arms optical_context radar_rescue

    python -u independent_candidate_replay.py --data rail-spatial-development --run rail-jia-outer-s73 --seed 73 --output rail-jia-outer-s73/independent_candidate_budget.json

两折开发验证合计 67 个候选外变化像元和 2,082,170 个候选外背景像元，其中 14 个候选外变化像元有合格同轨 S1。用真实 S1、同景错位和共享支持条件匹配的光学对照，分别回报原有误报预算及额外 4、10、25 个误报像元下的新增检中，连同逐事件留出检验。首次回执带本轮任务号、两个接收哈希校验、实际 PID 和优化步数。完成后回传验证 JSON、逐场景结果、预算对照和日志目录。
