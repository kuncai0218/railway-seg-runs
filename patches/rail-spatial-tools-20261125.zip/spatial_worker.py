"""Test whether qualified evidence verifies or independently proposes spatial changes."""
import argparse
from functools import lru_cache
import json
import os
from pathlib import Path
import time

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from fusion_worker import metric, read, write


FOLDS = ("r3_2023a", "r3_2023b")
ARMS = ("optical_context", "terrain_geometry", "terrain_wrong", "terrain_corrected", "radar_verify",
        "radar_rescue", "terrain_and_radar")
THRESHOLDS = (.40, .50, .60, .70, .80, .85, .90, .93, .96, .98, .99, 1.01)
STRATA = ("all", "same_track", "no_s1", "steep", "illumination", "cloud_or_missing", "candidate", "outside")


def block(a, b):
    return nn.Sequential(nn.Conv2d(a,b,3,padding=1),nn.GroupNorm(4,b),nn.SiLU(),
                         nn.Conv2d(b,b,3,padding=1),nn.GroupNorm(4,b),nn.SiLU())


class Spatial(nn.Module):
    def __init__(self, arm):
        super().__init__()
        self.arm=arm
        self.optical=block(15,24)
        self.low=block(24,32)
        self.restore=block(56,24)
        self.inner_opt=nn.Conv2d(24,1,1)
        self.outer_opt=nn.Conv2d(24,1,1)
        self.terrain=block(10,12)
        self.radar=block(12,12)
        self.inner_dem=nn.Sequential(block(36,16),nn.Conv2d(16,1,1))
        self.inner_sar=nn.Sequential(block(36,16),nn.Conv2d(16,1,1))
        self.outer_sar=nn.Sequential(block(36,16),nn.Conv2d(16,1,1))
        for layer in (self.inner_opt,self.outer_opt,self.inner_dem[-1],self.inner_sar[-1],self.outer_sar[-1]):
            nn.init.zeros_(layer.weight)
            nn.init.zeros_(layer.bias)
        nn.init.constant_(self.outer_opt.bias,-5)
        nn.init.constant_(self.outer_sar[-1].bias,-5)

    def freeze_optical(self, state):
        self.load_state_dict(state,strict=True)
        for net in (self.optical,self.low,self.restore,self.inner_opt,self.outer_opt):
            net.requires_grad_(False)

    def forward(self, data):
        arm=self.arm
        visible,corrected,terrain,wrong,radar,available,anchor,candidate=data
        optical=corrected if arm=="terrain_corrected" else visible
        opt=self.optical(torch.cat((optical,anchor,candidate),dim=1))
        dec=self.low(F.avg_pool2d(opt,2))
        hidden=self.restore(torch.cat((F.interpolate(dec,size=opt.shape[-2:],mode="nearest"),opt),dim=1))
        orig=torch.logit(anchor.clamp(.001,.999))
        near=torch.exp(-((anchor-.5)/.30).square())
        inner=orig+1.7*near*torch.tanh(self.inner_opt(hidden))
        outer=self.outer_opt(hidden)
        extra=torch.full_like(outer,-18)
        if arm in ("terrain_geometry","terrain_wrong","terrain_corrected","terrain_and_radar"):
            ground=wrong if arm=="terrain_wrong" else terrain
            geom=self.terrain(ground)
            # Bounded correction to the existing decision. Separate from radar's new proposals.
            inner=inner + 1.1*near*torch.tanh(self.inner_dem(torch.cat((hidden,geom),dim=1)))
        if arm in ("radar_verify","radar_rescue","terrain_and_radar"):
            microwave=self.radar(radar * available)
            evidence=torch.cat((hidden,microwave),dim=1)
            reliability=available*(.25+.75*radar[:,10:11].clamp(0,1))
            inner=inner + 1.6*near*reliability*torch.tanh(self.inner_sar(evidence))
            if arm!="radar_verify":
                extra=torch.where(available>.5,self.outer_sar(evidence),extra)
        return inner.float(),outer.float(),extra.float()


class Samples:
    def __init__(self, path):
        self.path=path
        self.rows=read(path/"index.json")
        self.events={}
        for i,row in enumerate(self.rows):
            with np.load(self.path/row["file"]) as z:
                y=z["y"]
            hit=np.argwhere(y==1)
            if len(hit): self.events[i]=hit

    @lru_cache(maxsize=96)
    def entry(self, i):
        with np.load(self.path/self.rows[i]["file"]) as z:
            keys=("opt","fixed","dem","wrong","s1","s1_valid","anchor","candidate","y")
            return tuple(z[k] if z[k].ndim==3 else z[k][None] for k in keys)

    def batch(self,rng,amount,side):
        events=tuple(self.events)
        if not events:
            raise RuntimeError("No A255 positive pixels in training fold")
        slices=[]
        for i in range(amount):
            if i%2==0:
                key=int(rng.choice(events))
                pool=self.events[key]
                center=pool[int(rng.integers(len(pool)))]
                offsets=rng.integers(side//4,side*3//4,size=2)
                a,b=np.clip(center-offsets,0,256-side)
            else:
                key=int(rng.integers(len(self.rows)))
                a,b=rng.integers(0,257-side,size=2)
            slices.append(tuple(v[:,a:a+side,b:b+side] for v in self.entry(key)))
        return to_cuda(tuple(np.stack(items) for items in zip(*slices)))


def to_cuda(items):
    return tuple(torch.as_tensor(x,device="cuda",dtype=torch.float32).contiguous(memory_format=torch.channels_last) for x in items)


def weighted_bce(logits,y,mask,boost=2.4):
    val=F.binary_cross_entropy_with_logits(logits,y,reduction="none")
    w=mask*((boost-1)*y+1)
    return (val*w).sum()/w.sum().clamp_min(1)


def fit(arm,train,path,epochs,steps,seed,optical,latest):
    torch.manual_seed(seed)
    model=Spatial(arm).to(device="cuda",memory_format=torch.channels_last)
    if optical is not None:
        model.freeze_optical(optical)
    optimizer=torch.optim.AdamW((p for p in model.parameters() if p.requires_grad),lr=.0008,weight_decay=.01)
    scaler=torch.amp.GradScaler("cuda")
    start_epoch, history=0,[]
    if path.exists():
        ckpt=torch.load(path,map_location="cuda",weights_only=True)
        assert ckpt['arm']==arm and ckpt['epochs']==epochs and ckpt['seed']==seed
        start_epoch, history=ckpt['last_epoch'],ckpt['losses']
        model.load_state_dict(ckpt['model'])
        optimizer.load_state_dict(ckpt['opt'])
        scaler.load_state_dict(ckpt['scaler'])
    for epoch in range(start_epoch,epochs):
        rng=np.random.default_rng(seed+8729*epoch)
        model.train()
        value=torch.zeros((),device="cuda")
        for _ in range(steps):
            *data, y=train.batch(rng,12,96)
            valid=(y<2).float()
            target=(y==1).float()
            candidate=data[-1]
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast("cuda",dtype=torch.float16):
                inner,outer,extra=model(data)
            loss=weighted_bce(inner,target,valid*candidate)
            if arm=="optical_context":
                loss=loss+.7*weighted_bce(outer,target,valid*(1-candidate),boost=5.)
            if arm in ("radar_rescue","terrain_and_radar"):
                loss=loss+.7*weighted_bce(extra,target,valid*(1-candidate)*data[5],boost=5.)
            if arm!="optical_context":
                anchor=torch.logit(data[-2].clamp(.001,.999))
                loss=loss+.02*((inner-anchor).square()*candidate).mean()
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            value+=loss.detach()
        loss=float(value.item()/steps)
        if not np.isfinite(loss): raise RuntimeError(f"Non-finite {arm} epoch {epoch+1}")
        history.append(loss)
        progress=dict(phase="training",job=path.stem,arm=arm,pid=os.getpid(),epoch=epoch+1,
                      optimizer_steps=(epoch+1)*steps,expected_epochs=epochs,loss=loss,updated_unix=time.time())
        write(latest,progress)
        if (epoch+1)%2==0 or epoch+1==epochs:
            temp=path.with_suffix(".partial")
            torch.save(dict(model=model.state_dict(),opt=optimizer.state_dict(),scaler=scaler.state_dict(),
                            arm=arm,seed=seed,epochs=epochs,last_epoch=epoch+1,losses=history),temp)
            temp.replace(path)
        print(path.stem,epoch+1,round(loss,5),flush=True)
    return model.eval()


@torch.inference_mode()
def evaluate(model,pack):
    out=np.zeros((len(THRESHOLDS),len(STRATA),4),np.int64)
    archive=np.zeros((len(STRATA),4),np.int64)
    case=[]
    for i,e in enumerate(pack.rows):
        *data, y=pack.entry(i)
        m=tuple(d[0] if d.shape[0]==1 else d for d in data)
        opt,_,dem,_,_,available,anchor,candidate=m
        y=y[0]
        with torch.autocast("cuda",dtype=torch.float16):
            scores=model(to_cuda(tuple(d[None] for d in data)))
        inner,outer,extra=[torch.sigmoid(t)[0,0].cpu().numpy() for t in scores]
        h=anchor>=.5
        truth=y==1
        background=y==0
        candidate=candidate.astype(bool)
        eligible=bool(available.any())
        flags=(np.ones_like(h),np.full_like(h,eligible),np.full_like(h,not eligible),dem[1]*45>=10,
               np.abs(dem[7])>=.15,opt[-1]<.5,candidate,~candidate)
        this=np.zeros_like(out)
        base_inner=(inner>=.5)&candidate
        proposal=np.maximum(outer,extra)
        for j,(mask,name) in enumerate(zip(flags,STRATA)):
            p=truth&mask
            n=background&mask
            npos,nneg=int(p.sum()),int(n.sum())
            archive[j]+=((p&h).sum(),(n&h).sum(),(p&~h).sum(),nneg)
            for k,t in enumerate(THRESHOLDS):
                found=base_inner | ((proposal>=t)&~candidate)
                tp, fp=int((found&p).sum()),int((found&n).sum())
                this[k,j]=(tp,fp,npos-tp,nneg)
        case.append({**e,"qualified":eligible,"counts":this[:,0].tolist()})
        out+=this
    values=[[metric(*map(int,m)) for m in row] for row in out]
    return {"thresholds":list(THRESHOLDS),"strata":list(STRATA),"values":values,"raw":out.tolist(),
            "archive":[metric(*map(int,m)) for m in archive],"cases":case}


def ranking(out,folds):
    pool={}
    for f in sorted(out.glob('*.spatial.json')):
        item=read(f)
        pool.setdefault((item['arm'],item['seed']),{})[item['fold']]=item
    answer=[]
    for (arm,seed), entries in pool.items():
        if set(entries)!=set(folds):continue
        cm=np.sum([np.array(row['curve']['raw']) for row in entries.values()],axis=0)
        curve=[metric(*map(int,m[0])) for m in cm]
        ref=sum(row['curve']['archive'][0]['fp'] for row in entries.values())
        best=max(range(len(curve)), key=lambda i:curve[i]['f1'])
        budget=[i for i,v in enumerate(curve) if v['fp']<=ref]
        constrained=max(budget,key=lambda i:curve[i]['f1']) if budget else None
        measure=lambda i:{"threshold":THRESHOLDS[i],**dict(zip(STRATA,[metric(*map(int,x)) for x in cm[i]]))}
        answer.append({"arm":arm,"seed":seed,"reference_fp_budget":ref,"best_development":measure(best),
                       "archive_matched_fp_budget":measure(constrained) if constrained is not None else None,
                       "candidate_only":measure(len(curve)-1)})
    answer.sort(key=lambda k:k['best_development']['all']['f1'],reverse=True)
    write(out/'validation_summary.json',{"role":"development only","ranked":answer})


def main(args):
    print('initializing spatial worker',flush=True)
    torch.set_num_threads(2)
    torch.set_float32_matmul_precision('high')
    torch.cuda.set_per_process_memory_fraction(.36)
    assert torch.cuda.is_available()
    args.output.mkdir(parents=True,exist_ok=True)
    latest=args.output/'latest.json'
    print(torch.cuda.get_device_name(),args.arms,flush=True)
    for fold in args.folds:
        while not (args.data/fold/'train/index.json').exists():
            write(latest,{"phase":"preparing","fold":fold,"pid":os.getpid(),"updated_unix":time.time()})
            time.sleep(8)
        train=Samples(args.data/fold/'train')
        valid=None
        optical=None
        for arm in tuple(dict.fromkeys(("optical_context",*args.arms))):
            name=f'{fold}_{arm}_s{args.seed}'
            path=args.output/(name+'.pt')
            result=args.output/(name+'.spatial.json')
            if not result.exists():
                model=fit(arm,train,path,args.epochs,args.steps,args.seed,optical,latest)
                if valid is None:
                    while not (args.data/fold/'val/index.json').exists():
                        write(latest,{"phase":"waiting_for_validation","fold":fold,"pid":os.getpid(),"updated_unix":time.time()})
                        time.sleep(8)
                    valid=Samples(args.data/fold/'val')
                val=evaluate(model,valid)
                write(result,dict(arm=arm,fold=fold,seed=args.seed,curve=val))
                ranking(args.output,args.folds)
                del model
            if arm=="optical_context":
                optical=torch.load(path,map_location='cuda',weights_only=True)['model']
        train.entry.cache_clear()
    write(latest,{"phase":"complete","pid":os.getpid(),"updated_unix":time.time()})


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--data',type=Path,default=Path('spatial_data'))
    p.add_argument('--output',type=Path,default=Path('spatial'))
    p.add_argument('--seed',type=int,default=17)
    p.add_argument('--epochs',type=int,default=16)
    p.add_argument('--steps',type=int,default=80)
    p.add_argument('--arms',choices=ARMS,nargs='+',default=ARMS)
    p.add_argument('--folds',choices=FOLDS,nargs='+',default=FOLDS)
    main(p.parse_args())
