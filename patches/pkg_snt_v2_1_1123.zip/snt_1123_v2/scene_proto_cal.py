# -*- coding: utf-8 -*-
"""Module 2 (v2): End-to-End Learnable K-Class Scene-Prototype Cross-Attention Calibration (SCPC)
+ Support Reliability Gate + Anti-Shortcut Scene-Consistent Radiometric Augmentation.
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class SceneConsistentRadiometricAug(nn.Module):
    """Physically faithful scene-consistent radiometric augmentation (v2.1).

    Real cross-region atmospheric / illumination shifts are primarily correlated across
    bands (global gain + haze offset) plus small per-band calibration residuals.
    Keeping per-band residuals small preserves spectral band ratios (e.g. NIR-G / NIR-R)
    so water and vegetation remain physically separable during from-scratch training.
    """

    def __init__(
        self,
        prob: float = 0.5,
        shared_gain_std: float = 0.08,
        band_gain_std: float = 0.03,
        shared_offset_std: float = 0.08,
        band_offset_std: float = 0.03,
        frame_jitter: float = 0.015,
    ):
        super().__init__()
        self.prob = prob
        self.shared_gain_std = shared_gain_std
        self.band_gain_std = band_gain_std
        self.shared_offset_std = shared_offset_std
        self.band_offset_std = band_offset_std
        self.frame_jitter = frame_jitter

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if (not self.training) or self.prob <= 0.0:
            return x
        B, T, C, H, W = x.shape
        apply = (torch.rand(B, 1, 1, 1, 1, device=x.device) < self.prob).to(x.dtype)
        sg = torch.randn(B, 1, 1, 1, 1, device=x.device, dtype=x.dtype).clamp(-2.0, 2.0) * self.shared_gain_std
        bg = torch.randn(B, 1, C, 1, 1, device=x.device, dtype=x.dtype).clamp(-2.0, 2.0) * self.band_gain_std
        gain = torch.exp(sg + bg)
        so = torch.randn(B, 1, 1, 1, 1, device=x.device, dtype=x.dtype).clamp(-2.0, 2.0) * self.shared_offset_std
        bo = torch.randn(B, 1, C, 1, 1, device=x.device, dtype=x.dtype).clamp(-2.0, 2.0) * self.band_offset_std
        jitter = torch.randn(B, T, 1, 1, 1, device=x.device, dtype=x.dtype).clamp(-2.0, 2.0) * self.frame_jitter
        x_aug = x * gain + (so + bo) + jitter
        return x * (1.0 - apply) + x_aug * apply


class SceneProtoCalibrator(nn.Module):
    def __init__(
        self,
        in_channels: int,
        c_s0: int,
        num_classes: int,
        d_proto: int = 32,
        grid_size: int = 4,
        tau_max: float = 1.0,
        causal: bool = False,
    ):
        super().__init__()
        self.C = in_channels
        self.c_s0 = c_s0
        self.K = num_classes
        self.d_proto = d_proto
        self.grid_size = grid_size
        self.tau_max = tau_max
        self.causal = causal

        raw_dim = in_channels + c_s0
        self.tok_norm = nn.LayerNorm(raw_dim)
        self.key_proj = nn.Linear(raw_dim, d_proto)
        self.val_proj = nn.Linear(raw_dim, d_proto)

        self.class_queries = nn.Parameter(torch.randn(num_classes, d_proto) * 0.08)
        self.source_protos = nn.Parameter(torch.zeros(num_classes, d_proto))
        self.log_temp = nn.Parameter(torch.tensor(math.log(math.sqrt(d_proto))))

        self.rely_gate = nn.Sequential(
            nn.Linear(3, 16),
            nn.GELU(),
            nn.Linear(16, 1),
        )
        nn.init.zeros_(self.rely_gate[-1].weight)
        nn.init.constant_(self.rely_gate[-1].bias, 0.5)

        self.cal_mlp = nn.Sequential(
            nn.Linear(3 * d_proto + 3, 32),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(32, 1, bias=False),
        )
        self.cls_bias = nn.Parameter(torch.zeros(num_classes))
        nn.init.zeros_(self.cal_mlp[-1].weight)

    def extract_raw_tokens(self, x: torch.Tensor, s0: torch.Tensor) -> torch.Tensor:
        B, T, _, H, W = x.shape
        G = self.grid_size
        feat = torch.cat([x, s0], dim=2).flatten(0, 1)
        pooled = F.adaptive_avg_pool2d(feat, (G, G))
        return pooled.flatten(2).transpose(1, 2).view(B, T, G * G, self.C + self.c_s0)

    def _attend(self, raw_tokens: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        B, M, _ = raw_tokens.shape
        tn = self.tok_norm(raw_tokens)
        keys = self.key_proj(tn)
        vals = self.val_proj(tn)

        temp = self.log_temp.exp().clamp(1.0, 20.0)
        scores = torch.einsum("kd,bmd->bkm", self.class_queries, keys) / temp
        attn = F.softmax(scores, dim=-1)

        p_scene = torch.einsum("bkm,bmd->bkd", attn, vals)
        g_scene = vals.mean(dim=1, keepdim=True).expand(-1, self.K, -1)

        neff_ratio = (1.0 / (attn.pow(2).sum(dim=-1).clamp_min(1e-6) * float(M))).clamp(0.0, 1.0)
        peak_w = attn.max(dim=-1).values
        ent = -(attn * torch.log(attn.clamp_min(1e-7))).sum(dim=-1) / max(math.log(max(M, 2)), 1e-6)
        stats = torch.stack([neff_ratio, peak_w, ent], dim=-1)

        rely = torch.sigmoid(self.rely_gate(stats)).squeeze(-1)
        p_diff = p_scene - self.source_protos[None, :, :]
        q_exp = self.class_queries[None, :, :].expand(B, -1, -1)
        cal_in = torch.cat([p_diff * rely.unsqueeze(-1), g_scene, q_exp, stats], dim=-1)
        raw_dz = self.cal_mlp(cal_in).squeeze(-1) + self.cls_bias[None, :]
        raw_dz = raw_dz - raw_dz.mean(dim=-1, keepdim=True)
        delta_z = self.tau_max * torch.tanh(raw_dz)
        return delta_z, rely

    def forward(
        self,
        x: torch.Tensor,
        s0: torch.Tensor,
        u_ctx: torch.Tensor,
        scene_bank_tokens: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, dict]:
        B, T, K, H, W = u_ctx.shape
        tile_toks = self.extract_raw_tokens(x, s0)

        if self.causal:
            dz_list, rely_list = [], []
            for t in range(T):
                if scene_bank_tokens is not None and scene_bank_tokens.dim() == 4:
                    toks_t = scene_bank_tokens[:, : t + 1].flatten(1, 2)
                else:
                    toks_t = tile_toks[:, : t + 1].flatten(1, 2)
                dz_t, rely_t = self._attend(toks_t)
                dz_list.append(dz_t)
                rely_list.append(rely_t)
            delta_z = torch.stack(dz_list, dim=1)
            rely = torch.stack(rely_list, dim=1)
            u_cal = u_ctx + delta_z[:, :, :, None, None]
        else:
            if scene_bank_tokens is not None:
                toks = scene_bank_tokens if scene_bank_tokens.dim() == 3 else scene_bank_tokens.flatten(1, 2)
            else:
                toks = tile_toks.flatten(1, 2)
            delta_z, rely = self._attend(toks)
            u_cal = u_ctx + delta_z[:, None, :, None, None]

        return u_cal, {"delta_z": delta_z, "rely": rely}
