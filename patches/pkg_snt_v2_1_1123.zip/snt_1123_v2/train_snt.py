# -*- coding: utf-8 -*-
"""Unified cross-platform trainer & evaluator for SNTNet v2 (2026-11-23).

Key upgrades over v1:
  - --crf_weighted 1 (default ON) + --crf_chg_boost 2.5 (class- & change-trajectory-weighted CRF NLL!)
  - Strictly non-negative bounded endpoint weights (lambda_loc in (0, 0.5), ep_witness_scale > 0)
  - Separate --head_wd (default 1e-2) + --drop 0.15 to curb source-AOI overfitting on s0/s2
  - Tracks BOTH official best_miou AND diagnostic best_scs checkpoints (saves both!)
  - Logs scalar head telemetry (lambda_loc, stay_scale, ep_witness_scale) every epoch in epochs.json!
  - Official test set strictly LOCKED OFF unless --run_official_test is passed.
"""
import argparse
import hashlib
import json
import os
import random
import sys
import time
from datetime import datetime
from functools import lru_cache
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "2")
os.environ.setdefault("MKL_NUM_THREADS", "2")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
os.environ["TQDM_DISABLE"] = "1"

import numpy as np
import torch
import torch.nn.functional as F

SCRIPT_DIR = Path(__file__).resolve().parent


def resolve_paths(dataset: str):
    t34_dir = Path(os.environ.get("SNT_T34_DIR", r"D:\Railway_project\work\公开数据_1102\scripts\t34_1119"))
    here_dir = Path(
        os.environ.get(
            "SNT_HERE_DIR",
            r"D:\Railway_project\work\公开数据_1102\总账_1110\结果\原版基线与正式测试_1119\原版重训_1119",
        )
    )
    if not here_dir.exists() and (t34_dir / "upstream").exists():
        here_dir = t34_dir
    author_dir = Path(os.environ.get("ST3D_REPO", str(here_dir / "upstream")))

    if dataset == "planet":
        data_dir = Path(os.environ.get("T34_DATA", r"D:\sitsscd_data\DynamicEarthNet"))
        default_cache = (
            Path(os.environ["LOCALAPPDATA"]) / "Railway_ST3DUNet_1119" / "cache"
            if "LOCALAPPDATA" in os.environ
            else Path("/root/autodl-tmp/t34/data/cache_t34_planet")
        )
        cache_dir = Path(os.environ.get("T34_CACHE", str(default_cache)))
    else:
        data_dir = Path(os.environ.get("T34_MSI_DATA", r"D:\sitsscd_data\DynamicEarthNetMSI_t34"))
        default_cache = (
            Path(os.environ["LOCALAPPDATA"]) / "Railway_ST3DUNet_1119" / "cache_msi"
            if "LOCALAPPDATA" in os.environ
            else Path("/root/autodl-tmp/t34/cache_msi")
        )
        cache_dir = Path(os.environ.get("T34_MSI_CACHE", str(default_cache)))

    return t34_dir, here_dir, author_dir, data_dir, cache_dir


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def save_json(path: Path, obj) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    tmp.replace(path)


def save_ckpt(path: Path, obj) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, tmp)
    tmp.replace(path)


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


class RichSCDAccumulator:
    def __init__(self, num_classes: int = 6):
        self.K = num_classes
        self.reset()

    def reset(self):
        K = self.K
        self.cm = np.zeros((K, K), dtype=np.int64)
        self.sc_cm = np.zeros((K, K), dtype=np.int64)
        self.joint = np.zeros((K, K, K, K), dtype=np.int64)
        self.aba_gt = 0
        self.aba_exact = 0
        self.aaa_gt = 0
        self.aaa_aba_fp = 0
        self.per_aoi = {}

    def _update_counts(self, y: np.ndarray, p: np.ndarray):
        K = self.K
        valid = (y >= 0) & (y < K)
        cm = np.bincount(K * y[valid].astype(np.int32) + p[valid].astype(np.int32), minlength=K * K).reshape(K, K)

        a, b, u, v = y[:, :-1], y[:, 1:], p[:, :-1], p[:, 1:]
        good = valid[:, :-1] & valid[:, 1:]
        true = good & (a != b)
        sc_cm = np.bincount(K * b[true].astype(np.int32) + v[true].astype(np.int32), minlength=K * K).reshape(K, K)
        enc = ((a[good].astype(np.int32) * K + b[good].astype(np.int32)) * K + u[good].astype(np.int32)) * K + v[good].astype(np.int32)
        joint = np.bincount(enc, minlength=K**4).reshape(K, K, K, K)

        k3 = valid[:, :-2] & valid[:, 1:-1] & valid[:, 2:]
        gt_aba = k3 & (y[:, :-2] == y[:, 2:]) & (y[:, :-2] != y[:, 1:-1])
        gt_aaa = k3 & (y[:, :-2] == y[:, 1:-1]) & (y[:, 1:-1] == y[:, 2:])
        ex_aba = gt_aba & (p[:, :-2] == y[:, :-2]) & (p[:, 1:-1] == y[:, 1:-1]) & (p[:, 2:] == y[:, 2:])
        fa_aba = gt_aaa & (p[:, :-2] == p[:, 2:]) & (p[:, :-2] != p[:, 1:-1])
        return cm, sc_cm, joint, int(gt_aba.sum()), int(ex_aba.sum()), int(gt_aaa.sum()), int(fa_aba.sum())

    def update(self, pred: np.ndarray, gt: np.ndarray, aoi_names=None):
        cm, sc_cm, joint, g_aba, e_aba, g_aaa, f_aaa = self._update_counts(gt, pred)
        self.cm += cm
        self.sc_cm += sc_cm
        self.joint += joint
        self.aba_gt += g_aba
        self.aba_exact += e_aba
        self.aaa_gt += g_aaa
        self.aaa_aba_fp += f_aaa
        if aoi_names is not None:
            for i, name in enumerate(aoi_names):
                key = str(name)
                if key not in self.per_aoi:
                    self.per_aoi[key] = [
                        np.zeros((self.K, self.K), dtype=np.int64),
                        np.zeros((self.K, self.K), dtype=np.int64),
                        np.zeros((self.K, self.K, self.K, self.K), dtype=np.int64),
                        0, 0, 0, 0,
                    ]
                c_i, s_i, j_i, ga_i, ea_i, g3_i, f3_i = self._update_counts(gt[i : i + 1], pred[i : i + 1])
                rec = self.per_aoi[key]
                rec[0] += c_i; rec[1] += s_i; rec[2] += j_i
                rec[3] += ga_i; rec[4] += ea_i; rec[5] += g3_i; rec[6] += f3_i

    @staticmethod
    def _summarize(cm, sc_cm, joint, aba_gt, aba_ex, aaa_gt, aaa_fa, K):
        def iou(m):
            den = m.sum(1) + m.sum(0) - m.diagonal()
            return np.divide(100.0 * m.diagonal(), den, out=np.zeros(K), where=den > 0)

        ci = iou(cm)
        sci = iou(sc_cm)
        a, b, c, d = np.indices((K, K, K, K))
        real = a != b
        alarm = c != d
        exact = real & (a == c) & (b == d)
        tr = int(joint[real].sum())
        al = int(joint[alarm].sum())
        tp = int(joint[real & alarm].sum())
        ex = int(joint[exact].sum())
        fp = al - tp
        stab = int(joint[~real].sum())
        bc = 100.0 * tp / max(1, tp + fp + (tr - tp))
        sc = float(sci.mean())
        out = {
            "miou": float(ci.mean()),
            "class_iou": [float(x) for x in ci],
            "sc": sc,
            "bc": float(bc),
            "scs": float(0.5 * (sc + bc)),
            "strict_f1": float(200.0 * ex / max(1, tr + al)),
            "change_f1": float(200.0 * tp / max(1, tr + al)),
            "precision": float(100.0 * tp / max(1, al)),
            "recall": float(100.0 * tp / max(1, tr)),
            "stable_fpr": float(100.0 * fp / max(1, stab)),
            "alarms": al,
            "true_changes": tr,
            "exact_hits": ex,
            "aba_exact_rec": float(100.0 * aba_ex / max(1, aba_gt)),
            "aaa_aba_fp": float(100.0 * aaa_fa / max(1, aaa_gt)),
        }
        if K == 6:
            agr_stab = int(joint[1, 1].sum())
            agr_al = int(sum(joint[1, 1, u, v] for u in range(K) for v in range(K) if u != v))
            vs_tr = int(joint[2, 4].sum())
            vs_ex = int(joint[2, 4, 2, 4])
            sv_tr = int(joint[4, 2].sum())
            sv_ex = int(joint[4, 2, 4, 2])
            out["agr_stable_fpr"] = float(100.0 * agr_al / max(1, agr_stab))
            out["veg_to_soil_exact_rec"] = float(100.0 * vs_ex / max(1, vs_tr))
            out["soil_to_veg_exact_rec"] = float(100.0 * sv_ex / max(1, sv_tr))
        return out

    def compute(self, include_per_aoi: bool = False) -> dict:
        res = self._summarize(
            self.cm, self.sc_cm, self.joint, self.aba_gt, self.aba_exact, self.aaa_gt, self.aaa_aba_fp, self.K
        )
        if include_per_aoi and self.per_aoi:
            res["per_aoi"] = {k: self._summarize(*v, self.K) for k, v in sorted(self.per_aoi.items())}
        return res


def gn_to_bn(model: torch.nn.Module):
    for n, ch in model.named_children():
        if isinstance(ch, torch.nn.GroupNorm):
            setattr(model, n, torch.nn.BatchNorm2d(ch.num_channels))
        else:
            gn_to_bn(ch)


def build_aoi_context_banks(model, loader, dataset, device):
    bank = {}
    model.eval()
    with torch.inference_mode():
        for batch in loader:
            x = batch["data"].to(device)
            idxs = batch["idx"].tolist() if isinstance(batch["idx"], torch.Tensor) else list(batch["idx"])
            toks = model.extract_scene_tokens(x)
            for i, tidx in enumerate(idxs):
                aoi = str(dataset.sits_ids[tidx])
                bank.setdefault(aoi, []).append(toks[i].cpu())
    return {aoi: torch.cat(lst, dim=1) for aoi, lst in bank.items()}


def evaluate_loader(model, loader, dataset, device, num_classes: int, use_aoi_bank: bool = False, per_aoi: bool = False):
    model.eval()
    aoi_bank = build_aoi_context_banks(model, loader, dataset, device) if (use_aoi_bank and model.scpc is not None) else None
    acc = RichSCDAccumulator(num_classes)
    with torch.inference_mode():
        for batch in loader:
            x = batch["data"].to(device)
            pos = batch["positions"].to(device)
            y = batch["gt"].numpy()
            idxs = batch["idx"].tolist() if isinstance(batch["idx"], torch.Tensor) else list(batch["idx"])
            aois = [str(dataset.sits_ids[tidx]) for tidx in idxs]

            if aoi_bank is not None:
                lens = [aoi_bank[a].shape[1] for a in aois]
                if len(set(lens)) == 1:
                    sb = torch.stack([aoi_bank[a] for a in aois], dim=0).to(device)
                    logits = model(x, pos, scene_bank_tokens=sb)
                else:
                    outs = [model(x[i : i + 1], pos[i : i + 1], scene_bank_tokens=aoi_bank[a][None].to(device)) for i, a in enumerate(aois)]
                    logits = torch.cat(outs, dim=0)
            else:
                logits = model(x, pos)

            pred = logits.argmax(dim=2).cpu().numpy().astype(np.uint8)
            acc.update(pred, y, aoi_names=aois if per_aoi else None)
    return acc.compute(include_per_aoi=per_aoi)


def read_head_telemetry(model) -> dict:
    t = {}
    if model.head is not None:
        t["lambda_loc"] = round(float(model.head.lambda_loc.detach().cpu()), 4)
        if hasattr(model.head, "stay_scale_raw"):
            t["stay_scale"] = round(float(F.softplus(model.head.stay_scale_raw).detach().cpu()), 4)
        if hasattr(model.head, "ep_witness_raw"):
            t["ep_witness"] = round(float(model.head.ep_witness_scale.detach().cpu()), 4)
    return t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=["planet", "s2"], default="planet")
    ap.add_argument("--seed", type=int, choices=[42, 43, 44], required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--head", choices=["none", "h1", "h2", "h3", "h3_nos0"], default="h3")
    ap.add_argument("--scpc", type=int, choices=[0, 1], default=1)
    ap.add_argument("--rad_aug", type=int, choices=[0, 1], default=1)
    ap.add_argument("--causal", type=int, choices=[0, 1], default=0)
    ap.add_argument("--freeze_backbone", action="store_true")
    ap.add_argument("--backbone_ckpt", type=str, default="")
    ap.add_argument("--backbone_opts", type=str, default="event=0,gate=0")
    ap.add_argument("--backbone_norm", choices=["gn", "bn"], default="gn")
    ap.add_argument("--epochs", type=int, default=120)
    ap.add_argument("--lr_tmax", type=int, default=250)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--head_lr", type=float, default=0.0, help="Separate LR for new modules (0 = use --lr)")
    ap.add_argument("--weight_decay", type=float, default=1e-3)
    ap.add_argument("--head_wd", type=float, default=1e-2, help="Stronger weight decay on new heads against source-AOI overfit")
    ap.add_argument("--drop", type=float, default=0.15)
    ap.add_argument("--w_crf", type=float, default=1.0)
    ap.add_argument("--w_ep", type=float, default=0.5)
    ap.add_argument("--w_norm", type=float, default=0.3)
    ap.add_argument("--w_event", type=float, default=1.0)
    ap.add_argument("--crf_weighted", type=int, choices=[0, 1], default=1)
    ap.add_argument("--crf_chg_boost", type=float, default=2.5)
    ap.add_argument("--select_metric", choices=["miou", "scs"], default="miou")
    ap.add_argument("--eval_aoi_bank", type=int, choices=[0, 1], default=1)
    ap.add_argument("--run_official_test", action="store_true",
                    help="ONLY enable in Phase 3 final runs! Keeps official test untouched in Phase 1/2.")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--smoke_steps", type=int, default=0)
    ap.add_argument("--num_workers", type=int, default=-1, help="-1 = auto (0 on Windows to avoid shared-event crash, YAML value on Linux)")
    ap.add_argument("--device", type=str, default="auto")
    args = ap.parse_args()

    t34_dir, here_dir, author_dir, data_dir, cache_dir = resolve_paths(args.dataset)
    os.environ["ST3D_REPO"] = str(author_dir)
    os.environ["ST3D_DATA"] = str(data_dir.parent)
    os.environ["ST3D_CACHE"] = str(cache_dir)

    for p in (str(SCRIPT_DIR), str(t34_dir), str(here_dir), str(author_dir)):
        if p not in sys.path:
            sys.path.insert(0, p)

    import st3d_repro as released_adapter
    from data.datamodule import ImageDataModule
    from models.losses import Losses
    from pse_net import make_pse
    from utils.wrapper import load_yaml
    from snt_model import SNTNet

    if args.dataset == "s2":
        s2_src = t34_dir / "s2_src"
        if str(s2_src) not in sys.path:
            sys.path.insert(0, str(s2_src))
        import msi_adapter
        make_set_fn = msi_adapter.make_set
        yaml_name = "dynamicearthnet_msi.yaml"
    else:
        make_set_fn = released_adapter.make_set
        yaml_name = "dynamicearthnet.yaml"

    device = ("cuda:0" if torch.cuda.is_available() else "cpu") if args.device == "auto" else args.device
    torch.set_num_threads(2)
    seed_everything(args.seed)

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    cfg = load_yaml(author_dir / "configs" / yaml_name)
    cfg["dataset"]["path"] = str(data_dir)
    cfg["dataset"]["split_file"] = str(data_dir / "split.json")
    cfg["computer"]["accelerator"] = device
    cfg["run"]["seed"] = args.seed
    num_classes = int(cfg["dataset"]["num_classes"])
    in_channels = int(cfg["model"]["num_channels"])
    ignore_idx = int(cfg["dataset"].get("ignore_index", 6))

    bb_opts = args.backbone_opts
    if args.causal and "causal=" not in bb_opts:
        bb_opts = (bb_opts + ",causal=1").strip(",")
    backbone = make_pse(cfg, bb_opts)
    if args.backbone_norm == "bn":
        gn_to_bn(backbone)

    if args.backbone_ckpt:
        ckpt_bb = torch.load(args.backbone_ckpt, map_location="cpu", weights_only=True)
        sd = ckpt_bb["model"] if isinstance(ckpt_bb, dict) and "model" in ckpt_bb else ckpt_bb
        backbone.load_state_dict(sd, strict=True)
        print(f"[INFO] Loaded pretrained backbone weights: {args.backbone_ckpt}", flush=True)

    model = SNTNet(
        backbone=backbone,
        in_channels=in_channels,
        num_classes=num_classes,
        head_mode=args.head,
        use_scpc=bool(args.scpc),
        use_rad_aug=bool(args.rad_aug),
        freeze_backbone=args.freeze_backbone,
        causal=bool(args.causal),
        ignore_index=ignore_idx,
        drop=args.drop,
    ).to(device)

    n_total = sum(p.numel() for p in model.parameters())
    n_train = sum(p.numel() for p in model.parameters() if p.requires_grad)
    n_new = sum(p.numel() for n, p in model.named_parameters() if not n.startswith("backbone."))

    loss_obj = Losses(**cfg["loss"])
    loss_fn = lambda pred, gt: loss_obj({"logits": pred}, {"gt": gt}, average=True)["loss"]  # noqa: E731
    cls_w = getattr(loss_obj.ce_loss, "weight", None) if hasattr(loss_obj, "ce_loss") else None
    if cls_w is None and hasattr(backbone, "cls_w"):
        cls_w = backbone.cls_w

    ds_tr = make_set_fn(cfg, "train")
    ds_vin = make_set_fn(cfg, "val", domain_shift=False)
    ds_vout = make_set_fn(cfg, "val", domain_shift=True)
    bs = int(cfg["dataset"]["global_batch_size"])
    if args.smoke_steps or device == "cpu":
        nw = 0
    elif args.num_workers >= 0:
        nw = int(args.num_workers)
    else:
        nw = 0 if os.name == "nt" else int(cfg["computer"]["num_workers"])

    print(
        f"[SNT-v2.1] head={args.head} scpc={args.scpc} rad_aug={args.rad_aug} crf_w={args.crf_weighted} "
        f"chg_boost={args.crf_chg_boost} bb_opts={bb_opts!r} freeze_bb={args.freeze_backbone} nw={nw} | "
        f"total={n_total:,} trainable={n_train:,} new_params={n_new:,}",
        flush=True,
    )

    dm_tr = ImageDataModule(ds_tr, ds_vin, ds_vin, bs, nw)
    dm_tr.setup("fit")
    dm_tr.setup("test")
    fit_loader = dm_tr.get_train_loader()
    val_in_loader = dm_tr.get_test_loader()

    dm_vo = ImageDataModule(ds_tr, ds_vout, ds_vout, bs, nw)
    dm_vo.setup("test")
    val_out_loader = dm_vo.get_test_loader()

    head_lr = args.head_lr if args.head_lr > 0 else args.lr
    if args.freeze_backbone:
        param_groups = [{"params": [p for p in model.parameters() if p.requires_grad], "lr": head_lr, "weight_decay": args.head_wd}]
    else:
        bb_params = [p for n, p in model.named_parameters() if n.startswith("backbone.") and p.requires_grad]
        new_params = [p for n, p in model.named_parameters() if not n.startswith("backbone.") and p.requires_grad]
        param_groups = [
            {"params": bb_params, "lr": args.lr, "weight_decay": args.weight_decay},
            {"params": new_params, "lr": head_lr, "weight_decay": args.head_wd},
        ]
    optimizer = torch.optim.AdamW(param_groups)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.lr_tmax, eta_min=min(args.lr, head_lr) * 0.01)

    contract = {
        "version": "snt_v2.1_1123",
        "created": now_iso(),
        "args": vars(args),
        "params": {"total": n_total, "trainable": n_train, "new_modules": n_new},
        "num_workers_effective": nw,
        "device": device,
        "torch": str(torch.__version__),
    }
    save_json(out_dir / "config_snt.json", contract)

    epoch_start = 1
    history = []
    best = {"in": None, "out": None, "out_scs": None}
    last_pth = out_dir / "last.pth"
    if args.resume and last_pth.exists():
        st = torch.load(last_pth, map_location="cpu", weights_only=False)
        model.load_state_dict(st["model"], strict=True)
        optimizer.load_state_dict(st["optimizer"])
        scheduler.load_state_dict(st["scheduler"])
        epoch_start = st["epoch"] + 1
        history = st["history"]
        best = st["best"]
        print(f"[RESUME] Resuming from epoch {epoch_start}", flush=True)

    max_ep = 2 if args.smoke_steps else args.epochs
    for epoch in range(epoch_start, max_ep + 1):
        t0 = time.monotonic()
        model.train()
        sums, steps = {}, 0
        for step, batch in enumerate(fit_loader):
            if args.smoke_steps and step >= args.smoke_steps:
                break
            x = batch["data"].to(device)
            y = batch["gt"].to(device)
            pos = batch["positions"].to(device)

            logits = model(x, pos)
            loss, parts = model.compute_total_loss(
                logits, y, loss_fn, cls_weight=cls_w,
                w_backbone_event=args.w_event, w_crf=args.w_crf, w_ep=args.w_ep, w_norm=args.w_norm,
                crf_weighted=bool(args.crf_weighted), crf_chg_boost=args.crf_chg_boost,
            )
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()

            for k, v in parts.items():
                sums[k] = sums.get(k, 0.0) + float(v.detach().cpu())
            steps += 1
        scheduler.step()
        train_sec = time.monotonic() - t0
        avg_loss = {k: v / max(steps, 1) for k, v in sums.items()}
        telem = read_head_telemetry(model)

        val_in_m = evaluate_loader(model, val_in_loader, ds_vin, device, num_classes, per_aoi=False) if not args.smoke_steps else {"miou": 0.0, "scs": 0.0, "strict_f1": 0.0}
        val_out_m = evaluate_loader(model, val_out_loader, ds_vout, device, num_classes, per_aoi=False) if not args.smoke_steps else {"miou": 0.0, "scs": 0.0, "strict_f1": 0.0}

        rec = {
            "epoch": epoch,
            "lr": optimizer.param_groups[-1]["lr"],
            "train_sec": round(train_sec, 1),
            "loss": avg_loss,
            "telemetry": telem,
            "val_in": val_in_m,
            "val_out": val_out_m,
        }
        history.append(rec)

        model_file = f"epoch{epoch:03d}.pth"
        keep = (epoch % 10 == 0) or (epoch == max_ep)
        for dom, vm in (("in", val_in_m), ("out", val_out_m)):
            score = vm[args.select_metric]
            if best[dom] is None or score > best[dom]["score"]:
                keep = True
                best[dom] = {
                    "epoch": epoch, "metric": args.select_metric, "score": score,
                    "miou": vm["miou"], "scs": vm["scs"], "strict_f1": vm["strict_f1"], "weights": model_file,
                }
        # Also track best val_out SCS checkpoint separately (diagnostic reference)
        if best["out_scs"] is None or val_out_m["scs"] > best["out_scs"]["score"]:
            keep = True
            best["out_scs"] = {
                "epoch": epoch, "metric": "scs", "score": val_out_m["scs"],
                "miou": val_out_m["miou"], "scs": val_out_m["scs"], "strict_f1": val_out_m["strict_f1"], "weights": model_file,
            }

        if keep:
            save_ckpt(out_dir / model_file, {"model": model.state_dict(), "epoch": epoch})
        save_ckpt(
            last_pth,
            {
                "model": model.state_dict(), "optimizer": optimizer.state_dict(),
                "scheduler": scheduler.state_dict(), "epoch": epoch, "history": history, "best": best,
            },
        )
        save_json(out_dir / "epochs.json", history)
        save_json(
            out_dir / "status.json",
            {
                "time": now_iso(),
                "phase": "smoke_complete" if (args.smoke_steps and epoch == max_ep) else "training",
                "epoch": epoch, "epochs": max_ep, "loss": avg_loss.get("loss", 0.0), "telemetry": telem, "best": best,
            },
        )
        print(
            f"[Ep {epoch:03d}/{max_ep:03d}] {train_sec:5.1f}s loss={avg_loss.get('loss',0):.4f} "
            f"| in mIoU={val_in_m['miou']:5.2f} SCS={val_in_m['scs']:5.2f} SF1={val_in_m['strict_f1']:5.2f} "
            f"| out mIoU={val_out_m['miou']:5.2f} SCS={val_out_m['scs']:5.2f} SF1={val_out_m['strict_f1']:5.2f} "
            f"FPR={val_out_m.get('stable_fpr',0):4.2f} Rec={val_out_m.get('recall',0):4.1f} | {telem}",
            flush=True,
        )

    if args.smoke_steps:
        print("[OK] SNT-v2 smoke test passed cleanly!", flush=True)
        return

    # Final detailed dev-val summary for BOTH best_out_miou and best_out_scs (Single-Tile & Whole-AOI!)
    summary = {"best": best, "dev_val_out": {}}
    for tag, bkey in (("selected_miou", "out"), ("selected_scs", "out_scs")):
        ck = torch.load(out_dir / best[bkey]["weights"], map_location="cpu", weights_only=True)
        model.load_state_dict(ck["model"], strict=True)
        entry = {
            "epoch": best[bkey]["epoch"],
            "single_tile": evaluate_loader(model, val_out_loader, ds_vout, device, num_classes, use_aoi_bank=False, per_aoi=True),
        }
        if args.eval_aoi_bank and model.scpc is not None:
            entry["whole_aoi_bank"] = evaluate_loader(model, val_out_loader, ds_vout, device, num_classes, use_aoi_bank=True, per_aoi=True)
        summary["dev_val_out"][tag] = entry
    save_json(out_dir / "dev_val_summary.json", summary)

    if args.run_official_test:
        off_res = {}
        for dom in ("in", "out"):
            shift = dom == "out"
            ck = torch.load(out_dir / best[dom]["weights"], map_location="cpu", weights_only=True)
            model.load_state_dict(ck["model"], strict=True)
            ds_te = make_set_fn(cfg, "test", domain_shift=shift, cache=False)
            decode_tile = lru_cache(maxsize=1)(ds_te.load_data)
            ds_te.load_data = lambda i, tile, months, path, _fn=decode_tile: _fn(i, tile, tuple(months), path)
            dm_te = ImageDataModule(ds_te, ds_te, ds_te, 2, 0)
            dm_te.setup("test")
            off_res[f"test_{dom}_single_tile"] = evaluate_loader(
                model, dm_te.get_test_loader(), ds_te, device, num_classes, use_aoi_bank=False, per_aoi=shift
            )
            if args.eval_aoi_bank and model.scpc is not None and shift:
                off_res["test_out_whole_aoi_bank"] = evaluate_loader(
                    model, dm_te.get_test_loader(), ds_te, device, num_classes, use_aoi_bank=True, per_aoi=True
                )
            decode_tile.cache_clear()
        save_json(out_dir / "official_test_snt.json", {"finished": now_iso(), "best": best, "results": off_res})

    save_json(out_dir / "status.json", {"time": now_iso(), "phase": "complete", "epoch": max_ep, "best": best})
    print("[COMPLETE] SNT-v2 finished cleanly ->", out_dir, flush=True)


if __name__ == "__main__":
    main()
