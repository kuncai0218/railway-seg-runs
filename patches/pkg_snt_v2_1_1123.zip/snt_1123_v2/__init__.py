# -*- coding: utf-8 -*-
"""SNT v2 (2026-11-23): X-ray upgraded from Phase 1 s42 diagnostics:
  1. Class-weighted + change-trajectory-boosted Linear-Chain CRF NLL (fixes Recall/SC suppression!)
  2. Strictly non-negative bounded endpoint weights (lambda_loc in [0, 0.5], ep_witness_scale > 0; fixes -0.43 sign flip!)
  3. Dropout2d(0.15) regularization inside lightweight heads + SceneConsistentRadiometricAug to stop source-AOI color overfitting!
"""
