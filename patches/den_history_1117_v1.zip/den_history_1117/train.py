"""E013 fixed-budget controlled training. Selection/evaluation uses source AOIs."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import random
import time
import numpy as np
import torch
from torch.utils.data import DataLoader
from data import DENSource, FixedDraws, source_split
from model import HistoryModel, losses
from metrics_1110 import ranking_metrics


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temp, path)


def atomic_torch(path, value):
    path = Path(path)
    temp = path.with_suffix(path.suffix + ".tmp")
    torch.save(value, temp)
    os.replace(temp, path)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def empty_counts():
    return {"cm": np.zeros((6, 6), np.int64), "sc_cm": np.zeros((6, 6), np.int64),
            "transitions": np.zeros((36, 36), np.int64),
            "tp": 0, "fp": 0, "fn": 0, "stable": 0, "flip": 0,
            "large_appearance_stable": 0, "large_appearance_fp": 0,
            "small_appearance_change": 0, "small_appearance_hit": 0}


def add_counts(count, y, pred, x):
    valid = y < 6
    count["cm"] += np.bincount((6 * y[valid] + pred[valid]), minlength=36).reshape(6, 6)
    v = valid[1:] & valid[:-1]
    gt = y[1:] != y[:-1]
    pr = pred[1:] != pred[:-1]
    count["tp"] += int((v & gt & pr).sum())
    count["fp"] += int((v & ~gt & pr).sum())
    count["fn"] += int((v & gt & ~pr).sum())
    count["stable"] += int((v & ~gt).sum())
    event = v & gt
    count["sc_cm"] += np.bincount(6 * y[1:][event] + pred[1:][event], minlength=36).reshape(6, 6)
    true_pair = y[:-1][v] * 6 + y[1:][v]
    pred_pair = pred[:-1][v] * 6 + pred[1:][v]
    count["transitions"] += np.bincount(36 * true_pair + pred_pair, minlength=1296).reshape(36, 36)
    v3 = valid[2:] & valid[1:-1] & valid[:-2]
    same3 = (y[2:] == y[1:-1]) & (y[1:-1] == y[:-2])
    flip = (pred[2:] == pred[:-2]) & (pred[1:-1] != pred[:-2])
    count["flip"] += int((v3 & same3 & flip).sum())
    difference = np.sqrt(np.mean((x[1:] - x[:-1]) ** 2, axis=1))
    large = v & ~gt & (difference > 0.08)
    small = v & gt & (difference <= 0.04)
    count["large_appearance_stable"] += int(large.sum())
    count["large_appearance_fp"] += int((large & pr).sum())
    count["small_appearance_change"] += int(small.sum())
    count["small_appearance_hit"] += int((small & pr).sum())


def summarize(c):
    cm = c["cm"]
    den = cm.sum(0) + cm.sum(1) - cm.diagonal()
    iou = np.divide(cm.diagonal(), den, out=np.zeros(6), where=den > 0)
    sc = c["sc_cm"]
    sd = sc.sum(0) + sc.sum(1) - sc.diagonal()
    sc_iou = np.divide(sc.diagonal(), sd, out=np.zeros(6), where=sd > 0)
    tp, fp, fn = c["tp"], c["fp"], c["fn"]
    bc = 100 * tp / max(tp + fp + fn, 1)
    return {"mIoU": 100 * float(iou.mean()), "class_IoU": (100 * iou).tolist(),
            "BC": bc, "SC": 100 * float(sc_iou.mean()), "SCS": (bc + 100 * float(sc_iou.mean())) / 2,
            "F1": 200 * tp / max(2 * tp + fp + fn, 1),
            "precision": 100 * tp / max(tp + fp, 1), "recall": 100 * tp / max(tp + fn, 1),
            "stable_FPR": 100 * fp / max(c["stable"], 1),
            "large_appearance_stable_FPR": 100 * c["large_appearance_fp"] / max(c["large_appearance_stable"], 1),
            "small_appearance_change_recall": 100 * c["small_appearance_hit"] / max(c["small_appearance_change"], 1),
            "counts": {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in c.items()}}


@torch.no_grad()
def evaluate(model, loader, device, history_mode="normal", limit=0, collect_ap=True):
    model.eval()
    groups, scores, truths = {}, [], []
    for i, batch in enumerate(loader):
        if limit and i >= limit:
            break
        x, days = batch["x"].to(device), batch["days"].to(device)
        out = model(x, days, history_mode=history_mode)
        probability = out["logits"].float().softmax(2).cpu().numpy()
        pred, y, obs = probability.argmax(2), batch["y"].numpy(), batch["x"].numpy()
        for b, rid in enumerate(batch["region"].tolist()):
            for name, pp in (("final", pred[b]), ("unary", out["unary"][b].argmax(1).cpu().numpy())):
                key = (name, rid)
                if key not in groups:
                    groups[key] = empty_counts()
                add_counts(groups[key], y[b], pp, obs[b])
        if collect_ap:
            # Uniform deterministic 1/32 spatial subsample. Ranking ONLY;
            # argmax F1/IoU counts above use every valid native pixel.
            yy = y.reshape(len(y), len(y[0]), -1)[:, :, ::32]
            p = probability.reshape(len(y), len(y[0]), 6, -1)[:, :, :, ::32]
            v = (yy[:, 1:] < 6) & (yy[:, :-1] < 6)
            score = 0.5 * np.abs(p[:, 1:] - p[:, :-1]).sum(2)
            scores.append(score[v])
            truths.append((yy[:, 1:] != yy[:, :-1])[v])
    result = {}
    for name in ("final", "unary"):
        selected = {rid: c for (nm, rid), c in groups.items() if nm == name}
        total = empty_counts()
        for c in selected.values():
            for k in total:
                total[k] += c[k]
        result[name] = {"aggregate": summarize(total), "regions": {str(r): summarize(c) for r, c in selected.items()}}
    if scores:
        result["ranking_diagnostic"] = ranking_metrics(np.concatenate(scores), np.concatenate(truths))
        result["ranking_diagnostic"]["sampling"] = "Every 32nd pixel, no class rebalancing; not full-pixel AP"
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-root", required=True)
    ap.add_argument("--cache-root", required=True)
    ap.add_argument("--arm", choices=HistoryModel.ARMS, required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--steps", type=int, default=3000)
    ap.add_argument("--batch", type=int, default=4)
    ap.add_argument("--eval-batch", type=int, default=4)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--aux-weight", type=float, default=0.2)
    ap.add_argument("--eval-every", type=int, default=750)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--eval-limit", type=int, default=0)
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    torch.set_num_threads(2)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    device = torch.device(args.device)
    torch.backends.cudnn.benchmark = device.type == "cuda"
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)
    if (outdir / "completed.json").exists():
        print("Already completed; leaving results intact.", flush=True)
        return
    split = source_split(args.raw_root)
    code_hashes = {p.name: sha(p) for p in Path(__file__).parent.glob("*.py")}
    cfg = {"args": vars(args), "split": split, "code_SHA256": code_hashes,
           "scope": "Fixed-budget 4-band mechanism pilot, not author recipe or final SOTA",
           "test_labels_read": False, "official_val_labels_read": False}
    if (outdir / "config.json").exists():
        old = json.loads((outdir / "config.json").read_text(encoding="utf-8"))
        assert old == cfg, "Refuse continuation with changed code, split or arguments"
    atomic_json(outdir / "config.json", cfg)
    trainset = DENSource(args.raw_root, args.cache_root, "train", args.seed)
    valset = DENSource(args.raw_root, args.cache_root, "hold", args.seed)
    val_loader = DataLoader(valset, batch_size=args.eval_batch, shuffle=False, num_workers=0)
    model = HistoryModel(args.arm).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-3)
    amp = device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=amp, init_scale=1024.)
    begin = 0
    if (outdir / "last.pth").exists():
        ck = torch.load(outdir / "last.pth", map_location="cpu", weights_only=False)
        model.load_state_dict(ck["model"])
        optimizer.load_state_dict(ck["optimizer"])
        scaler.load_state_dict(ck["scaler"])
        torch.set_rng_state(ck["torch_rng"])
        if amp:
            torch.cuda.set_rng_state_all(ck["cuda_rng"])
        begin = ck["step"]
    # All arms instantiate the same modules, and consume exactly the same draws.
    draws = FixedDraws(trainset, args.seed, (args.steps - begin) * args.batch, begin * args.batch)
    loader = DataLoader(draws, batch_size=args.batch, shuffle=False, num_workers=args.workers,
                        persistent_workers=args.workers > 0, pin_memory=amp)
    start = time.time()
    print(json.dumps({"stage": "training", "arm": args.arm, "seed": args.seed,
                      "start_step": begin, "params": sum(p.numel() for p in model.parameters()),
                      "source_train": len(trainset.regions), "source_hold": len(valset.regions),
                      "official_val_test_not_opened": True}), flush=True)
    sums = {"ce": 0., "prediction": 0.}
    model.train()
    for step, batch in enumerate(loader, start=begin + 1):
        lr = args.lr * (0.01 + 0.99 * 0.5 * (1 + math.cos(math.pi * (step - 1) / args.steps)))
        for group in optimizer.param_groups:
            group["lr"] = lr
        model.progress = min(1., step / 500)
        x, y, days = batch["x"].to(device), batch["y"].to(device), batch["days"].to(device)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp):
            output = model(x, days)
            loss, parts = losses(output, y, args.aux_weight)
        if not torch.isfinite(loss):
            raise RuntimeError("Non-finite objective at step " + str(step))
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 5.)
        if not torch.isfinite(norm):
            raise RuntimeError("Non-finite gradients at step " + str(step))
        scaler.step(optimizer)
        scaler.update()
        for key in sums:
            sums[key] += float(parts[key])
        if step % 100 == 0 or step == args.steps:
            record = {"step": step, "arm": args.arm, "lr": lr, "elapsed_sec": time.time() - start,
                      "ce": sums["ce"] / (100 if step % 100 == 0 else step % 100),
                      "prediction": sums["prediction"] / (100 if step % 100 == 0 else step % 100)}
            with open(outdir / "steps.jsonl", "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
            print(json.dumps(record), flush=True)
            sums = {"ce": 0., "prediction": 0.}
        if step % args.eval_every == 0 or step == args.steps:
            model.progress = 1.
            result = evaluate(model, val_loader, device, limit=args.eval_limit)
            atomic_json(outdir / ("source_hold_step" + str(step) + ".json"), result)
            print(json.dumps({"step": step, "source_hold": {k: v for k, v in result["final"]["aggregate"].items() if k != "counts"}}), flush=True)
            atomic_torch(outdir / "last.pth", {"step": step, "model": model.state_dict(),
                         "optimizer": optimizer.state_dict(), "scaler": scaler.state_dict(),
                         "torch_rng": torch.get_rng_state(),
                         "cuda_rng": torch.cuda.get_rng_state_all() if amp else []})
            model.train()
    model.progress = 1.
    full = DENSource(args.raw_root, args.cache_root, "hold", args.seed, full_eval=True)
    full_loader = DataLoader(full, batch_size=args.eval_batch, shuffle=False, num_workers=0)
    final = evaluate(model, full_loader, device, limit=args.eval_limit)
    atomic_json(outdir / "source_hold_full.json", final)
    if args.arm in ("evidence", "fusion", "shared"):
        diagnostics = {}
        for mode in ("none", "reverse"):
            diagnostics[mode] = evaluate(model, val_loader, device, history_mode=mode,
                                         limit=args.eval_limit, collect_ap=False)
        atomic_json(outdir / "history_interventions.json", diagnostics)
    atomic_json(outdir / "completed.json", {"at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "steps": args.steps, "arm": args.arm, "seed": args.seed, "smoke": args.smoke,
                "source_hold": {k: v for k, v in final["final"]["aggregate"].items() if k != "counts"},
                "checkpoint_SHA256": sha(outdir / "last.pth"), "code_SHA256": code_hashes})
    print("COMPLETE", flush=True)


if __name__ == "__main__":
    main()
