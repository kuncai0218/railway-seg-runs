"""Threshold-realizable binary metrics and a fixed source-domain empirical CDF.

Scores in a tie are inseparable. Best-F1 and target-FPR recall are explicitly
oracle diagnostics; deployed results must use a source-selected fixed threshold.
All percentage metrics are on a 0--100 scale.
"""
import hashlib
import numpy as np

def inputs(scores,labels):
 s=np.asarray(scores,dtype=np.float64).reshape(-1);y=np.asarray(labels).reshape(-1)
 if s.shape!=y.shape or not s.size:raise ValueError('Nonempty scores and labels must have identical size')
 if not np.isfinite(s).all() or not np.isin(y,[0,1]).all():raise ValueError('Finite scores and binary labels required; mask ignored labels first')
 return s,y.astype(np.int64)

def grouped_curve(scores,labels):
 s,y=inputs(scores,labels);order=np.argsort(-s,kind='stable');s,y=s[order],y[order]
 ends=np.r_[np.flatnonzero(s[:-1]!=s[1:]),len(s)-1]
 tp=np.r_[0,np.cumsum(y,dtype=np.int64)[ends]];fp=np.r_[0,ends+1-tp[1:]]
 return {'thresholds':np.r_[np.inf,s[ends]],'tp':tp,'fp':fp,'positives':int(y.sum()),'negatives':int(len(y)-y.sum()),'groups':len(ends)}

def ranking_metrics(scores,labels,fpr_budget=.1):
 if not 0<=fpr_budget<=1:raise ValueError('FPR budget must lie in[0,1]')
 c=grouped_curve(scores,labels);tp,fp=c['tp'],c['fp'];P,N=c['positives'],c['negatives']
 precision=np.divide(tp,tp+fp,out=np.zeros(len(tp),float),where=(tp+fp)>0);recall=tp/max(P,1)
 ap=float(np.sum(np.diff(recall)*precision[1:]));f1=2*tp/np.maximum(P+tp+fp,1)
 fpr=fp/max(N,1);valid=fpr<=fpr_budget
 return {'AP':100*ap,'oracle_best_F1':float(100*f1.max()),'oracle_recall_at_target_FPR':float(100*recall[valid].max()),'target_FPR_budget':fpr_budget,'score_groups':c['groups'],'positives':P,'negatives':N,'undefined_denominators':[name for name,value in [('recall',P),('FPR',N)] if value==0],'note':'Oracle curve summaries do not define a deployed operating threshold.'}

def select_source_threshold(scores,labels,fpr_budget=.1):
 if not 0<=fpr_budget<=1:raise ValueError('FPR budget must lie in[0,1]')
 c=grouped_curve(scores,labels);P,N=c['positives'],c['negatives']
 if not P or not N:raise ValueError('Source calibration requires both classes')
 valid=np.flatnonzero(c['fp']/N<=fpr_budget);i=int(valid[-1])
 return float(c['thresholds'][i]),{'source_precision':float(100*c['tp'][i]/max(c['tp'][i]+c['fp'][i],1)),'source_recall':float(100*c['tp'][i]/P),'source_FPR':float(100*c['fp'][i]/N),'fpr_budget':fpr_budget,'selection_domain':'source only'}

def evaluate_fixed_threshold(scores,labels,threshold):
 s,y=inputs(scores,labels)
 if np.isnan(threshold):raise ValueError('Threshold must not be NaN')
 p=s>=threshold;tp=int((p&(y==1)).sum());fp=int((p&(y==0)).sum());P=int(y.sum());N=len(y)-P
 return {'threshold':float(threshold),'tp':tp,'fp':fp,'positives':P,'negatives':N,'precision':100*tp/max(tp+fp,1),'recall':100*tp/max(P,1),'F1':200*tp/max(P+tp+fp,1),'FPR':100*fp/max(N,1)}

class SourceCDF:
 """The source reference stays fixed when target batches or mosaic sizes change."""
 def __init__(self,source_scores):
  reference=np.asarray(source_scores,dtype=np.float64).reshape(-1)
  if not reference.size or not np.isfinite(reference).all():raise ValueError('Finite nonempty source reference required')
  self.reference=np.sort(reference).copy();self.reference.flags.writeable=False
  self.reference_sha256=hashlib.sha256(self.reference.tobytes()).hexdigest()
 def transform(self,scores):
  scores=np.asarray(scores,dtype=np.float64)
  if not np.isfinite(scores).all():raise ValueError('Finite target scores required')
  return np.searchsorted(self.reference,scores,side='left')/len(self.reference)
