"""Structural/data tests needed before spending training compute."""
import argparse
import json
from pathlib import Path
import time
import torch
from torch.utils.data import DataLoader
from model import HistoryModel, losses
from data import DENSource, source_split
from train import add_counts, empty_counts, summarize, atomic_json
from metrics_1110 import ranking_metrics


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-root")
    ap.add_argument("--cache-root")
    ap.add_argument("--out", required=True)
    ap.add_argument("--gpu-bench", action="store_true")
    args = ap.parse_args()
    torch.set_num_threads(2)
    torch.manual_seed(9301)
    x, days = torch.rand(2, 8, 4, 32, 32), torch.tensor([[0., 91, 182, 274, 396, 487, 578, 701]]).repeat(2, 1)
    result = {"at": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "checks": {}}
    model = HistoryModel("evidence").eval()
    out = model(x, days)
    x2 = x.clone()
    x2[:, 4:] = torch.rand_like(x2[:, 4:])
    out2 = model(x2, days)
    delta = (out["predicted_observation"][:, 4] - out2["predicted_observation"][:, 4]).abs().max().item()
    assert delta == 0, "Current/future observation leaked into historical prediction"
    result["checks"]["predictor_current_future_independence_max_abs"] = delta
    delta = (out["logits"][:, :4] - out2["logits"][:, :4]).abs().max().item()
    assert delta == 0, "Later frames affected previous decisions"
    result["checks"]["causal_decision_max_abs"] = delta
    x3 = x.clone()
    x3[1] = torch.rand_like(x3[1])
    delta = (out["logits"][0] - model(x3, days)["logits"][0]).abs().max().item()
    assert delta == 0, "Cross-sample mixing"
    result["checks"]["batch_independence_max_abs"] = delta
    delta = (out["logits"][:, 0] - out["unary"][:, 0]).abs().max().item()
    assert delta == 0
    result["checks"]["first_frame_unary_fallback_max_abs"] = delta
    o1, o2 = model(x, days), model(x, days, history_mode="none")
    effect = (o1["predicted_observation"][:, 4:] - o2["predicted_observation"][:, 4:]).abs().mean().item()
    assert effect > 1e-6
    result["checks"]["history_actually_changes_prediction"] = effect
    initial = None
    for arm in HistoryModel.ARMS:
        torch.manual_seed(42)
        m = HistoryModel(arm)
        if initial is None:
            initial = {k: p.detach().clone() for k, p in m.encoder.named_parameters()}
        assert all(torch.equal(p, initial[k]) for k, p in m.encoder.named_parameters())
        y = torch.randint(0, 7, (2, 8, 32, 32))
        loss, parts = losses(m(x, days), y)
        loss.backward()
        assert torch.isfinite(loss) and all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters())
        result["checks"][arm + "_loss_gradient_finite"] = float(loss.detach())
    # All ties: AP must equal positive prevalence, not row order.
    ap1 = ranking_metrics([1, 1, 1, 1], [1, 0, 1, 0])
    ap2 = ranking_metrics([1, 1, 1, 1], [0, 1, 0, 1])
    assert ap1["AP"] == ap2["AP"] == 50.
    result["checks"]["tie_AP"] = ap1["AP"]
    import numpy as np
    gt = np.zeros((3, 4, 4), np.int64)
    pr = gt.copy()
    gt[1:, 0, 0] = 1
    pr[1:, 0, 0] = 1
    pr[1, 1, 1] = 2  # two false changes, one flip
    gt[:, 3, 3] = 6
    c = empty_counts()
    add_counts(c, gt, pr, np.zeros((3, 4, 4, 4), np.float32))
    assert (c["tp"], c["fp"], c["fn"], c["flip"]) == (1, 2, 0, 1)
    assert c["cm"].sum() == 45 and c["transitions"].sum() == 30
    assert summarize(c)["F1"] == 50.
    result["checks"]["metric_toy"] = {"tp": c["tp"], "fp": c["fp"], "fn": c["fn"], "flip": c["flip"]}
    if args.raw_root and args.cache_root:
        splits = source_split(args.raw_root)
        a = DENSource(args.raw_root, args.cache_root, "train")
        b = DENSource(args.raw_root, args.cache_root, "hold")
        assert not set(a.regions) & set(b.regions)
        item = a[0]
        region = a.regions[0]
        # Independent direct label crop, before the deterministic augmentation.
        mm = np.load(Path(args.raw_root) / "labels" / (region + ".npy"), mmap_mode="r")
        assert item["x"].shape == (8, 4, 128, 128)
        assert item["y"].shape == (8, 128, 128)
        assert set(a.blocks).isdisjoint({(6, 7), (7, 6)})
        # Apply inverse-free identical geometric operations to a direct crop.
        from data import MONTHS
        yy = np.array(mm[MONTHS, :128, :128], copy=True)
        rng = np.random.default_rng(42)
        k = int(rng.integers(4))
        yy = np.rot90(yy, k, (-2, -1))
        if rng.random() < .5:
            yy = yy[..., ::-1]
        assert np.array_equal(yy, item["y"].numpy())
        result["data"] = {"source_train": a.regions, "source_hold": b.regions,
                          "train_blocks_per_AOI": len(a.blocks), "validation_blocks_per_AOI": len(b.blocks),
                          "direct_label_crop_equal": True, "official_val_test_not_opened": True}
        # Read input/label shape only for every source region.
        for reg in a.regions + b.regions:
            aa = np.load(a.cache_root / (reg + ".blk.npy"), mmap_mode="r")
            ll = np.load(Path(args.raw_root) / "labels" / (reg + ".npy"), mmap_mode="r")
            assert aa.dtype == np.uint8 and aa.shape[-1] == 4
            assert ll.shape == (24, 1024, 1024)
        result["data"]["all55_source_file_shapes_validated"] = True
        if args.gpu_bench:
            item = next(iter(DataLoader(a, batch_size=2, num_workers=0)))
            m = HistoryModel("evidence").cuda()
            opt = torch.optim.AdamW(m.parameters(), lr=3e-4)
            xg, yg, dg = item["x"].cuda(), item["y"].cuda(), item["days"].cuda()
            torch.cuda.reset_peak_memory_stats()
            start = time.time()
            for i in range(12):
                opt.zero_grad(set_to_none=True)
                l, _ = losses(m(xg, dg), yg)
                l.backward()
                opt.step()
                torch.cuda.synchronize()
            result["gpu_bench"] = {"batch": 2, "steps": 12, "elapsed": time.time() - start,
                                   "max_allocated_GiB": torch.cuda.max_memory_allocated() / 2**30,
                                   "max_reserved_GiB": torch.cuda.max_memory_reserved() / 2**30}
    result["passed"] = True
    atomic_json(args.out, result)
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
