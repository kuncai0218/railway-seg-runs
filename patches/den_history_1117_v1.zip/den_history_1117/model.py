"""E013 candidate: past observations predict class-conditional current appearance.

This is a mechanism pilot, not an established novel method or a SOTA claim.
Every frame has an independent spatial encoder. The history predictor cannot
read the current/future frame, its label, or a future hidden state.
"""
import math
import torch
from torch import nn
import torch.nn.functional as F


def conv(cin, cout):
    return nn.Sequential(nn.Conv2d(cin, cout, 3, padding=1, bias=False),
                         nn.GroupNorm(4, cout), nn.SiLU(),
                         nn.Conv2d(cout, cout, 3, padding=1, bias=False),
                         nn.GroupNorm(4, cout), nn.SiLU())


class SpatialEncoder(nn.Module):
    def __init__(self, cin=4, width=24):
        super().__init__()
        self.c0 = conv(cin, width)
        self.c1 = conv(width, 2 * width)
        self.c2 = conv(2 * width, 4 * width)
        self.u1 = conv(6 * width, 2 * width)
        self.u0 = conv(3 * width, width)

    def forward(self, x):
        a = self.c0(x)
        b = self.c1(F.avg_pool2d(a, 2))
        c = self.c2(F.avg_pool2d(b, 2))
        b = self.u1(torch.cat([b, F.interpolate(c, size=b.shape[-2:], mode="bilinear", align_corners=False)], 1))
        return self.u0(torch.cat([a, F.interpolate(b, size=a.shape[-2:], mode="bilinear", align_corners=False)], 1))


def time_features(days):
    a = days.float() * (2 * math.pi / 365.25)
    return torch.stack([a.sin(), a.cos(), (2 * a).sin(), (2 * a).cos(),
                        days.float() / 730.5, torch.ones_like(a)], -1)


class HistoryModel(nn.Module):
    ARMS = ("current", "fusion", "aux", "evidence", "null", "shared")

    def __init__(self, arm="evidence", width=24, classes=6):
        super().__init__()
        if arm not in self.ARMS:
            raise ValueError(arm)
        self.arm, self.width, self.classes = arm, width, classes
        self.encoder = SpatialEncoder(4, width)
        self.unary = nn.Conv2d(width, classes, 1)
        self.class_embedding = nn.Embedding(classes, 8)
        self.clock = nn.Linear(6, width)
        # Same prediction bank is trained in fusion/aux/evidence/null/shared.
        self.predictor = nn.Sequential(nn.Linear(width + 6 + 8, 64),
                                       nn.SiLU(), nn.Linear(64, 4), nn.Sigmoid())
        self.phase = nn.Parameter(torch.zeros(classes))
        self.age = nn.Parameter(torch.zeros(classes))
        self.log_scale = nn.Parameter(torch.tensor(-2.0))
        # Fusion has MORE active discriminative parameters than evidence.
        self.fusion = nn.Sequential(nn.Conv2d(2 * width, width, 1), nn.SiLU(),
                                    nn.Conv2d(width, classes, 1))
        self.progress = 1.0

    def forward(self, x, days, history_mode="normal"):
        """x [B,T,4,H,W] in [0,1]; output includes label-free predictions."""
        B, T, C, H, W = x.shape
        f = self.encoder(x.reshape(B * T, C, H, W)).reshape(B, T, self.width, H, W)
        unary = self.unary(f.reshape(B * T, self.width, H, W)).reshape(B, T, self.classes, H, W)
        if self.arm == "current":
            return {"logits": unary, "unary": unary}
        h, w = H // 4, W // 4
        z = F.avg_pool2d(f.reshape(B * T, self.width, H, W), 4).reshape(B, T, self.width, h, w)
        p = F.avg_pool2d(unary.detach().softmax(2).reshape(B * T, self.classes, H, W), 4).reshape(B, T, self.classes, h, w)
        tf = time_features(days)
        z = z + self.clock(tf)[..., None, None]
        mus, summaries, supports = [], [], []
        for q in range(T):
            past = q
            if past and self.arm != "null" and history_mode != "none":
                zp, pp = z[:, :past], p[:, :past]
                dp = days[:, :past]
                if history_mode == "reverse":
                    # Invalid past/content pairing intervention; keep query intact.
                    zp, pp = zp.flip(1), pp.flip(1)
                if history_mode == "other_sample":
                    zp, pp = zp.roll(1, 0), pp.roll(1, 0)
                delta = (days[:, q:q + 1] - dp).float() / 365.25
                phase = (2 * math.pi * delta).cos()
                log_kernel = (F.softplus(self.phase)[None, None, :, None, None] * phase[:, :, None, None, None]
                              - F.softplus(self.age)[None, None, :, None, None] * delta[:, :, None, None, None].clamp_min(0))
                responsibility = pp if self.arm != "shared" else torch.ones_like(pp) / self.classes
                # Unit pseudocount prevents tiny historical class mass from
                # becoming a highly confident reference for a newly seen class.
                weight = responsibility * log_kernel.clamp(-12, 4).exp()
                support = weight.sum(1)
                summary = torch.einsum("bskhw,bsdhw->bkdhw", weight, zp) / (1 + support[:, :, None])
            else:
                summary = z.new_zeros(B, self.classes, self.width, h, w)
                support = z.new_zeros(B, self.classes, h, w)
            ce = self.class_embedding.weight[None, :, None, None].expand(B, -1, h, w, -1)
            qt = tf[:, q, None, None, None].expand(-1, self.classes, h, w, -1)
            inp = torch.cat([summary.permute(0, 1, 3, 4, 2), ce, qt], -1)
            mus.append(self.predictor(inp).permute(0, 1, 4, 2, 3))
            summaries.append(summary.mean(1))
            supports.append(support)
        mu = torch.stack(mus, 1)  # B T K C h w; cannot see x at q or later.
        observed = F.avg_pool2d(x.reshape(B * T, C, H, W), 4).reshape(B, T, C, h, w)
        # Fixed measurement scale; no per-query variance that could hide errors.
        score = -((observed[:, :, None] - mu).square().mean(3) / 0.04)
        available = (torch.arange(T, device=x.device) > 0).to(x.dtype)[None, :, None, None, None]
        score = score * available
        scale = 2.0 * self.log_scale.sigmoid() * float(self.progress)
        if self.arm == "fusion":
            hist = torch.stack(summaries, 1).reshape(B * T, self.width, h, w)
            hist = F.interpolate(hist, size=(H, W), mode="bilinear", align_corners=False)
            correction = self.fusion(torch.cat([f.reshape(B * T, self.width, H, W), hist], 1)).reshape(B, T, self.classes, H, W)
            logits = unary + correction * available
        elif self.arm == "aux":
            logits = unary
        else:
            # Score competition changes semantic hypotheses; it does not blend
            # current features with an averaged historical feature map.
            correction = F.interpolate(score.reshape(B * T, self.classes, h, w),
                                       size=(H, W), mode="bilinear", align_corners=False)
            logits = unary + scale * correction.reshape(B, T, self.classes, H, W)
        return {"logits": logits, "unary": unary, "predicted_observation": mu,
                "observed": observed, "support": torch.stack(supports, 1),
                "score": score, "evidence_scale": scale}


def losses(out, y, aux_weight=0.2, ignore=6):
    logits = out["logits"]
    B, T, K, H, W = logits.shape
    valid = y < K
    ce = (F.cross_entropy(logits.reshape(B * T, K, H, W), y.reshape(B * T, H, W), ignore_index=ignore)
          if valid.any() else logits.sum() * 0.)
    if "predicted_observation" not in out:
        return ce, {"ce": ce.detach(), "prediction": ce.detach() * 0}
    mu, obs = out["predicted_observation"], out["observed"]
    h, w = mu.shape[-2:]
    onehot = F.one_hot(y.clamp_max(K), K + 1)[..., :K].permute(0, 1, 4, 2, 3).float()
    fraction = F.avg_pool2d(onehot.reshape(B * T, K, H, W), 4).reshape(B, T, K, h, w)
    # All valid pixels contribute through class fractions; no purity filtering.
    error = F.smooth_l1_loss(mu, obs[:, :, None].expand_as(mu), reduction="none").mean(3)
    time_ok = (torch.arange(T, device=y.device) > 0)[None, :, None, None, None]
    weights = fraction * time_ok
    pred = (error * weights).sum() / weights.sum().clamp_min(1)
    return ce + aux_weight * pred, {"ce": ce.detach(), "prediction": pred.detach()}
