"""Only the original 55 source AOIs. Never opens official val/test labels."""
import datetime
import json
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import Dataset

MONTHS = [0, 3, 6, 9, 13, 16, 19, 23]
DATES = [(datetime.date(2018 + m // 12, m % 12 + 1, 1) - datetime.date(2018, 1, 1)).days for m in MONTHS]
EVAL_BLOCKS = [(0, 0), (0, 7), (2, 2), (3, 5), (5, 3), (6, 6), (7, 0), (7, 7)]
RESERVED = {(6, 7), (7, 6)}


def source_split(raw_root):
    original = json.loads((Path(raw_root) / "split.json").read_text(encoding="utf-8"))
    source = sorted(original["train"])
    hold = source[::5]
    train = [r for r in source if r not in hold]
    assert len(source) == 55 and len(train) == 44 and len(hold) == 11
    assert not (set(source) & set(original["val"] + original["test"]))
    return {"train": train, "hold": hold, "official_val_test_not_opened": True}


class DENSource(Dataset):
    def __init__(self, raw_root, cache_root, fold="train", seed=42, full_eval=False):
        self.raw_root, self.cache_root = Path(raw_root), Path(cache_root)
        self.fold, self.seed = fold, seed
        self.regions = source_split(raw_root)["train" if fold == "train" else "hold"]
        if not (self.cache_root / "index.json").exists() and (self.cache_root / "train" / "index.json").exists():
            self.cache_root = self.cache_root / "train"
        index = json.loads((self.cache_root / "index.json").read_text(encoding="utf-8"))
        self.rows = [index["days"].index(d) for d in DATES]
        self.blocks = ([(r, c) for r in range(8) for c in range(8) if (r, c) not in RESERVED]
                       if fold == "train" else ([(r, c) for r in range(8) for c in range(8)] if full_eval else EVAL_BLOCKS))
        self._images, self._labels = {}, {}
        for reg in self.regions:
            if not (self.cache_root / (reg + ".blk.npy")).exists():
                raise FileNotFoundError(self.cache_root / (reg + ".blk.npy"))
            if not (self.raw_root / "labels" / (reg + ".npy")).exists():
                raise FileNotFoundError(self.raw_root / "labels" / (reg + ".npy"))

    def __len__(self):
        return len(self.regions) * len(self.blocks)

    def __getstate__(self):
        state = self.__dict__.copy()
        state["_images"], state["_labels"] = {}, {}
        return state

    def __getitem__(self, index):
        ri, bi = divmod(index, len(self.blocks))
        reg, (r, c) = self.regions[ri], self.blocks[bi]
        if reg not in self._images:
            im = np.load(self.cache_root / (reg + ".blk.npy"), mmap_mode="r")
            lab = np.load(self.raw_root / "labels" / (reg + ".npy"), mmap_mode="r")
            assert im.shape[:2] == (8, 8) and im.shape[-3:] == (128, 128, 4) and im.dtype == np.uint8
            assert lab.shape == (24, 1024, 1024) and lab.dtype == np.uint8
            self._images[reg], self._labels[reg] = im, lab
        x = np.array(self._images[reg][r, c, self.rows], copy=True).transpose(0, 3, 1, 2)
        y = np.array(self._labels[reg][MONTHS, r * 128:(r + 1) * 128, c * 128:(c + 1) * 128], copy=True)
        # Reproducible augmentations depend on the sampler's unique item index.
        if self.fold == "train":
            rng = np.random.default_rng(self.seed + 104729 * index)
            k = int(rng.integers(4))
            x, y = np.rot90(x, k, (-2, -1)), np.rot90(y, k, (-2, -1))
            if rng.random() < 0.5:
                x, y = x[..., ::-1], y[..., ::-1]
        return {"x": torch.from_numpy(np.ascontiguousarray(x)).float() / 255.0,
                "y": torch.from_numpy(np.ascontiguousarray(y)).long(),
                "days": torch.tensor(DATES, dtype=torch.float32), "region": ri, "block": bi}


class FixedDraws(Dataset):
    """Fixed sampler sequence, exact continuation without mutable RNG workers."""
    def __init__(self, dataset, seed, count, offset=0):
        self.dataset, self.count, self.offset = dataset, count, offset
        self.indices = np.random.default_rng(seed + 7919).integers(len(dataset), size=count + offset)

    def __len__(self):
        return self.count

    def __getitem__(self, index):
        return self.dataset[int(self.indices[index + self.offset])]
