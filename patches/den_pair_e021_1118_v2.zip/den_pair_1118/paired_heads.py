"""Fit matched FP32 transition heads on a frozen, source-held DEN feature packet."""
import argparse
import hashlib
import json
import math
import os
import time
from pathlib import Path

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("OMP_NUM_THREADS", "2")
os.environ.setdefault("MKL_NUM_THREADS", "2")
import numpy as np
import torch
from torch import nn
from torch.nn.functional import cross_entropy

K = 6
DIAGONAL = np.arange(K) * (K + 1)
DIFFERENT = np.flatnonzero(~np.isin(np.arange(K*K), DIAGONAL))
ARMS = ("JS", "anchor", "ordinary", "factorized", "ordinary_placebo", "factorized_placebo")


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".{os.getpid()}.tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf8")
    os.replace(temp, path)


def mlp(num_inputs, width, outputs):
    return nn.Sequential(nn.Linear(num_inputs,width), nn.SiLU(), nn.Linear(width,outputs))


class Evidence(nn.Module):
    """Given the anchor logits, either score all pairs jointly or share endpoint scores."""
    def __init__(self, context, observation, factorized):
        super().__init__()
        self.factorized = factorized
        full_inputs = context + 2 * observation + 2
        direct = 32 * (full_inputs + 1 + K*K) + K*K
        per_unit = 2 * (context + observation + 1 + K)
        width = max(1,round((direct-2*K)/per_unit))
        if factorized:
            self.from_head = mlp(context+observation,width,K)
            self.to_head = mlp(context+observation,width,K)
        else:
            self.direct = mlp(full_inputs,32,K*K)

    def forward(self, context, residual, observed):
        valid = observed[...,None]
        z = torch.where(valid,residual,torch.zeros_like(residual))
        zero = torch.zeros_like(z)
        if self.factorized:
            a = self.from_head(torch.cat((context,z[:,0]),1)) - self.from_head(torch.cat((context,zero[:,0]),1))
            b = self.to_head(torch.cat((context,z[:,1]),1)) - self.to_head(torch.cat((context,zero[:,1]),1))
            return (a[...,None]+b[:,None,:]).flatten(1)
        mask = observed.to(context.dtype)
        return self.direct(torch.cat((context,z.flatten(1),mask),1)) - self.direct(
            torch.cat((context,zero.flatten(1),mask),1))


def configure(device):
    torch.set_num_threads(2)
    torch.manual_seed(21721)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_tf32 = False
    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested, but PyTorch CUDA is unavailable")


def smoke(device, out):
    configure(device)
    n = 48
    c = torch.randn(n,34,device=device)
    z = torch.randn(n,2,5,device=device)
    op = torch.ones(n,2,dtype=torch.bool,device=device)
    clear = torch.zeros_like(op)
    raw = torch.randn(n,K*K,device=device)
    outputs = {}
    for factor in (False,True):
        net = Evidence(c.shape[-1],z.shape[-1],factor).to(device)
        assert torch.equal(net(c,z,clear),torch.zeros_like(raw))
        assert torch.equal(net(c,torch.zeros_like(z),op),torch.zeros_like(raw))
        if factor:
            a = net(c,z,op & (torch.arange(2,device=device)==0)).reshape(n,K,K)
            b = net(c,z,op & (torch.arange(2,device=device)==1)).reshape(n,K,K)
            assert torch.equal(a[:,:,0],a[:,:,1]) and torch.equal(b[:,0,:],b[:,1,:])
        optimizer = torch.optim.AdamW(net.parameters(),lr=.002)
        first = [v.detach().clone() for v in net.parameters()]
        for step in range(8):
            loss = cross_entropy(raw+net(c,z,op),torch.arange(n,device=device)%36)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            assert torch.isfinite(loss)
        assert any(not torch.equal(a,b) for a,b in zip(first,net.parameters()))
        outputs["factorized" if factor else "ordinary"] = {
            "steps":8,"last_loss":float(loss.detach()),"n_parameters":sum(p.numel() for p in net.parameters())}
    payload = {"kind":"E021_smoke","at":time.strftime("%Y-%m-%dT%H:%M:%S%z"),"device":device,
        "gpu":torch.cuda.get_device_name() if device=="cuda" else None,"torch":str(torch.__version__),
        "precision":"FP32, TF32 disabled","both_passed":True,"checks":outputs,
        "script_sha256":sha(__file__)}
    if out:
        write_json(out,payload)
    print(json.dumps(payload,ensure_ascii=False),flush=True)


def threshold(scores, truth, cap=.10):
    stable = np.sort(scores[truth//K == truth%K])[::-1]
    if not len(stable):
        return np.inf
    k = math.floor(cap*len(stable))
    if k == len(stable):
        return -np.inf
    # Float32 predictions are converted first so nextafter really excludes this tie group.
    return np.nextafter(float(stable[k]), np.inf)


def fixed_choice(scores, quota):
    selected = np.zeros(len(scores),dtype=bool)
    selected[np.argsort(-scores,kind="stable")[:int(quota)]] = True
    return selected


def counts(truth, path, pair, picked):
    change = truth//K != truth%K
    persistent = path==1
    return np.array([len(truth), change.sum(), picked.sum(), (picked & change).sum(),
        (picked & change & (pair==truth)).sum(), (picked & ~change).sum(),
        (picked & persistent & (truth//K==pair//K)).sum(),
        (picked & persistent & (truth%K==pair%K)).sum()],dtype=np.int64)


def summarize(count):
    fields = ("pairs","true_change","alarms","binary_tp","strict_tp","stable_fp",
              "persistent_from_alarms","persistent_to_alarms")
    result = {f:int(v) for f,v in zip(fields,count)}
    result["strict_F1"] = float(200*count[4]/(count[1]+count[2])) if count[1]+count[2] else None
    result["binary_recall"] = float(100*count[3]/count[1]) if count[1] else None
    result["stable_FPR"] = float(100*count[5]/(count[0]-count[1])) if count[0]>count[1] else None
    return result


def evidence_stats(scores, truth, path, proposed):
    out = {}
    for label, state in (("persistent_from",proposed//K),("persistent_to",proposed%K)):
        true_move = truth==proposed
        stable_code = state * (K+1)
        select = true_move | ((truth==stable_code)&(path==1))
        loc = np.flatnonzero(select)
        odds = scores[loc,proposed[select]] - scores[loc,stable_code[select]]
        side = np.where(true_move[select],-1,1)
        out[label] = [len(loc),float(np.logaddexp(0,odds*side).sum())]
    return out


def fit_batches(net, scoring, y, fit, steps, seed, name):
    rng = np.random.default_rng(seed)
    optim = torch.optim.AdamW(net.parameters(),lr=.002,weight_decay=.01)
    net.train()
    for step in range(steps):
        idx = rng.choice(fit,min(1024,len(fit)),replace=False)
        logits = scoring(idx)
        loss = cross_entropy(logits,y[idx])
        if not torch.isfinite(loss):
            raise RuntimeError(f"{name} non-finite loss at step {step+1}")
        optim.zero_grad(set_to_none=True)
        loss.backward()
        optim.step()
        if step in (0,steps-1):
            print(f"{name} update {step+1}/{steps} loss={float(loss.detach()):.5f}",flush=True)
    net.eval()


def run_fold(data, area_roles, steps, seed, device, name):
    xa, zd, wrong, obs, y, path, region, rawp = (data[key] for key in (
        "context","delta","placebo","observed","truth","path","region","prob"))
    fit, cal, test = [np.flatnonzero(np.isin(region,regions)) for regions in area_roles]
    assert min(len(fit),len(cal),len(test))>0
    n_observed = int(obs[np.r_[fit,cal,test]].any(1).sum())
    if not obs[fit].any() or not obs[test].any():
        raise ValueError(f"{name} has no additional observations in fit or test")
    mu = xa[fit].mean(0,dtype=np.float64)
    sd = np.maximum(.02,xa[fit].std(0,dtype=np.float64))
    to_t = lambda v: torch.as_tensor(v,dtype=torch.float32,device=device)
    x = to_t(np.clip((xa-mu)/sd,-5,5))
    training_z = zd[fit][obs[fit]]
    scale = np.maximum(.05,training_z.std(axis=0,dtype=np.float64))
    zs = to_t(np.clip(zd/scale,-5,5))
    zs_wrong = to_t(np.clip(wrong/scale,-5,5))
    valid = torch.as_tensor(obs,dtype=torch.bool,device=device)
    yt = torch.as_tensor(y,dtype=torch.long,device=device)
    p0,p1 = rawp[:,0],rawp[:,1]
    outer = to_t(np.log(np.maximum(p0[:,:,None]*p1[:,None,:],1e-8)).reshape(-1,36))
    average = (p0+p1)/2
    js = sum(.5*(p*np.log(np.maximum(p,1e-8)/np.maximum(average,1e-8))).sum(1) for p in (p0,p1))
    outer_np = outer.cpu().numpy()
    proposal = DIFFERENT[outer_np[:,DIFFERENT].argmax(1)]
    raw_change = p0.argmax(1)!=p1.argmax(1)
    cat = {}
    index = np.r_[cal,test]
    torch.manual_seed(seed)
    anchor = mlp(x.shape[1],32,36).to(device)
    fit_batches(anchor,lambda idx: outer[idx]+anchor(x[idx]),yt,fit,steps,seed,name+"/anchor")
    with torch.no_grad():
        fixed = outer + anchor(x)
    cat["anchor"] = fixed[index].cpu().numpy()
    for arm in ARMS[2:]:
        candidate = Evidence(x.shape[-1],zs.shape[-1],arm.startswith("factorized")).to(device)
        z = zs_wrong if arm.endswith("_placebo") else zs
        scoring = lambda idx: fixed[idx]+candidate(x[idx],z[idx],valid[idx])
        # A common draw order limits sampling variance in paired comparisons.
        fit_batches(candidate,scoring,yt,fit,steps,seed,name+"/"+arm)
        with torch.no_grad():
            cat[arm] = scoring(index).cpu().numpy()
    out = {}
    for arm in ARMS:
        if arm=="JS":
            score,pair = js[index],proposal[index]
            mech = evidence_stats(outer_np[test],y[test],path[test],proposal[test])
        else:
            all_scores = cat[arm]
            normalized = np.exp(all_scores-all_scores.max(1,keepdims=True))
            normalized /= normalized.sum(1,keepdims=True)
            best = normalized[:,DIFFERENT].argmax(1)
            pair = DIFFERENT[best]
            score = normalized[np.arange(len(normalized)),pair]
            mech = evidence_stats(all_scores[len(cal):],y[test],path[test],proposal[test])
        th = threshold(score[:len(cal)],y[cal])
        test_score = score[len(cal):].astype(np.float64)
        pair_test = pair[len(cal):]
        by_area = {}
        for ri in np.unique(region[test]):
            sel = region[test]==ri
            yy,pp,ps = y[test][sel],path[test][sel],pair_test[sel]
            quota = raw_change[test][sel].sum()
            by_area[str(int(ri))] = {
                "equal_alerts":summarize(counts(yy,pp,ps,fixed_choice(test_score[sel],quota))),
                "source_threshold":summarize(counts(yy,pp,ps,test_score[sel]>=th))}
        out[arm] = {"areas":by_area,"source_threshold":float(th) if np.isfinite(th) else None,
                    "mechanism_loss_sum_n":mech}
    return {"roles":[list(map(int,r)) for r in area_roles],"observed_rows":n_observed,"arms":out}


def read_packet(path):
    with np.load(path,allow_pickle=False) as f:
        info = json.loads(f["meta"].item())
        data = {k:f[k] for k in ("context","delta","placebo","observed","truth","path","region","prob")}
    assert info["kind"]=="E021_source_packet" and info["split"]=="source_only"
    n = len(data["truth"])
    assert n==info["sample_count"] and all(len(v)==n for v in data.values())
    assert data["prob"].shape==(n,2,6) and data["delta"].shape==data["placebo"].shape==(n,2,5)
    assert data["observed"].shape==(n,2) and np.issubdtype(data["truth"].dtype,np.signedinteger)
    assert data["truth"].min()>=0 and data["truth"].max()<36
    assert np.isfinite(data["context"]).all() and np.isfinite(data["delta"]).all() and np.isfinite(data["placebo"]).all()
    regions = info["regions"]
    assert len(data["region"]) and set(data["region"])==set(range(len(regions)))
    return info,data


def scheduled_roles(meta, shard):
    entries = meta["regions"]
    rnd = np.random.default_rng(211118)
    for parent in sorted({ent["parent"] for ent in entries}):
        eligible = [i for i,ent in enumerate(entries) if ent["parent"]==parent]
        members = {g:[i for i in eligible if entries[i]["geo"]==g] for g in sorted({entries[i]["geo"] for i in eligible})}
        groups = rnd.permutation(sorted(members))
        assert len(groups)>=5
        bins = [group.tolist() for group in np.array_split(groups,5)]
        for fold in range(5):
            if shard=="jia" and fold not in (0,2,4):
                continue
            if shard=="yi" and fold not in (1,3):
                continue
            calibrate = (fold+1)%5
            fit = [i for k,b in enumerate(bins) if k not in (calibrate,fold) for g in b for i in members[g]]
            cal = [i for g in bins[calibrate] for i in members[g]]
            test = [i for g in bins[fold] for i in members[g]]
            role_groups = [{entries[i]["geo"] for i in role} for role in (fit,cal,test)]
            assert not (role_groups[0]&role_groups[1] or role_groups[0]&role_groups[2] or role_groups[1]&role_groups[2])
            yield f"p{parent}/f{fold}", (fit,cal,test)


def run(path, out, device, seed, steps, shard, limit=None):
    configure(device)
    meta,data = read_packet(path)
    fp = sha(path)
    status = {"kind":"E021_pair_results","state":"running","packet_sha256":fp,"packet":meta,
              "fp32":True,"device":device,"seed":seed,"steps_per_arm":steps,"shard":shard,
              "gpu":torch.cuda.get_device_name() if device=="cuda" else None,
              "script_sha256":sha(__file__),"folds":{}}
    out = Path(out)
    if out.exists():
        old = json.loads(out.read_text(encoding="utf8"))
        keys = ("packet_sha256","seed","steps_per_arm","shard","device","script_sha256")
        if any(old.get(k)!=status[k] for k in keys):
            raise ValueError("Output already exists for a different configuration")
        if old["state"]=="complete":
            return old
        status["folds"] = old["folds"]
    for i,(name,roles) in enumerate(scheduled_roles(meta,shard)):
        if limit is not None and i>=limit:
            break
        if name not in status["folds"]:
            status["folds"][name] = run_fold(data,roles,steps,seed,device,name)
            write_json(out,status)
    status["state"] = "complete" if limit is None else "smoke_complete"
    write_json(out,status)
    return status


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--device",choices=("cpu","cuda"),default="cpu")
    parser.add_argument("--in-packet",type=Path)
    parser.add_argument("--out",type=Path)
    parser.add_argument("--seed",type=int,default=42)
    parser.add_argument("--steps",type=int,default=180)
    parser.add_argument("--shard",choices=("all","jia","yi"),default="all")
    parser.add_argument("--smoke",action="store_true")
    args = parser.parse_args()
    if args.smoke:
        smoke(args.device,args.out)
        return
    if not args.in_packet or not args.out or args.steps<1:
        parser.error("Supply --in-packet, --out and a positive --steps.")
    run(args.in_packet,args.out,args.device,args.seed,args.steps,args.shard)


if __name__=="__main__":
    main()
