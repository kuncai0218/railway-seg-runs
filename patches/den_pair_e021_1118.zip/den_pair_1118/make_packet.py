"""Extract a small, aligned packet from local source-only imagery and frozen outputs."""
import argparse
import datetime as dt
import json
import os
import sys
from pathlib import Path

import numpy as np
from PIL import Image

from paired_heads import configure, sha, write_json

MONTHS = [0,3,6,9,13,16,19,23]
DAYS = [(dt.date(2018+m//12,m%12+1,1)-dt.date(2018,1,1)).days for m in MONTHS]
EARLY = [d+14 for d in DAYS[:-1]]
LATE = [d-14 for d in DAYS[1:]]
BLOCKS = [7,6]
NPIX = 16**2
YX = np.meshgrid(np.arange(2,128,8),np.arange(2,128,8),indexing="ij")
HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def regions(raw):
    obj = read(raw/"split.json")
    source = sorted(obj["train"])
    assert len(source)==55 and len(set(source))==55
    assert not (set(source)&set(obj["val"]+obj["test"]))
    return source


def scene_paths(raw, rid, day):
    stem = f"{rid}_{day}"
    return tuple(raw/"train"/rid/(stem+s) for s in ("_rgb.jpeg","_infra.jpeg"))


def inventory(raw, source, cache=None):
    details = {}
    cached_days = set(read(cache/"index.json")["days"]) if cache and (cache/"index.json").is_file() else set()
    for rid in source:
        stored = cached_days if cache and (cache/(rid+".blk.npy")).is_file() else set()
        selected = sorted(set(EARLY+LATE))
        misses = [d for d in selected if d not in stored and not all(p.is_file() for p in scene_paths(raw,rid,d))]
        details[rid] = {"missing_nominal_days":misses,"label_present":(raw/"labels"/(rid+".npy")).is_file()}
    return details


def samples(raw, rid, cache=None):
    a = np.zeros((len(BLOCKS),NPIX,4),dtype=np.uint8)
    images = {}
    cache_block = None
    cache_days = None
    if cache:
        cache_days = read(cache/"index.json")["days"]
        cache_block = np.load(cache/(rid+".blk.npy"),mmap_mode="r")
    for day in sorted(set(DAYS+EARLY+LATE)):
        rgb,air = scene_paths(raw,rid,day)
        if cache_block is not None and day in cache_days:
            row = cache_days.index(day)
            images[day] = np.stack([cache_block[b,b,row,2::8,2::8] for b in BLOCKS]).reshape(len(BLOCKS),NPIX,4)
            continue
        if not rgb.is_file() or not air.is_file():
            images[day] = a
            continue
        with Image.open(rgb) as ri,Image.open(air) as ni:
            assert ri.mode=="RGB" and ri.size==ni.size==(1024,1024)
            rgb_array = np.asarray(ri)
            nir_array = np.asarray(ni)
            if nir_array.ndim==3:
                nir_array=nir_array[...,0]
            y,x=YX
            frames=[np.dstack((rgb_array[y+b*128,x+b*128,:],nir_array[y+b*128,x+b*128])) for b in BLOCKS]
            images[day]=np.stack(frames).reshape(len(BLOCKS),NPIX,4)
    return images


def spectral(features):
    v = features.astype(np.float32)/255
    color = (v[:,3]-v[:,0])/np.maximum(v[:,3]+v[:,0],.02)
    return np.column_stack((v,color)).astype(np.float32)


def head_context(anchor, other, start, end, old, new, both_present):
    mix = (anchor+other)/2
    js = sum(.5*(p*np.log(np.maximum(p,1e-8)/np.maximum(mix,1e-8))).sum(1) for p in (anchor,other))
    phases = 2*np.pi*np.array((start,end))/365.25
    date = np.tile(np.r_[np.sin(phases),np.cos(phases),(end-start)/90],(len(anchor),1))
    return np.column_stack((anchor,other,np.abs(anchor-other),js,date,old,new,both_present)).astype(np.float32)


def count_path(truth):
    closed = truth[0]==truth[-1]
    valid = (truth<6).all(0)
    changes = (truth[1:]!=truth[:-1]).sum(0)
    return np.select((~valid,changes==0,closed),(0,1,2),default=3).astype(np.int8)


def new_rows(ri, truth, probs, images, blocks):
    for bi,b in enumerate(blocks):
        label = truth[:,b*128:(b+1)*128,b*128:(b+1)*128]
        q = probs[bi][:,:,2::8,2::8].transpose(0,2,3,1).reshape(8,NPIX,6).astype(np.float32)
        assert np.isfinite(q).all() and np.max(np.abs(q.sum(-1)-1))<.002
        q /= q.sum(-1,keepdims=True)
        donor = np.roll(np.arange(NPIX), 97+(ri+b)%61)
        for slot,(m,n) in enumerate(zip(MONTHS,MONTHS[1:])):
            window = label[m:n+1,2::8,2::8].reshape(n-m+1,NPIX)
            valid = (window[0]<6)&(window[-1]<6)
            old,new = [images[d][bi] for d in DAYS[slot:slot+2]]
            real = np.stack([images[EARLY[slot]][bi],images[LATE[slot]][bi]],axis=1)
            have_anchor = np.column_stack(((old!=0).any(1),(new!=0).any(1)))
            obs = (real!=0).any(2)&(real[donor]!=0).any(2)&have_anchor
            endpoint = [spectral(old),spectral(new)]
            z = np.stack([spectral(real[:,side])-endpoint[side] for side in (0,1)],axis=1)
            control = np.stack([spectral(real[donor,side])-endpoint[side] for side in (0,1)],axis=1)
            common = head_context(q[slot],q[slot+1],DAYS[slot],DAYS[slot+1],*endpoint,have_anchor)
            y=window[0].astype(np.int16)*6+window[-1]
            yield {
                "context":common[valid],"delta":z[valid],"placebo":control[valid],"observed":obs[valid],
                "truth":y[valid],"path":count_path(window)[valid],"region":np.full(valid.sum(),ri,dtype=np.int16),
                "prob":np.stack((q[slot],q[slot+1]),axis=1)[valid]}


def stored_predictions(args, source):
    if args.t32:
        dump = args.t32
        info = read(dump/"meta.json")
        assert info["split"]=="val_oof" and info["regions"]==source and info["patches_per_region"]==64
        assert info["K"]==info["ignore"]==6
        folds = read(args.folds)
        assert sha(args.folds)==info["folds_sha256"] and folds["all_train_sorted"]==source
        index = {}
        for parent,row in folds["folds"].items():
            assert info["ckpts"][parent]["epoch"]==30
            for rid in row["hold_regions"]:
                assert rid not in index
                index[rid]=int(parent)
        assert set(index)==set(source)
        input_dirs = {0:dump}
        families = {rid:(j,index[rid],0,[j*64+b*8+b for b in BLOCKS]) for j,rid in enumerate(source)}
        mode="t32_75channel_seed42_nominal_screen"
    else:
        input_dirs = {p:args.legacy/f"pse_3src_gate0_f{p}_e30_s42/dump_last_pbn/plain/val_in" for p in (0,1)}
        ids = {}
        for p,d in input_dirs.items():
            assert read(d/"meta.json")["regions"]==source
            meta = read(d.parents[2]/"config.json")["args"]
            assert (meta["n_folds"],meta["hold_fold"],meta["seed"])==(2,p,42)
            ids[p] = np.load(d/"region.npy",allow_pickle=False)
        families={rid:(j,j%2,j%2,np.flatnonzero(ids[j%2]==j)) for j,rid in enumerate(source)}
        mode="legacy_pse_seed42_nominal_screen"
    stacks = {}
    for p,d in input_dirs.items():
        probabilities=np.load(d/"probs.npy",mmap_mode="r")
        gt=np.load(d/"gt.npy",mmap_mode="r")
        days=np.load(d/"days.npy",allow_pickle=False)
        rows=np.load(d/"region.npy",allow_pickle=False)
        assert probabilities.shape==(len(rows),8,6,128,128) and gt.shape==(len(rows),8,128,128)
        assert probabilities.dtype==np.float16 and np.all(days==DAYS)
        stacks[p] = (probabilities,gt,rows)
    def by_region(rid, truth):
        ri,parent,stack,row_ids = families[rid]
        pr,gt,idx = stacks[stack]
        assert len(row_ids)==2 and np.all(idx[row_ids]==ri)
        for b,n in zip(BLOCKS,row_ids):
            assert np.array_equal(gt[n],truth[MONTHS,b*128:(b+1)*128,b*128:(b+1)*128])
        return parent,pr[row_ids]
    provenance = {str(key):{"meta_sha256":sha(d/"meta.json"),"days_sha256":sha(d/"days.npy")} for key,d in input_dirs.items()}
    return source,mode,by_region,provenance


def compact_teacher(args, source):
    import torch
    cfg = read(args.checkpoint.parent/"config.json")
    hold = cfg["split"]["hold"]
    assert sorted(hold)==source[::5]
    assert sorted(cfg["split"]["train"])==sorted(set(source)-set(hold))
    assert cfg["args"]["arm"]=="current" and cfg["args"]["device"]=="cuda"
    for name in ("model.py","backbone.py"):
        assert sha(args.teacher_code/name)==cfg["code_SHA256"][name], name
    configure(args.device)
    sys.path.insert(0,str(args.teacher_code))
    from model import HistoryModel
    model = HistoryModel("current").to(args.device).eval()
    cp = torch.load(args.checkpoint,map_location=args.device,weights_only=True)
    assert cp["step"]==cfg["args"]["steps"]==12000
    model.load_state_dict(cp["model"])
    cache_index = read(args.cache/"index.json")
    cache_days = [cache_index["days"].index(d) for d in DAYS]
    def by_region(rid, _):
        arr=np.load(args.cache/(rid+".blk.npy"),mmap_mode="r")
        assert arr.shape[:2]==(8,8) and arr.shape[-3:]==(128,128,4) and arr.dtype==np.uint8
        x=np.stack([arr[b,b,cache_days] for b in BLOCKS]).transpose(0,1,4,2,3).copy()
        x=torch.from_numpy(x).to(args.device).float()/255.
        day=torch.tensor(DAYS,dtype=torch.float32,device=args.device)[None].expand(len(x),-1).contiguous()
        with torch.inference_mode():
            q=model(x,day)["logits"].softmax(2).cpu().numpy()
        return 0,q
    provenance={"checkpoint_sha256":sha(args.checkpoint),"config_sha256":sha(args.checkpoint.parent/"config.json"),
                "backbone_seed":cfg["args"]["seed"],"cache_index_sha256":sha(args.cache/"index.json")}
    return hold,"e015_compact_teacher_nominal_screen",by_region,provenance


def build(args):
    source = regions(args.raw_root)
    geo = read(args.geo)
    assert sorted(geo["groups"])==source
    if args.inventory:
        select = source[::5] if args.compact_inventory else source
        data = inventory(args.raw_root,select,args.cache)
        payload = {"kind":"E021_input_inventory","regions":len(select),"calendar_dates_only":True,
                   "dates_ok_regions":sum(v["label_present"] and not v["missing_nominal_days"] for v in data.values()),
                   "missing":{r:v for r,v in data.items() if v["missing_nominal_days"] or not v["label_present"]}}
        write_json(args.out,payload)
        print(json.dumps(payload,ensure_ascii=False),flush=True)
        return
    loader = compact_teacher if args.checkpoint else stored_predictions
    selection,mode,predict,provenance = loader(args,source)
    results,area = [],[]
    for ri, rid in enumerate(selection):
        lab=np.load(args.raw_root/"labels"/(rid+".npy"),mmap_mode="r")
        assert lab.shape==(24,1024,1024) and lab.dtype==np.uint8
        parent,q=predict(rid,lab)
        images=samples(args.raw_root,rid,args.cache)
        results.extend(new_rows(ri,lab,q,images,BLOCKS))
        area.append({"id":rid,"parent":parent,"geo":geo["groups"][rid]})
    packed={k:np.concatenate([p[k] for p in results]) for k in results[0]}
    metadata={"kind":"E021_source_packet","split":"source_only","family":mode,"regions":area,
              "acquisition_identified":False,"days":DAYS,"early_and_late":[EARLY,LATE],
              "sample_count":len(packed["truth"]),"valid_window_samples":packed["observed"].sum(0).tolist(),
              "frozen":provenance,"extractor_sha256":sha(__file__)}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    tmp=args.out.with_name(args.out.name+f".{os.getpid()}.tmp")
    with tmp.open("wb") as f:
        np.savez_compressed(f,meta=json.dumps(metadata,ensure_ascii=False),**packed)
    os.replace(tmp,args.out)
    print(json.dumps({k:metadata[k] for k in ("family","sample_count","valid_window_samples")}),flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--raw-root",type=Path,required=True)
    parser.add_argument("--out",type=Path,required=True)
    parser.add_argument("--geo",type=Path,default=HERE/"geo_source.json")
    option=parser.add_mutually_exclusive_group(required=True)
    option.add_argument("--legacy",type=Path)
    option.add_argument("--t32",type=Path)
    option.add_argument("--checkpoint",type=Path)
    option.add_argument("--inventory",action="store_true")
    parser.add_argument("--folds",type=Path)
    parser.add_argument("--teacher-code",type=Path)
    parser.add_argument("--cache",type=Path)
    parser.add_argument("--device",choices=("cpu","cuda"),default="cpu")
    parser.add_argument("--compact-inventory",action="store_true")
    args=parser.parse_args()
    if args.t32 and not args.folds:
        parser.error("--t32 requires --folds")
    if args.checkpoint and not (args.teacher_code and args.cache):
        parser.error("--checkpoint requires --teacher-code and --cache")
    build(args)


if __name__=="__main__":
    main()
