"""Run the E021 local-data pilot and send bounded stage receipts for the coordinator."""
import argparse
import datetime as dt
import json
import subprocess
import sys
import urllib.request
from pathlib import Path

from make_packet import DAYS, EARLY, LATE, inventory, read, regions
from paired_heads import sha, smoke, write_json

HERE = Path(__file__).resolve().parent
TASK = {"jia":("jia-den-e021-1118",43),"yi":("yi-den-e021-1118",44)}
WORK = Path.home()/"work_st3d"


def resources():
    run = subprocess.run(
        ["nvidia-smi","--query-gpu=name,memory.used,memory.total,utilization.gpu","--format=csv,noheader"],
        text=True,capture_output=True,timeout=10,check=True)
    return run.stdout.strip().splitlines()[0]


def receipt(args, state, **detail):
    task,seed = TASK[args.name]
    obj = {"kind":"E021_DEN_competing_transitions","instruction":task,"node":args.name,"seed":seed,
        "state":state,"at":dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "runner_sha256":sha(__file__),"package_sha256":args.package_sha,
        "details":detail}
    write_json(args.out/"status.json",obj)
    print(json.dumps(obj,ensure_ascii=False),flush=True)
    if not args.notify:
        return
    try:
        url = "https://ntfy.sh/railseg-d4a86d-status-"+args.name
        body = json.dumps(obj,ensure_ascii=False,separators=(",",":")).encode("utf-8")
        request=urllib.request.Request(url,body,method="POST",headers={
            "Title":f"E021 DEN {args.name} {state}","Content-Type":"text/plain; charset=utf-8"})
        assert len(body)<=4096
        with urllib.request.urlopen(request,timeout=12) as response:
            response.read(4096)
    except Exception as err:
        print("Status was recorded locally. Status service:",type(err).__name__,flush=True)


def call(script,*arguments):
    subprocess.run([sys.executable,"-u","-X","utf8",str(script),*map(str,arguments)],check=True)


def valid_teacher(cp, seed):
    if not cp.is_file() or not (cp.parent/"completed.json").is_file():
        return False
    data = read(cp.parent/"completed.json")
    config = read(cp.parent/"config.json")["args"]
    return (data["steps"]==12000 and data["seed"]==seed and data["arm"]=="current"
        and not data["smoke"] and data["checkpoint_SHA256"]==sha(cp)
        and config["amp_dtype"]=="float32")


def report_scores(result):
    arms = {}
    for stage in result["folds"].values():
        for arm,d in stage["arms"].items():
            saved = arms.setdefault(arm,[0,0,0])
            for r in d["areas"].values():
                q = r["equal_alerts"]
                saved[0] += q["strict_tp"]
                saved[1] += q["true_change"]
                saved[2] += q["alarms"]
    return {a:round(200*k/(z+b),4) if z+b else None for a,(k,z,b) in arms.items()}


def execute(args):
    seed = TASK[args.name][1]
    teacher_code = HERE/"teacher"
    args.out.mkdir(parents=True,exist_ok=True)
    receipt(args,"received",gpu=resources(), paired_runner_sha256=sha(HERE/"paired_heads.py"))
    smoke("cuda",args.out/"smoke_cuda.json")
    receipt(args,"cuda_smoke_complete",smoke_sha256=sha(args.out/"smoke_cuda.json"))
    if not (args.raw_root/"split.json").is_file():
        receipt(args,"waiting_local_input",missing="official source split.json",cuda_smoke=True)
        return
    source = regions(args.raw_root)
    hold = source[::5]
    expected = set(EARLY+LATE)
    checklist = inventory(args.raw_root,hold,args.cache)
    if not (args.cache/"index.json").is_file():
        receipt(args,"waiting_local_input",missing="8-date source cache index",cuda_smoke=True)
        return
    cache_days = set(read(args.cache/"index.json")["days"])
    no_labels = [r for r,d in checklist.items() if not d["label_present"]]
    no_cache = [r for r in hold if not (args.cache/(r+".blk.npy")).is_file()]
    sources = [r for r,d in checklist.items() if set(d["missing_nominal_days"])!=expected]
    write_json(args.out/"day_inventory.json",checklist)
    if no_labels or no_cache or not set(DAYS).issubset(cache_days) or len(sources)<6:
        receipt(args,"waiting_local_input",label_missing=len(no_labels),cache_missing=len(no_cache),
                observed_site_count=len(sources),hold_sites=len(hold),gpu_smoke=True,
                inventory_sha256=sha(args.out/"day_inventory.json"))
        return
    cp = args.checkpoint or WORK/f"e015_v3_fp32_runs_s{seed}_1117/current_s{seed}/last.pth"
    if not valid_teacher(cp,seed):
        cp = args.out/"teacher_current"/"last.pth"
    if not valid_teacher(cp,seed):
        lack = [r for r in source if not (args.cache/(r+".blk.npy")).is_file() or
                not (args.raw_root/"labels"/(r+".npy")).is_file()]
        if lack:
            receipt(args,"waiting_local_input",missing="source55 assets for FP32 teacher",
                    missing_sites=len(lack),observed_site_count=len(sources),gpu_smoke=True)
            return
        receipt(args,"starting_fp32_teacher",step_goal=12000)
        call(teacher_code/"train.py","--raw-root",args.raw_root,"--cache-root",args.cache,
             "--arm","current","--seed",seed,"--out",cp.parent,"--steps",12000,
             "--eval-every",3000,"--device","cuda","--amp-dtype","float32")
    if not valid_teacher(cp,seed):
        raise ValueError("FP32 teacher integrity check failed")
    packet = args.out/"source_pairs.npz"
    if not packet.is_file():
        receipt(args,"extracting_source_packet",observed_site_count=len(sources),teacher_sha256=sha(cp))
        call(HERE/"make_packet.py","--raw-root",args.raw_root,"--cache",args.cache,
             "--checkpoint",cp,"--teacher-code",teacher_code,"--device","cuda","--out",packet)
    result = args.out/"paired_results.json"
    receipt(args,"starting_paired_heads",steps_per_arm=180,packet_sha256=sha(packet),
            folds=[0,2,4] if args.name=="jia" else [1,3])
    call(HERE/"paired_heads.py","--in-packet",packet,"--out",result,"--device","cuda",
         "--steps",180,"--seed",seed,"--shard",args.name)
    data = read(result)
    assert data["state"]=="complete" and len(data["folds"])==(3 if args.name=="jia" else 2)
    receipt(args,"complete",folds=list(data["folds"]),result_sha256=sha(result),
            equal_alert_strict_F1=report_scores(data),source="4band E015 teacher, nominal-date screen")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--name",choices=tuple(TASK),required=True)
    parser.add_argument("--raw-root",type=Path,default=WORK/"E002_1112/den_raw_source55")
    parser.add_argument("--cache",type=Path,default=WORK/"DENH_source55_8date/train")
    parser.add_argument("--checkpoint",type=Path)
    parser.add_argument("--out",type=Path,required=True)
    parser.add_argument("--package-sha",required=True)
    parser.add_argument("--notify",action="store_true")
    args = parser.parse_args()
    try:
        execute(args)
    except Exception as err:
        receipt(args,"failed",error_type=type(err).__name__)
        raise


if __name__=="__main__":
    main()
