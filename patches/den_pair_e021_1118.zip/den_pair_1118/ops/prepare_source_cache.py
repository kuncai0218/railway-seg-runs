"""Prepare a NEW 8-date source55 cache from local cache/JPEGs; no downloads.

Never overwrites the E002 cache. Only original source train IDs are read.
Existing cache is sampled using its own date index; missing AOIs use the
same torchvision JPEG decoder as the project's original DEN cache builder.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import numpy as np

MONTHS = [0, 3, 6, 9, 13, 16, 19, 23]
DAYS = [(datetime.date(2018 + m // 12, m % 12 + 1, 1) - datetime.date(2018, 1, 1)).days for m in MONTHS]


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8 * 2**20), b""):
            h.update(chunk)
    return h.hexdigest()


def write(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-root", required=True)
    ap.add_argument("--existing-cache", required=True)
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--audit-only", action="store_true")
    ap.add_argument("--only", nargs="+")
    a = ap.parse_args()
    raw, cache, out = [Path(p).resolve() for p in (a.raw_root, a.existing_cache, a.out_root)]
    assert out != cache and out != raw and cache not in out.parents, "Use a separate cache directory"
    split = json.loads((raw / "split.json").read_text(encoding="utf-8"))
    source = sorted(split["train"])
    assert len(source) == 55
    assert not set(source) & set(split["val"] + split["test"])
    ids = a.only or source
    assert set(ids) <= set(source)
    idx = json.loads((cache / "index.json").read_text(encoding="utf-8"))
    rows = [idx["days"].index(d) for d in DAYS]
    jobs, missing = [], []
    for sid in ids:
        existing = cache / (sid + ".blk.npy")
        if existing.exists():
            x = np.load(existing, mmap_mode="r")
            assert x.dtype == np.uint8 and x.shape == (8, 8, len(idx["days"]), 128, 128, 4), str(existing)
            jobs.append({"sid": sid, "kind": "cache", "path": str(existing)})
        else:
            candidates = [raw / "train" / sid, raw / sid]
            folder = next((p for p in candidates if p.is_dir()), candidates[0])
            paths = [folder / (sid + "_" + str(d) + suffix) for d in DAYS for suffix in ("_rgb.jpeg", "_infra.jpeg")]
            missing.extend(str(p) for p in paths if not p.exists())
            jobs.append({"sid": sid, "kind": "JPEG", "folder": str(folder)})
        assert (raw / "labels" / (sid + ".npy")).exists()
    plan = {"days": DAYS, "source_ids": ids, "jobs": jobs, "missing_input_files": missing,
            "estimated_output_GiB": len(ids) * 8 * 1024 * 1024 * 4 / 2**30,
            "complete_source55": len(ids) == 55, "network_used": False,
            "source_cache_preserved": True, "official_val_test_read": False}
    print(json.dumps({k: v for k, v in plan.items() if k != "jobs"}, ensure_ascii=False), flush=True)
    if a.audit_only:
        return
    assert not missing, "Local raw images missing; report paths, do not silently download or change the source fold"
    out.mkdir(parents=True, exist_ok=True)
    assert shutil.disk_usage(out).free > (plan["estimated_output_GiB"] + 5) * 2**30
    write(out / "preparation_plan.json", plan)
    if (out / "index.json").exists():
        old = json.loads((out / "index.json").read_text(encoding="utf-8"))
        assert old["days"] == DAYS and old["tiles"] == ids
    else:
        write(out / "index.json", {"days": DAYS, "tiles": ids})
    records = []
    for job in jobs:
        sid = job["sid"]
        dest = out / (sid + ".blk.npy")
        receipt = out / (sid + ".receipt.json")
        if dest.exists():
            assert receipt.exists(), "Unverified prior file; retain and investigate " + str(dest)
            record = json.loads(receipt.read_text(encoding="utf-8"))
            assert sha(dest) == record["SHA256"]
            records.append(record)
            continue
        block = np.empty((8, 8, 8, 128, 128, 4), np.uint8)
        if job["kind"] == "cache":
            x = np.load(job["path"], mmap_mode="r")
            for i, r in enumerate(rows):
                block[:, :, i] = x[:, :, r]
            assert np.array_equal(block, x[:, :, rows])
        else:
            import torchvision
            for i, d in enumerate(DAYS):
                stem = Path(job["folder"]) / (sid + "_" + str(d))
                rgb = torchvision.io.read_image(str(stem) + "_rgb.jpeg").numpy()
                nir = torchvision.io.read_image(str(stem) + "_infra.jpeg").numpy()
                image = np.concatenate([rgb, nir[:1]], 0)
                assert image.shape == (4, 1024, 1024) and image.dtype == np.uint8
                block[:, :, i] = image.reshape(4, 8, 128, 8, 128).transpose(1, 3, 2, 4, 0)
                # Independently undo block layout and compare every decoded pixel.
                check = block[:, :, i].transpose(4, 0, 2, 1, 3).reshape(4, 1024, 1024)
                assert np.array_equal(check, image)
        temp = dest.with_suffix(".partial.npy")
        if not temp.exists():
            np.save(temp, block)
        check = np.load(temp, mmap_mode="r")
        assert np.array_equal(check, block)
        del check  # Windows cannot rename an open memory-mapped file.
        os.replace(temp, dest)
        record = dict(job, SHA256=sha(dest), bytes=dest.stat().st_size, days=DAYS, all_pixels_validated=True)
        write(receipt, record)
        records.append(record)
        print("complete", sid, job["kind"], flush=True)
    write(out / "preparation_complete.json", {"source55_complete": len(ids) == 55, "records": records,
                                             "no_network": True, "days": DAYS})


if __name__ == "__main__":
    main()
