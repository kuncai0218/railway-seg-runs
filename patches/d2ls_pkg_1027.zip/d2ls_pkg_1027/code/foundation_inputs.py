"""10-27 Claude（Wisc 会话）：分割第二步（A2）的输入方式，供 train_foundation.py 用。
bands = 12 波段；aux 或 aux-组+组 = 12 波段 + 22 层辅助（只保留所列组，其余为 0）；prev = 12 波段 + 同测点过去 180 天内最近一期的 12 波段 + 该期无云比例（没有则为 0）。
辅助层由 inputs_f16.npy 第 12—30 层现算，与 10-18 的 aux_f16.npy 逐值相同（10-26 已核对）；前期影像不用往年同期组（含后期影像的偏离特征）。"""
import json
import os
from pathlib import Path
import numpy as np

ROOT = Path(os.environ.get('RAIL_FRONTIER_ROOT', Path(__file__).resolve().parent.parent))
AUX_GROUPS = {'multiyear': [0, 1, 2, 3, 4, 5, 6, 20], 'hist': [7, 8, 9, 10, 11, 12, 13, 21],
              'terrain': [14, 15, 16, 17, 18], 'clear': [19]}


def n_channels(mode):
    return 12 if mode == 'bands' else 3 if mode == 'rgb' else 34 if mode.startswith('aux') else 25 if mode == 'prev' else None


class InputView:
    def __init__(self, base, mode, index):
        self.base, self.mode = base, mode
        self.channels = n_channels(mode)
        assert self.channels, f'未知输入方式 {mode}'
        self.shape = (base.shape[0], self.channels) + base.shape[2:]
        self.clouds = np.load(ROOT / 'assets/clouds_u8.npy', mmap_mode='r')
        self.before = np.array([w == 'before' for _, w in index['src']])
        if mode.startswith('aux'):
            groups = mode.split('-', 1)[1].split('+') if '-' in mode else list(AUX_GROUPS)
            assert all(g in AUX_GROUPS for g in groups), f'未知的辅助组 {groups}'
            self.keep = np.zeros(22, np.float32)
            for g in groups:
                self.keep[AUX_GROUPS[g]] = 1
        if mode == 'prev':
            self.frames = json.loads((ROOT / 'assets/temporal.json').read_text('utf-8'))

    def __getitem__(self, key):
        i, channels, *sl = key
        r, c = sl if sl else (slice(None), slice(None))
        if self.mode.startswith('aux'):
            x = np.asarray(self.base[i, :, r, c], np.float32)
            a = np.empty((22,) + x.shape[1:], np.float32)
            a[:19] = x[12:31]
            if self.before[i]:
                a[7:14] = 0
            a[19] = 1 - np.asarray(self.clouds[i, r, c], np.float32)
            a[20] = a[6]; a[21] = a[13]
            a *= self.keep[:, None, None]
            return np.concatenate([x[:12], a], 0)[channels]
        cur = np.asarray(self.base[i, :12, r, c], np.float32)
        row = self.frames[i]
        if len(row['indices']) > 1 and row['valid'][1]:
            j = row['indices'][1]
            prev = np.asarray(self.base[j, :12, r, c], np.float32)
            clear = 1 - np.asarray(self.clouds[j, r, c], np.float32)
        else:
            prev = np.zeros_like(cur); clear = np.zeros(cur.shape[1:], np.float32)
        return np.concatenate([cur, prev, clear[None]], 0)[channels]
