"""Official SAM3/SAM3.1 visual encoders with a declared custom five-class head.

These are task adaptations, not reproductions of the full prompt/video models.
All learned encoder tensors must match the publisher's checkpoint.
"""
from pathlib import Path
import hashlib,json,math,os,sys,types,importlib.util
import torch
from torch import nn
import torch.nn.functional as F

ROOT=Path(os.environ.get('RAIL_FRONTIER_ROOT',Path(__file__).resolve().parent))
RGB=[3,2,1]
def sha256(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

class LoRAQKV(nn.Module):
    def __init__(self,base,rank):
        super().__init__();self.base=base;self.rank=rank
        self.in_features=base.in_features;self.out_features=base.out_features
        self.a=nn.Linear(base.in_features,rank,bias=False);self.b=nn.Linear(rank,base.out_features,bias=False)
        nn.init.kaiming_uniform_(self.a.weight,a=math.sqrt(5));nn.init.zeros_(self.b.weight)
    def forward(self,x):return self.base(x)+self.b(self.a(x))

class SAMSemantic(nn.Module):
    def __init__(self,version,rank,channels):
        super().__init__();sys.path.insert(0,str(ROOT/'third_party/sam3'))
        from sam3.model_builder import _create_vision_backbone,_create_multiplex_tri_backbone
        self.version=version
        self.encoder=(_create_multiplex_tri_backbone(use_fa3=False,use_rope_real=False) if version=='sam31'
                      else _create_vision_backbone(enable_inst_interactivity=False))
        name='sam3.pt' if version=='sam3' else 'sam3.1_multiplex.pt'
        checkpoint=ROOT/'weights'/name
        expected={'sam3':'9999e2341ceef5e136daa386eecb55cb414446a00ac2b55eb2dfd2f7c3cf8c9e','sam31':'0567debeec80ba4ac6369540c6c248025283cb3ff2b92827509e57e2b3541cb6'}[version]
        assert sha256(checkpoint)==expected,'Publisher checkpoint hash differs'
        sd=torch.load(checkpoint,map_location='cpu',weights_only=True,mmap=True)
        if 'model' in sd:sd=sd['model']
        target=self.encoder.state_dict();prefixes=['detector.backbone.vision_backbone.','sam3_model.backbone.vision_backbone.','backbone.vision_backbone.']
        candidates=[{k.removeprefix(prefix):v for k,v in sd.items() if k.startswith(prefix)} for prefix in prefixes]
        selected=max(candidates,key=lambda s:len(set(s)&set(target)))
        matching={k:v for k,v in selected.items() if k in target and v.shape==target[k].shape}
        missing=set(target)-set(matching)
        assert not missing,('Incomplete learned visual backbone',sorted(missing)[:15])
        self.encoder.load_state_dict(matching,strict=True);del sd,selected,candidates,matching
        for block in self.encoder.trunk.blocks:
            if block.window_size==0:
                block.attn.input_size=(24,24)
                block.attn._setup_rope_freqs()
        self.encoder.requires_grad_(False)
        # Upstream's fused inference-only MLP detaches weights and rejects
        # autograd. Use the same Linear->GELU computation for adaptation.
        # All pretrained tensors remain unchanged and were loaded strictly.
        def differentiable_mlp(m,x):
            return m.drop2(m.fc2(m.norm(m.drop1(m.act(m.fc1(x))))))
        for m in self.encoder.modules():
            if type(m).__name__=='Mlp' and all(hasattr(m,k) for k in ['fc1','fc2','act','norm','drop1','drop2']):
                m.forward=types.MethodType(differentiable_mlp,m)
        adapted=[]
        if rank:
            for n,m in list(self.encoder.named_modules()):
                if n.endswith('.attn.qkv') and isinstance(m,nn.Linear):
                    parent,_,child=n.rpartition('.');setattr(self.encoder.get_submodule(parent),child,LoRAQKV(m,rank));adapted.append(n)
            assert len(adapted)==32,('Expected all32 SAM visual blocks',len(adapted))
        self.spectral=None
        if channels==12:
            self.spectral=nn.Conv2d(12,3,1,bias=False)
            with torch.no_grad():
                self.spectral.weight.zero_()
                for i,c in enumerate(RGB):self.spectral.weight[i,c]=1
        self.head=nn.Sequential(nn.Conv2d(256,128,3,padding=1),nn.GroupNorm(8,128),nn.GELU(),nn.Conv2d(128,5,1))
        self.rank=rank
        self.provenance=dict(version=version,publisher_sha256=expected,visual_tensors_loaded=len(target),strict_visual_load=True,lora_rank=rank,lora_modules=adapted,head='custom 256->128->5 convolutional head',model_input_resolution=336,raw_prompt_model=False,gradient_bridge='same Linear/GELU replaces inference-only fused MLP',geometry_bridge='official interpolated RoPE recalculated at336px; learned positional tensors unchanged',activation_checkpointing=bool(rank))
    def train(self,mode=True):
        super().train(mode);self.encoder.eval()
        if self.rank and mode:self.encoder.trunk.training=True
        return self
    def forward(self,x):
        shape=x.shape[-2:]
        if self.spectral is not None:x=self.spectral(x)
        # Existing trainer supplies ImageNet-standardized RGB. Convert to
        # physical reflectance and the official SAM image normalization.
        m=x.new_tensor([.485,.456,.406])[None,:,None,None];s=x.new_tensor([.229,.224,.225])[None,:,None,None]
        x=F.interpolate((x*s+m-.5)/.5,size=(336,336),mode='bilinear',align_corners=False)
        def encode():
            if self.version=='sam31':
                return self.encoder(x,need_interactive_out=False,need_propagation_out=False)[0][-1].tensors
            return self.encoder(x)[0][-2]
        if self.rank or self.spectral is not None:
            features=encode()
            if self.training and torch.is_grad_enabled():assert features.requires_grad
        else:
            with torch.no_grad():features=encode()
        return F.interpolate(self.head(features),size=shape,mode='bilinear',align_corners=False)

def build(arch,input_mode='rgb',backbone='small',weights_dir=None):
    if arch=='d2ls':
        path=ROOT/'third_party/D2LS/network/models/d2ls.py'
        namespace={'__name__':'rail_author_d2ls','__file__':str(path)}
        exec(compile(path.read_text('utf-8').replace('import cv2',''),str(path),'exec'),namespace)
        checkpoint=ROOT/'weights/convnext_base-6075fbad.pth';digest=sha256(checkpoint)
        assert digest.startswith('6075fbad'),'TorchVision ConvNeXt-B checkpoint hash differs'
        original=namespace['convnext_base']
        def offline_convnext(*args,**kwargs):
            m=original(weights=None);m.load_state_dict(torch.load(checkpoint,map_location='cpu',weights_only=True),strict=True);return m
        namespace['convnext_base']=offline_convnext
        base=namespace['DynamicDictionaryLearning'](model='convnext_base',token_length=5,num_classes=5,l=3,use_aux=True,has_contrastive_loss=True)
        class WrappedD2LS(nn.Module):
            def __init__(self,base):
                super().__init__();self.base=base;self.regularizer=None;self.input_adapter=None
                if input_mode!='rgb':   # 10-27：bands 为 12 通道；aux / prev 等为 12 + 辅助通道，辅助通道权重初始为 0（简单融合：输入端拼接、零初始化）
                    from foundation_inputs import n_channels
                    self.input_adapter=nn.Conv2d(n_channels(input_mode),3,1,bias=False)
                    with torch.no_grad():
                        self.input_adapter.weight.zero_()
                        for i,c in enumerate(RGB):self.input_adapter.weight[i,c]=1
            def forward(self,x):
                if self.input_adapter is not None:x=self.input_adapter(x)
                out=self.base(x)
                if isinstance(out,tuple) and len(out)==3:
                    self.regularizer=out[2];return out[:2]
                self.regularizer=None;return out
        model=WrappedD2LS(base)
        return model,dict(architecture='D2LS',repository='https://github.com/XavierJiezou/D2LS',author_source_sha256=sha256(path),checkpoint_sha256=digest,input=input_mode,classes=5,token_length=5,interactor_layers=3,auxiliary_weight=.4,contrastive_weight=.1,adaptation='official architecture; five class tokens; zero-extra 12-to-RGB adapter for multispectral arm',trainable_parameters=sum(p.numel() for p in model.parameters()))
    version='sam31' if arch.startswith('sam31') else 'sam3'
    rank=0 if arch.endswith('frozen') else int(arch.rsplit('lora',1)[1])
    model=SAMSemantic(version,rank,12 if input_mode=='bands' else 3)
    details=dict(architecture=arch,input=input_mode,repository='https://github.com/facebookresearch/sam3',adaptation='custom semantic encoder/head adaptation',trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),**model.provenance)
    return model,details
