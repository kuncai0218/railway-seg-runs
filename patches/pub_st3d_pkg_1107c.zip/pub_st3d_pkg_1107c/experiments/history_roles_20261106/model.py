"""Paired, frozen-encoder screen of task-specific temporal-context reading.

This is an offline T=8 experiment, not a causal/online detector. Both variants
have exactly the same parameters and inputs. A averages two score maps before
reading; B uses one map for semantic support and one for change reference.
The two endpoints of each target interval are excluded from contextual memory.
"""
from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F


def block(cin: int, cout: int, kernel: int = 1) -> nn.Sequential:
    return nn.Sequential(
        nn.Conv2d(cin, cout, kernel, padding=kernel // 2),
        nn.GroupNorm(4, cout), nn.SiLU(),
    )


class HistoryReader(nn.Module):
    def __init__(self, role_specific: bool, channels: int = 32,
                 hidden: int = 32, classes: int = 6, stride: int = 4):
        super().__init__()
        self.role_specific = role_specific
        self.hidden, self.classes, self.stride = hidden, classes, stride
        self.project = block(channels, hidden)
        self.key = nn.Conv2d(hidden, hidden, 1)
        self.value = nn.Conv2d(hidden, hidden, 1)
        self.queries = nn.ModuleList([
            nn.Sequential(block(3 * hidden, hidden), nn.Conv2d(hidden, hidden, 1))
            for _ in range(2)
        ])
        self.time_scores = nn.ModuleList([
            nn.Sequential(nn.Linear(3, 16), nn.SiLU(), nn.Linear(16, 1))
            for _ in range(2)
        ])
        self.null_scores = nn.Parameter(torch.zeros(2))
        self.semantic = nn.Sequential(block(4 * hidden, hidden, 3), nn.Conv2d(hidden, classes, 1))
        self.change = nn.Sequential(block(4 * hidden, hidden, 3), nn.Conv2d(hidden, 1, 1))
        # Both variants initially reproduce the identical frozen mono logits.
        for head in (self.semantic[-1], self.change[-1]):
            nn.init.zeros_(head.weight)
            nn.init.zeros_(head.bias)

    def forward(self, features: torch.Tensor, baseline_logits: torch.Tensor,
                positions: torch.Tensor, history_keep: torch.Tensor | None = None,
                return_attention: bool = False) -> dict[str, torch.Tensor]:
        b, t, c, height, width = features.shape
        if t < 2 or positions.shape != (b, t):
            raise ValueError("Need at least two dates and positions [batch, time].")
        if baseline_logits.shape != (b, t, self.classes, height, width):
            raise ValueError("Baseline logits must match the feature dates and image size.")
        p, d = t - 1, self.hidden
        pooled = F.avg_pool2d(features.reshape(b * t, c, height, width), self.stride)
        z = self.project(pooled)
        h, w = z.shape[-2:]
        keys = self.key(z).reshape(b, t, d, h, w)
        values = self.value(z).reshape(b, t, d, h, w)
        z = z.reshape(b, t, d, h, w)
        endpoints = torch.stack((z[:, :-1], z[:, 1:]), dim=2)  # B P 2 D h w
        other = endpoints.flip(2)
        query_input = torch.cat((endpoints, other, endpoints - other), dim=3)
        query_input = query_input.reshape(b * p * 2, 3 * d, h, w)

        # Relative time to each endpoint, relative time to its counterpart,
        # and interval length. No labels or predicted label confidence enter.
        ep_dates = torch.stack((positions[:, :-1], positions[:, 1:]), dim=2).float()
        dt = (positions[:, None, None, :].float() - ep_dates[..., None]) / 365.0
        dt_other = (positions[:, None, None, :].float() - ep_dates.flip(2)[..., None]) / 365.0
        gap = ((positions[:, 1:] - positions[:, :-1]).float() / 365.0)
        time_input = torch.stack((dt, dt_other, gap[:, :, None, None].expand_as(dt)), dim=-1)

        dates = torch.arange(t, device=features.device)
        intervals = torch.arange(p, device=features.device)
        valid = (dates[None] != intervals[:, None]) & (dates[None] != intervals[:, None] + 1)
        valid = valid[None, :, None, :, None, None].expand(b, p, 2, t, h, w)
        if history_keep is not None:
            if history_keep.shape == (t,):
                keep = history_keep[None].expand(b, t)
            elif history_keep.shape == (b, t):
                keep = history_keep
            else:
                raise ValueError("history_keep must have shape [time] or [batch, time].")
            valid = valid & keep.to(device=features.device, dtype=torch.bool)[:, None, None, :, None, None]

        scores = []
        for i in range(2):
            q = self.queries[i](query_input).reshape(b, p, 2, d, h, w)
            score = torch.einsum("bpedhw,btdhw->bpethw", q, keys) / math.sqrt(d)
            score = score + self.time_scores[i](time_input)[..., 0, None, None]
            score = score.masked_fill(~valid, float("-inf"))
            null = self.null_scores[i].expand(b, p, 2, 1, h, w)
            scores.append(torch.cat((score, null), dim=3))
        if self.role_specific:
            semantic_attention, reference_attention = [s.softmax(3) for s in scores]
        else:
            common = ((scores[0] + scores[1]) * 0.5).softmax(3)
            semantic_attention = reference_attention = common

        def read(attention: torch.Tensor) -> torch.Tensor:
            # The null candidate has value zero; all-history-off remains finite.
            return torch.einsum("bpethw,btdhw->bpedhw", attention[:, :, :, :t], values)

        support = read(semantic_attention)
        reference = read(reference_attention)
        semantic_input = torch.cat((endpoints, other, support, endpoints - reference), dim=3)
        corrections = self.semantic(semantic_input.reshape(b * p * 2, 4 * d, h, w))
        corrections = F.interpolate(corrections, size=(height, width), mode="bilinear", align_corners=False)
        corrections = corrections.reshape(b, p, 2, self.classes, height, width)
        zeros = torch.zeros_like(corrections[:, :1, 0])
        left = torch.cat((corrections[:, :, 0], zeros), dim=1)
        right = torch.cat((zeros, corrections[:, :, 1]), dim=1)
        counts = features.new_full((t,), 2)
        counts[0] = counts[-1] = 1
        delta = (left + right) / counts[None, :, None, None, None]

        old, new = endpoints[:, :, 0], endpoints[:, :, 1]
        residual = (new - reference[:, :, 1]) - (old - reference[:, :, 0])
        change_input = torch.cat((old, new, new - old, residual), dim=2)
        change = self.change(change_input.reshape(b * p, 4 * d, h, w))
        change = F.interpolate(change, size=(height, width), mode="bilinear", align_corners=False)
        result = {"logits": baseline_logits + delta, "change_logits": change.reshape(b, p, height, width),
                  "semantic_null": semantic_attention[:, :, :, -1].mean(),
                  "reference_null": reference_attention[:, :, :, -1].mean()}
        if return_attention:
            result.update(semantic_attention=semantic_attention, reference_attention=reference_attention)
        return result


def balanced_change_loss(logits: torch.Tensor, gt: torch.Tensor, ignore: int) -> torch.Tensor:
    valid = (gt[:, :-1] != ignore) & (gt[:, 1:] != ignore)
    target = (gt[:, :-1] != gt[:, 1:]).to(logits.dtype)
    losses = F.binary_cross_entropy_with_logits(logits, target, reduction="none")
    terms = []
    for changed in (False, True):
        mask = valid & (target.bool() == changed)
        if mask.any():
            terms.append(losses[mask].mean())
    return torch.stack(terms).mean() if terms else logits.sum() * 0.0


class FrozenMonoEncoder(nn.Module):
    """Reuse the existing per-date model, including frozen precise-BN statistics."""
    def __init__(self, model: nn.Module):
        super().__init__()
        self.model = model.eval().requires_grad_(False)
        self._features = None
        self.model.out_conv[2].register_forward_hook(self._capture)

    def _capture(self, module, inputs, output):
        self._features = output.detach()

    def train(self, mode: bool = True):
        super().train(False)
        self.model.eval()
        return self

    @torch.no_grad()
    def forward(self, images: torch.Tensor, positions: torch.Tensor):
        logits = self.model(images, positions)
        features = self._features.permute(0, 2, 1, 3, 4).contiguous()
        self._features = None
        return features, logits.detach()
