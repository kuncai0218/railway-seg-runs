"""CPU correctness checks for the scientific intervention and its edge cases."""
import copy
import hashlib
import json
from pathlib import Path

import torch

from model import HistoryReader, balanced_change_loss


def main():
    torch.set_num_threads(4)
    torch.manual_seed(42)
    a = HistoryReader(False, channels=8, hidden=8, classes=3, stride=2)
    b = copy.deepcopy(a)
    b.role_specific = True
    f = torch.randn(2, 5, 8, 16, 16)
    base = torch.randn(2, 5, 3, 16, 16)
    dates = torch.arange(5)[None].repeat(2, 1) * 90
    out_a, out_b = a(f, base, dates, return_attention=True), b(f, base, dates, return_attention=True)
    assert sum(x.numel() for x in a.parameters()) == sum(x.numel() for x in b.parameters())
    assert torch.equal(out_a['logits'], base) and torch.equal(out_b['logits'], base)
    assert torch.equal(out_a['semantic_attention'], out_a['reference_attention'])
    assert not torch.allclose(out_b['semantic_attention'], out_b['reference_attention'])
    for output in (out_a, out_b):
        for name in ('semantic_attention', 'reference_attention'):
            attention = output[name]
            assert torch.allclose(attention.sum(3), torch.ones_like(attention.sum(3)), atol=1e-6)
            for p in range(4):
                assert torch.count_nonzero(attention[:, p, :, p:p + 2]) == 0
    for reader in (a, b):
        output = reader(f, base, dates, history_keep=torch.zeros(5, dtype=torch.bool), return_attention=True)
        for name in ('semantic_attention', 'reference_attention'):
            assert torch.equal(output[name][:, :, :, -1], torch.ones_like(output[name][:, :, :, -1]))
        # T=2 has no contextual candidates; the null branch must work unaided.
        assert torch.isfinite(reader(f[:, :2], base[:, :2], dates[:, :2])['logits']).all()
        gt = torch.randint(0, 3, (2, 5, 16, 16))
        gt[:, 1, :3] = 3
        opt = torch.optim.AdamW(reader.parameters(), lr=1e-3)
        for _ in range(3):
            opt.zero_grad()
            output = reader(f, base, dates)
            loss = torch.nn.functional.cross_entropy(output['logits'].flatten(0, 1), gt.flatten(0, 1), ignore_index=3)
            loss = loss + 0.25 * balanced_change_loss(output['change_logits'], gt, 3)
            loss.backward()
            assert all(p.grad is None or torch.isfinite(p.grad).all() for p in reader.parameters())
            opt.step()
        assert any(p.grad is not None and p.grad.abs().sum() > 0 for p in reader.queries[0].parameters())
        assert any(p.grad is not None and p.grad.abs().sum() > 0 for p in reader.queries[1].parameters())
        ignored = torch.full_like(gt, 3)
        empty_loss = balanced_change_loss(output['change_logits'], ignored, 3)
        assert torch.isfinite(empty_loss) and empty_loss.item() == 0
    result = dict(status='passed', device='cpu', equal_parameter_count=True,
                  identical_initial_semantic_predictions=True, endpoint_memory_exclusion=True,
                  null_and_two_date_cases=True, both_readers_receive_finite_gradients=True,
                  ignore_label_change_loss=True,
                  source_hashes={name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
                                 for name in ('model.py', 'check_model.py')})
    Path(__file__).with_name('model_checks.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
