"""Train A/B together on identical batches and a shared frozen mono encoder.

No test dataset is instantiated. This is a 50-epoch frozen-feature screening
experiment, not the 250-epoch end-to-end main-table protocol.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from st3d_repro import SCDMetric, collate_fn, load_run_model, make_set, seed_all
from models.losses import CrossEntropyLoss
from model import FrozenMonoEncoder, HistoryReader, balanced_change_loss


def write_json(path, value):
    path = Path(path)
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    os.replace(temp, path)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def cpu_state(model):
    return {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}


def build(a, device):
    seed_all(a.seed)
    original, cfg, data, epoch = load_run_model(a.checkpoint, device=device)
    source = json.loads(Path(a.checkpoint).with_name('config.json').read_text(encoding='utf-8'))
    if source['args'].get('arch') != 'mono':
        raise ValueError('This screen requires a verified per-date mono checkpoint.')
    if data != 'dynamicearthnet':
        raise ValueError('Initial preregistered screen is DynamicEarthNet only.')
    encoder = FrozenMonoEncoder(original).to(device)
    nclasses = cfg['dataset']['num_classes']
    a_model = HistoryReader(False, channels=32, hidden=a.hidden, classes=nclasses, stride=a.memory_stride).to(device)
    b_model = copy.deepcopy(a_model)
    b_model.role_specific = True
    return encoder, {'A_shared': a_model, 'B_roles': b_model}, cfg


def losses(output, gt, ce, ignore, change_weight):
    semantic = ce(output['logits'], gt) if (gt != ignore).any() else output['logits'].sum() * 0
    change = balanced_change_loss(output['change_logits'], gt, ignore)
    total = semantic + change_weight * change
    if not torch.isfinite(total):
        raise FloatingPointError('Non-finite training loss.')
    return total, {'loss': float(total.detach()), 'semantic_ce': float(semantic.detach()),
                   'change_bce': float(change.detach()), 'semantic_null': float(output['semantic_null'].detach()),
                   'reference_null': float(output['reference_null'].detach())}


def update_hist(hist, scores, targets):
    bins = (scores.clamp(0, 1) * (hist.shape[1] - 1)).long().cpu().numpy()
    y = targets.long().cpu().numpy()
    hist += np.bincount(y * hist.shape[1] + bins, minlength=hist.size).reshape(hist.shape)


def hist_metrics(hist):
    negatives, positives = hist.sum(1)
    if not positives or not negatives:
        return None
    fpr = np.r_[0, np.cumsum(hist[0, ::-1]) / negatives]
    tpr = np.r_[0, np.cumsum(hist[1, ::-1]) / positives]
    auc = float(((tpr[1:] + tpr[:-1]) * np.diff(fpr) * 0.5).sum())
    return {'auc_approx': auc, 'recall_at_10pct_fpr_approx': float(np.interp(0.1, fpr, tpr)),
            'sampled_positive': int(positives), 'sampled_negative': int(negatives), 'score_bins': int(hist.shape[1]),
            'use': 'validation ranking diagnostic, not a deployment threshold or official SCS'}


@torch.no_grad()
def evaluate(encoder, readers, loader, cfg, device, no_history=False):
    encoder.eval()
    for reader in readers.values():
        reader.eval()
    k, ignore = cfg['dataset']['num_classes'], cfg['dataset']['ignore_index']
    names = ['mono_anchor'] + list(readers)
    metrics = {name: SCDMetric(k, cfg['dataset']['class_names'], ignore) for name in names}
    histograms = {name: {'js': np.zeros((2, 4096), np.int64)} for name in names}
    for name in readers:
        histograms[name]['direct_change'] = np.zeros((2, 4096), np.int64)
    transitions = {name: [0, 0] for name in names}
    nulls = {name: np.zeros(3, dtype=float) for name in readers}
    offset = 0
    t0 = time.perf_counter()
    for batch in loader:
        images, positions = batch['data'].to(device), batch['positions'].to(device)
        gt = batch['gt'].to(device)
        features, base = encoder(images, positions)
        results = {'mono_anchor': {'logits': base}}
        keep = torch.zeros(features.shape[1], device=device, dtype=torch.bool) if no_history else None
        for name, reader in readers.items():
            results[name] = reader(features, base, positions, history_keep=keep)
            nulls[name] += [float(results[name]['semantic_null']) * len(images),
                            float(results[name]['reference_null']) * len(images), len(images)]
        valid = (gt[:, :-1] != ignore) & (gt[:, 1:] != ignore)
        changed = gt[:, :-1] != gt[:, 1:]
        pair_pixels = changed[0].numel()
        # A private RNG keeps this diagnostic sampling independent of training.
        samples = np.stack([np.random.default_rng(1729 + offset + j).choice(pair_pixels, min(1024, pair_pixels), replace=False)
                            for j in range(len(images))])
        sample_idx = torch.as_tensor(samples, device=device)
        sample_valid = valid.flatten(1).gather(1, sample_idx)
        sample_target = changed.flatten(1).gather(1, sample_idx)[sample_valid]
        for name, output in results.items():
            logits = output['logits']
            pred = logits.argmax(2)
            metrics[name].update(pred.cpu(), batch['gt'])
            correct = (pred[:, :-1] == gt[:, :-1]) & (pred[:, 1:] == gt[:, 1:])
            transitions[name][0] += int((correct & changed & valid).sum())
            transitions[name][1] += int((changed & valid).sum())
            probs = logits.softmax(2).clamp_min(1e-8)
            old, new = probs[:, :-1], probs[:, 1:]
            mean = (old + new) * 0.5
            js = ((old * (old.log() - mean.log())).sum(2) + (new * (new.log() - mean.log())).sum(2)) * (0.5 / np.log(2))
            update_hist(histograms[name]['js'], js.flatten(1).gather(1, sample_idx)[sample_valid], sample_target)
            if 'change_logits' in output:
                score = output['change_logits'].sigmoid()
                update_hist(histograms[name]['direct_change'], score.flatten(1).gather(1, sample_idx)[sample_valid], sample_target)
        offset += len(images)
    out = {}
    for name in names:
        cm = metrics[name].conf_matrix_change.copy()
        r = {key: float(value) for key, value in metrics[name].compute().items()}
        r.update(change_recall=float(cm[1, 1] / max(cm[1].sum(), 1)),
                 change_precision=float(cm[1, 1] / max(cm[:, 1].sum(), 1)),
                 stable_fpr=float(cm[0, 1] / max(cm[0].sum(), 1)),
                 both_endpoint_accuracy_on_true_change=transitions[name][0] / max(transitions[name][1], 1),
                 ranking_diagnostics={key: hist_metrics(value) for key, value in histograms[name].items()})
        if name in nulls:
            n = nulls[name]
            r.update(mean_semantic_null=float(n[0] / n[2]), mean_reference_null=float(n[1] / n[2]))
        out[name] = r
    return {'patches': offset, 'minutes': (time.perf_counter() - t0) / 60, 'no_history': no_history, 'models': out}


def smoke(a):
    torch.set_num_threads(4)
    encoder, readers, cfg = build(a, 'cpu')
    ds = make_set(cfg, 'val', True)
    batch = collate_fn([ds[0]])
    features, logits = encoder(batch['data'], batch['positions'])
    for reader in readers.values():
        result = reader(features, logits, batch['positions'])
        if not torch.equal(result['logits'], logits) or not torch.isfinite(result['change_logits']).all():
            raise AssertionError('Real-data initial prediction check failed.')
    if any(p.requires_grad for p in encoder.parameters()):
        raise AssertionError('Frozen encoder has trainable parameters.')
    changed_images = batch['data'].clone()
    changed_images[:, 3] = 0
    changed_features, changed_logits = encoder(changed_images, batch['positions'])
    other = [i for i in range(8) if i != 3]
    feature_difference = (features - changed_features).abs().amax(dim=(0, 2, 3, 4)).tolist()
    logit_difference = (logits - changed_logits).abs().amax(dim=(0, 2, 3, 4)).tolist()
    print(json.dumps({'per_date_feature_difference': feature_difference,
                      'per_date_logit_difference': logit_difference}), flush=True)
    if not torch.allclose(features[:, other], changed_features[:, other], atol=1e-5, rtol=1e-5):
        raise AssertionError('The encoder features mix different dates.')
    if not torch.allclose(logits[:, other], changed_logits[:, other], atol=1e-5, rtol=1e-5):
        raise AssertionError('The encoder logits mix different dates.')
    mini_loader = DataLoader(torch.utils.data.Subset(ds, [0, 64]), batch_size=1,
                             shuffle=False, num_workers=0, collate_fn=collate_fn)
    mini_eval = evaluate(encoder, readers, mini_loader, cfg, 'cpu')
    reference_metrics = mini_eval['models']['mono_anchor']
    for name in readers:
        for key in ('miou', 'bc', 'sc', 'scs'):
            if mini_eval['models'][name][key] != reference_metrics[key]:
                raise AssertionError('Initial official metrics differ from the frozen anchor.')
    result = {'status': 'passed', 'device': 'cpu', 'data': 'one cross-region validation patch, inference only',
              'images': list(batch['data'].shape), 'features': list(features.shape),
              'trainable_parameters_each': sum(p.numel() for p in readers['A_shared'].parameters()),
              'frozen_parameters': sum(p.numel() for p in encoder.parameters()),
              'real_data_initial_logits_exact': True, 'frozen_encoder_date_independence_atol_rtol': 1e-5,
              'per_date_feature_difference': feature_difference, 'per_date_logit_difference': logit_difference,
              'official_metric_and_ranking_pipeline_checked': True,
              'mini_validation': mini_eval,
              'source_hashes': {name: sha256(HERE / name) for name in ('model.py', 'train_ab.py', 'protocol.json')},
              'test_data_instantiated': False}
    write_json(a.out / 'real_data_checks.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--checkpoint', type=Path, default=ROOT / 'runs_st3d' / 'den_mono_s42' / 'last_pbn.pth')
    ap.add_argument('--out', type=Path, default=HERE / 'run_s42')
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--epochs', type=int, default=50)
    ap.add_argument('--lr', type=float, default=1e-4)
    ap.add_argument('--weight-decay', type=float, default=1e-3)
    ap.add_argument('--change-weight', type=float, default=0.25)
    ap.add_argument('--hidden', type=int, default=32)
    ap.add_argument('--memory-stride', type=int, default=4)
    ap.add_argument('--batch', type=int, default=2)
    ap.add_argument('--eval-batch', type=int, default=2)
    ap.add_argument('--eval-every', type=int, default=5)
    ap.add_argument('--bench', type=int, default=0)
    ap.add_argument('--cpu-smoke', action='store_true')
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    if a.cpu_smoke:
        return smoke(a)
    device = 'cuda:0'
    torch.set_num_threads(4)
    encoder, readers, cfg = build(a, device)
    encoder.eval()
    ce = CrossEntropyLoss(ignore_index=cfg['dataset']['ignore_index'])
    opts = {name: torch.optim.AdamW(reader.parameters(), lr=a.lr, weight_decay=a.weight_decay) for name, reader in readers.items()}
    schedules = {name: torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=a.epochs, eta_min=1e-6) for name, opt in opts.items()}
    configuration = {'args': {key: str(value) if isinstance(value, Path) else value for key, value in vars(a).items()},
                     'checkpoint_sha256': sha256(a.checkpoint), 'cfg': cfg,
                     'source_hashes': {name: sha256(path) for name, path in {
                         'model.py': HERE / 'model.py', 'train_ab.py': HERE / 'train_ab.py',
                         'protocol.json': HERE / 'protocol.json',
                         'st3d_repro.py': ROOT / 'scripts' / 'st3d_repro.py',
                         'st3d_mono.py': ROOT / 'scripts' / 'st3d_mono.py'}.items()},
                     'parameters_each': sum(p.numel() for p in readers['A_shared'].parameters()),
                     'frozen_feature_screen': True, 'future_context_allowed': True,
                     'test_data_instantiated': False, 'encoder_bn': 'frozen source-train precise-BN; no recalibration',
                     'data_workers': 0, 'paired_identical_training_batches': True}
    config_path = a.out / ('bench_config.json' if a.bench else 'config.json')
    if config_path.exists():
        previous = json.loads(config_path.read_text(encoding='utf-8'))
        if previous != configuration:
            raise RuntimeError('Configuration/code changed; use a fresh output directory.')
    else:
        write_json(config_path, configuration)
    train = make_set(cfg, 'train')
    # Workers=0 avoids replicating the 1.3-GB label tensor in Windows workers.
    generator = torch.Generator().manual_seed(a.seed)
    loader = DataLoader(train, batch_size=a.batch, shuffle=True, drop_last=True, num_workers=0,
                        collate_fn=collate_fn, generator=generator)
    ignore = cfg['dataset']['ignore_index']

    def step(batch):
        images, gt, positions = (batch[key].to(device) for key in ('data', 'gt', 'positions'))
        features, anchor = encoder(images, positions)
        record = {}
        for name, reader in readers.items():
            reader.train()
            opts[name].zero_grad(set_to_none=True)
            output = reader(features, anchor, positions)
            loss, rec = losses(output, gt, ce, ignore, a.change_weight)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(reader.parameters(), 5.0, error_if_nonfinite=True)
            opts[name].step()
            record[name] = rec
        return record

    if a.bench:
        if a.bench <= 20 or a.bench > len(loader):
            raise ValueError('Benchmark must exceed 20 warm-up steps and fit in one epoch.')
        torch.cuda.reset_peak_memory_stats()
        start = time.perf_counter()
        for i, batch in enumerate(loader):
            record = step(batch)
            if i == 19:
                torch.cuda.synchronize()
                start = time.perf_counter()
            if i + 1 >= a.bench:
                break
        torch.cuda.synchronize()
        sps = (a.bench - 20) / (time.perf_counter() - start)
        result = {'status': 'passed', 'paired_steps_per_second': sps,
                  'gpu': torch.cuda.get_device_name(), 'peak_allocated_gib': torch.cuda.max_memory_allocated() / 2**30,
                  'peak_reserved_gib': torch.cuda.max_memory_reserved() / 2**30,
                  'steps_per_epoch': len(loader), 'paired_training_minutes_per_epoch': len(loader) / sps / 60,
                  'paired_50_epochs_train_hours_excluding_eval': 50 * len(loader) / sps / 3600,
                  'losses': record, 'benchmark_weights_discarded': True}
        write_json(a.out / 'bench.json', result)
        print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
        return

    validation = {key: make_set(cfg, 'val', key == 'val_out') for key in ('val_in', 'val_out')}
    val_loaders = {key: DataLoader(ds, batch_size=a.eval_batch, shuffle=False, num_workers=0, collate_fn=collate_fn)
                   for key, ds in validation.items()}
    last = a.out / 'last.pth'
    start_epoch = 1
    if last.exists():
        ck = torch.load(last, map_location=device, weights_only=False)
        for name, reader in readers.items():
            reader.load_state_dict(ck['readers'][name])
            opts[name].load_state_dict(ck['optimizers'][name])
            schedules[name].load_state_dict(ck['schedulers'][name])
        generator.set_state(ck['loader_rng'].cpu())
        random.setstate(ck['python_rng'])
        np.random.set_state(ck['numpy_rng'])
        torch.set_rng_state(ck['torch_rng'].cpu())
        torch.cuda.set_rng_state_all([state.cpu() for state in ck['cuda_rng']])
        start_epoch = ck['epoch'] + 1
    if not (a.out / 'initial_validation.json').exists():
        initial = {key: evaluate(encoder, readers, value, cfg, device) for key, value in val_loaders.items()}
        write_json(a.out / 'initial_validation.json', initial)
    write_json(a.out / 'status.json', {'state': 'training', 'epoch': start_epoch - 1, 'epochs': a.epochs,
                                      'pid': os.getpid(), 'updated': time.strftime('%Y-%m-%d %H:%M:%S')})
    print(f'Paired A/B start: {len(loader)} steps/epoch; epochs={a.epochs}; frozen encoder; validation only.', flush=True)
    with open(a.out / 'epochs.jsonl', 'a', encoding='utf-8') as log:
        for epoch in range(start_epoch, a.epochs + 1):
            start = time.perf_counter()
            sums = {name: {} for name in readers}
            for i, batch in enumerate(loader):
                record = step(batch)
                for name, rec in record.items():
                    for key, value in rec.items():
                        sums[name][key] = sums[name].get(key, 0.0) + value
                if (i + 1) % 250 == 0:
                    write_json(a.out / 'status.json', {'state': 'training', 'epoch': epoch, 'epochs': a.epochs,
                                                      'step': i + 1, 'steps_per_epoch': len(loader), 'pid': os.getpid(),
                                                      'updated': time.strftime('%Y-%m-%d %H:%M:%S')})
            rec = {'epoch': epoch, 'train_minutes': (time.perf_counter() - start) / 60,
                   'losses': {name: {key: value / len(loader) for key, value in values.items()} for name, values in sums.items()}}
            for schedule in schedules.values():
                schedule.step()
            if epoch == 1 or epoch % a.eval_every == 0 or epoch == a.epochs:
                rec['validation'] = {key: evaluate(encoder, readers, value, cfg, device) for key, value in val_loaders.items()}
            rec['minutes_including_evaluation'] = (time.perf_counter() - start) / 60
            ck = {'epoch': epoch, 'readers': {name: cpu_state(reader) for name, reader in readers.items()},
                  'optimizers': {name: opt.state_dict() for name, opt in opts.items()},
                  'schedulers': {name: schedule.state_dict() for name, schedule in schedules.items()},
                  'loader_rng': generator.get_state(), 'python_rng': random.getstate(), 'numpy_rng': np.random.get_state(),
                  'torch_rng': torch.get_rng_state(), 'cuda_rng': torch.cuda.get_rng_state_all()}
            torch.save(ck, last.with_suffix('.tmp'))
            os.replace(last.with_suffix('.tmp'), last)
            log.write(json.dumps(rec, ensure_ascii=False, allow_nan=False) + '\n')
            log.flush()
            print(json.dumps(rec, ensure_ascii=False), flush=True)
    final = {key: evaluate(encoder, readers, value, cfg, device) for key, value in val_loaders.items()}
    ablations = {key: evaluate(encoder, readers, value, cfg, device, no_history=True) for key, value in val_loaders.items()}
    write_json(a.out / 'final.json', {'epoch': a.epochs, 'validation': final, 'no_history_ablation': ablations,
                                     'scope': 'frozen-feature single-seed screen, not main-table evidence'})
    write_json(a.out / 'status.json', {'state': 'complete', 'epochs': a.epochs,
                                      'updated': time.strftime('%Y-%m-%d %H:%M:%S')})
    print('Paired A/B screen complete.', flush=True)


if __name__ == '__main__':
    main()
