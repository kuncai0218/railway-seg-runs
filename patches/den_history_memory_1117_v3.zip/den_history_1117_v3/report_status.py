"""Small E015 peer reports via the already authorized ntfy coordination topics."""
import argparse
import json
from pathlib import Path
import shutil
import time
import urllib.request
import psutil
from run_experiments import gpu_sample


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", choices=["jia", "yi"], required=True)
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--loop", type=int, default=0)
    ap.add_argument("--no-send", action="store_true")
    a = ap.parse_args()
    root = Path(a.out_root)
    root.mkdir(parents=True, exist_ok=True)
    while True:
        value = {"kind": "E015_DEN_history_memory", "name": a.name,
                 "at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                 "gpu": gpu_sample(), "RAM_available_GiB": psutil.virtual_memory().available / 2**30,
                 "disk_free_GiB": shutil.disk_usage(root).free / 2**30, "processes": [],
                 "queues": {}, "runs": {}}
        for proc in psutil.process_iter(["pid", "cmdline", "create_time"]):
            try:
                cmd = proc.info["cmdline"] or []
                if any("den_history_1117" in str(t) for t in cmd):
                    value["processes"].append(proc.info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        for q in root.glob("queue_seed*.json"):
            value["queues"][q.name] = json.loads(q.read_text(encoding="utf-8"))
        for run in root.iterdir():
            if not run.is_dir():
                continue
            files = {}
            for filename in ["config.json", "completed.json", "source_hold_full.json"]:
                path = run / filename
                if path.exists():
                    files[filename] = json.loads(path.read_text(encoding="utf-8"))
            path = run / "steps.jsonl"
            if path.exists():
                lines = path.read_text(encoding="utf-8").splitlines()
                files["steps_tail"] = [json.loads(line) for line in lines[-3:]]
            path = run / "train.log"
            if path.exists():
                files["log_tail"] = path.read_text(encoding="utf-8", errors="replace")[-2500:]
            value["runs"][run.name] = files
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        assert len(body) < 10 * 2**20, "Report exceeded bounded small-file budget"
        (root / ("status_" + a.name + ".json")).write_bytes(body)
        if not a.no_send:
            req = urllib.request.Request("https://ntfy.sh/railseg-d4a86d-status-" + a.name, body,
                                         headers={"Filename": "E015_" + a.name + "_" + time.strftime("%Y%m%d_%H%M%S") + ".json",
                                                  "Title": "E015 DEN history " + a.name,
                                                  "Message": "E015_DEN_history_memory report"},
                                         method="POST")
            try:
                with urllib.request.urlopen(req, timeout=30) as response:
                    print(response.read().decode("utf-8")[:250], flush=True)
            except Exception as error:
                print("Report saved locally; send error:", repr(error), flush=True)
        if not a.loop:
            break
        time.sleep(a.loop)


if __name__ == "__main__":
    main()
