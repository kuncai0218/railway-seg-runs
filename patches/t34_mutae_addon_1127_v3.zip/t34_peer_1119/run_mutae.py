# -*- coding: utf-8 -*-
"""Multi-UTAE（DynamicEarthNet Planet，论文配方 + 作者混合精度 16-mixed，第 3 版）一个种子：冒烟 → 正式训练（入口训练完自动按验证 mIoU 分域选轮并正式测试）→ 第 250 轮固定末轮测试。
一次一个；失败即停，不自动改配方；可重复运行（已完成的跳过，有 last.pth 的续跑）。
用法：python -X utf8 run_mutae.py --seed 43 --runs <作业根目录>
需要与跑 T34 配对时相同的环境变量 T34_DATA、T34_CACHE（缓存已在 11-19 由 stage_den_cache.py 生成，不用重做）。"""
import argparse
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent


def now():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, choices=[43, 44], required=True)
    ap.add_argument("--runs", required=True)
    a = ap.parse_args()
    runs = Path(a.runs)
    runs.mkdir(parents=True, exist_ok=True)
    state_path = runs / f"mutae_s{a.seed}_state.json"
    state = {"seed": a.seed, "started": now(), "steps": []}

    def save():
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), "utf-8")

    entry = str(HERE / "train_t34_mutae.py")
    smoke = runs / f"_smoke_mutae_s{a.seed}"
    formal = runs / f"den_planet_mutae_s{a.seed}"
    plan = []
    if not ((smoke / "status.json").exists() and "smoke_complete" in (smoke / "status.json").read_text("utf-8")):
        plan.append(("smoke", [entry, "--seed", str(a.seed), "--method", "mutae", "--out", str(smoke), "--smoke_steps", "20"]))
    if not (formal / "official_test.json").exists():
        plan.append(("formal", [entry, "--seed", str(a.seed), "--method", "mutae", "--out", str(formal)] + (["--resume"] if (formal / "last.pth").exists() else [])))
    if not (formal / "official_test_last.json").exists():
        plan.append(("test_last", [str(HERE / "test_last_mutae.py"), "--entry", entry, "--out", str(formal), "--seed", str(a.seed), "--method", "mutae"]))
    for kind, args in plan:
        log = runs / f"mutae_s{a.seed}_{kind}_{datetime.now():%Y%m%d_%H%M%S}.log"
        rec = {"step": kind, "args": args, "log": str(log), "start": now()}
        state["steps"].append(rec)
        save()
        with open(log, "w", encoding="utf-8") as fh:
            rc = subprocess.call([sys.executable, "-B", "-u", "-X", "utf8"] + args, cwd=str(HERE), stdout=fh, stderr=subprocess.STDOUT)
        rec.update(end=now(), returncode=rc)
        save()
        if rc != 0:
            state["stopped"] = f"{kind} 返回码 {rc}，见日志；未自动重试（正式训练中断可再运行本脚本，会带 --resume 续跑）"
            save()
            sys.exit(rc)
    state["done"] = now()
    save()


if __name__ == "__main__":
    main()
