"""Matched MUDS runs using the released data loader and existing SNT v2.1 modules."""

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

for variable in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(variable, "2")

import numpy as np
import torch
from torch.utils.data import DataLoader

from train_snt import RichSCDAccumulator, save_ckpt, save_json, seed_everything


HERE = Path(__file__).resolve().parent
SPLIT_SHA = "008b2db51aabf66b23b9d9d644b394285a36687f3a0dcdbc6397c5f28abf7b7f"
PSE_OPTIONS = "event=0,gate=0"
DOMAINS = ("in", "out")


def sha(path):
    with path.open("rb") as stream:
        digest = hashlib.sha256()
        for block in iter(lambda: stream.read(2**20), b""):
            digest.update(block)
    return digest.hexdigest()


def setup(args):
    split_path = args.data / "split.json"
    if sha(split_path) != SPLIT_SHA:
        raise ValueError("MUDS split differs from the verified 40/10/10 release")
    split = json.loads(split_path.read_text(encoding="utf8"))
    if [len(split[k]) for k in ("train", "val", "test")] != [40, 10, 10]:
        raise ValueError("Unexpected number of MUDS areas")
    if args.cache:
        if args.cache.name.lower() != "muds":
            raise ValueError("--cache must point to the Muds cache directory itself")
        for part in ("train", "val"):
            for area in split[part]:
                if not (args.cache / part / f"{area}.blk.npy").is_file():
                    raise ValueError(f"Incomplete cache: {part}/{area}.blk.npy")
    os.environ["ST3D_REPO"] = str(HERE / "upstream")
    os.environ["ST3D_DATA"] = str(args.data.parent)
    if args.cache:
        os.environ["ST3D_CACHE"] = str(args.cache.parent)
    import st3d_repro as adapter

    config = adapter.load_yaml(HERE / "upstream" / "configs" / "muds.yaml")
    config["dataset"].update(path=str(args.data), split_file=str(split_path))
    config["run"]["seed"] = args.seed
    config["computer"]["accelerator"] = args.device
    return adapter, config


def build(adapter, config, method):
    if method == "st3d":
        return adapter.build_model(config, "st3d")
    from snt_model import SNTNet

    backbone = adapter.build_model(config, "pse", PSE_OPTIONS)
    m3 = method == "m3"
    return SNTNet(backbone, in_channels=3, num_classes=2, head_mode="h3" if m3 else "none",
                  use_scpc=m3, use_rad_aug=m3, ignore_index=2, drop=.15)


def make_loader(dataset, workers=0, training=False, generator=None):
    return DataLoader(dataset, batch_size=2 if training else 1, shuffle=training, drop_last=training,
                      num_workers=workers, collate_fn=dataset.collate_fn, generator=generator)


@torch.inference_mode()
def evaluate(model, dataset, device, official, detail=False, limit=None):
    model.eval()
    metric = official(num_classes=2, class_names=["not building", "building"], ignore_index=2)
    extra = RichSCDAccumulator(2)
    for number, batch in enumerate(make_loader(dataset)):
        if limit is not None and number >= limit:
            break
        positions = batch["positions"].to(device)
        labels = batch["gt"]
        logits = model(batch["data"].to(device), positions)
        pred = logits.argmax(dim=2).cpu()
        metric.update(pred, labels)
        names = [dataset.sits_ids[int(i)] for i in batch["idx"]] if detail else None
        extra.update(pred.numpy(), labels.numpy(), aoi_names=names)
    scores = {key: float(value) for key, value in metric.compute().items()}
    diagnostics = extra.compute(include_per_aoi=detail)
    for name in ("miou", "scs", "bc", "sc"):
        if abs(scores[name] - diagnostics[name]) > 1e-8:
            raise RuntimeError(f"Metric conflict for {name}")
    scores.update({k: v for k, v in diagnostics.items() if k not in scores})
    if detail:
        scores["joint_counts_by_area"] = {k: row[2].tolist() for k, row in sorted(extra.per_aoi.items())}
    return scores


def official_test(adapter, cfg, model, args, weights):
    report = {}
    for domain in DOMAINS:
        weight = weights[domain]
        state = torch.load(weight, map_location="cpu", weights_only=True)
        model.load_state_dict(state["model"], strict=True)
        evaluation = adapter.make_set(cfg, "test", domain_shift=domain == "out", cache=False)
        expected = 80 if domain == "in" else 640
        if len(evaluation) != expected:
            raise RuntimeError(f"MUDS {domain} test has {len(evaluation)} blocks, expected {expected}")
        scores = evaluate(model, evaluation, args.device, adapter.SCDMetric, detail=True)
        report[domain] = {"epoch": int(state["epoch"]), "weights": str(weight), "sha256": sha(weight),
                          "blocks": len(evaluation), "metrics": scores}
        print(f"[MUDS TEST {domain}] ep={state['epoch']} mIoU={scores['miou']:.2f} SCS={scores['scs']:.2f}", flush=True)
    save_json(args.out / "official_test.json", report)


def replay_original(adapter, cfg, model, args):
    """Use historical validation selection, and explicitly disclose its evaluation batch size."""
    saved = json.loads((args.replay_original / "config.json").read_text(encoding="utf8"))
    old = saved["args"]
    for key, expected in (("data", "muds"), ("seed", args.seed), ("sched", "paper"), ("lr", 1e-4), ("wd", 1e-3)):
        if old.get(key) != expected:
            raise ValueError(f"Historical configuration mismatch for {key}: {old.get(key)!r}")
    if old.get("arch", "st3d") != "st3d" or saved["cfg"]["ST3DUNET"]["INPUT_CHANNELS"] != 3:
        raise ValueError("The historical model must be the released three-channel ST3DUNet")
    with (args.replay_original / "epochs.jsonl").open(encoding="utf8") as stream:
        history = [json.loads(line) for line in stream if line.strip()]
    if [row["epoch"] for row in history] != list(range(1, 251)):
        raise ValueError("Historical training must have every validation evaluation through epoch 250")
    selected = {domain: max(history, key=lambda row: row[f"val_{domain}"]["miou"])["epoch"] for domain in DOMAINS}
    weights = {}
    for domain, epoch in selected.items():
        candidate = args.replay_original / f"best_{domain}.pth"
        if not candidate.exists() or torch.load(candidate, map_location="cpu", weights_only=True)["epoch"] != epoch:
            raise ValueError(f"Historical validation-selected {domain} checkpoint for epoch {epoch} is missing")
        weights[domain] = candidate
    save_json(args.out / "historical_selection.json", {"epoch": selected, "config": saved,
               "original_selection_batch_size": old.get("eval_batch"), "source_epochs_sha256": sha(args.replay_original / "epochs.jsonl")})
    official_test(adapter, cfg, model, args, weights)


def train(adapter, cfg, model, args, contract):
    def dataset(part, shift=False):
        return adapter.make_set(cfg, part, domain_shift=shift, cache=args.cache is not None)

    source = dataset("train")
    validation = {domain: dataset("val", domain == "out") for domain in DOMAINS}
    if [len(source), *(len(validation[d]) for d in DOMAINS)] != [2400, 80, 640]:
        raise RuntimeError("Unexpected MUDS training and validation sizes")
    loss_object = adapter.Losses(**cfg["loss"])

    def main_ce(logits, labels):
        return loss_object({"logits": logits}, {"gt": labels})["loss"]

    if args.method == "st3d":
        groups = [{"params": model.parameters(), "weight_decay": .001}]
    else:
        groups = [{"params": model.backbone.parameters(), "weight_decay": .001}]
        if args.method == "m3":
            groups.append({"params": [p for n, p in model.named_parameters() if not n.startswith("backbone.")],
                           "weight_decay": .01})
    optim = torch.optim.AdamW(groups, lr=.0001)
    schedule = torch.optim.lr_scheduler.CosineAnnealingLR(optim, 250, eta_min=1e-6)
    run_path = args.out / "last.pth"
    history, best = [], {}
    if args.resume:
        saved = torch.load(run_path, map_location="cpu", weights_only=True)
        if saved["contract"] != contract:
            raise ValueError("Resume configuration differs from checkpoint")
        model.load_state_dict(saved["model"], strict=True)
        optim.load_state_dict(saved["optimizer"])
        schedule.load_state_dict(saved["scheduler"])
        history, best = saved["history"], saved["best"]

    epochs = 1 if args.smoke else 250
    for epoch in range(len(history) + 1, epochs + 1):
        seed_everything(args.seed + 10000 * epoch)
        draw = torch.Generator().manual_seed(args.seed + 10000 * epoch)
        loader = make_loader(source, args.workers, training=True, generator=draw)
        model.train()
        total = 0.0
        start = time.monotonic()
        for step, batch in enumerate(loader, 1):
            x = batch["data"].to(args.device)
            y = batch["gt"].to(args.device)
            logits = model(x, batch["positions"].to(args.device))
            optim.zero_grad(set_to_none=True)
            if args.method == "st3d":
                loss = main_ce(logits, y)
            else:
                loss, _ = model.compute_total_loss(logits, y, main_ce, cls_weight=model.backbone.cls_w)
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Non-finite loss at epoch {epoch}, step {step}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5, error_if_nonfinite=True)
            optim.step()
            total += float(loss.detach())
            if step == 1 or step % 100 == 0:
                print(f"[MUDS TRAIN] {args.method} seed={args.seed} epoch={epoch} step={step}/{len(loader)} loss={total/step:.6f}", flush=True)
            if args.smoke:
                break
        schedule.step()
        result = {d: evaluate(model, ds, args.device, adapter.SCDMetric, limit=1 if args.smoke else None)
                  for d, ds in validation.items()}
        for domain in DOMAINS:
            score = result[domain]["miou"]
            if score > best.get(domain, {}).get("score", -1):
                archive = args.out / f"best_{domain}_ep{epoch:03d}.pth"
                save_ckpt(archive, {"model": model.state_dict(), "epoch": epoch})
                best[domain] = {"score": score, "epoch": epoch, "file": archive.name}
        history.append({"epoch": epoch, "loss": total/step, "seconds": time.monotonic()-start,
                        "lr_after_epoch": schedule.get_last_lr()[0], "validation": result})
        save_ckpt(run_path, {"model": model.state_dict(), "optimizer": optim.state_dict(), "epoch": epoch,
                            "scheduler": schedule.state_dict(), "history": history, "best": best, "contract": contract})
        save_json(args.out / "epochs.json", history)
        save_json(args.out / "status.json", {"phase": "smoke_complete" if args.smoke else "training", "epoch": epoch,
                                              "best": best, "metrics": result})
        print(f"[MUDS EPOCH] {epoch}/{epochs} in_SCS={result['in']['scs']:.2f} out_SCS={result['out']['scs']:.2f}", flush=True)

    if not args.smoke:
        official_test(adapter, cfg, model, args, {d: args.out / best[d]["file"] for d in DOMAINS})
        save_json(args.out / "status.json", {"phase": "complete", "epoch": epochs, "best": best})


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--cache", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--method", choices=("st3d", "pse", "m3"), required=True)
    ap.add_argument("--seed", type=int, choices=(42, 43, 44), required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--replay-original", type=Path)
    args = ap.parse_args()
    if args.replay_original and (args.method != "st3d" or args.smoke or args.resume):
        ap.error("--replay-original is available only for original ST3DUNet test replay")
    args.data = args.data.resolve()
    if args.cache:
        args.cache = args.cache.resolve()
    torch.set_num_threads(2)
    seed_everything(args.seed)
    adapter, cfg = setup(args)
    model = build(adapter, cfg, args.method).to(args.device)
    args.out.mkdir(parents=True, exist_ok=True)
    contract = {"method": args.method, "seed": args.seed, "torch": str(torch.__version__),
                "device": args.device, "workers": args.workers, "split_sha256": SPLIT_SHA,
                "data": str(args.data), "cache": str(args.cache), "smoke": args.smoke,
                "replay_original": str(args.replay_original), "training_epochs": 250,
                "training_batch": 2, "evaluation_batch": 1, "selection": "maximum validation mIoU, earlier epoch on tie",
                "pse_options": PSE_OPTIONS if args.method != "st3d" else None,
                "model_parameters": sum(p.numel() for p in model.parameters()),
                "sources": {p.name: sha(p) for p in (Path(__file__), HERE / "st3d_repro.py", HERE / "pse_net.py",
                            HERE / "snt_model.py", HERE / "normalcy_crf.py", HERE / "scene_proto_cal.py")}}
    cfg_path = args.out / "protocol.json"
    if args.resume and json.loads(cfg_path.read_text(encoding="utf8")) != contract:
        raise ValueError("Resume configuration differs from the existing protocol")
    if not args.resume and (cfg_path.exists() or any(args.out.iterdir())):
        raise ValueError("Use a new output directory or explicitly resume the existing run")
    save_json(cfg_path, contract)
    if args.replay_original:
        replay_original(adapter, cfg, model, args)
    else:
        train(adapter, cfg, model, args, contract)


if __name__ == "__main__":
    main()
