"""Receive the verified follow-up optical chips for the C02/C04/C08 review."""
import argparse
from io import BytesIO
import json
from pathlib import Path
import re
from zipfile import ZipFile
from hashlib import sha256

import numpy as np

from receive_spatial_development import access_token, digest, request


NAME = "railway_interim_optical_evidence.zip"


def check(path, output=None):
    with ZipFile(path) as z:
        if z.testzip() is not None:
            raise ValueError("Archive CRC test failed")
        index=json.loads(z.read("index.json"))
        records=index["members"]
        cases={r["case"] for r in index["observations"]}
        if cases!={"C02","C04","C08"} or set(z.namelist())!={"index.json",*records}:
            raise ValueError("Unexpected review archive inventory")
        for name, planned in records.items():
            if name!="开始复核.md" and re.fullmatch(r"C(?:02|04|08)/(?:时间证据原图\.png|\d{4}-\d{2}-\d{2}\.npz)",name) is None:
                raise ValueError(f"Unexpected review archive name {name}")
            data=z.read(name)
            if len(data)!=planned["bytes"] or sha256(data).hexdigest()!=planned["sha256"]:
                raise ValueError(f"Review member checksum differs for {name}")
            if name.endswith(".npz"):
                with np.load(BytesIO(data),allow_pickle=False) as sample:
                    expected={"reflectance","quality","clear","strict","observed","polygon"}
                    if set(sample.files)!=expected or sample["reflectance"].shape!=(5,200,200):
                        raise ValueError("The observation does not match the documented crop")
                    if any(sample[key].shape!=(200,200) for key in expected-{"reflectance"}):
                        raise ValueError("Quality mask grid differs from the crop")
        if output:
            z.extractall(output)
    print("Verified follow-up observations",len(index["observations"]),path.stat().st_size,digest(path),flush=True)


def receive(args):
    args.out.mkdir(parents=True,exist_ok=True)
    origin=args.endpoint.rstrip("/")+"/"+access_token(args.key_data,args.nonce)
    probe=args.out/"route_probe.bin"
    manifest=args.out/"manifest.json"
    request(origin+"/route_probe.bin",probe,args.interface,15)
    request(origin+"/manifest.json",manifest,args.interface,15)
    if probe.stat().st_size!=4096 or digest(probe)!=args.probe or digest(manifest)!=args.manifest:
        raise ValueError("The physical route probe or send manifest did not match")
    item=json.loads(manifest.read_text(encoding="utf-8"))["assets"][NAME]
    if item["sha256"]!=args.package:
        raise ValueError("Archive identity differs from the active instruction")
    target=args.out/NAME
    if not target.exists():
        interim=target.with_suffix(".part")
        if not interim.exists() or interim.stat().st_size!=item["bytes"]:
            request(origin+"/"+NAME,interim,args.interface,180,offset=True)
        if interim.stat().st_size!=item["bytes"] or digest(interim)!=args.package:
            raise ValueError("The received crop archive differs from the send record")
        interim.replace(target)
    if target.stat().st_size!=item["bytes"] or digest(target)!=args.package:
        raise ValueError("The saved crop archive differs from the send record")
    check(target,args.out/"images")


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    for key in ("endpoint","interface","nonce","probe","manifest","package"):
        cli.add_argument("--"+key,required=True)
    cli.add_argument("--key-data",type=Path,required=True)
    cli.add_argument("--out",type=Path,required=True)
    receive(cli.parse_args())
