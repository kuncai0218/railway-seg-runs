# 实验包 event_pkg_1115（T22 阶段 1，MUDS）

组长 11-15 安排。与以前的 pub_st3d_pkg_* 放在同一个上级目录（和 st3d_data、st3d_cache、st3d_runs 并列），沿用已有的 MUDS 数据与缓存，**不下载任何数据**。

包里自带组长本机同版本的训练代码（`scripts/st3d_repro.py`、`st3d_mono.py`、`ST3DUNet/`），新代码在 `scripts/event_1115/`。不要改任何代码和参数。

## 步骤（在 event_pkg_1115 目录里，用以前跑 st3d 任务的同一个 Python 环境）

1. 冒烟（约 10 分钟）：`python -X utf8 scripts/event_1115/run_queue_event.py tasks/smoke_event_1115.json --max 1`
   - 运行器先自检：MUDS 数据与缓存在不在、`check_event.py` 是否“全部通过”。不过就停下，把 `../st3d_runs/t22_queue.log` 和 `../st3d_runs/t22_check.txt` 回报。
   - 三条冒烟都写出 `final_event.json` 才算通过。
2. 正式任务：甲 `python -X utf8 scripts/event_1115/run_queue_event.py tasks/jia_event_1115.json --max 2`；乙把文件名换成 `yi_event_1115.json`。
3. 启动后同步：编号、运行器与训练进程号、显存、间隔至少 60 秒的两次真实步数（`../st3d_runs/<任务名>/train.log` 里的 Step 行）。之后每 15 分钟同步。
4. 每个任务完成（`../st3d_runs/<任务名>/final_event.json` 出现）后，在状态附件里回传这三个小文件：`final_event.json`、`epochs.jsonl`、`config.json`。权重和大数组留在本机，不用上传。
5. 出错：同一任务失败两次，运行器会停下。回报 `t22_queue.log` 和该任务 `train.log` 末尾 50 行，不要自己改代码或参数。中途被打断，重新运行第 2 步的命令即可，已完成的跳过，未完成的从断点接着跑。
