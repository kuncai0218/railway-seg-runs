# -*- coding: utf-8 -*-
"""T22（总账_1110\\任务书\\T22_判决对齐训练_阶段1_MUDS.md）：短窗口变化通道、按段似然（整段至多变一次、容许差 tol 期）、精确最大后验判决、
楼边界 / 楼间接触辅助目标。骨干不改：用前向预钩子取官方 out_conv 之前的逐期解码特征（同 T21 的 chead.py）。
不改任何共享脚本。
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class ShortWindowChangeHead(nn.Module):
    """f: [B, C, T, H, W] → 第 i 对（第 i 期到第 i+1 期）的变化对数几率 [B, T-1, H, W]。
    前段 = 第 max(0, i-win+1)..i 期特征平均，后段 = 第 i+1..min(T-1, i+win) 期特征平均；[前段, 后段, |差|] → 3×3 卷积 → 组归一化 → ReLU → 1×1。"""

    def __init__(self, cin, mid=32, win=2):
        super().__init__()
        self.win = int(win)
        self.net = nn.Sequential(nn.Conv2d(3 * cin, mid, 3, padding=1), nn.GroupNorm(max(1, min(8, mid // 8)), mid),
                                 nn.ReLU(inplace=True), nn.Conv2d(mid, 1, 1))

    def forward(self, f):
        B, C, T, H, W = f.shape
        cs = torch.cat([torch.zeros_like(f[:, :, :1]), torch.cumsum(f, 2)], 2)        # cs[:, :, k] = Σ_{u<k} f[:, :, u]
        pre, post = [], []
        for i in range(T - 1):
            a0, b0 = max(0, i - self.win + 1), i + 1
            a1, b1 = i + 1, min(T, i + 1 + self.win)
            pre.append((cs[:, :, b0] - cs[:, :, a0]) / (b0 - a0))
            post.append((cs[:, :, b1] - cs[:, :, a1]) / (b1 - a1))
        pre, post = torch.stack(pre, 2), torch.stack(post, 2)                          # [B, C, T-1, H, W]
        z = torch.cat([pre, post, (pre - post).abs()], 1)
        z = z.permute(0, 2, 1, 3, 4).reshape(B * (T - 1), 3 * C, H, W)
        return self.net(z).view(B, T - 1, H, W)


class EventWrap(nn.Module):
    """base：build_model 建好的官方模型（本任务用 mono_gn）。
    前向返回 (类别 logits [B,T,K,h,w], 变化对数几率 [B,T-1,h,w], 辅助 logits [B,T,2,h,w] 或 None)；h = up × 输入尺寸。
    up > 1 时在进骨干前把输入双线性放大（骨干须按放大后的尺寸建瓶颈注意力）。"""

    def __init__(self, base, K, mid=32, win=2, up=1, aux=False):
        super().__init__()
        assert hasattr(base, "out_conv"), "只接在官方 ST3DUNet 结构上（需要 out_conv）"
        self.base, self.up, self.aux = base, int(up), bool(aux)
        cin = base.out_conv[0].in_channels
        self.head = ShortWindowChangeHead(cin, mid, win)
        self.hazard = nn.Parameter(torch.zeros(K, K))
        self.aux_head = nn.Conv2d(cin, 2, 1) if self.aux else None
        self._feat = None
        base.out_conv.register_forward_pre_hook(self._grab)

    def _grab(self, module, inputs):
        self._feat = inputs[0]

    def forward(self, x, batch_positions=None):
        if self.up > 1:
            B, T, C, H, W = x.shape
            x = F.interpolate(x.reshape(B * T, C, H, W), scale_factor=self.up, mode="bilinear", align_corners=False).view(B, T, C, H * self.up, W * self.up)
        logits = self.base(x, batch_positions)
        f, self._feat = self._feat, None
        f = f[:, :, :logits.shape[1]]
        clog = self.head(f)
        aux = None
        if self.aux:
            B, C, T, h, w = f.shape
            aux = self.aux_head(f.permute(0, 2, 1, 3, 4).reshape(B * T, C, h, w)).view(B, T, 2, h, w)
        return logits, clog, aux


# ---------------------------------------------------------------- 标签工具
def up_labels(y, up):
    """y: [B, T, H, W] → 最近邻放大 up 倍。"""
    if up == 1:
        return y
    return y.repeat_interleave(up, dim=2).repeat_interleave(up, dim=3)


def change_targets(y, ignore):
    v = y != ignore
    m = v[:, 1:] & v[:, :-1]
    return (y[:, 1:] != y[:, :-1]) & m, m


def change_bce(clog, y, ignore, pos_weight=1.0):
    d, m = change_targets(y, ignore)
    if not bool(m.any()):
        return clog.sum() * 0.0
    pw = None if float(pos_weight) == 1.0 else torch.tensor(float(pos_weight), device=clog.device, dtype=clog.dtype)
    return F.binary_cross_entropy_with_logits(clog[m], d[m].to(clog.dtype), pos_weight=pw)


def aux_targets(y, ignore, gap=2):
    """楼边界：建筑像元、8 邻域里有背景；楼间接触：背景像元，左右或上下 gap 像元内两侧都有建筑。y: [B,T,H,W] → [B,T,2,H,W] 浮点、有效掩膜 [B,T,H,W]。"""
    B, T, H, W = y.shape
    v = y != ignore
    bld = ((y == 1) & v).float().view(B * T, 1, H, W)
    bg = ((y == 0) & v).float().view(B * T, 1, H, W)
    bnd = bld * F.max_pool2d(bg, 3, 1, 1)

    def shift(t, dy, dx):  # 结果在 (r, c) 处取 t[r-dy, c-dx]，越界补 0（不绕回）
        h, w = t.shape[-2:]
        p = F.pad(t, (max(dx, 0), max(-dx, 0), max(dy, 0), max(-dy, 0)))
        r0, c0 = max(-dy, 0), max(-dx, 0)
        return p[..., r0:r0 + h, c0:c0 + w]

    def shift_any(t, dx, dy):
        acc = torch.zeros_like(t)
        for k in range(1, gap + 1):
            acc = torch.maximum(acc, shift(t, k * dy, k * dx))
        return acc
    lr = shift_any(bld, 1, 0) * shift_any(bld, -1, 0)
    ud = shift_any(bld, 0, 1) * shift_any(bld, 0, -1)
    con = bg * torch.maximum(lr, ud)
    return torch.cat([bnd, con], 1).view(B, T, 2, H, W), v


def aux_loss(aux, y, ignore, pos_weight=5.0, gap=2):
    tgt, v = aux_targets(y, ignore, gap)
    if not bool(v.any()):
        return aux.sum() * 0.0
    m = v[:, :, None].expand_as(tgt)
    pw = torch.tensor(float(pos_weight), device=aux.device, dtype=aux.dtype)
    return F.binary_cross_entropy_with_logits(aux[m], tgt[m], pos_weight=pw)


# ---------------------------------------------------------------- 按段似然（与 结果\F1_files\event_likelihood_1115.py 同式，向量化）
def path_scores(s, g, valid):
    """s [N,T,K] 每期状态对数概率；g [N,T-1,K,K] 换类得分；valid [N,T]。返回 不变路径 [N,K]、在 τ=1..T-1 由 a 变 b 的路径 [N,T-1,K,K]。"""
    N, T, K = s.shape
    s = s * valid[..., None].to(s.dtype)
    P = torch.cat([torch.zeros(N, 1, K, dtype=s.dtype, device=s.device), torch.cumsum(s, 1)], 1)
    const = P[:, T]
    pre = P[:, 1:T]
    post = const[:, None] - pre
    ch = pre[:, :, :, None] + post[:, :, None, :] + g
    eye = torch.eye(K, dtype=torch.bool, device=s.device)
    return const, ch.masked_fill(eye[None, None], float("-inf"))


def event_nll(s, g, y, ignore, tol=1):
    """向量化的按段似然。y [N,T]（ignore 处无效）。返回 (每像元负对数似然 [N], 可用掩膜 [N])；
    可用 = 至少一期有效、有效期之间至多一次换类。"""
    N, T, K = s.shape
    v = y != ignore
    const, ch = path_scores(s, g, v)
    logZ = torch.logsumexp(torch.cat([const, ch.flatten(1)], 1), 1)
    yc = y.clamp(0, K - 1).long()
    idx = torch.arange(T, device=s.device).expand(N, T)
    last_valid = torch.cummax(torch.where(v, idx, torch.full_like(idx, -1)), 1).values      # 到 t 为止最后一个有效期
    prev_idx = torch.cat([torch.full((N, 1), -1, device=s.device, dtype=idx.dtype), last_valid[:, :-1]], 1)
    prev_lab = torch.gather(yc, 1, prev_idx.clamp(min=0))
    chg = v & (prev_idx >= 0) & (yc != prev_lab)
    nchg = chg.sum(1)
    nvalid = v.sum(1)
    usable = (nvalid > 0) & (nchg <= 1)
    first = torch.argmax(v.to(torch.int8), 1)
    a0 = torch.gather(yc, 1, first[:, None])[:, 0]
    num_const = torch.gather(const, 1, a0[:, None])[:, 0]
    t1 = torch.argmax(chg.to(torch.int8), 1)
    t0 = torch.gather(prev_idx, 1, t1[:, None])[:, 0].clamp(min=0)
    a = torch.gather(prev_lab, 1, t1[:, None])[:, 0]
    b = torch.gather(yc, 1, t1[:, None])[:, 0]
    tau = torch.arange(1, T, device=s.device)
    lo = (t0 + 1 - tol).clamp(min=1)
    hi = (t1 + tol).clamp(max=T - 1)
    allowed = (tau[None] >= lo[:, None]) & (tau[None] <= hi[:, None])
    ch_ab = torch.gather(ch.reshape(N, T - 1, K * K), 2, (a * K + b)[:, None, None].expand(N, T - 1, 1))[:, :, 0]
    num_chg = torch.logsumexp(torch.where(allowed, ch_ab, torch.full_like(ch_ab, float("-inf"))), 1)
    num = torch.where(nchg == 1, num_chg, num_const)
    nll = logZ - num
    usable = usable & torch.isfinite(nll)
    return torch.where(usable, nll, torch.zeros_like(nll)), usable


def map_decode(s, g, valid):
    """精确最大后验：s [N,T,K]、g [N,T-1,K,K]、valid [N,T] → 每期身份 [N,T]。"""
    N, T, K = s.shape
    const, ch = path_scores(s, g, valid)
    bc, ac = const.max(1)
    bch, ich = ch.flatten(1).max(1)
    tau = ich // (K * K) + 1
    a = (ich % (K * K)) // K
    b = ich % K
    t = torch.arange(T, device=s.device)[None]
    out = torch.where(t < tau[:, None], a[:, None], b[:, None])
    return torch.where((bch > bc)[:, None], out, ac[:, None].expand(N, T))


def to_pixels(logits, clog):
    """[B,T,K,H,W] 与 [B,T-1,H,W] → 每期对数概率 s [N,T,K] 与变化对数几率 c [N,T-1]（N = B·H·W）。"""
    B, T, K, H, W = logits.shape
    s = F.log_softmax(logits.float(), 2).permute(0, 3, 4, 1, 2).reshape(-1, T, K)
    c = clog.float().permute(0, 2, 3, 1).reshape(-1, T - 1)
    return s, c


def event_loss(logits, clog, hazard, y, ignore, tol=1):
    """按段似然损失（可用像元平均，再除以期数，与每期交叉熵量级相当）。"""
    s, c = to_pixels(logits, clog)
    T = s.shape[1]
    g = c[:, :, None, None] + hazard[None, None].float()
    yy = y.permute(0, 2, 3, 1).reshape(-1, T)
    nll, usable = event_nll(s, g, yy, ignore, tol)
    if not bool(usable.any()):
        return logits.sum() * 0.0
    return nll[usable].mean() / T


def native(logits, clog, up):
    """放大训练的输出回到原分辨率：概率在 up×up 上平均（返回对数概率），变化对数几率取平均。"""
    if up == 1:
        return F.log_softmax(logits.float(), 2), clog.float()
    B, T, K, H, W = logits.shape
    p = F.softmax(logits.float(), 2).view(B * T, K, H, W)
    p = F.avg_pool2d(p, up).view(B, T, K, H // up, W // up)
    c = F.avg_pool2d(clog.float(), up)
    return torch.log(p.clamp_min(1e-6)), c
