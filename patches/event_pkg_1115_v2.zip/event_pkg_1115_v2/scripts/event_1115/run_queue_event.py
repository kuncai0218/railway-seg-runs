# -*- coding: utf-8 -*-
"""T22 任务运行器（实验包 event_pkg_1115 用；Windows、Linux 都可）。在实验包目录里运行：
  python -X utf8 scripts/run_queue_event.py tasks/<任务文件>.json [--max 2]
目录约定（与以前的 pub_st3d_pkg_* 相同，都在实验包的上一级目录下）：st3d_data/Muds、st3d_cache/Muds、st3d_runs/。
- 启动前自检：MUDS 数据与缓存在不在；scripts/event_1115/check_event.py 是否“全部通过”。任何一项不过就停下，不下载数据、不改代码。
- 任务文件每条：{"名称": ..., "步骤": [{"脚本": ..., "参数": [...]}, ...]}；参数里的 {out} 换成输出目录 st3d_runs/<名称>。
- 输出目录里已有 final_event.json 的任务跳过；中途停掉后重新运行本命令，训练会从 last.pth 接着跑。
- 同一任务失败自动重试一次（接着跑）；再失败就不再接新任务，等组长处理。
- 日志：st3d_runs/t22_queue.log；每个任务的输出在 st3d_runs/<名称>/train.log。
环境变量 T22_DATA、T22_CACHE、T22_RUNS 可覆盖默认目录（只在组长本机测试用）。
"""
import argparse
import json
import os
import subprocess
import sys
import threading
import time

PKG = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
WORK = os.path.dirname(PKG)
RUNS = os.environ.get("T22_RUNS", os.path.join(WORK, "st3d_runs"))
DATA = os.environ.get("T22_DATA", os.path.join(WORK, "st3d_data"))
CACHE = os.environ.get("T22_CACHE", os.path.join(WORK, "st3d_cache"))
ENV = dict(os.environ, ST3D_REPO=os.path.join(PKG, "ST3DUNet"), ST3D_DATA=DATA, ST3D_CACHE=CACHE, TQDM_DISABLE="1", PYTHONIOENCODING="utf-8")
LOCK = threading.Lock()


def log(msg):
    line = time.strftime("%m-%d %H:%M:%S ") + msg
    with LOCK:
        print(line, flush=True)
        with open(os.path.join(RUNS, "t22_queue.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")


def preflight():
    need = [os.path.join(DATA, "Muds", "split.json"), os.path.join(CACHE, "Muds")]
    miss = [p for p in need if not os.path.exists(p)]
    if miss:
        log(f"自检不过：找不到 {miss}。不要下载数据，把这一行回报组长。")
        return False
    r = subprocess.run([sys.executable, "-X", "utf8", os.path.join("scripts", "event_1115", "check_event.py")], cwd=PKG, env=ENV,
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    out = (r.stdout or "") + (r.stderr or "")
    with open(os.path.join(RUNS, "t22_check.txt"), "w", encoding="utf-8") as f:
        f.write(out)
    ok = r.returncode == 0 and out.strip().endswith("全部通过")
    log("自检：check_event.py " + ("全部通过" if ok else f"没通过（返回码 {r.returncode}），输出在 t22_check.txt，回报组长"))
    return ok


def run_task(task, state):
    out = os.path.join(RUNS, task["名称"])
    os.makedirs(out, exist_ok=True)
    for attempt in (1, 2):
        ok = True
        for st in task["步骤"]:
            args = [x.replace("{out}", out) for x in st["参数"]]
            if os.path.basename(st["脚本"]) in ("st3d_repro.py", "run_st3d.py") and "--out" not in args:
                args += ["--out", out]
            if os.path.basename(st["脚本"]) in ("st3d_repro.py", "run_st3d.py") and os.path.exists(os.path.join(out, "final.json")):
                continue                                                      # 训练已完成，只补后面的评价
            with open(os.path.join(out, "train.log"), "a", encoding="utf-8") as f:
                p = subprocess.Popen([sys.executable, "-X", "utf8", st["脚本"]] + args, cwd=PKG, env=ENV, stdout=f, stderr=subprocess.STDOUT)
                log(f"开始 {task['名称']}：{st['脚本']}（第 {attempt} 次），进程号 {p.pid}")
                rc = p.wait()
            if rc != 0:
                log(f"{task['名称']}：{st['脚本']} 返回码 {rc}")
                ok = False
                break
        if ok and os.path.exists(os.path.join(out, "final_event.json")):
            log(f"结束 {task['名称']}，正常完成（final_event.json 已写出）")
            return
        if attempt == 1:
            log(f"{task['名称']} 失败，自动重试一次（接着跑）")
    log(f"{task['名称']} 第二次失败：不再接新任务，看 {task['名称']}/train.log 末尾，回报组长")
    state["stop"] = True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tasks")
    ap.add_argument("--max", type=int, default=2)
    ap.add_argument("--skip_check", action="store_true")
    a = ap.parse_args()
    os.makedirs(RUNS, exist_ok=True)
    log(f"运行器启动，进程号 {os.getpid()}；实验包 {PKG}；数据 {DATA}；缓存 {CACHE}；输出 {RUNS}")
    if not a.skip_check and not preflight():
        sys.exit(2)
    tasks = json.load(open(os.path.join(PKG, a.tasks), encoding="utf-8"))["任务"]
    todo = []
    for t in tasks:
        if os.path.exists(os.path.join(RUNS, t["名称"], "final_event.json")):
            log(f"{t['名称']} 已完成，跳过")
        else:
            todo.append(t)
    state = {"stop": False}
    threads = []
    while todo or any(th.is_alive() for th in threads):
        threads = [th for th in threads if th.is_alive()]
        while todo and len(threads) < a.max and not state["stop"]:
            t = todo.pop(0)
            th = threading.Thread(target=run_task, args=(t, state), daemon=False)
            th.start(); threads.append(th)
            time.sleep(20)                                                   # 错开数据载入
        if state["stop"]:
            todo.clear()
        time.sleep(15)
    log("运行器退出")


if __name__ == "__main__":
    main()
