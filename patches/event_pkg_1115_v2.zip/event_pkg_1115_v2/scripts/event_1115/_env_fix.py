# -*- coding: utf-8 -*-
"""本机 cdtrain 环境里 scipy.signal 的一个 DLL 被 Windows 应用程序控制策略拦截（11-15 发现），导致 torchmetrics 导入失败。
torchmetrics 导入 scipy.signal 只为一个兼容补丁（hamming）；这里只在本进程、只在导入失败时放一个占位模块，不改系统设置、不改共享代码。
其他机器上 scipy.signal 能正常导入时，本文件什么都不做。"""
import sys
import types

try:
    import scipy.signal  # noqa: F401
    SCIPY_SIGNAL_STUB = False
except ImportError:
    _stub = types.ModuleType("scipy.signal")
    _stub.hamming = None
    _stub.windows = types.SimpleNamespace(hamming=None)
    sys.modules["scipy.signal"] = _stub
    SCIPY_SIGNAL_STUB = True
