# -*- coding: utf-8 -*-
"""T22 训练入口（G2 / G3 / G4）。任务书：总账_1110\\任务书\\T22_判决对齐训练_阶段1_MUDS.md。

与 st3d_repro.py 的运行逐项相同的部分（直接调用 st3d_repro 的函数）：数据、缓存、增强、批大小、优化器、学习率、调度、种子流程、官方类别损失。
不同的只有：
1. 骨干外包 EventWrap（短窗口变化通道、可学换类先验、可选辅助头、可选输入放大）；骨干先建、新部件后建，同一种子下骨干初始化与 G1 相同；
2. 损失 = 官方类别损失 + w_chg × 变化通道二值交叉熵（正样本权重 pos_weight）+ w_evt × 按段似然（容许 tol 期）+ w_aux × 辅助目标；
3. 每轮只评同区域（val_in）；新区（val_out）只在训练结束后评一次，写 final.json 与 final_event.json；不存 best，不读测试区。
用法见 README.md；冒烟（CPU）：加 --device cpu --epochs 1 --max_steps 2 --max_eval_batches 2 --skip_final_out
"""
import argparse
import copy
import json
import os
import sys
import time

import torch
from torch.utils.data import DataLoader

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)
import _env_fix  # noqa: E402,F401  本机 scipy.signal 被策略拦截时的占位
import st3d_repro as R  # noqa: E402
from event_model import EventWrap, aux_loss, change_bce, event_loss, native, up_labels  # noqa: E402
from event_eval import evaluate_full, machine_info  # noqa: E402

ARMS = {  # 任务书第 2 节写定的各组设置
    "G2": dict(w_evt=0.0, up=1, aux=0),
    "G3": dict(w_evt=1.0, up=1, aux=0),
    "G4": dict(w_evt=1.0, up=2, aux=1),
}


def train_epoch(model, loader, wrapper, optimizer, device, epoch, a, ignore, max_steps=None):
    model.train()
    sums, n = {}, 0
    total = len(loader)
    for step, batch in enumerate(loader):
        if max_steps and step >= max_steps:
            break
        x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
        logits, clog, aux = model(x, date)
        yl = up_labels(y, a.up)
        losses = wrapper.compute_loss(pred=logits, batch=yl, average=True)
        lc = change_bce(clog, yl, ignore, a.pos_weight)
        le = event_loss(logits, clog, model.hazard, yl, ignore, a.tol) if a.w_evt > 0 else lc * 0.0
        la = aux_loss(aux, yl, ignore, a.aux_pw, 2 * a.up) if a.aux else lc * 0.0
        loss = losses["loss"] + a.w_chg * lc + a.w_evt * le + a.w_aux * la
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        for k, v in {**losses, "change_bce": lc, "event_nll": le, "aux": la}.items():
            sums[k] = sums.get(k, 0.0) + float(v.detach())
        n += 1
        if (step + 1) % max(1, total // 3) == 0:
            print(f"[Epoch {epoch}] Step [{step + 1}/{total}] loss {float(loss):.4f} 类别 {float(losses['loss']):.4f} 变化 {float(lc):.4f} "
                  f"按段 {float(le):.4f} 辅助 {float(la):.4f}", flush=True)
    return {k: v / max(n, 1) for k, v in sums.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", choices=list(ARMS), required=True)
    ap.add_argument("--data", default="muds")
    ap.add_argument("--arch", choices=["mono_gn", "mono", "st3d_gn", "st3d"], default="mono_gn")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--wd", type=float, default=1e-3)
    ap.add_argument("--sched", choices=["code", "paper"], default="paper")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--eval_workers", type=int, default=0)
    ap.add_argument("--eval_batch", type=int, default=16)
    ap.add_argument("--valid", type=int, default=0)
    ap.add_argument("--valid_aug", type=float, default=0.0)
    ap.add_argument("--s2align", type=int, default=0)
    ap.add_argument("--dn", choices=["none", "pca32"], default="none")
    ap.add_argument("--oe", choices=["none", "pca32", "pca32_v13"], default="none")
    ap.add_argument("--s2", choices=["none", "all", "swir"], default="none")
    ap.add_argument("--dw", choices=["none", "month"], default="none")
    ap.add_argument("--aef", choices=["none", "prev", "prev2", "same"], default="none")
    ap.add_argument("--w_chg", type=float, default=1.0)
    ap.add_argument("--pos_weight", type=float, default=10.0, help="变化通道正样本权重（T22 定为 10）")
    ap.add_argument("--tol", type=int, default=1, help="按段似然容许的变化时刻误差（期）")
    ap.add_argument("--win", type=int, default=2, help="短窗口长度（期）")
    ap.add_argument("--w_aux", type=float, default=0.5)
    ap.add_argument("--aux_pw", type=float, default=5.0)
    ap.add_argument("--head_mid", type=int, default=32)
    ap.add_argument("--no_cache", action="store_true")
    ap.add_argument("--deterministic", action="store_true")
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--max_steps", type=int, default=0)
    ap.add_argument("--max_eval_batches", type=int, default=0)
    ap.add_argument("--skip_final_out", action="store_true")
    ap.add_argument("--dump_out", action="store_true", help="本机用：把新区原分辨率对数概率与变化对数几率存成 float16")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    for k, v in ARMS[a.arm].items():
        setattr(a, k, v)

    cfg = R.load_yaml(os.path.join(R.REPO, "configs", f"{a.data}.yaml"))
    cfg["dataset"]["path"] = R.DATA[a.data][1]
    R.apply_s2(cfg, a.s2, a.oe, a.dw, a.aef, a.dn, a.valid)
    cfg["dataset"]["valid_aug"] = float(a.valid_aug)
    cfg["dataset"]["s2align"] = int(a.s2align)
    epochs, device, ign = a.epochs, a.device, cfg["dataset"]["ignore_index"]
    K = cfg["dataset"]["num_classes"]
    side = cfg["dataset"]["true_size"] // cfg["dataset"]["image_size"]
    ppr = side * side
    os.makedirs(a.out, exist_ok=True)
    files = [os.path.abspath(__file__), os.path.join(HERE, "event_model.py"), os.path.join(HERE, "event_eval.py"), os.path.abspath(R.__file__)]
    json.dump({"args": vars(a), "epochs": epochs, "cfg": cfg, "t22": {"arm": a.arm, "设置": ARMS[a.arm], "机器": machine_info(files)}},
              open(os.path.join(a.out, "config.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    R.seed_all(a.seed, a.deterministic)

    t0 = time.time()
    cache = not a.no_cache
    trainset = R.make_set(cfg, "train", cache=cache)
    sets = {"val_in": R.make_set(cfg, "val", False, cache), "val_out": R.make_set(cfg, "val", True, cache)}
    print(f"数据载入 {time.time() - t0:.0f} 秒；训练 {len(trainset)}，" + "，".join(f"{k} {len(v)}" for k, v in sets.items()), flush=True)
    bs = cfg["dataset"]["global_batch_size"]
    train_loader = DataLoader(trainset, batch_size=bs, shuffle=True, drop_last=True, pin_memory=False, num_workers=a.workers,
                              collate_fn=R.collate_fn, persistent_workers=a.workers > 0)
    loaders = {k: DataLoader(v, batch_size=a.eval_batch, shuffle=False, pin_memory=False, num_workers=a.eval_workers,
                             collate_fn=R.collate_fn, persistent_workers=a.eval_workers > 0) for k, v in sets.items()}

    mcfg = copy.deepcopy(cfg)
    if a.up > 1:  # 骨干瓶颈的空间注意力按放大后的输入尺寸建（位置编码个数随之变）
        mcfg["ST3DUNET"]["SPATIAL_ATTENTION"]["IMAGE_SIZE"] = int(cfg["ST3DUNET"]["SPATIAL_ATTENTION"]["IMAGE_SIZE"]) * a.up
    base = R.build_model(mcfg, a.arch, None, 0)  # 与 G1 同一函数、同一时刻建骨干
    model = EventWrap(base, K, a.head_mid, a.win, a.up, bool(a.aux)).to(device)
    nb = sum(p.numel() for p in base.parameters() if p.requires_grad)
    nh = sum(p.numel() for n_, p in model.named_parameters() if not n_.startswith("base."))
    print(f"组 {a.arm}；参数量：骨干 {nb / 1e6:.3f} M，新部件 {nh / 1e3:.1f} K（{100 * nh / nb:.2f}%）；放大 {a.up}，辅助 {a.aux}", flush=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=a.wd)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=a.lr * 0.01, last_epoch=-1)
    metric = R.SCDMetric(num_classes=K, ignore_index=ign, class_names=cfg["dataset"]["class_names"])
    wrapper = R.SitsScdWrapper(model=base, loss_fn=R.Losses(mix=cfg["loss"]["mix"], ignore_index=cfg["loss"]["ignore_index"]),
                               val_metrics=metric, trainloader=train_loader, testloader_in=loaders["val_in"],
                               testloader_out=loaders["val_out"], optimizer=optimizer, scheduler=scheduler, device=device,
                               seq_len=cfg["dataset"]["seq_len"], save_ckpt_path=a.out, save_log_path=a.out)

    def fwd(x, date):
        model.eval()
        logits, clog, _ = model(x, date)
        return native(logits, clog, a.up)

    log = open(os.path.join(a.out, "epochs.jsonl"), "a", encoding="utf-8")
    start = 1
    if os.path.exists(os.path.join(a.out, "last.pth")):  # 断点续跑
        ck = torch.load(os.path.join(a.out, "last.pth"), map_location=device)
        model.load_state_dict(ck["model"]); optimizer.load_state_dict(ck["optimizer"]); scheduler.load_state_dict(ck["scheduler"])
        start = ck["epoch"] + 1
        print(f"从第 {start} 轮接着跑", flush=True)
    for epoch in range(start, epochs + 1):
        t1 = time.time()
        losses = train_epoch(model, train_loader, wrapper, optimizer, device, epoch, a, ign, a.max_steps or None)
        if a.sched == "paper":
            scheduler.step()
        rec = {"epoch": epoch, "lr": optimizer.param_groups[0]["lr"], **{k: losses.get(k) for k in ("loss", "change_bce", "event_nll", "aux")},
               "hazard": model.hazard.detach().cpu().tolist(), "train_min": round((time.time() - t1) / 60, 2)}
        ev = evaluate_full(fwd, loaders["val_in"], metric, device, ign, ppr, side, model.hazard.detach(), a.max_eval_batches)
        rec["val_in"] = {k: v for k, v in ev.items() if k != "变化"}
        rec["val_in_变化F1"] = {k: round(v["F1"], 3) for k, v in ev["变化"].items() if isinstance(v, dict)}
        if epoch % cfg["trainer"]["ckpt_interval"] == 0:
            torch.save({"model": model.state_dict(), "epoch": epoch}, os.path.join(a.out, f"epoch{epoch}.pth"))
        rec["min"] = round((time.time() - t1) / 60, 2)
        log.write(json.dumps(rec, ensure_ascii=False) + "\n"); log.flush()
        print(f"第 {epoch} 轮 loss {rec['loss']:.4f} | val_in mIoU {rec['val_in']['miou']:.2f} | 变化 F1 " +
              " ".join(f"{k} {v:.1f}" for k, v in rec["val_in_变化F1"].items()) + f" | 换类先验 {rec['hazard']} | {rec['min']} 分钟", flush=True)
        torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(), "scheduler": scheduler.state_dict(), "epoch": epoch},
                   os.path.join(a.out, "last.pth"))

    final = {"组": a.arm, "种子": a.seed, "last": {"epoch": epochs, "hazard": model.hazard.detach().cpu().tolist()}}
    final["last"]["val_in"] = evaluate_full(fwd, loaders["val_in"], metric, device, ign, ppr, side, model.hazard.detach(), a.max_eval_batches)
    if not a.skip_final_out:  # 新区只在这里读一次
        dump = {} if a.dump_out else None
        final["last"]["val_out"] = evaluate_full(fwd, loaders["val_out"], metric, device, ign, ppr, side, model.hazard.detach(),
                                                 a.max_eval_batches, collect_objects=True, dump=dump)
        if dump:
            import numpy as np
            dd = os.path.join(a.out, "dump_out"); os.makedirs(dd, exist_ok=True)
            for k, v in dump.items():
                np.save(os.path.join(dd, f"{k}.npy"), np.concatenate(v))
            json.dump({"patches_per_region": ppr, "side": side, "K": K, "ignore": ign, "说明": "logp 为原分辨率对数概率 float16；clog 为变化对数几率"},
                      open(os.path.join(dd, "meta.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    final["机器"] = machine_info(files)
    for name in ("final_event.json", "final.json"):
        json.dump(final, open(os.path.join(a.out, name), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    vo = final["last"].get("val_out", final["last"]["val_in"])
    print("完成", json.dumps({"mIoU": round(vo["miou"], 2), **{k: round(v["F1"], 2) for k, v in vo["变化"].items() if isinstance(v, dict)}}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
