# -*- coding: utf-8 -*-
"""T22 等价性与正确性检查（CPU）：
1. 向量化按段似然 = 穷举（含无效期、容许误差、多于一次换类的像元被剔除）；数值梯度；
2. 最大后验判决 = 穷举，且换类项取常数 −4 时与 F10 的按段判类一致；
3. 包上 EventWrap 后骨干输出与裸骨干逐位相同；
4. 放大 2 倍时骨干能按 256 建瓶颈并前向、反传；
5. 辅助目标在玩具标签上符合定义。
用法：python -X utf8 check_event.py   （全部通过时最后一行打印“全部通过”）
"""
import copy
import os
import sys

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)
import _env_fix  # noqa: E402,F401  本机 scipy.signal 被策略拦截时的占位
from event_model import EventWrap, aux_targets, event_nll, map_decode, path_scores  # noqa: E402


def brute(s, g, y, ignore, tol):
    N, T, K = s.shape
    outs, use = [], []
    for i in range(N):
        v = y[i] != ignore
        sv = s[i] * v[:, None]
        paths = [(sv[:, a].sum(), ('c', a)) for a in range(K)]
        for tau in range(1, T):
            for a in range(K):
                for b in range(K):
                    if a != b:
                        paths.append((sv[:tau, a].sum() + sv[tau:, b].sum() + g[i, tau - 1, a, b], ('x', tau, a, b)))
        Z = torch.logsumexp(torch.stack([p for p, _ in paths]), 0)
        idx = torch.nonzero(v).flatten()
        if len(idx) == 0:
            outs.append(torch.tensor(0., dtype=s.dtype)); use.append(False); continue
        yy = y[i, idx]
        ch = torch.nonzero(yy[1:] != yy[:-1]).flatten()
        if len(ch) == 0:
            num = sv[:, int(yy[0])].sum()
        elif len(ch) == 1:
            a, b = int(yy[ch[0]]), int(yy[ch[0] + 1])
            lo_t, hi_t = int(idx[ch[0]]) + 1, int(idx[ch[0] + 1])
            num = torch.logsumexp(torch.stack([p for p, k in paths if k[0] == 'x' and k[2] == a and k[3] == b and max(1, lo_t - tol) <= k[1] <= min(T - 1, hi_t + tol)]), 0)
        else:
            outs.append(torch.tensor(0., dtype=s.dtype)); use.append(False); continue
        outs.append(Z - num); use.append(True)
    return torch.stack(outs), torch.tensor(use)


def main():
    torch.manual_seed(0)
    ok = True
    N, T, K, ign = 300, 8, 2, 2
    s = torch.randn(N, T, K, dtype=torch.float64).log_softmax(-1)
    g = torch.randn(N, T - 1, K, K, dtype=torch.float64)
    y = torch.randint(0, K, (N, 1)).expand(N, T).clone()
    for i in range(N):
        r = torch.rand(1).item()
        if r < 0.4:
            tau = int(torch.randint(1, T, (1,))); y[i, tau:] = 1 - y[i, 0]
        elif r < 0.5:
            y[i, 2:4] = 1 - y[i, 0]                      # 往返（两次换类，应被剔除）
        y[i, torch.rand(T) < 0.15] = ign                 # 随机无效期
    y[0] = ign                                            # 全无效
    for tol in (0, 1, 2):
        nll, use = event_nll(s, g, y, ign, tol)
        rn, ru = brute(s, g, y, ign, tol)
        d = float((nll[use] - rn[use]).abs().max()) if bool(use.any()) else 0.0
        same_use = bool((use == ru).all())
        print(f"1. 容许 {tol} 期：与穷举最大差 {d:.2e}，可用掩膜一致 {same_use}，可用 {int(use.sum())}/{N}")
        ok &= d < 1e-9 and same_use
    sg = s[:20].clone().requires_grad_(True); gg = g[:20].clone().requires_grad_(True)
    gc = torch.autograd.gradcheck(lambda a_, b_: event_nll(a_, b_, y[:20], ign, 1)[0].sum(), (sg, gg))
    print("1. 数值梯度检查", gc); ok &= bool(gc)
    v = y != ign
    dec = map_decode(s, torch.full_like(g, -4.0), v)
    const, ch = path_scores(s, torch.full_like(g, -4.0), v)
    best = torch.cat([const, ch.flatten(1)], 1).argmax(1)
    agree = True
    for i in range(N):
        b = int(best[i])
        if b < K:
            exp = torch.full((T,), b)
        else:
            j = b - K; tau = j // (K * K) + 1; a_ = (j % (K * K)) // K; b_ = j % K
            exp = torch.tensor([a_] * tau + [b_] * (T - tau))
        agree &= bool((dec[i] == exp).all())
    print("2. 最大后验判决与穷举一致", agree); ok &= agree
    sys.path.insert(0, os.path.dirname(HERE))
    import st3d_repro as R
    cfg = R.load_yaml(os.path.join(R.REPO, "configs", "muds.yaml"))
    torch.manual_seed(1)
    base = R.build_model(copy.deepcopy(cfg), "mono_gn", None, 0).eval()
    x = torch.randn(1, 8, 3, 128, 128)
    d = torch.arange(8)[None] * 90
    with torch.no_grad():
        y0 = base(x, d)
        w = EventWrap(base, 2).eval()
        y1, c1, _ = w(x, d)
    same = bool(torch.equal(y0, y1))
    print("3. 包上 EventWrap 后骨干输出逐位相同", same, "变化通道形状", tuple(c1.shape)); ok &= same and tuple(c1.shape) == (1, 7, 128, 128)
    mcfg = copy.deepcopy(cfg); mcfg["ST3DUNET"]["SPATIAL_ATTENTION"]["IMAGE_SIZE"] = 256
    w2 = EventWrap(R.build_model(mcfg, "mono_gn", None, 0), 2, up=2, aux=True)
    l2, c2, a2 = w2(torch.randn(1, 8, 3, 128, 128), d)
    (l2.mean() + c2.mean() + a2.mean()).backward()
    sh = (tuple(l2.shape), tuple(c2.shape), tuple(a2.shape))
    print("4. 放大 2 倍前向与反传", sh); ok &= sh == ((1, 8, 2, 256, 256), (1, 7, 256, 256), (1, 8, 2, 256, 256))
    yy = torch.zeros(1, 1, 9, 9, dtype=torch.long)
    yy[0, 0, 2:7, 1:4] = 1; yy[0, 0, 2:7, 5:8] = 1      # 两栋楼，中间第 4 列是 1 像元的缝
    t, _ = aux_targets(yy, 2, gap=2)
    con = t[0, 0, 1]; bnd = t[0, 0, 0]
    c_ok = bool(con[2:7, 4].all()) and float(con.sum()) == 5.0
    b_ok = bool(bnd[2, 1:4].all()) and not bool(bnd[4, 2])
    print("5. 辅助目标：缝被标为接触", c_ok, "，边界正确", b_ok); ok &= c_ok and b_ok
    print("全部通过" if ok else "有检查没通过")


if __name__ == "__main__":
    main()
