# -*- coding: utf-8 -*-
"""T22：给原脚本训练的 G1（只有每期类别）算与 G2—G4 同口径的评价（逐期相减、事后按段代价 4、逐区计数、对象级统计）。
用法：python -X utf8 eval_ckpt.py <运行目录>/last.pth [--out <运行目录>/final_event.json] [--eval_batch 16]
只评 val_in、val_out；不读测试区。"""
import argparse
import json
import os
import sys

import torch
from torch.utils.data import DataLoader

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)
import _env_fix  # noqa: E402,F401  本机 scipy.signal 被策略拦截时的占位
import st3d_repro as R  # noqa: E402
from event_eval import evaluate_full, machine_info  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ckpt")
    ap.add_argument("--out", default=None)
    ap.add_argument("--eval_batch", type=int, default=16)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--max_eval_batches", type=int, default=0)
    a = ap.parse_args()
    model, cfg, data, epoch = R.load_run_model(a.ckpt, a.device)
    ign = cfg["dataset"]["ignore_index"]
    side = cfg["dataset"]["true_size"] // cfg["dataset"]["image_size"]
    ppr = side * side
    metric = R.SCDMetric(num_classes=cfg["dataset"]["num_classes"], ignore_index=ign, class_names=cfg["dataset"]["class_names"])

    def fwd(x, date):
        return torch.log_softmax(model(x, date).float(), 2), None

    res = {"组": "G1", "检查点": os.path.abspath(a.ckpt), "last": {"epoch": epoch}}
    for split, ds in (("val_in", False), ("val_out", True)):
        loader = DataLoader(R.make_set(cfg, "val", ds, True), batch_size=a.eval_batch, shuffle=False, num_workers=0, collate_fn=R.collate_fn)
        res["last"][split] = evaluate_full(fwd, loader, metric, a.device, ign, ppr, side, None, a.max_eval_batches, collect_objects=(split == "val_out"))
    res["机器"] = machine_info([os.path.abspath(__file__), os.path.join(HERE, "event_eval.py"), os.path.join(HERE, "event_model.py"), os.path.abspath(R.__file__)])
    out = a.out or os.path.join(os.path.dirname(os.path.abspath(a.ckpt)), "final_event.json")
    json.dump(res, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    vo = res["last"]["val_out"]
    print("完成", json.dumps({"mIoU": round(vo["miou"], 2), **{k: round(v["F1"], 2) for k, v in vo["变化"].items() if isinstance(v, dict)}}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
