# -*- coding: utf-8 -*-
"""T22：原样执行 scripts/st3d_repro.py 的 main()（参数原样传入），只在执行前装上 _env_fix 的占位（本机 scipy.signal 被策略拦截时才生效）。
用“导入后调用 main()”而不是 runpy：Windows 下数据加载的子进程会重新导入主模块，这样子进程导入的是本文件（先装占位），不会再撞上拦截。
不改 st3d_repro.py 的任何内容；其他机器上与直接运行 st3d_repro.py 完全相同。"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import _env_fix  # noqa: E402,F401

if __name__ == "__main__":
    import st3d_g1_t22 as st3d_repro  # noqa: E402
    sys.argv[0] = os.path.abspath(st3d_repro.__file__)
    st3d_repro.main()

    # Record the evaluation-policy adapter; model, losses and training helpers are unchanged.
    import json
    from event_eval import machine_info
    out_dir = sys.argv[sys.argv.index("--out") + 1]
    config_path = os.path.join(out_dir, "config.json")
    with open(config_path, encoding="utf-8") as f:
        config = json.load(f)
    config["t22"] = {"arm": "G1", "evaluation_policy": "val_in during training; fixed last only; val_out once in eval_ckpt.py", "机器": machine_info([os.path.abspath(__file__), os.path.abspath(st3d_repro.__file__)])}
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=1)
