# -*- coding: utf-8 -*-
"""T22 评价：同一遍里算官方类别指标 + 几种判决下的二值变化（逐期相减 / 事后按段代价 4 / 职责判决 / 学出来的判决 / 变化通道 0.5），
逐区计数，按对象（同一期对上 8 邻接相连的一片）的找到与报出比例（有 scipy 时）。新区只在训练结束时调用一次。"""
import hashlib
import os
import platform

import numpy as np
import torch

from event_model import map_decode

DECODES = ["逐期相减", "事后按段代价4", "职责判决", "学出来的判决", "变化通道0.5"]
SIZE_BINS = [(1, 16), (17, 64), (65, 10 ** 9)]
SIZE_NAMES = ["1—16", "17—64", "≥65"]


def sha256(path):
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def machine_info(files):
    info = {"platform": platform.platform(), "python": platform.python_version(), "torch": torch.__version__,
            "cuda": torch.version.cuda, "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
            "code_sha256": {os.path.basename(f): sha256(f) for f in files}}
    return info


def decode_all(logp, clog, hazard, valid):
    """logp [B,T,K,H,W] 对数概率；clog [B,T-1,H,W] 或 None；hazard [K,K] 或 None；valid [B,T,H,W]。返回 {判决名: [B,T,H,W] 类别}。"""
    B, T, K, H, W = logp.shape
    s = logp.permute(0, 3, 4, 1, 2).reshape(-1, T, K)
    v = valid.permute(0, 2, 3, 1).reshape(-1, T)
    out = {"逐期相减": logp.argmax(2)}
    g4 = torch.full((s.shape[0], T - 1, K, K), -4.0, device=s.device)
    out["事后按段代价4"] = map_decode(s, g4, v).view(B, H, W, T).permute(0, 3, 1, 2)
    if clog is not None:
        c = clog.permute(0, 2, 3, 1).reshape(-1, T - 1)
        g = c[:, :, None, None].expand(-1, -1, K, K)
        out["职责判决"] = map_decode(s, g, v).view(B, H, W, T).permute(0, 3, 1, 2)
        if hazard is not None:
            out["学出来的判决"] = map_decode(s, g + hazard[None, None], v).view(B, H, W, T).permute(0, 3, 1, 2)
    return out


class ChangeCounter:
    """逐区累计 tp/fp/fn；可选收集整幅图做对象级统计。"""

    def __init__(self, ppr, side, collect_objects=False):
        self.ppr, self.side = ppr, side
        self.c = {}
        self.collect = collect_objects
        self.buf = {}            # 区 → {"true": [ppr,T-1,h,w] bool, 判决名: 同形}
        self.obj = {}

    def add(self, sample_idx, y, ignore, preds, clog=None):
        """y [B,T,H,W]；preds {名: [B,T,H,W]}；clog [B,T-1,H,W] 或 None（变化通道 0.5 判决）。"""
        v = y != ignore
        m = v[:, 1:] & v[:, :-1]
        tc = (y[:, 1:] != y[:, :-1]) & m
        pcs = {k: (p[:, 1:] != p[:, :-1]) & m for k, p in preds.items()}
        if clog is not None:
            pcs["变化通道0.5"] = (clog > 0) & m
        for b in range(y.shape[0]):
            r = int((sample_idx + b) // self.ppr)
            d = self.c.setdefault(r, {})
            for k, pc in pcs.items():
                e = d.setdefault(k, [0, 0, 0])
                e[0] += int((pc[b] & tc[b]).sum()); e[1] += int((pc[b] & ~tc[b]).sum()); e[2] += int((tc[b] & ~pc[b]).sum())
            if self.collect:
                bb = self.buf.setdefault(r, {"true": [None] * self.ppr, **{k: [None] * self.ppr for k in pcs}})
                p = int((sample_idx + b) % self.ppr)
                bb["true"][p] = tc[b].cpu().numpy()
                for k, pc in pcs.items():
                    bb.setdefault(k, [None] * self.ppr)[p] = pc[b].cpu().numpy()
                if all(x is not None for x in bb["true"]):
                    self._objects(r, bb)
                    del self.buf[r]

    def _objects(self, r, bb):
        try:
            from scipy import ndimage
        except ImportError:
            self.obj = None
            return
        n = self.side
        def mosaic(lst):
            a = np.stack(lst)                                                     # [ppr, T-1, h, w]
            P, T1, h, w = a.shape
            return a.reshape(n, n, T1, h, w).transpose(2, 0, 3, 1, 4).reshape(T1, n * h, n * w)
        tru = mosaic(bb["true"])
        st = np.ones((3, 3), int)
        res = self.obj.setdefault(r, {})
        for k in bb:
            if k == "true":
                continue
            pr = mosaic(bb[k])
            near_p = pr.copy(); near_p[1:] |= pr[:-1]; near_p[:-1] |= pr[1:]       # 容许差一期
            near_t = tru.copy(); near_t[1:] |= tru[:-1]; near_t[:-1] |= tru[1:]
            e = res.setdefault(k, {"真对象": [0, 0, 0], "找到": [0, 0, 0], "报出对象": 0, "报出为真": 0})
            for t in range(tru.shape[0]):
                lab, nobj = ndimage.label(tru[t], structure=st)
                if nobj:
                    sz = np.bincount(lab.ravel(), minlength=nobj + 1)[1:]
                    hit = ndimage.maximum(near_p[t], lab, np.arange(1, nobj + 1)).astype(bool)
                    for bi, (lo, hi) in enumerate(SIZE_BINS):
                        sel = (sz >= lo) & (sz <= hi)
                        e["真对象"][bi] += int(sel.sum()); e["找到"][bi] += int((sel & hit).sum())
                lab2, n2 = ndimage.label(pr[t], structure=st)
                if n2:
                    ok = ndimage.maximum(near_t[t], lab2, np.arange(1, n2 + 1)).astype(bool)
                    e["报出对象"] += int(n2); e["报出为真"] += int(ok.sum())

    def summary(self):
        names = sorted({k for d in self.c.values() for k in d})
        out = {}
        for k in names:
            tp = sum(d.get(k, [0, 0, 0])[0] for d in self.c.values())
            fp = sum(d.get(k, [0, 0, 0])[1] for d in self.c.values())
            fn = sum(d.get(k, [0, 0, 0])[2] for d in self.c.values())
            out[k] = {"F1": 100 * 2 * tp / max(2 * tp + fp + fn, 1), "精确率": 100 * tp / max(tp + fp, 1), "召回": 100 * tp / max(tp + fn, 1),
                      "命中": tp, "误报": fp, "漏检": fn, "逐区": {str(r): d.get(k, [0, 0, 0]) for r, d in sorted(self.c.items())}}
        if self.obj:
            for k in names:
                agg = {"真对象": [0, 0, 0], "找到": [0, 0, 0], "报出对象": 0, "报出为真": 0}
                for r in self.obj.values():
                    e = r.get(k)
                    if not e:
                        continue
                    for i in range(3):
                        agg["真对象"][i] += e["真对象"][i]; agg["找到"][i] += e["找到"][i]
                    agg["报出对象"] += e["报出对象"]; agg["报出为真"] += e["报出为真"]
                if k in out:
                    out[k]["对象"] = {"找到比例%": {SIZE_NAMES[i]: round(100 * agg["找到"][i] / max(agg["真对象"][i], 1), 2) for i in range(3)},
                                      "真对象数": dict(zip(SIZE_NAMES, agg["真对象"])), "报出对象为真%": round(100 * agg["报出为真"] / max(agg["报出对象"], 1), 2),
                                      "报出对象数": agg["报出对象"]}
        elif self.obj is None:
            out["_对象"] = "本机没有 scipy，未算对象级统计"
        return out


@torch.no_grad()
def evaluate_full(forward_fn, loader, metric, device, ignore, ppr, side, hazard=None, max_batches=0, collect_objects=False, dump=None):
    """forward_fn(x, date) → (对数概率 [B,T,K,H,W]（原分辨率）, 变化对数几率 [B,T-1,H,W] 或 None)。
    dump：可选 dict，收集原分辨率对数概率与变化对数几率（float16，numpy），用于本机导出。"""
    metric.reset()
    cnt = ChangeCounter(ppr, side, collect_objects)
    idx = 0
    for i, batch in enumerate(loader):
        if max_batches and i >= max_batches:
            break
        x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
        logp, clog = forward_fn(x, date)
        valid = y != ignore
        preds = decode_all(logp, clog, hazard, valid)
        metric.update(preds["逐期相减"].cpu(), y.cpu())
        cnt.add(idx, y, ignore, preds, clog)
        if dump is not None:
            dump.setdefault("logp", []).append(logp.half().cpu().numpy())
            if clog is not None:
                dump.setdefault("clog", []).append(clog.half().cpu().numpy())
            dump.setdefault("gt", []).append(y.to(torch.uint8).cpu().numpy())
        idx += y.shape[0]
    out = {k: float(v) for k, v in metric.compute().items()}
    out["变化"] = cnt.summary()
    return out
