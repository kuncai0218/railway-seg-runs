"""Export real DEN features, check on the assigned device, and run the four paired arms."""

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path


HERE = Path(__file__).resolve().parent


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data", required=True, type=Path)
    p.add_argument("--cache", type=Path)
    p.add_argument("--checkpoint", required=True, type=Path)
    p.add_argument("--sensor", required=True, choices=("s2", "planet"))
    p.add_argument("--seed", required=True, type=int)
    p.add_argument("--out", required=True, type=Path)
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--feature-device", default=None)
    p.add_argument("--opts", default="auto")
    p.add_argument("--stride", default=16, type=int, choices=(8, 16))
    p.add_argument("--steps", default=500, type=int)
    p.add_argument("--preexported", action="store_true")
    args = p.parse_args()
    out = args.out.resolve()
    features = out / "features"
    out.mkdir(parents=True, exist_ok=True)
    status_file = out / "runner_status.json"

    def stage(phase, command=None, rc=None):
        data = {"time": datetime.now().astimezone().isoformat(timespec="seconds"),
                "pid": os.getpid(), "phase": phase, "sensor": args.sensor,
                "seed": args.seed, "return_code": rc}
        if command is not None:
            data["command"] = [str(s) for s in command]
        tmp = status_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf8")
        tmp.replace(status_file)

    def execute(phase, filename, *flags):
        cmd = [sys.executable, "-B", "-u", "-X", "utf8", HERE / filename, *flags]
        stage(phase, cmd)
        with (out / f"{phase}.log").open("a", encoding="utf8") as log:
            log.write(f"\n[{datetime.now().isoformat(timespec='seconds')}] " + subprocess.list2cmdline(list(map(str, cmd))) + "\n")
            log.flush()
            result = subprocess.run(list(map(str, cmd)), cwd=HERE, stdout=log, stderr=subprocess.STDOUT)
        if result.returncode:
            stage(f"failed_{phase}", cmd, result.returncode)
            raise SystemExit(result.returncode)

    if not args.preexported:
        cache = ["--cache", args.cache.resolve()] if args.cache else []
        execute("export", "extract_features.py", "--sensor", args.sensor, "--data", args.data.resolve(),
                "--checkpoint", args.checkpoint.resolve(), "--out", features, "--opts", args.opts,
                "--device", args.feature_device or args.device, "--stride", args.stride, *cache)
    execute("smoke", "verify.py", "--device", args.device, "--features", features)
    execute("train", "train_pilot.py", "--features", features, "--out", out / "fit",
            "--seed", args.seed, "--steps", args.steps, "--device", args.device)
    stage("complete", rc=0)


if __name__ == "__main__":
    main()
