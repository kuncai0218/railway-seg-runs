"""Run the same-budget 2x2 DEN mechanism screen on a verified feature export."""

import argparse
import json
import math
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from extract_features import save_json, sha256
from transition import TransitionModel, decode, loss_terms, marginal_decode, paired_loss


ARMS = ("local_mass", "local_rival", "spectral_mass", "spectral_rival")
CLASSES = 6
OPERATING_POINT = 0.10


def read_part(root, manifest, name):
    arrays = {}
    areas = []
    for site, (area, digest) in enumerate(sorted(manifest["outputs"][name].items())):
        file = root / name / f"{area}.npz"
        if sha256(file) != digest:
            raise ValueError(f"Feature hash mismatch: {file}")
        with np.load(file, allow_pickle=False) as part:
            for key in part.files:
                arrays.setdefault(key, []).append(part[key])
            count = len(part["labels"])
        arrays.setdefault("site", []).append(np.full(count, site, dtype=np.int32))
        areas.append(area)
    return areas, {name: np.concatenate(parts) for name, parts in arrays.items()}


def geographic_folds(areas):
    """Keep areas connected within 100 km in the same fold as earlier source probes."""
    groups = np.arange(len(areas))
    coords = []
    for i, area in enumerate(areas):
        x, y, zoom = map(int, area.split("_"))
        n = 2**zoom
        lat = math.atan(math.sinh(math.pi * (1 - 2*(y+.5)/n)))
        lon = ((x+.5)/n*2-1)*math.pi
        coords.append((lat, lon))
        for j, (other_lat, other_lon) in enumerate(coords[:i]):
            hav = math.sin((lat-other_lat)/2)**2
            hav += math.cos(lat)*math.cos(other_lat)*math.sin((lon-other_lon)/2)**2
            if 2 * 6371 * math.asin(math.sqrt(min(1., hav))) <= 100:
                groups[groups == groups[i]] = groups[j]
    order = np.random.default_rng(20261125).permutation(np.unique(groups))
    return np.array([np.flatnonzero(order == group)[0] % 5 for group in groups])


def valid_class(y):
    return (y >= 0) & (y < CLASSES)


def matched_samples(train, seed):
    rng = np.random.default_rng(seed)
    y, seen = train["labels"], train["observed"]
    valid = valid_class(y) & seen
    records = []
    for site in np.unique(train["site"]):
        rows = np.flatnonzero(train["site"] == site)
        tile = train["tile"][rows]
        for time in range(y.shape[1]-1):
            old, new = y[rows, time], y[rows, time+1]
            usable = valid[rows, time] & valid[rows, time+1]
            changed = usable & (old != new)
            stable = usable & (old == new)
            for tile_id in np.unique(tile):
                cases = changed & (tile == tile_id)
                for cls in np.unique(np.r_[old[cases], new[cases]]):
                    positives = rows[cases & ((old == cls) | (new == cls))]
                    controls = rows[stable & (old == cls) & (tile != tile_id)]
                    if len(controls):
                        partner = rng.choice(controls, size=len(positives))
                        records.append(np.column_stack([positives, partner,
                                                        np.full(len(positives), time),
                                                        y[positives, time], y[positives, time+1],
                                                        np.full(len(positives), cls)]))
    if not records:
        raise ValueError("No same-area stable comparisons across distinct tiles")
    return np.concatenate(records).astype("int64")


def tensorize(part, feature_type, weights, device):
    local = part["local"].astype("float32")
    extra = part["spectral"].shape[-1]
    if feature_type == "spectral":
        # Same input width and parameter count: replace the last 2C old feature values.
        local[..., -extra:] = part["spectral"]
    if weights is None:
        observed = part["observed"]
        available = local[observed]
        mean = available.mean(0)
        scale = available.std(0).clip(1e-4)
        weights = (mean, scale)
    local -= weights[0]
    local /= weights[1]
    np.clip(local, -8, 8, out=local)
    local[~part["observed"]] = 0
    context = torch.as_tensor(part["context"], device=device)
    observed = torch.as_tensor(part["observed"], device=device)
    labels = torch.as_tensor(part["labels"], dtype=torch.long, device=device)
    return (context, torch.from_numpy(local).to(device), observed, labels), weights


def stable_threshold(scores, y, rate=OPERATING_POINT):
    known = valid_class(y[:, :-1]) & valid_class(y[:, 1:])
    stable = scores[known & (y[:, :-1] == y[:, 1:])]
    if not len(stable):
        raise ValueError("Empty stable calibration support")
    maximum = min(len(stable)-1, int(rate*len(stable)))
    return float(np.partition(stable, len(stable)-1-maximum)[len(stable)-1-maximum])


def js_scores(logits):
    logp = logits.float().log_softmax(-1)
    a, b = logp[:, :-1], logp[:, 1:]
    mixed = torch.logaddexp(a, b) - math.log(2.)
    return 0.5 * ((a.exp() * (a-mixed)).sum(-1) + (b.exp() * (b-mixed)).sum(-1))


def dimensions(y, p):
    valid = valid_class(y)
    matrix = np.bincount(CLASSES * y[valid].astype(np.int64) + p[valid],
                         minlength=CLASSES**2).reshape(CLASSES, CLASSES)
    labelled = valid[:, :-1] & valid[:, 1:]
    a, b = y[:, :-1][labelled], y[:, 1:][labelled]
    c, d = p[:, :-1][labelled], p[:, 1:][labelled]
    event, alarm = a != b, c != d
    pair = CLASSES * a.astype(np.int64) + b
    correct = event & (a == c) & (b == d)
    by_pair = np.bincount(pair[event], minlength=CLASSES**2).reshape(CLASSES, CLASSES)
    exact_by_pair = np.bincount(pair[correct], minlength=CLASSES**2).reshape(CLASSES, CLASSES)
    semantic = np.bincount(CLASSES * b[event].astype(np.int64) + d[event],
                           minlength=CLASSES**2).reshape(CLASSES, CLASSES)
    event_count, alarm_count, hits = event.sum(), alarm.sum(), (event & alarm).sum()

    def iou(cm):
        den = cm.sum(0) + cm.sum(1) - cm.diagonal()
        return 100 * np.divide(cm.diagonal(), den, out=np.zeros(len(cm)), where=den != 0)

    classes = iou(matrix)
    sc = float(iou(semantic).mean())
    bc = 100 * hits / max(event_count + alarm_count - hits, 1)
    return {
        "miou": float(classes.mean()), "scs": float((sc+bc)*0.5), "bc": float(bc), "sc": sc,
        "strict_f1": float(200 * correct.sum() / max(event_count+alarm_count, 1)),
        "stable_fpr": float(100 * (alarm_count-hits) / max(len(event)-event_count, 1)),
        "event_recall": float(100 * hits / max(event_count, 1)),
        "strict_recall": float(100 * correct.sum() / max(event_count, 1)),
        "true_change": int(event_count), "stable": int(len(event)-event_count),
        "alarms": int(alarm_count), "binary_hits": int(hits), "exact_hits": int(correct.sum()),
        "miou_by_class": classes.tolist(), "total_by_pair": by_pair.tolist(),
        "correct_by_pair": exact_by_pair.tolist(), "semantic_confusion": semantic.tolist(),
        "date_confusion": matrix.tolist(),
    }


def pr_auc(scores, y):
    valid = valid_class(y[:, :-1]) & valid_class(y[:, 1:])
    scores = scores[valid]
    changed = (y[:, :-1] != y[:, 1:])[valid]
    if not changed.any():
        return None
    order = np.argsort(-scores, kind="stable")
    counts = np.cumsum(changed[order])
    ranks = np.r_[np.flatnonzero(np.diff(scores[order]))+1, len(order)]
    at = counts[ranks-1]
    return float(100*np.sum(np.diff(np.r_[0, at]) * at/ranks) / at[-1])


def split_arrays(arrays, rows):
    return {key: value[rows] for key, value in arrays.items()}


def fit_classifier_bias(source, seed, steps, device):
    c = torch.as_tensor(source["context"], device=device)
    y = torch.as_tensor(source["labels"], dtype=torch.long, device=device)
    bias = nn.Parameter(torch.zeros(CLASSES, device=device))
    scale = nn.Parameter(torch.zeros((), device=device))
    opt = torch.optim.AdamW([bias, scale], lr=0.02)
    rng = np.random.default_rng(seed)
    for _ in range(steps):
        idx = rng.integers(len(y), size=384)
        x, target = c[idx], y[idx]
        target = target.masked_fill(~((target >= 0) & (target < CLASSES)), -1)
        loss = F.cross_entropy((x * scale.clamp(-2, 2).exp() + bias).flatten(0, 1),
                               target.flatten(), ignore_index=-1)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
    return bias.detach(), scale.detach().clamp(-2, 2).exp()


def fit_arm(dataset, pairs, name, seed, steps, device):
    torch.manual_seed(seed)
    model = TransitionModel(dataset[1].shape[-1], CLASSES, name.endswith("rival")).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.0015, weight_decay=0.001)
    rng = np.random.default_rng(seed + 731)
    context, features, observed, labels = dataset
    history = []
    for step in range(1, steps+1):
        chosen = rng.integers(len(labels), size=384)
        pair = pairs[rng.integers(len(pairs), size=96)]
        comparison = np.r_[pair[:, 0], pair[:, 1]]
        rows = np.r_[chosen, comparison]
        state, residual, event, local = model(context[rows], features[rows], observed[rows])
        natural = tuple(a[:len(chosen)] for a in (state, residual, event, local))
        loss = loss_terms(model, natural, labels[chosen], observed[chosen])
        index = torch.from_numpy(np.tile(pair[:, 2:], (2, 1))).to(device).T
        contest = paired_loss(state[len(chosen):], residual[len(chosen):], *index)
        total = loss + 0.30*contest
        optimizer.zero_grad(set_to_none=True)
        total.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 5.0, error_if_nonfinite=True)
        optimizer.step()
        if step == 1 or step % 50 == 0 or step == steps:
            record = {"step": step, "loss": float(total.detach()), "matched": float(contest.detach())}
            history.append(record)
            print(f"[FIT] {name} {step}/{steps} loss={record['loss']:.5f} match={record['matched']:.5f}",
                  flush=True)
    return model.eval(), history


@torch.inference_mode()
def evaluate_arm(model, calibration, validation, js_mask, sites, areas):
    def predict(data):
        context, features, observed, _ = data
        chunks = [model(context[i:i+1024], features[i:i+1024], observed[i:i+1024])[:3]
                  for i in range(0, len(context), 1024)]
        return tuple(torch.cat(values) for values in zip(*chunks))

    state, residual, logits = predict(validation)
    _, _, from_source = predict(calibration)
    y = validation[3].cpu().numpy()
    source_y = calibration[3].cpu().numpy()
    cutoff = stable_threshold(from_source.cpu().numpy(), source_y)
    stable = (source_y[:, :-1] == source_y[:, 1:]) & valid_class(source_y[:, :-1])
    source_fpr = 100 * (from_source.cpu().numpy()[stable] > cutoff).mean()
    discrete = logits > cutoff
    fixed = decode(state, residual, js_mask, model.different)
    decided = decode(state, residual, discrete, model.different)
    assert torch.equal(decided[:, :-1] != decided[:, 1:], discrete)
    assert torch.equal(fixed[:, :-1] != fixed[:, 1:], js_mask)
    soft = marginal_decode(state, residual, logits, model.different).cpu().numpy()
    decided, fixed = decided.cpu().numpy(), fixed.cpu().numpy()
    score = logits.cpu().numpy()
    by_rate = {}
    for rate in (0.05, 0.10, 0.20):
        # The validation comparator evaluates ranking at fixed false-alarm budgets.
        diagnostic = stable_threshold(score, y, rate)
        p = decode(state, residual, logits > diagnostic, model.different).cpu().numpy()
        by_rate[f"{rate:.2f}"] = dimensions(y, p)
    return {
        "params": sum(p.numel() for p in model.parameters()), "source_threshold": cutoff,
        "source_fpr": float(source_fpr),
        "event_ap": pr_auc(score, y), "natural_threshold": dimensions(y, decided),
        "same_js_alerts": dimensions(y, fixed), "soft_chain": dimensions(y, soft),
        "endpoint_argmax": dimensions(y, state.argmax(-1).cpu().numpy()),
        "curve_fixed_validation_fpr": by_rate,
        "by_area": {area: {"natural_threshold": dimensions(y[sites == i], decided[sites == i]),
                           "same_js_alerts": dimensions(y[sites == i], fixed[sites == i])}
                    for i, area in enumerate(areas)},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--features", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--steps", type=int, default=500)
    parser.add_argument("--device", default="cuda:0" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if args.steps < 1:
        parser.error("--steps must be positive")
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32 = False
    device = torch.device(args.device)
    export_protocol = json.loads((args.features / "protocol.json").read_text(encoding="utf8"))
    manifest_path = args.features / "complete.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf8"))
    if export_protocol["smoke"] or manifest["split_sha256"] != export_protocol["split_sha256"]:
        raise ValueError("A complete released-split feature export is required")
    train_areas, train = read_part(args.features, manifest, "train")
    val_areas, val = read_part(args.features, manifest, "val")
    if len(train_areas) != 47 or len(val_areas) != 10 or set(train_areas) & set(val_areas):
        raise ValueError("Expected the 47 training and 10 distinct validation areas")
    folds = geographic_folds(train_areas)
    hold = folds[train["site"]] == 0
    fit, cal = split_arrays(train, ~hold), split_arrays(train, hold)
    del train
    pairs = matched_samples(fit, args.seed)
    args.out.mkdir(parents=True, exist_ok=True)
    protocol = {
        "claims": "Screen using a frozen pretrained backbone, calibrated source area holdout, "
                  "and fixed sampled official validation geography. No new official test evaluation.",
        "export": export_protocol, "manifest_sha256": sha256(manifest_path),
        "calibration_areas": [site for site, fold in zip(train_areas, folds) if fold == 0],
        "fit_areas": [site for site, fold in zip(train_areas, folds) if fold != 0],
        "evaluation_areas": val_areas, "seed": args.seed, "steps": args.steps,
        "matched_comparison_intervals": len(pairs), "natural_batch": 384, "matched_batch": 96,
        "fpr_target_source": OPERATING_POINT, "arms": list(ARMS), "device": str(device),
        "torch": str(torch.__version__), "conditional_map_event_probability_rule": "score > threshold",
        "source_hashes": {f.name: sha256(f) for f in
                          (Path(__file__), Path(__file__).with_name("transition.py"))},
    }
    protocol_path = args.out / "protocol.json"
    if protocol_path.exists() and json.loads(protocol_path.read_text(encoding="utf8")) != protocol:
        raise ValueError("Existing fit uses another configuration")
    save_json(protocol_path, protocol)
    print(f"[PROTOCOL] fit={len(fit['labels'])} cal={len(cal['labels'])} val={len(val['labels'])}"
          f" matched={len(pairs)} device={device}", flush=True)
    vc = torch.as_tensor(val["context"], device=device)
    yc = val["labels"]
    diff = ~torch.eye(CLASSES, device=device, dtype=torch.bool)
    js = js_scores(vc)
    js_source = js_scores(torch.as_tensor(cal["context"], device=device)).cpu().numpy()
    js_cutoff = stable_threshold(js_source, cal["labels"])
    js_mask = js > js_cutoff
    reference_edges = vc.new_zeros(len(vc), vc.shape[1]-1, CLASSES, CLASSES)
    constrained = decode(vc.log_softmax(-1), reference_edges, js_mask, diff).cpu().numpy()
    intercept, scale = fit_classifier_bias(fit, args.seed, args.steps, device)
    biased = (vc * scale + intercept).argmax(-1).cpu().numpy()
    baseline = {
        "context_argmax": dimensions(yc, vc.argmax(-1).cpu().numpy()),
        "context_bias_temperature": dimensions(yc, biased),
        "same_js_alerts": dimensions(yc, constrained),
        "same_js_alerts_source_threshold": js_cutoff,
        "baseline_event_ap": pr_auc(js.cpu().numpy(), yc),
        "by_area": {area: dimensions(yc[val["site"] == i], constrained[val["site"] == i])
                    for i, area in enumerate(val_areas)},
    }
    save_json(args.out / "baselines.json", baseline)
    records = {}
    for name in ARMS:
        result_path = args.out / f"{name}.json"
        if result_path.exists():
            records[name] = json.loads(result_path.read_text(encoding="utf8"))
            continue
        kind = name.split("_")[0]
        fit_data, weights = tensorize(fit, kind, None, device)
        model, history = fit_arm(fit_data, pairs, name, args.seed, args.steps, device)
        del fit_data
        cal_data, _ = tensorize(cal, kind, weights, device)
        val_data, _ = tensorize(val, kind, weights, device)
        result = evaluate_arm(model, cal_data, val_data, js_mask, val["site"], val_areas)
        assert result["same_js_alerts"]["alarms"] == baseline["same_js_alerts"]["alarms"]
        result["history"] = history
        checkpoint = args.out / f"{name}.pth"
        tmp = checkpoint.with_suffix(".tmp")
        torch.save({"model": model.state_dict(), "arm": name, "normalization_mean": torch.tensor(weights[0]),
                    "normalization_scale": torch.tensor(weights[1])}, tmp)
        tmp.replace(checkpoint)
        result["checkpoint_sha256"] = sha256(checkpoint)
        save_json(result_path, result)
        records[name] = result
        print(f"[DONE] {name}: SCS={result['natural_threshold']['scs']:.2f} "
              f"same-JS strict F1={result['same_js_alerts']['strict_f1']:.2f}", flush=True)
        del model, cal_data, val_data
    assert len({value["params"] for value in records.values()}) == 1
    save_json(args.out / "results.json", {"finished": datetime.now().astimezone().isoformat(),
              "protocol_sha256": sha256(protocol_path), "baselines": baseline, "arms": records})


if __name__ == "__main__":
    main()
