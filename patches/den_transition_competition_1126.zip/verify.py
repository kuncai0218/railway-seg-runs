"""Compare the exact path loss with enumeration, then take GPU steps on real DEN tiles."""

import argparse
import itertools
from pathlib import Path

import numpy as np
import torch

from train_pilot import ARMS, fit_arm, matched_samples, tensorize
from transition import decode, path_nll


def verify_probabilities(device):
    torch.manual_seed(16)
    classes, dates = 3, 4
    node = torch.randn(4, dates, classes, device=device, dtype=torch.float64).log_softmax(-1)
    edge = torch.randn(4, dates-1, classes, classes, device=device, dtype=torch.float64)
    labels = torch.tensor([[2, 2, 1, 1], [1, 3, 0, 2], [3, 0, 1, 3], [3, 3, 3, 3]], device=device)
    valid = labels < classes
    truth = labels.clamp(0, classes-1)
    known = valid[:, :-1] & valid[:, 1:]
    alarm = truth[:, :-1] != truth[:, 1:]
    different = ~torch.eye(classes, dtype=torch.bool, device=device)
    paths = torch.tensor(list(itertools.product(range(classes), repeat=dates)), device=device)
    corrected = []
    for i in range(len(node)):
        score = node[i, torch.arange(dates, device=device), paths].sum(-1)
        score = score + (edge[i, torch.arange(dates-1, device=device), paths[:, :-1], paths[:, 1:]]
                         * known[i]).sum(-1)
        mask = ((paths[:, :-1] != paths[:, 1:]) == alarm[i]) | ~known[i]
        agrees = ((paths == truth[i]) | ~valid[i]).all(-1)
        corrected.append(score[mask.all(-1)].logsumexp(0) - score[agrees].logsumexp(0))
    expected = torch.stack(corrected).sum() / valid.sum()
    measured = path_nll(node, edge, labels, different)
    torch.testing.assert_close(measured, expected, atol=1e-11, rtol=0)

    patterns = torch.tensor(list(itertools.product((False, True), repeat=dates-1)), device=device)
    node = node[0:1].expand(len(patterns), -1, -1)
    edge = edge[0:1].expand(len(patterns), -1, -1, -1)
    predicted = decode(node, edge, patterns, different)
    assert torch.equal(predicted[:, :-1] != predicted[:, 1:], patterns)
    print("[VERIFIED] Exact conditional likelihood with missing labels and all 8 alarm masks", flush=True)


def real_steps(features, device, steps):
    site_files = sorted((features / "train").glob("*.npz"))[:4]
    if not site_files:
        raise ValueError("Wait for at least one complete nine-tile training-area export")
    streams = {}
    for site, file in enumerate(site_files):
        with np.load(file, allow_pickle=False) as f:
            for name in f.files:
                streams.setdefault(name, []).append(f[name])
            streams.setdefault("site", []).append(np.full(len(f["labels"]), site))
    part = {name: np.concatenate(data) for name, data in streams.items()}
    pairs = matched_samples(part, 42)
    for arm in ARMS:
        dataset, _ = tensorize(part, arm.split("_")[0], None, device)
        model, metrics = fit_arm(dataset, pairs, arm, 42, steps, device)
        assert np.isfinite([row["loss"] for row in metrics]).all()
        print(f"[VERIFIED] {arm} updated on {len(site_files)} real source area(s), "
              f"{len(pairs)} matched comparisons, {device}", flush=True)
        del model, dataset


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--device", default="cpu")
    p.add_argument("--features", type=Path)
    p.add_argument("--steps", type=int, default=4)
    args = p.parse_args()
    torch.set_num_threads(2)
    device = torch.device(args.device)
    if device.type == "cuda":
        torch.cuda.set_per_process_memory_fraction(0.12, device)
    verify_probabilities(device)
    if args.features:
        real_steps(args.features, device, args.steps)


if __name__ == "__main__":
    main()
