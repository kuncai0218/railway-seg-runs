"""Shared endpoint model and two change statistics for the DEN screening experiment."""

import math

import torch
from torch import nn
from torch.nn import functional as F


def event_odds(pair, different, competition):
    if not competition:
        return pair[..., different].logsumexp(-1) - pair[..., ~different].logsumexp(-1)
    stable = pair.diagonal(dim1=-2, dim2=-1)
    strongest_rival = torch.maximum(stable[..., :, None], stable[..., None, :])
    margins = (pair - strongest_rival)[..., different]
    # A smooth maximum over candidate directions with the same fixed temperature.
    return 0.5 * ((margins / 0.5).logsumexp(-1) - math.log(margins.shape[-1]))


class TransitionModel(nn.Module):
    def __init__(self, features, classes, competition):
        super().__init__()
        self.competition = competition
        self.local = nn.Sequential(nn.Linear(features, 48), nn.GELU(), nn.Linear(48, 32), nn.GELU())
        self.local_classes = nn.Linear(32, classes)
        self.pair = nn.Sequential(nn.Linear(96, 48), nn.GELU(), nn.Linear(48, classes * classes))
        self.context_scale = nn.Parameter(torch.zeros(()))
        self.context_bias = nn.Parameter(torch.zeros(classes))
        self.local_scale = nn.Parameter(torch.tensor(-1.4))
        self.event_scale = nn.Parameter(torch.zeros(()))
        self.event_bias = nn.Parameter(torch.zeros(()))
        self.register_buffer("different", ~torch.eye(classes, dtype=torch.bool))
        nn.init.zeros_(self.pair[-1].weight)
        nn.init.zeros_(self.pair[-1].bias)

    def forward(self, context, features, observed):
        prior = context.log_softmax(-1)
        hidden = self.local(features)
        local = self.local_classes(hidden)
        centered = local - local.mean(-1, keepdim=True)
        state = prior * self.context_scale.clamp(-2, 2).exp() + self.context_bias
        state = (state + self.local_scale.sigmoid() * centered * observed[..., None]).log_softmax(-1)
        start, finish = hidden[:, :-1], hidden[:, 1:]
        seen = observed[:, :-1] & observed[:, 1:]
        local_pair = self.pair(torch.cat([start, finish, finish - start], dim=-1))
        residual = local_pair.reshape(*seen.shape, *self.different.shape)
        residual = residual * seen[..., None, None]
        pair = state[:, :-1, :, None] + state[:, 1:, None, :] + residual
        prior_pair = prior[:, :-1, :, None] + prior[:, 1:, None, :]
        reference_odds = event_odds(prior_pair, self.different, False)
        adjustment = (event_odds(pair, self.different, self.competition)
                      - event_odds(prior_pair, self.different, self.competition))
        event = (reference_odds + adjustment) * self.event_scale.clamp(-2, 2).exp() + self.event_bias
        return state, residual, event, local


def conditional_edges(residual, changed, known, different):
    allowed = (different == changed[..., None, None]) | ~known[..., None, None]
    return (residual * known[..., None, None]).masked_fill(~allowed, float("-inf"))


def path_nll(state, residual, labels, different):
    """Exact conditional likelihood on each contiguous segment of labelled dates."""
    valid = (labels >= 0) & (labels < state.shape[-1])
    known = valid[:, :-1] & valid[:, 1:]
    safe = labels.clamp(0, state.shape[-1] - 1)
    edges = conditional_edges(residual, safe[:, :-1] != safe[:, 1:], known, different)
    unary = state.gather(-1, safe[..., None]).squeeze(-1)
    truth = (unary * valid).sum(-1)
    row = torch.arange(len(labels), device=labels.device)[:, None]
    t = torch.arange(labels.shape[1] - 1, device=labels.device)
    truth = truth + (residual[row, t, safe[:, :-1], safe[:, 1:]] * known).sum(-1)
    message = state[:, 0]
    for t in range(edges.shape[1]):
        message = state[:, t + 1] + (message[..., None] + edges[:, t]).logsumexp(-2)
    return (message.logsumexp(-1) - truth).sum() / valid.sum().clamp_min(1)


def decode(state, residual, alarms, different):
    """MAP class trajectory conditional on the supplied binary alarm sequence."""
    edges = conditional_edges(residual, alarms, torch.ones_like(alarms), different)
    message = state[:, 0]
    back = []
    for t in range(edges.shape[1]):
        best, parent = (message[..., None] + edges[:, t]).max(dim=-2)
        message = state[:, t + 1] + best
        back.append(parent)
    path = [message.argmax(-1)]
    for parent in reversed(back):
        path.append(parent.gather(-1, path[-1][:, None]).squeeze(-1))
    return torch.stack(path[::-1], dim=1)


def marginal_decode(state, residual, event, different):
    """Marginal-argmax control. Match the isolated pair's event log odds first."""
    pair = state[:, :-1, :, None] + state[:, 1:, None, :] + residual
    correction = event - event_odds(pair, different, False)
    edges = residual + correction[..., None, None] * different
    prefix = [state[:, 0]]
    for t in range(edges.shape[1]):
        prefix.append(state[:, t+1] + (prefix[-1][..., None] + edges[:, t]).logsumexp(-2))
    suffix = torch.zeros_like(prefix[-1])
    estimates = [prefix[-1].argmax(-1)]
    for t in reversed(range(edges.shape[1])):
        suffix = (edges[:, t] + (suffix + state[:, t+1])[:, None]).logsumexp(-1)
        estimates.append((prefix[t] + suffix).argmax(-1))
    return torch.stack(estimates[::-1], dim=-1)


def loss_terms(model, result, labels, observed):
    state, residual, event, local = result
    classes = state.shape[-1]
    valid = (labels >= 0) & (labels < classes)
    known = valid[:, :-1] & valid[:, 1:]
    change = labels[:, :-1] != labels[:, 1:]
    binary = (F.binary_cross_entropy_with_logits(event, change.float(), reduction="none") * known).sum()
    binary = binary / known.sum().clamp_min(1)
    safe = labels.clamp(0, classes - 1)
    context_loss = -(state.gather(-1, safe[..., None]).squeeze(-1) * valid).sum() / valid.sum().clamp_min(1)
    mask = valid & observed
    local_logp = local.log_softmax(-1).gather(-1, safe[..., None]).squeeze(-1)
    local_loss = -(local_logp * mask).sum() / mask.sum().clamp_min(1)
    sequence = path_nll(state, residual, labels, model.different)
    return binary + sequence + 0.25 * context_loss + 0.25 * local_loss


def paired_loss(state, residual, time, before, after, rival):
    """First half changed, second half stable at one candidate endpoint."""
    rows = torch.arange(len(state), device=state.device)
    a, b = state[rows, time], state[rows, time + 1]
    edge = residual[rows, time]
    candidate = a[rows, before] + b[rows, after] + edge[rows, before, after]
    stable = a[rows, rival] + b[rows, rival] + edge[rows, rival, rival]
    positive, control = (candidate - stable).chunk(2)
    return F.softplus(control - positive).mean()
