"""Sample the same eight released DEN dates through a frozen PSE-family backbone."""

import argparse
import hashlib
import itertools
import json
import os
from datetime import date
from pathlib import Path

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(variable, "2")

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from pse_net import make_pse


MONTHS = (0, 3, 6, 9, 13, 16, 19, 23)
DAYS = tuple((date(2018 + month // 12, month % 12 + 1, 1) - date(2018, 1, 1)).days for month in MONTHS)
NORMALIZATION = {
    "s2": (
        [1161.5256, 1399.3857, 1455.7269, 2761.0648, 1815.2145, 2465.5625,
         2722.3400, 2867.8205, 2336.8220, 1742.1495, 1069.3466, 3128.7744],
        [1541.3866, 1459.2290, 1528.1924, 1405.8515, 1518.5338, 1386.2684,
         1405.3624, 1410.5013, 1377.1001, 1296.2761, 1609.3568, 2166.7642],
    ),
    "planet": ([83.1029, 80.7615, 69.3328, 133.8648], [33.2714, 25.5288, 23.9868, 30.5591]),
}
TRAIN_TILES = list(itertools.product((0, 2, 4), (0, 3, 6)))
VAL_TILES = list(itertools.product((1, 3, 5, 7), repeat=2))


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(2**20), b""):
            digest.update(block)
    return digest.hexdigest()


def save_json(path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def released_split(data):
    split = json.loads((data / "split.json").read_text(encoding="utf-8-sig"))
    if [len(split[part]) for part in ("train", "val", "test")] != [47, 10, 7]:
        raise ValueError("Expected the released 47/10/7 DEN geographic split")
    if len(set().union(*(set(split[part]) for part in ("train", "val", "test")))) != 64:
        raise ValueError("Geographic split contains duplicate sites")
    return split


def convert_batch_norm(net):
    for name, layer in net.named_children():
        if isinstance(layer, nn.GroupNorm):
            # PSE+BN changes only image-grid normalization. Attention's LayerNorm stays.
            setattr(net, name, nn.BatchNorm2d(layer.num_channels))
        else:
            convert_batch_norm(layer)


def load_backbone(checkpoint, sensor, opts, device):
    channels = len(NORMALIZATION[sensor][0])
    cfg = {"model": {"num_channels": channels}, "ST3DUNET": {"INPUT_CHANNELS": channels},
           "dataset": {"num_classes": 6, "ignore_index": 6}}
    payload = torch.load(checkpoint, weights_only=True, map_location="cpu")
    for key in ("model", "state_dict", "model_state_dict", "model_state"):
        if key in payload:
            state = payload[key]
            break
    else:
        state = payload
    state = {key.removeprefix("module."): value for key, value in state.items()}
    if any(key.startswith("backbone.") for key in state):
        state = {key.removeprefix("backbone."): value for key, value in state.items()
                 if key.startswith("backbone.")}
    net = make_pse(cfg, opts)
    if any(key.endswith(".running_mean") for key in state):
        convert_batch_norm(net)
    net.load_state_dict(state, strict=True)
    return net.to(device).eval(), payload.get("epoch")


def cached_or_original(data, cache, sensor, part, area):
    if sensor == "s2":
        paths = [] if cache is None else [cache / part / f"{area}.npy", cache / f"{area}.npy"]
        paths.append(data / part / area / f"{area}.npy")
        chosen = next((p for p in paths if p.is_file()), None)
        if chosen is None:
            raise FileNotFoundError(paths[-1])
        array = np.load(chosen, mmap_mode="r", allow_pickle=False)
        if array.shape == (8, 12, 1024, 1024):
            return array, tuple(range(8))
        if array.shape == (24, 12, 1024, 1024):
            return array, MONTHS
        raise ValueError(f"Unsupported MSI array {chosen}: {array.shape}")
    # Read just the eight original dated JPEG pairs. No reliance on a machine-specific cache format.
    from PIL import Image

    directory = data / part / area
    frames = []
    for day in DAYS:
        with Image.open(directory / f"{area}_{day}_rgb.jpeg") as image:
            rgb = np.asarray(image.convert("RGB")).transpose(2, 0, 1)
        with Image.open(directory / f"{area}_{day}_infra.jpeg") as image:
            infrared = np.asarray(image.convert("L"))[None]
        frames.append(np.concatenate([rgb, infrared], axis=0))
    array = np.stack(frames, axis=0)
    if array.shape != (8, 4, 1024, 1024):
        raise ValueError(f"Unexpected Planet dimensions in {directory}: {array.shape}")
    return array, tuple(range(8))


def choose_centers(features, stride):
    start = stride // 2
    return features[:, :, start::stride, start::stride].permute(2, 3, 0, 1).flatten(0, 1)


@torch.inference_mode()
def sample_area(net, imagery, times, labels, tiles, sensor, device, stride):
    taps = {}

    def save_tap(name):
        def capture(_layer, _incoming, output):
            taps[name] = output
        return capture

    hooks = [net.stem.register_forward_hook(save_tap("s0")), net.d2.register_forward_hook(save_tap("s2"))]
    mean, deviation = [torch.tensor(v, dtype=torch.float32).reshape(1, -1, 1, 1)
                       for v in NORMALIZATION[sensor]]
    days = torch.tensor([DAYS], device=device)
    outputs = {key: [] for key in ("context", "local", "spectral", "labels", "observed", "tile")}
    try:
        for tile_index, (r, c) in enumerate(tiles):
            rows = slice(128 * r, 128 * (r + 1))
            cols = slice(128 * c, 128 * (c + 1))
            patch = torch.from_numpy(np.array(imagery[list(times), :, rows, cols], dtype=np.float32, copy=True))
            available = torch.isfinite(patch).all(1, keepdim=True) & (patch != 0).any(1, keepdim=True)
            patch = torch.where(available, patch, mean)
            image = (patch - mean) / deviation
            normalized_shape = F.normalize(patch, dim=1)
            spectral = choose_centers(torch.cat([image, normalized_shape], dim=1), stride)
            logits = net(image.to(device)[None], days)[0]
            s2 = F.interpolate(taps["s2"], size=(128, 128), mode="bilinear", align_corners=False)
            local = choose_centers(torch.cat([taps["s0"], s2], dim=1), stride)
            selected = (slice(stride // 2, None, stride), slice(stride // 2, None, stride))
            y = labels[:, rows, cols][:, selected[0], selected[1]].reshape(8, -1).T
            outputs["context"].append(choose_centers(logits, stride).cpu().numpy().astype("float32"))
            outputs["local"].append(local.cpu().numpy().astype("float16"))
            outputs["spectral"].append(spectral.numpy().astype("float32"))
            outputs["labels"].append(y.astype("uint8"))
            outputs["observed"].append(choose_centers(available, stride).squeeze(-1).numpy())
            outputs["tile"].append(np.full(len(y), tile_index, dtype="uint8"))
            taps.clear()
    finally:
        for hook in hooks:
            hook.remove()
    return {key: np.concatenate(values) for key, values in outputs.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--cache", type=Path)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--sensor", choices=tuple(NORMALIZATION), required=True)
    parser.add_argument("--opts", default="event=0,gate=0")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--device", default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--stride", type=int, choices=(8, 16), default=16)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(args.threads)
    torch.backends.cudnn.allow_tf32 = False
    args.out.mkdir(parents=True, exist_ok=True)
    checkpoint = args.checkpoint.resolve()
    split = released_split(args.data)
    opts = args.opts
    if opts == "auto":
        # Ordinary PSE checkpoints declare their event branch in the checkpoint keys.
        payload = torch.load(checkpoint, weights_only=True, map_location="cpu")
        weights = next((payload[key] for key in ("model", "state_dict", "model_state_dict", "model_state")
                        if key in payload), payload)
        has_event = any(key.removeprefix("module.").removeprefix("backbone.").startswith("ev.") for key in weights)
        opts = f"event={int(has_event)},gate={int(has_event)}"
        del payload, weights
    model, epoch = load_backbone(checkpoint, args.sensor, opts, args.device)
    protocol = {
        "sensor": args.sensor, "months": MONTHS, "days": DAYS, "stride": args.stride,
        "checkpoint": checkpoint.name, "checkpoint_sha256": sha256(checkpoint), "epoch": epoch,
        "opts": opts, "split_sha256": sha256(args.data / "split.json"), "torch": str(torch.__version__),
        "device": args.device, "tiles_train": TRAIN_TILES, "tiles_val": VAL_TILES, "smoke": args.smoke,
        "model_source_sha256": sha256(Path(__file__).with_name("pse_net.py")),
        "export_source_sha256": sha256(Path(__file__)),
    }
    protocol = json.loads(json.dumps(protocol))
    manifest = args.out / "protocol.json"
    if manifest.exists() and json.loads(manifest.read_text(encoding="utf-8")) != protocol:
        raise ValueError("Existing feature export uses another protocol. Choose a new output directory.")
    save_json(manifest, protocol)
    completed = {}
    for part, tiles in (("train", TRAIN_TILES), ("val", VAL_TILES)):
        sites = sorted(split[part])
        if args.smoke:
            sites, tiles = sites[:1], tiles[:1]
        directory = args.out / part
        directory.mkdir(exist_ok=True)
        for number, area in enumerate(sites, start=1):
            output = directory / f"{area}.npz"
            if not output.exists():
                frames, times = cached_or_original(args.data, args.cache, args.sensor, part, area)
                reference = np.load(args.data / "labels" / f"{area}.npy", mmap_mode="r", allow_pickle=False)
                if reference.shape != (24, 1024, 1024):
                    raise ValueError(f"Unexpected label grid: {area}, {reference.shape}")
                labels = reference[list(MONTHS)]
                parts = sample_area(model, frames, times, labels, tiles, args.sensor, args.device, args.stride)
                if not all(np.isfinite(parts[k]).all() for k in ("context", "local", "spectral")):
                    raise ValueError(f"Non-finite features for {part}/{area}")
                tmp = output.with_suffix(".tmp")
                with tmp.open("wb") as handle:
                    np.savez(handle, **parts)
                tmp.replace(output)
                del frames, reference, labels, parts
            completed.setdefault(part, {})[area] = sha256(output)
            save_json(args.out / "progress.json", {"part": part, "area": area, "completed": number, "total": len(sites)})
            print(f"[FEATURES] {part} {number}/{len(sites)} {area}", flush=True)
    save_json(args.out / "complete.json", {"split_sha256": protocol["split_sha256"], "outputs": completed})


if __name__ == "__main__":
    main()
