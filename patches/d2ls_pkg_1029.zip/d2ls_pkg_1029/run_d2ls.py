"""D2LS 分割第二步实验包的启动脚本（10-27 组长本机生成）。三条命令：
  python run_d2ls.py check  --task tasks/<你的任务>.json --data <原实验包>/data/d_c23_r3
      自检：下载并校验 ConvNeXt-Base 官方预训练权重（PyTorch 官方地址，SHA256 固定）、检查数据文件、跑一次很短的冒烟训练；最后打印“自检通过”。
  python run_d2ls.py run    --task tasks/<你的任务>.json --data <原实验包>/data/d_c23_r3
      正式训练（自动续跑；已完成的部分跳过）。
  python run_d2ls.py status --task tasks/<你的任务>.json
本脚本只设置环境变量 RAIL_FRONTIER_ROOT（指向本包根目录）后调用 code/run_tasks.py 与 code/train_foundation.py，不改任何训练参数。"""
import argparse
import hashlib
import os
import subprocess
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
W_URL = "https://download.pytorch.org/models/convnext_base-6075fbad.pth"
W_SHA = "6075fbad31c688f9ed013922a59daf0fc2f4dc12e6e43bc01fa840c7bd1ca2cd"
W_FILE = ROOT / "weights" / "convnext_base-6075fbad.pth"
DATA_FILES = ("index.json", "inputs_f16.npy", "labels_u8.npy", "norm.json", "splits_periods.json")


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def env():
    return dict(os.environ, RAIL_FRONTIER_ROOT=str(ROOT), PYTHONIOENCODING="utf-8", PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True")


def ensure_weights():
    if W_FILE.exists() and sha256(W_FILE) == W_SHA:
        print("ConvNeXt-Base 权重已在，校验通过"); return
    print("下载 ConvNeXt-Base 官方预训练权重（约 340 MB）：", W_URL)
    tmp = W_FILE.with_suffix(".part")
    urllib.request.urlretrieve(W_URL, tmp)
    got = sha256(tmp)
    if got != W_SHA:
        tmp.unlink()
        raise SystemExit(f"权重校验失败：SHA256 {got}，应为 {W_SHA}。请把这一行原样报告组长，不要继续。")
    tmp.replace(W_FILE); print("下载完成，校验通过")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["check", "run", "status"])
    ap.add_argument("--task", type=Path, required=True)
    ap.add_argument("--data", type=Path)
    ap.add_argument("--amp", default="auto", choices=["auto", "bf16", "fp16"])
    a = ap.parse_args()
    task = a.task if a.task.is_absolute() else ROOT / a.task
    if a.cmd == "status":
        sys.exit(subprocess.run([sys.executable, "-X", "utf8", str(ROOT / "code" / "run_tasks.py"), "--task", str(task), "--status"], cwd=ROOT, env=env()).returncode)
    if not a.data:
        raise SystemExit("请用 --data 指向原实验包里的 data/d_c23_r3 目录")
    data = a.data.resolve()
    miss = [f for f in DATA_FILES if not (data / f).exists()]
    if miss:
        raise SystemExit(f"数据目录 {data} 缺少：{miss}。--data 应指向原实验包里的 data/d_c23_r3")
    if a.cmd == "check":
        import torch
        print("torch", torch.__version__, "CUDA 可用" if torch.cuda.is_available() else "CUDA 不可用")
        if not torch.cuda.is_available():
            raise SystemExit("没有可用的 NVIDIA 显卡，不能训练")
        cap = torch.cuda.get_device_capability(0); amp = "bf16" if cap[0] >= 8 else "fp16"
        print("显卡", torch.cuda.get_device_name(0), "，混合精度用", amp)
        ensure_weights()
        cmd = [sys.executable, "-X", "utf8", str(ROOT / "code" / "train_foundation.py"), "--arch", "d2ls", "--name", "smoke_d2ls_aux", "--input", "aux",
               "--data", str(data), "--weights", str(ROOT / "weights"), "--out", str(ROOT / "results" / "_check"), "--folds", "r3_2024", "--parts", "A",
               "--batch", "8", "--crop", "256", "--amp", amp, "--smoke"]
        print("冒烟训练（几分钟）……")
        rc = subprocess.run(cmd, cwd=ROOT, env=env()).returncode
        if rc:
            raise SystemExit(f"冒烟训练失败（返回码 {rc}），请把上面最后 30 行报错原样报告组长")
        print("自检通过"); return
    ensure_weights()
    cmd = [sys.executable, "-X", "utf8", str(ROOT / "code" / "run_tasks.py"), "--task", str(task), "--data", str(data), "--weights", str(ROOT / "weights"),
           "--out", str(ROOT / "results"), "--amp", a.amp]
    sys.exit(subprocess.run(cmd, cwd=ROOT, env=env()).returncode)


if __name__ == "__main__":
    main()
