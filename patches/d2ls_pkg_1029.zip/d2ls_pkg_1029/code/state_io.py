"""Atomic JSON replacement resilient to brief Windows reader/AV file locks."""
from pathlib import Path
import json
import os
import tempfile
import time


def atomic_json(path, value, timeout=30.):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    payload=json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)
    # Unique staging names also isolate independent writers of shared metadata.
    fd,name=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    tmp=Path(name)
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='\n') as stream:
            stream.write(payload)
        deadline=time.monotonic()+timeout
        while True:
            try:
                os.replace(tmp,path)
                return
            except PermissionError:
                if time.monotonic()>=deadline:raise
                time.sleep(.05)
    finally:
        try:tmp.unlink(missing_ok=True)
        except PermissionError:pass
