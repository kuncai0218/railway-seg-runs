"""同学分割实验包的任务运行器（10-26，Claude）。

用法（在实验包根目录下）：
    python code/run_tasks.py --task tasks/我的任务.json            # 跑全部任务；中断后重新运行同一命令即可接着跑
    python code/run_tasks.py --task tasks/我的任务.json --status   # 只看进度
    python code/run_tasks.py --task tasks/我的任务.json --dry-run  # 只打印将要执行的命令

每个任务分两段：
  1. 试学习率：每个候选学习率在第三折（r3_2024）的半期 A 上训练一次，按该半期预测期的 mIoU 选最好的；
  2. 正式实验：用选中的学习率，按任务里的随机种子，三折 × 全期 / 半期 A / 半期 B 全部训练并预测。
已完成的部分会自动跳过（训练脚本按 complete.json 判断），训练到一半中断会从 last.pt 接着训。
"""
import argparse
import datetime
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FOLDS = 'r3_2023a,r3_2023b,r3_2024'
SWEEP_FOLD = 'r3_2024'


def now():
    return datetime.datetime.now().strftime('%m-%d %H:%M:%S')


def log(msg, path):
    line = f'{now()} {msg}'
    print(line, flush=True)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(line + '\n')


def auto_amp():
    import torch
    if not torch.cuda.is_available():
        raise SystemExit('没有检测到可用的 NVIDIA 显卡（torch.cuda.is_available() 为 False），请先按指南检查驱动和 PyTorch 版本')
    major, _ = torch.cuda.get_device_capability(0)
    return 'bf16' if major >= 8 else 'fp16'      # 30 系及以后用 bf16；Titan RTX（图灵架构，7.5）用 fp16


def part_done(out, name, fold, part):
    return (out / f'pred_{name}' / fold / f'state_{part}' / 'complete.json').exists()


def part_miou(out, name, fold, part):
    f = out / f'pred_{name}' / fold / f'state_{part}' / 'complete.json'
    return json.loads(f.read_text('utf-8'))['mIoU'] if f.exists() else None


def command(a, job, name, lr, seed, folds, parts):
    return [a.python, '-X', 'utf8', str(HERE / job.get('trainer', 'train_study.py')), '--arch', job['arch'], '--name', name,
            '--input', job['input'], '--data', str(a.data), '--out', str(a.out), '--weights', str(a.weights),
            '--folds', folds, '--parts', parts, '--iters', str(job['iters']), '--batch', str(job['batch']),
            '--crop', str(job['crop']), '--accum', str(job.get('accum', 1)), '--lr', f"{lr:g}", '--seed', str(seed),
            '--amp', a.amp, '--eval-every', str(job.get('eval_every', 500)), '--predict-batch', str(job.get('predict_batch', 2))] \
        + (['--drop-group', job['drop_group']] if job.get('drop_group') else []) \
        + (['--consist-weight', str(job['consist_weight'])] if job.get('consist_weight') else [])   # 10-28：训练时随机整组丢弃；S2 一致性损失


def run(a, cmd, name, logf):
    if a.dry_run:
        print(' '.join(cmd)); return 0
    (a.out / 'logs').mkdir(parents=True, exist_ok=True)
    log(f'开始 {name}', logf)
    with open(a.out / 'logs' / f'{name}.log', 'a', encoding='utf-8') as fh:
        rc = subprocess.run(cmd, cwd=ROOT, stdout=fh, stderr=subprocess.STDOUT).returncode
    log(f'结束 {name}，返回码 {rc}' + ('' if rc == 0 else f'（出错，详见 results/logs/{name}.log 末尾）'), logf)
    return rc


def sweep_names(job):
    return [(lr, f"{job['id']}_lr{lr:g}_sweep") for lr in job['lr_candidates']]


def chosen_lr(a, job, jobs_by_id):
    if 'lr_fixed' in job:                     # 稳健性对照等：固定学习率，不试
        return float(job['lr_fixed'])
    if 'lr_from' in job:                      # 沿用另一个任务选出的学习率（例如 RGB 版沿用 12 波段版）
        f = a.out / f"chosen_lr_{job['lr_from']}.json"
        return json.loads(f.read_text('utf-8'))['lr'] if f.exists() else None
    f = a.out / f"chosen_lr_{job['id']}.json"
    if f.exists():
        return json.loads(f.read_text('utf-8'))['lr']
    scores = {lr: part_miou(a.out, n, SWEEP_FOLD, 'A') for lr, n in sweep_names(job)}
    if any(v is None for v in scores.values()):
        return None
    best = max(scores, key=lambda lr: scores[lr])
    f.write_text(json.dumps({'id': job['id'], 'lr': best, 'sweep_mIoU': {f'{k:g}': v for k, v in scores.items()},
                             'rule': '第三折半期 A 预测期 mIoU 最高', 'time': now()}, ensure_ascii=False, indent=1), encoding='utf-8')
    return best


def status(a, jobs):
    print(f'{"任务":28s} {"阶段":6s} 进度')
    by_id = {j['id']: j for j in jobs}
    for job in jobs:
        if 'lr_from' not in job and 'lr_fixed' not in job:
            done = sum(part_done(a.out, n, SWEEP_FOLD, 'A') for _, n in sweep_names(job))
            print(f"{job['id']:28s} {'试学习率':6s} {done}/{len(job['lr_candidates'])}")
        lr = chosen_lr(a, job, by_id)
        for seed in job['seeds']:
            name = f"{job['id']}_s{seed}"
            fl = job.get('folds', FOLDS).split(',')
            done = sum(part_done(a.out, name, f, p) for f in fl for p in ('full', 'A', 'B'))
            print(f"{name:28s} {'正式':6s} {done}/{3 * len(fl)}" + (f'  学习率 {lr:g}' if lr else '  （学习率未定）'))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--task', type=Path, required=True)
    ap.add_argument('--python', default=sys.executable)
    ap.add_argument('--data', type=Path, default=ROOT / 'data' / 'd_c23_r3')
    ap.add_argument('--weights', type=Path, default=ROOT / 'weights')
    ap.add_argument('--out', type=Path, default=ROOT / 'results')
    ap.add_argument('--amp', default='auto', choices=['auto', 'bf16', 'fp16', 'off'])
    ap.add_argument('--status', action='store_true')
    ap.add_argument('--dry-run', action='store_true')
    a = ap.parse_args()
    task = json.loads(a.task.read_text('utf-8'))
    jobs = task['jobs']
    a.out.mkdir(parents=True, exist_ok=True)
    if a.status:
        status(a, jobs); return
    if a.amp == 'auto':
        a.amp = 'fp16' if a.dry_run else auto_amp()
    logf = a.out / 'runner_log.txt'
    log(f"任务文件 {a.task.name}（{task.get('person', '')}），混合精度 {a.amp}", logf)
    by_id = {j['id']: j for j in jobs}
    failed = []
    for job in jobs:                                           # 第一段：试学习率
        if 'lr_from' in job or 'lr_fixed' in job:
            continue
        for lr, name in sweep_names(job):
            if not part_done(a.out, name, SWEEP_FOLD, 'A'):
                if run(a, command(a, job, name, lr, job['seeds'][0], SWEEP_FOLD, 'A'), name, logf):
                    failed.append(name)
        lr = chosen_lr(a, job, by_id)
        if lr is not None:
            log(f"{job['id']} 选定学习率 {lr:g}", logf)
    for job in jobs:                                           # 第二段：正式实验
        lr = chosen_lr(a, job, by_id)
        if lr is None and a.dry_run:
            print(f"（{job['id']} 的正式实验要等试学习率跑完后才能定学习率，此处略）"); continue
        if lr is None:
            log(f"{job['id']} 学习率还没选出来（试学习率有失败），跳过正式实验", logf); failed.append(job['id']); continue
        for seed in job['seeds']:
            name = f"{job['id']}_s{seed}"
            fl = job.get('folds', FOLDS)
            if all(part_done(a.out, name, f, p) for f in fl.split(',') for p in ('full', 'A', 'B')):
                continue
            if run(a, command(a, job, name, lr, seed, fl, 'full,A,B'), name, logf):
                failed.append(name)
    log('全部任务结束' + (f'；出错的：{failed}，请把 results/logs 里对应日志发回' if failed else '，没有出错'), logf)
    if not a.dry_run:
        status(a, jobs)


if __name__ == '__main__':
    main()
