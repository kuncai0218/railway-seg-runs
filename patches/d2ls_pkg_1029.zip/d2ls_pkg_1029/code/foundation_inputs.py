"""10-27 Claude（Wisc 会话）：分割第二步（A2）的输入方式，供 train_foundation.py 用。
bands = 12 波段；aux 或 aux-组+组 = 12 波段 + 22 层辅助（只保留所列组，其余为 0）；prev = 12 波段 + 同测点过去 180 天内最近一期的 12 波段 + 该期无云比例（没有则为 0）。
辅助层由 inputs_f16.npy 第 12—30 层现算，与 10-18 的 aux_f16.npy 逐值相同（10-26 已核对）；前期影像不用往年同期组（含后期影像的偏离特征）。
10-28 加两组由 12 个波段现算的光谱指数（各 6 层，接在 34 层之后，顺序按组名在 mode 里出现的先后）：
  idx   = 当期 NDVI、NDWI、MNDWI、BSI、NDBI（短波红外与近红外的归一化差）、可见光亮度（B2—B4 均值 ×5）；
  pdiff = 同样 6 个指数“当期减前一期”（前一期 = prev 用的同一张：同测点 180 天内最近一期，只用更早的影像），
          两期都无云处做稳健标准化 (d − 中位数) / (1.4826 × 中位数绝对偏差)，截断 ±6 后除以 6；有云或没有前一期处为 0（与直接检测的指数差同一做法）。"""
import json
import os
from pathlib import Path
import numpy as np

ROOT = Path(os.environ.get('RAIL_FRONTIER_ROOT', Path(__file__).resolve().parent.parent))
AUX_GROUPS = {'multiyear': [0, 1, 2, 3, 4, 5, 6, 20], 'hist': [7, 8, 9, 10, 11, 12, 13, 21],
              'terrain': [14, 15, 16, 17, 18], 'clear': [19]}
EXTRA_GROUPS = ('idx', 'pdiff')        # 10-28：现算的指数组，各 6 层
B2, B3, B4, B8, B11 = 1, 2, 3, 7, 10   # inputs_f16 前 12 层：B1 B2 B3 B4 B5 B6 B7 B8 B8A B9 B11 B12（反射率）


def base_mode(mode):
    """10-27 分割第三步：输入写成“接法:输入”（如 film:aux-multiyear），这里取冒号后的输入部分"""
    return mode.split(':', 1)[-1]


def split_drop(g):
    """10-29 Claude：输入写成 aux-multiyear~3 时，表示多年地表统计去掉第 3 项（0 起；多项用点隔开，如 ~1.2）；返回 (组名, 去掉的项)"""
    if '~' in g:
        name, k = g.split('~', 1)
        return name, [int(x) for x in k.split('.')]
    return g, []


def groups_of(mode):
    mode = base_mode(mode)
    return mode.split('-', 1)[1].split('+') if '-' in mode else list(AUX_GROUPS)


def n_channels(mode):
    mode = base_mode(mode)
    if mode.startswith('aux'):
        return 34 + 6 * sum(g in EXTRA_GROUPS for g in groups_of(mode))
    return 12 if mode == 'bands' else 3 if mode == 'rgb' else 25 if mode == 'prev' else None


def channel_index(mode, group):
    """该组在拼接后输入里的通道号（训练时随机整组丢弃用）"""
    if group in AUX_GROUPS:
        return [12 + k for k in AUX_GROUPS[group]]
    extra = [g for g in groups_of(mode) if g in EXTRA_GROUPS]
    s = 34 + 6 * extra.index(group)
    return list(range(s, s + 6))


def _nd(a, b):
    return (a - b) / np.maximum(a + b, 1e-4)


def spectral_indices(x):
    """x: (12, H, W) 反射率 → (6, H, W)"""
    b2, b3, b4, b8, b11 = x[B2], x[B3], x[B4], x[B8], x[B11]
    bsi = _nd(b11 + b4, b8 + b2)
    out = np.stack([_nd(b8, b4), _nd(b3, b8), _nd(b3, b11), bsi, _nd(b11, b8), (b2 + b3 + b4) / 3 * 5], 0)
    return np.clip(out, -1.5, 1.5).astype(np.float32)


class InputView:
    def __init__(self, base, mode, index):
        mode = base_mode(mode)
        self.base, self.mode = base, mode
        self.channels = n_channels(mode)
        assert self.channels, f'未知输入方式 {mode}'
        self.shape = (base.shape[0], self.channels) + base.shape[2:]
        self.clouds = np.load(ROOT / 'assets/clouds_u8.npy', mmap_mode='r')
        self.before = np.array([w == 'before' for _, w in index['src']])
        if mode.startswith('aux'):
            groups = groups_of(mode)
            names = [split_drop(g)[0] for g in groups]
            assert all(g in AUX_GROUPS or g in EXTRA_GROUPS for g in names), f'未知的辅助组 {groups}'
            self.keep = np.zeros(22, np.float32)
            for g in groups:
                name, drop = split_drop(g)
                if name in AUX_GROUPS:
                    self.keep[AUX_GROUPS[name]] = 1
                    for k in drop:                       # 10-29：逐项去掉（观测次数在 20、21 另有复制通道，一并去掉）
                        self.keep[AUX_GROUPS[name][k]] = 0
                        if k == 6:
                            self.keep[{'multiyear': 20, 'hist': 21}.get(name, AUX_GROUPS[name][k])] = 0
            self.extra = [g for g in names if g in EXTRA_GROUPS]
        if mode == 'prev' or (mode.startswith('aux') and 'pdiff' in self.extra):
            self.frames = json.loads((ROOT / 'assets/temporal.json').read_text('utf-8'))

    def _pdiff(self, i, cur, r, c):
        """当期减前一期的 6 个指数；稳健标准化用整幅 256×256 的统计量（与裁剪位置无关）"""
        row = self.frames[i]
        if not (len(row['indices']) > 1 and row['valid'][1]):
            return np.zeros((6,) + cur.shape[1:], np.float32)
        j = row['indices'][1]
        full_c = np.asarray(self.base[i, :12], np.float32); full_p = np.asarray(self.base[j, :12], np.float32)
        ok = (np.asarray(self.clouds[i]) == 0) & (np.asarray(self.clouds[j]) == 0)
        d = spectral_indices(full_c) - spectral_indices(full_p)
        out = np.zeros_like(d)
        if ok.sum() >= 100:
            for k in range(6):
                v = d[k][ok]; med = np.median(v); mad = np.median(np.abs(v - med)) * 1.4826
                out[k] = np.where(ok, np.clip((d[k] - med) / max(mad, 1e-4), -6, 6) / 6, 0)
        return out[:, r, c]

    def __getitem__(self, key):
        i, channels, *sl = key
        r, c = sl if sl else (slice(None), slice(None))
        if self.mode.startswith('aux'):
            x = np.asarray(self.base[i, :, r, c], np.float32)
            a = np.empty((22,) + x.shape[1:], np.float32)
            a[:19] = x[12:31]
            if self.before[i]:
                a[7:14] = 0
            a[19] = 1 - np.asarray(self.clouds[i, r, c], np.float32)
            a[20] = a[6]; a[21] = a[13]
            a *= self.keep[:, None, None]
            parts = [x[:12], a]
            for g in self.extra:
                parts.append(spectral_indices(x[:12]) if g == 'idx' else self._pdiff(i, x[:12], r, c))
            return np.concatenate(parts, 0)[channels]
        cur = np.asarray(self.base[i, :12, r, c], np.float32)
        row = self.frames[i]
        if len(row['indices']) > 1 and row['valid'][1]:
            j = row['indices'][1]
            prev = np.asarray(self.base[j, :12, r, c], np.float32)
            clear = 1 - np.asarray(self.clouds[j, r, c], np.float32)
        else:
            prev = np.zeros_like(cur); clear = np.zeros(cur.shape[1:], np.float32)
        return np.concatenate([cur, prev, clear[None]], 0)[channels]
