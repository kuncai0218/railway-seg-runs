"""打包要发回的结果（10-26，Claude）：在实验包根目录运行  python code/pack_results.py --name 同学甲
只打包每个实验的概率图（*.npz）、评估结果、训练曲线、运行记录和日志；不打包检查点（last.pt，很大，不需要）。
生成 回传_<名字>_<日期时间>.zip，放在实验包根目录，发给组长即可。中途也可以随时打包发一次已完成的部分。"""
import argparse
import datetime
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKIP_SUFFIX = {'.pt', '.tmp'}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--name', required=True)
    a = ap.parse_args()
    res = ROOT / 'results'
    stamp = datetime.datetime.now().strftime('%m%d_%H%M')
    out = ROOT / f'回传_{a.name}_{stamp}.zip'
    n = size = 0
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=1, allowZip64=True) as z:
        for f in sorted(res.rglob('*')):
            if f.is_dir() or f.suffix in SKIP_SUFFIX or '_check' in f.parts:
                continue
            z.write(f, Path('results') / f.relative_to(res))
            n += 1; size += f.stat().st_size
        for f in sorted((ROOT / 'tasks').glob('*.json')):
            z.write(f, Path('tasks') / f.name)
    print(f'已打包 {n} 个文件（原始 {size / 2**30:.2f} GB）→ {out}（{out.stat().st_size / 2**30:.2f} GB）')


if __name__ == '__main__':
    main()
