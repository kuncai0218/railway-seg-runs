# -*- coding: utf-8 -*-
"""新方法逐层追踪（11-27，只用验证集）：同一个新方法权重内部有三层输出——
  ctx    骨干分数（场景校准之前）
  unary  链前一元分数（场景校准 + 局部支路之后）
  chain  时间链后验边际（官方输出）
对每个“干净新建事件”，看它在哪一层从“第 t 期判建筑”变成“没判建筑”，以及各层的事件分类（准时/提前/晚/没切）。
同时报三层各自的官方 BC、SC、严格 F1、召回、报警倍数，回答“SC 掉在场景校准还是掉在时间链”。
用法：python analyze_layers.py <新方法 tag>"""
import os
import json
import sys
from pathlib import Path

import numpy as np

from analyze import CATS, OUT, T, categorize, events

RT = Path(os.environ.get("MUDS_RT", r"D:\Railway_project\work\公开数据_1102\scripts\muds_m3_1126\runtime"))
sys.path.insert(0, str(RT))
os.environ.setdefault("ST3D_REPO", str(RT / "upstream"))


def main():
    tag = sys.argv[1]
    import torch
    import st3d_repro as adapter
    from train_snt import RichSCDAccumulator
    meta = json.loads((OUT / tag / "meta.json").read_text("utf-8"))
    local = OUT / tag / "gt.npy"
    gt = np.load(local if local.exists() else OUT / f"gt_val_{meta['domain']}.npy")
    ctx = np.load(OUT / tag / "ctx.npy", mmap_mode="r")
    un = np.load(OUT / tag / "unary.npy", mmap_mode="r")
    pred = np.load(OUT / tag / "pred.npy")
    n = pred.shape[0]
    gt = gt[:n]
    layers = {
        "ctx": lambda i: np.asarray(ctx[i]).argmax(1).astype(np.uint8),
        "unary": lambda i: np.asarray(un[i]).argmax(1).astype(np.uint8),
        "chain": lambda i: ((pred[i][None] >> np.arange(T, dtype=np.uint8)[:, None, None]) & 1).astype(np.uint8),
    }
    P = {k: np.zeros((n, T) + gt.shape[2:], np.uint8) for k in layers}
    mets = {k: adapter.SCDMetric(num_classes=2, class_names=["not building", "building"], ignore_index=2) for k in layers}
    rich = {k: RichSCDAccumulator(2) for k in layers}
    for i in range(n):
        g = torch.from_numpy(gt[i].astype(np.int64))[None]
        for k, f in layers.items():
            p = f(i)
            P[k][i] = p
            mets[k].update(torch.from_numpy(p.astype(np.int64))[None], g)
            rich[k].update(p[None].astype(np.int64), gt[i][None].astype(np.int64))
    res = {"tag": tag, "层": {}}
    for k in layers:
        s = {q: float(v) for q, v in mets[k].compute().items()}
        r = rich[k].compute(include_per_aoi=False)
        res["层"][k] = {"miou": round(s["miou"], 2), "bc": round(s["bc"], 2), "sc": round(s["sc"], 2), "scs": round(s["scs"], 2),
                       "严格F1": round(r["strict_f1"], 2), "召回": round(r["recall"], 2), "稳定误报": round(r["stable_fpr"], 3),
                       "报警倍数": round(r["alarms"] / max(r["true_changes"], 1), 2)}
    chg, cons, demo, clean = events(gt)
    cats = {}
    for k in layers:
        idx, c = categorize(gt, P[k], clean)
        cats[k] = c
        cnt = np.bincount(c, minlength=len(CATS))
        res["层"][k]["干净新建_分类%"] = {CATS[j]: round(float(cnt[j] / max(len(c), 1) * 100), 2) for j in range(len(CATS))}
        res["层"][k]["新建处第t期判建筑%"] = round(float(P[k][cons].mean() * 100), 2)
    # 第 t 期判建筑与否在三层之间的流转（只看干净新建）
    hit = {k: np.isin(cats[k], [0, 1, 2, 3]) for k in layers}  # 第 t 期判成建筑（SC 记对）
    flow = {}
    for a, b in (("ctx", "unary"), ("unary", "chain")):
        flow[f"{a}→{b}"] = {"对→错": int((hit[a] & ~hit[b]).sum()), "错→对": int((~hit[a] & hit[b]).sum()),
                            "都对": int((hit[a] & hit[b]).sum()), "都错": int((~hit[a] & ~hit[b]).sum())}
    res["第t期判建筑的流转（干净新建像元）"] = flow
    # 链把哪些类别的事件变成了什么
    tab = np.zeros((len(CATS), len(CATS)), int)
    np.add.at(tab, (cats["unary"], cats["chain"]), 1)
    res["链前→链后_事件分类交叉表"] = {"行=链前,列=链后": CATS, "表": tab.tolist()}
    print(json.dumps(res, ensure_ascii=False, indent=1))
    (OUT / tag / "layers.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), "utf-8")


if __name__ == "__main__":
    main()
