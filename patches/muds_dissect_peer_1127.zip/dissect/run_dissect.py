# -*- coding: utf-8 -*-
"""MUDS 错题拆解一键运行（11-27，给甲乙在本机用自己的权重跑；只读验证集，不碰测试集，不训练）。
依次：
  1) 逐像元导出（dump_val.py）：新方法、骨干各三份——同区权重在同区验证、跨区权重在跨区验证、跨区权重在同区验证（后者给改读法在同区选参数用）
  2) 事件归类与逐事件交叉表（analyze.py）、新方法逐层追踪（analyze_layers.py）、空间诊断（analyze_spatial.py）
  3) 零训练改读法：时间链读法网格（decode.py --grid）、“先定轮廓再定开工期”（decode_footprint.py --ws）
  4) 把所有结果 JSON 和日志打成 dissect_results_s<种子>.zip（几百 KB，不含导出的大数组），打印字节数与 SHA256
可重复运行：已有结果的步骤跳过。导出的数组约 2.5 GB，留在 --out 目录，组长确认收到结果后再删。
用法（在配对包 train_muds.py 所在目录，用训练时同一个 Python）：
  python -X utf8 dissect/run_dissect.py --seed 43 --data <Muds 数据目录> --out <新的空目录>
      --m3_in <best_in_epXXX.pth> --m3_out <best_out_epXXX.pth> --a1_in <...> --a1_out <...>"""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(2**20), b""):
            h.update(b)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--runtime", default=str(Path.cwd()), help="配对包 runtime（train_muds.py 所在目录），默认当前目录")
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    for k in ("m3_in", "m3_out", "a1_in", "a1_out"):
        ap.add_argument(f"--{k}", required=True)
    ap.add_argument("--device", default="cuda:0")
    a = ap.parse_args()
    rt = Path(a.runtime).resolve()
    assert (rt / "train_muds.py").is_file() and (rt / "upstream").is_dir(), f"{rt} 不是配对包目录（缺 train_muds.py 或 upstream）"
    out = Path(a.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, MUDS_RT=str(rt), MUDS_DATA=str(Path(a.data).resolve()), DISSECT_OUT=str(out),
               ST3D_REPO=str(rt / "upstream"), PYTHONIOENCODING="utf-8")
    log = open(out / f"run_dissect_s{a.seed}.log", "a", encoding="utf-8")
    py = [sys.executable, "-B", "-u", "-X", "utf8"]
    S = a.seed

    def run(args, done_file):
        if done_file is not None and Path(done_file).exists():
            print("跳过（已有）", done_file, flush=True)
            return
        t0 = time.monotonic()
        print(time.strftime("%H:%M:%S"), "运行", " ".join(str(x) for x in args[4:]), flush=True)
        log.write(f"\n===== {time.strftime('%F %T')} {' '.join(str(x) for x in args)}\n")
        log.flush()
        r = subprocess.run(py + [str(x) for x in args], cwd=str(HERE), env=env, stdout=log, stderr=subprocess.STDOUT)
        print(f"  返回码 {r.returncode}，{time.monotonic() - t0:.0f} 秒", flush=True)
        if r.returncode != 0:
            raise SystemExit(f"失败：{args}，见 {log.name}")

    dumps = [("m3", a.m3_in, "in", f"m3_s{S}_in"), ("m3", a.m3_out, "out", f"m3_s{S}_out"), ("m3", a.m3_out, "in", f"m3_s{S}_outw_in"),
             ("pse", a.a1_in, "in", f"a1_s{S}_in"), ("pse", a.a1_out, "out", f"a1_s{S}_out"), ("pse", a.a1_out, "in", f"a1_s{S}_outw_in")]
    for method, w, dom, tag in dumps:
        run([HERE / "dump_val.py", "--method", method, "--weights", w, "--domain", dom, "--tag", tag, "--device", a.device], out / tag / "meta.json")
    for dom in ("in", "out"):
        run([HERE / "analyze.py", f"a1_s{S}_{dom}", f"m3_s{S}_{dom}"], out / f"cross_a1_s{S}_{dom}__m3_s{S}_{dom}.npy")
        run([HERE / "analyze_layers.py", f"m3_s{S}_{dom}"], out / f"m3_s{S}_{dom}" / "layers.json")
    run([HERE / "analyze_spatial.py", f"a1_s{S}_in", f"m3_s{S}_in", f"a1_s{S}_out", f"m3_s{S}_out"], out / f"m3_s{S}_out" / "spatial.json")
    for tag in (f"m3_s{S}_in", f"m3_s{S}_outw_in", f"m3_s{S}_out"):
        run([HERE / "decode.py", tag, "--grid"], out / tag / "decode_grid.json")
    for tag in (f"a1_s{S}_in", f"a1_s{S}_outw_in", f"a1_s{S}_out", f"m3_s{S}_in", f"m3_s{S}_outw_in", f"m3_s{S}_out"):
        run([HERE / "decode_footprint.py", tag, "--ws"], out / tag / "footprint_ws.json")
    log.close()
    zp = out / f"dissect_results_s{S}.zip"
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob("*")):
            if p.is_file() and (p.suffix in (".json", ".log") or p.name.startswith("cross_")) and p != zp:
                z.write(p, p.relative_to(out).as_posix())
    print("完成：", zp, zp.stat().st_size, "字节", "SHA256", sha(zp), flush=True)


if __name__ == "__main__":
    main()
