# -*- coding: utf-8 -*-
"""拆解脚本用到的几个图像操作，只依赖 numpy + torch（甲乙的训练环境不一定装了 scipy；为让各机器结果一致，本机也统一用这一份）。
  label(mask, conn)          连通域（4 或 8 邻接），返回 (lab, k)，lab 为 0..k
  cheb_dist(target, maxd)    到 target 的切比雪夫距离（8 邻接逐层膨胀），超过 maxd 记 maxd+1；target 处为 0
  erode(mask)                3×3 腐蚀（边界外按 0）
  maxfilter(x, size)         size×size 极大值滤波
  grow_labels(seeds, mask)   在 mask 内从种子标签逐层向外长（8 邻接；同时到达取编号大的），没长到的为 0
  mean_by_label(v, lab, k)   每个标签内 v 的平均（1..k）"""
import numpy as np
import torch
import torch.nn.functional as F

_K4 = torch.tensor([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=torch.bool)


def _pool_max(x, conn=8):
    """x [H,W] float/int64 tensor → 3×3 邻域最大（conn=4 时只看上下左右）"""
    if conn == 8:
        return F.max_pool2d(x[None, None].float(), 3, stride=1, padding=1)[0, 0]
    xp = F.pad(x[None, None].float(), (1, 1, 1, 1), value=float("-inf"))[0, 0]
    H, W = x.shape
    c = xp[1:H + 1, 1:W + 1]
    return torch.stack([c, xp[0:H, 1:W + 1], xp[2:H + 2, 1:W + 1], xp[1:H + 1, 0:W], xp[1:H + 1, 2:W + 2]]).max(0).values


def label(mask, conn=4):
    m = torch.from_numpy(np.ascontiguousarray(mask)).bool()
    if not m.any():
        return np.zeros(mask.shape, np.int64), 0
    H, W = m.shape
    lab = torch.where(m, torch.arange(1, H * W + 1, dtype=torch.float32).view(H, W), torch.zeros(H, W))
    while True:
        nxt = torch.where(m, _pool_max(lab, conn), torch.zeros_like(lab))
        if torch.equal(nxt, lab):
            break
        lab = nxt
    lab = lab.long().numpy()
    u, inv = np.unique(lab, return_inverse=True)
    inv = inv.reshape(lab.shape)
    if u[0] != 0:
        inv = inv + 1
    return inv.astype(np.int64), int(inv.max())


def cheb_dist(target, maxd=12):
    t = torch.from_numpy(np.ascontiguousarray(target)).float()
    d = torch.full(t.shape, float(maxd + 1))
    cur = t.clone()
    d[cur > 0] = 0
    for k in range(1, maxd + 1):
        cur = _pool_max(cur, 8)
        newly = (cur > 0) & (d > k)
        d[newly] = k
    return d.numpy()


def erode(mask):
    m = torch.from_numpy(np.ascontiguousarray(mask)).float()
    e = -F.max_pool2d(-F.pad(m[None, None], (1, 1, 1, 1), value=0.0), 3, stride=1)[0, 0]
    return (e > 0.5).numpy()


def maxfilter(x, size):
    t = torch.from_numpy(np.ascontiguousarray(x)).float()
    return F.max_pool2d(t[None, None], size, stride=1, padding=size // 2)[0, 0].numpy()


def grow_labels(seeds, mask):
    lab = torch.from_numpy(np.ascontiguousarray(seeds)).float()
    m = torch.from_numpy(np.ascontiguousarray(mask)).bool()
    lab = torch.where(m, lab, torch.zeros_like(lab))
    while True:
        cand = _pool_max(lab, 8)
        nxt = torch.where(m & (lab == 0), cand, lab)
        if torch.equal(nxt, lab):
            break
        lab = nxt
    return lab.long().numpy()


def _jfa(seed):
    """跳跃泛洪：每个像元最近的种子像元坐标（欧氏），seed [H,W] bool；没有种子时返回 None。"""
    s = torch.from_numpy(np.ascontiguousarray(seed)).bool()
    if not s.any():
        return None
    H, W = s.shape
    yy, xx = torch.meshgrid(torch.arange(H, dtype=torch.float32), torch.arange(W, dtype=torch.float32), indexing="ij")
    INF = 1e9
    sy = torch.where(s, yy, torch.full_like(yy, INF))
    sx = torch.where(s, xx, torch.full_like(xx, INF))
    d = torch.where(s, torch.zeros_like(yy), torch.full_like(yy, INF))
    k = 1
    while k * 2 < max(H, W):
        k *= 2
    steps = []
    while k >= 1:
        steps.append(k)
        k //= 2
    steps += [2, 1, 1]  # 末尾补几轮小步长，减少跳跃泛洪的个别误差
    for k in steps:
        for dy in (-k, 0, k):
            for dx in (-k, 0, k):
                if dy == 0 and dx == 0:
                    continue
                y0, y1 = max(0, dy), H + min(0, dy)
                x0, x1 = max(0, dx), W + min(0, dx)
                cy = torch.full_like(sy, INF)
                cx = torch.full_like(sx, INF)
                cy[y0 - dy:y1 - dy, x0 - dx:x1 - dx] = sy[y0:y1, x0:x1]
                cx[y0 - dy:y1 - dy, x0 - dx:x1 - dx] = sx[y0:y1, x0:x1]
                cd = (yy - cy) ** 2 + (xx - cx) ** 2
                better = cd < d
                d = torch.where(better, cd, d)
                sy = torch.where(better, cy, sy)
                sx = torch.where(better, cx, sx)
    return sy.long(), sx.long(), d.sqrt()


def edt(mask):
    """与 scipy.ndimage.distance_transform_edt(mask) 相同：mask 内每个像元到最近 mask 外像元的欧氏距离，mask 外为 0。"""
    r = _jfa(~np.asarray(mask, bool))
    if r is None:
        return np.full(np.shape(mask), np.inf)
    d = r[2].numpy()
    return np.where(mask, d, 0.0)


def nearest_label(seeds):
    """每个像元取欧氏距离最近的种子像元的标签（seeds>0 为种子），与 scipy 的 distance_transform_edt(seeds==0, return_indices=True) 取法相同。"""
    r = _jfa(np.asarray(seeds) > 0)
    if r is None:
        return np.zeros(np.shape(seeds), np.int64)
    sy, sx, _ = r
    return np.asarray(seeds)[sy.numpy(), sx.numpy()]


def mean_by_label(v, lab, k):
    s = np.bincount(lab.ravel(), weights=v.ravel().astype(np.float64), minlength=k + 1)
    c = np.bincount(lab.ravel(), minlength=k + 1)
    return (s / np.maximum(c, 1))[1:]
