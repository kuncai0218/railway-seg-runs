# -*- coding: utf-8 -*-
"""MUDS 验证集错题拆解（11-27）：读 dump_val.py 的导出，按“新建/拆除事件”逐像元、逐对象归类。

一个真变化事件 = 某像元第 t-1、t 期标签都有效且不同（官方 BC、SC 只在这些位置计分）。
对“干净的新建事件”（有效期里标签先全是非建筑、从 t 起全是建筑）看模型的“稳定切换期”s：
  从 s 起模型一直判建筑（s=0 表示从头到尾都是建筑；s=T 表示最后一期仍不是建筑）。
  分类：一直是建筑 / 提前 k 期 / 准时 / 晚 k 期 / 到最后也没切（其中再分“后面闪过建筑”和“从没判过建筑”）。
SC 只看第 t 期判得对不对：一直是建筑、提前、准时都算对，晚、没切都算错。
用法：python analyze.py <tag1> [<tag2> ...]（同一域；两个 tag 时另出逐事件交叉表）"""
import os
import json
import sys
from pathlib import Path

import numpy as np
import ndi

OUT = Path(os.environ.get("DISSECT_OUT", r"D:\Railway_project\work\公开数据_1102\runs_muds_dissect_1127"))
T = 8
CATS = ["一直是建筑", "提前2期以上", "提前1期", "准时", "晚1期", "晚2期以上", "没切_闪过", "没切_从没判过"]


def load(tag):
    meta = json.loads((OUT / tag / "meta.json").read_text("utf-8"))
    pred = np.load(OUT / tag / "pred.npy")
    pb = np.load(OUT / tag / "pb.npy").astype(np.float32)
    n = pred.shape[0]
    local = OUT / tag / "gt.npy"
    gt = np.load(local if local.exists() else OUT / f"gt_val_{meta['domain']}.npy")[:n]
    p = ((pred[:, None] >> np.arange(T, dtype=np.uint8)[None, :, None, None]) & 1).astype(np.uint8)  # [N,T,H,W]
    return meta, gt, p, pb


def settle(p):
    """p: [..., T] 0/1。返回稳定切换期 s：从 s 起全为 1；最后一期为 0 时 s=T。"""
    s = np.full(p.shape[:-1], T, np.int64)
    ones_suffix = np.ones(p.shape[:-1], bool)
    for t in range(T - 1, -1, -1):
        ones_suffix &= p[..., t] == 1
        s = np.where(ones_suffix, t, s)
    return s


def events(gt):
    """新建与拆除事件掩膜 [N,T,H,W]（第 0 期恒 False），以及“干净新建”掩膜。"""
    v = gt != 2
    chg = np.zeros(gt.shape, bool)
    chg[:, 1:] = v[:, 1:] & v[:, :-1] & (gt[:, 1:] != gt[:, :-1])
    cons = chg & (gt == 1)
    demo = chg & (gt == 0)
    # 干净新建：该像元只有这一次标签变化，且之前有效期全是 0、之后全是 1
    nchg = chg.sum(1, keepdims=True)
    clean = cons & (nchg == 1)
    return chg, cons, demo, clean


def categorize(gt, p, clean):
    """对每个干净新建事件返回类别编号（与 CATS 对应），以及事件所在的 (块, t, y, x)。"""
    idx = np.argwhere(clean)  # [E,4] n,t,y,x
    seq = p[idx[:, 0], :, idx[:, 2], idx[:, 3]]  # [E,T]
    t = idx[:, 1]
    s = settle(seq)
    after_any = np.array([seq[i, t[i]:].any() for i in range(len(t))]) if len(t) else np.zeros(0, bool)
    cat = np.full(len(t), -1)
    cat[s == 0] = 0
    cat[(s > 0) & (s <= t - 2)] = 1
    cat[(s > 0) & (s == t - 1)] = 2
    cat[s == t] = 3
    cat[(s == t + 1) & (s < T)] = 4
    cat[(s >= t + 2) & (s < T)] = 5
    cat[(s == T) & after_any] = 6
    cat[(s == T) & ~after_any] = 7
    assert (cat >= 0).all()
    return idx, cat


def summarize(tag):
    meta, gt, p, pb = load(tag)
    chg, cons, demo, clean = events(gt)
    v = gt != 2
    res = {"tag": tag, "epoch": meta["epoch"], "official_val": {k: round(meta["official_val"][k], 2) for k in ("miou", "bc", "sc", "scs")}}
    res["真变化像元"] = int(chg.sum())
    res["新建"] = int(cons.sum())
    res["拆除"] = int(demo.sum())
    res["干净新建"] = int(clean.sum())
    # 官方 SC 在新建位置的得分：第 t 期判成建筑
    res["新建处第t期判建筑%"] = round(float(p[cons].mean() * 100), 2)
    res["拆除处第t期判非建筑%"] = round(float((1 - p[demo]).mean() * 100), 2) if demo.any() else None
    idx, cat = categorize(gt, p, clean)
    counts = np.bincount(cat, minlength=len(CATS))
    res["干净新建_分类%"] = {c: round(float(counts[i] / max(len(cat), 1) * 100), 2) for i, c in enumerate(CATS)}
    # 各类第 t-1、t、t+1 期建筑概率的中位数
    probs = {}
    for i, c in enumerate(CATS):
        sel = idx[cat == i]
        if len(sel) == 0:
            continue
        row = {}
        for off in (-1, 0, 1):
            tt = sel[:, 1] + off
            ok = (tt >= 0) & (tt < T)
            row[f"t{off:+d}"] = round(float(np.median(pb[sel[ok, 0], tt[ok], sel[ok, 2], sel[ok, 3]])), 3)
        probs[c] = row
    res["各类建筑概率中位数"] = probs
    # 对象：同一块、同一 t 的干净新建像元按 8 邻接连通
    objs = []
    for n_ in range(gt.shape[0]):
        for t_ in range(1, T):
            m = clean[n_, t_]
            if not m.any():
                continue
            lab, k = ndi.label(m, 8)
            for j in range(1, k + 1):
                o = lab == j
                pt = p[n_, t_][o]
                objs.append((n_, t_, int(o.sum()), float(pt.mean()), float(p[n_, t_ - 1][o].mean())))
    objs = np.array(objs, dtype=float) if objs else np.zeros((0, 5))
    bins = [(1, 4), (5, 16), (17, 64), (65, 256), (257, 10**9)]
    size_tab = {}
    for lo, hi in bins:
        sel = (objs[:, 2] >= lo) & (objs[:, 2] <= hi) if len(objs) else np.zeros(0, bool)
        if sel.sum() == 0:
            continue
        w = objs[sel, 2]
        size_tab[f"{lo}-{hi if hi < 10**9 else '以上'}像元"] = {
            "对象数": int(sel.sum()), "像元数": int(w.sum()),
            "第t期判建筑%(按像元)": round(float((objs[sel, 3] * w).sum() / w.sum() * 100), 1),
            "第t-1期已判建筑%(按像元)": round(float((objs[sel, 4] * w).sum() / w.sum() * 100), 1),
            "对象第t期过半判建筑%": round(float((objs[sel, 3] >= 0.5).mean() * 100), 1)}
    res["新建对象按大小"] = size_tab
    # 边缘与内部：第 t 期标签 3×3 邻域全是建筑算内部
    interior = np.zeros(clean.shape, bool)
    b = (gt == 1)
    for n_ in range(gt.shape[0]):
        for t_ in range(1, T):
            if clean[n_, t_].any():
                interior[n_, t_] = ndi.erode(b[n_, t_]) & clean[n_, t_]
    ii = interior[idx[:, 0], idx[:, 1], idx[:, 2], idx[:, 3]]
    res["内部_分类%"] = {c: round(float(((cat == i) & ii).sum() / max(ii.sum(), 1) * 100), 2) for i, c in enumerate(CATS)}
    res["边缘_分类%"] = {c: round(float(((cat == i) & ~ii).sum() / max((~ii).sum(), 1) * 100), 2) for i, c in enumerate(CATS)}
    res["内部像元占干净新建%"] = round(float(ii.mean() * 100), 1)
    # 标签整体：一直非建筑而模型在某些期判建筑（误报来源）
    stable0 = v.all(1) & (gt == 0).all(1)
    res["全程非建筑像元里_模型某期判建筑%"] = round(float(p.any(1)[stable0].mean() * 100), 3)
    return res, (idx, cat)


def main():
    tags = sys.argv[1:]
    outs = {}
    for tag in tags:
        res, ev = summarize(tag)
        outs[tag] = ev
        print(json.dumps(res, ensure_ascii=False, indent=1))
        (OUT / tag / "analysis.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), "utf-8")
    if len(tags) == 2:
        (i1, c1), (i2, c2) = outs[tags[0]], outs[tags[1]]
        assert np.array_equal(i1, i2)
        tab = np.zeros((len(CATS), len(CATS)), int)
        np.add.at(tab, (c1, c2), 1)
        print(f"逐事件交叉表（行 {tags[0]}，列 {tags[1]}，单位：干净新建像元）")
        print("\t" + "\t".join(CATS))
        for i, c in enumerate(CATS):
            print(c + "\t" + "\t".join(str(x) for x in tab[i]))
        np.save(OUT / f"cross_{tags[0]}__{tags[1]}.npy", tab)


if __name__ == "__main__":
    main()
