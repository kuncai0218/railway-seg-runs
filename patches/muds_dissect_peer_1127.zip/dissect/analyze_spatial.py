# -*- coding: utf-8 -*-
"""MUDS 验证集空间诊断（11-27）：
  1) 误报（标签没变、模型判变了）离最近的“标签建筑”有多远——检验“误报主要是团块边缘来回抖”；
  2) 新建事件离 t-1 期已有建筑有多远（贴着旧楼长出来 vs 孤立新楼），各距离段里事件分类（准时/晚/没切……）的比例。
距离用到标签建筑的切比雪夫距离（8 邻接逐层膨胀，像元，4.77 m；12 像元以上记 13）。用法：python analyze_spatial.py <tag> [<tag2> ...]"""
import json
import sys

import numpy as np
import ndi

from analyze import CATS, OUT, T, categorize, events, load

BINS = [(0, 0, "建筑内部"), (1, 1, "1像元"), (2, 2, "2像元"), (3, 5, "3-5像元"), (6, 10, "6-10像元"), (11, 10**6, ">10像元")]
EBINS = [(1, 2, "贴着旧楼(1-2像元)"), (3, 5, "3-5像元"), (6, 10, "6-10像元"), (11, 10**6, "孤立(>10像元)"), (None, None, "块内此前无楼")]


def main():
    for tag in sys.argv[1:]:
        meta, gt, p, pb = load(tag)
        v = gt != 2
        chg, cons, demo, clean = events(gt)
        idx, cat = categorize(gt, p, clean)
        catmap = np.full(clean.shape, -1, np.int8)
        catmap[idx[:, 0], idx[:, 1], idx[:, 2], idx[:, 3]] = cat
        fa_d = np.zeros(len(BINS), np.int64)
        ev = {b[2]: np.zeros(len(CATS), np.int64) for b in EBINS}
        for n in range(gt.shape[0]):
            for t in range(1, T):
                stable = v[n, t] & v[n, t - 1] & (gt[n, t] == gt[n, t - 1])
                fa = stable & (p[n, t] != p[n, t - 1])
                bld = (gt[n, t] == 1) | (gt[n, t - 1] == 1)
                if fa.any():
                    d = ndi.cheb_dist(bld, 12) if bld.any() else np.full(bld.shape, 1e6)
                    dd = d[fa]
                    for j, (lo, hi, _) in enumerate(BINS):
                        fa_d[j] += int(((dd >= lo) & (dd <= hi)).sum())
                m = clean[n, t]
                if m.any():
                    old = (gt[n, t - 1] == 1) & v[n, t - 1]
                    cm = catmap[n, t][m]
                    if not old.any():
                        ev["块内此前无楼"] += np.bincount(cm, minlength=len(CATS))
                    else:
                        d = ndi.cheb_dist(old, 12)[m]
                        for lo, hi, name in EBINS[:-1]:
                            sel = (d >= lo) & (d <= hi)
                            ev[name] += np.bincount(cm[sel], minlength=len(CATS))
        tot = fa_d.sum()
        res = {"tag": tag, "误报像元期数": int(tot),
               "误报离最近标签建筑的距离%": {BINS[j][2]: round(float(fa_d[j] / max(tot, 1) * 100), 1) for j in range(len(BINS))},
               "新建事件按离旧楼距离": {}}
        for name, c in ev.items():
            s = c.sum()
            if s == 0:
                continue
            hit = c[[0, 1, 2, 3]].sum()
            res["新建事件按离旧楼距离"][name] = {"像元数": int(s), "第t期判建筑%": round(float(hit / s * 100), 1),
                                          "准时%": round(float(c[3] / s * 100), 1),
                                          "晚(1期及以上)%": round(float(c[[4, 5]].sum() / s * 100), 1),
                                          "没切%": round(float(c[[6, 7]].sum() / s * 100), 1),
                                          "提前或一直是建筑%": round(float(c[[0, 1, 2]].sum() / s * 100), 1)}
        print(json.dumps(res, ensure_ascii=False, indent=1))
        (OUT / tag / "spatial.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), "utf-8")


if __name__ == "__main__":
    main()
