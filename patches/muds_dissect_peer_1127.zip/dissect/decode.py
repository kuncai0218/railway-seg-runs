# -*- coding: utf-8 -*-
"""新方法（时间链）零训练改读法检验（11-27，只用验证集）。读 dump_val.py 导出的链前一元分数 unary 与成对势 psi，
在不改任何权重的前提下换几种读法，用官方 SCDMetric 与 RichSCD 算验证成绩：
  marginal      官方读法：逐期后验边际取最大（应与导出时的 pred 逐像元相同，作核对）
  viterbi       整条最可能路径
  bias=δ        给“建筑”一元分数加 δ 再取边际（判定门槛整体前移/后移；δ 在同区验证上选，再原样用到跨区）
  chg=c         给所有“换类”成对势加 c（换类代价整体减小/增大）
  bias=δ,chg=c  两者组合
用法：python decode.py <tag> [--grid]   （--grid 跑 δ、c 网格；否则只跑 marginal、viterbi 核对）"""
import os
import argparse
import json
import sys
from pathlib import Path

import numpy as np

RT = Path(os.environ.get("MUDS_RT", r"D:\Railway_project\work\公开数据_1102\scripts\muds_m3_1126\runtime"))
OUT = Path(os.environ.get("DISSECT_OUT", r"D:\Railway_project\work\公开数据_1102\runs_muds_dissect_1127"))
sys.path.insert(0, str(RT))
os.environ.setdefault("ST3D_REPO", str(RT / "upstream"))
import torch  # noqa: E402


def marginals(u, psi):
    """u [P,T,K]，psi [P,T-1,K,K] → 对数边际 [P,T,K]"""
    P, T, K = u.shape
    al = [u[:, 0]]
    for t in range(1, T):
        al.append(u[:, t] + torch.logsumexp(al[-1][:, :, None] + psi[:, t - 1], dim=1))
    be = [torch.zeros_like(u[:, 0])]
    for t in range(T - 2, -1, -1):
        be.insert(0, torch.logsumexp(psi[:, t] + (u[:, t + 1] + be[0])[:, None, :], dim=2))
    logZ = torch.logsumexp(al[-1], dim=1, keepdim=True)
    return torch.stack([al[t] + be[t] - logZ for t in range(T)], dim=1)


def viterbi(u, psi):
    P, T, K = u.shape
    d = u[:, 0]
    back = []
    for t in range(1, T):
        s = d[:, :, None] + psi[:, t - 1]  # [P,K_prev,K]
        m, arg = s.max(dim=1)
        back.append(arg)
        d = m + u[:, t]
    path = torch.zeros(P, T, dtype=torch.long)
    path[:, -1] = d.argmax(1)
    for t in range(T - 2, -1, -1):
        path[:, t] = back[t].gather(1, path[:, t + 1:t + 2]).squeeze(1)
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tag")
    ap.add_argument("--grid", action="store_true")
    a = ap.parse_args()
    import st3d_repro as adapter  # noqa: E402  只为官方 SCDMetric（与训练同一份）
    from train_snt import RichSCDAccumulator  # noqa: E402
    meta = json.loads((OUT / a.tag / "meta.json").read_text("utf-8"))
    U = np.load(OUT / a.tag / "unary.npy", mmap_mode="r")
    PSI = np.load(OUT / a.tag / "psi.npy", mmap_mode="r")
    pred0 = np.load(OUT / a.tag / "pred.npy")
    local = OUT / a.tag / "gt.npy"
    GT = np.load(local if local.exists() else OUT / f"gt_val_{meta['domain']}.npy")
    N, T, K, H, W = U.shape
    variants = {"marginal": (0.0, 0.0), "viterbi": None}
    if a.grid:
        for dl in (-1.0, -0.5, 0.5, 1.0, 1.5, 2.0):
            variants[f"bias={dl:+.1f}"] = (dl, 0.0)
        for c in (-2.0, -1.0, -0.5, 0.5, 1.0):
            variants[f"chg={c:+.1f}"] = (0.0, c)
        for dl in (0.5, 1.0):
            for c in (-1.0, -0.5, 0.5):
                variants[f"bias={dl:+.1f},chg={c:+.1f}"] = (dl, c)
    mets = {k: adapter.SCDMetric(num_classes=2, class_names=["not building", "building"], ignore_index=2) for k in variants}
    rich = {k: RichSCDAccumulator(2) for k in variants}
    mismatch = 0
    eye = torch.eye(K)
    for i in range(N):
        u = torch.from_numpy(np.asarray(U[i], dtype=np.float32)).permute(2, 3, 0, 1).reshape(-1, T, K)  # [P,T,K]
        psi = torch.from_numpy(np.asarray(PSI[i], dtype=np.float32)).permute(3, 4, 0, 1, 2).reshape(-1, T - 1, K, K)
        gt = torch.from_numpy(GT[i].astype(np.int64))[None]  # [1,T,H,W]
        for name, spec in variants.items():
            if spec is None:
                path = viterbi(u, psi)
            else:
                dl, c = spec
                uu = u.clone()
                uu[:, :, 1] += dl
                pp = psi + c * (1 - eye)
                path = marginals(uu, pp).argmax(-1)
            pred = path.reshape(H, W, T).permute(2, 0, 1)[None]
            if name == "marginal":
                bits = (pred[0].numpy().astype(np.uint8) << np.arange(T, dtype=np.uint8)[:, None, None]).sum(0).astype(np.uint8)
                mismatch += int((bits != pred0[i]).sum())
            mets[name].update(pred, gt)
            rich[name].update(pred.numpy(), gt.numpy())
        if (i + 1) % 80 == 0 or i + 1 == N:
            print(f"{i + 1}/{N}", flush=True)
    rows = {}
    for name in variants:
        s = {k: float(v) for k, v in mets[name].compute().items()}
        r = rich[name].compute(include_per_aoi=False)
        rows[name] = {"miou": s["miou"], "bc": s["bc"], "sc": s["sc"], "scs": s["scs"], "strict_f1": r["strict_f1"],
                      "recall": r["recall"], "precision": r["precision"], "stable_fpr": r["stable_fpr"],
                      "alarm_ratio": r["alarms"] / max(r["true_changes"], 1)}
    print("官方读法与导出 pred 不一致的像元期数：", mismatch)
    print("读法\tmIoU\tBC\tSC\tSCS\t严格F1\t召回\t查准\t稳定误报\t报警倍数")
    for name, r in rows.items():
        print(name + "\t" + "\t".join(f"{r[k]:.2f}" for k in ("miou", "bc", "sc", "scs", "strict_f1", "recall", "precision", "stable_fpr", "alarm_ratio")))
    (OUT / a.tag / ("decode_grid.json" if a.grid else "decode_check.json")).write_text(json.dumps({"mismatch": mismatch, "rows": rows}, ensure_ascii=False, indent=1), "utf-8")


if __name__ == "__main__":
    main()
