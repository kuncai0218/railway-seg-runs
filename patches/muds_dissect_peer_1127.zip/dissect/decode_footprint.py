# -*- coding: utf-8 -*-
"""“先定轮廓、再定开工期”的零训练读法（11-27，只用验证集）。思路来自 SpaceNet 7 冠军方案（lxastro0：假设建筑出现后不再变，
把时间维压掉、每栋楼只定一次位置，再在固定轮廓内按期平均概率定出现时刻），这里只拿来检验“按对象合并证据”能否让 SC、BC 一起涨。
对一个 tag 的逐期建筑概率 pb [N,T,H,W]：
  1) 轮廓：M = max_t（第 t 期到最后一期建筑概率的平均），M > τ 的 4 邻接连通域为一个对象（可选分水岭再切开相连的楼）；
  2) 开工期：对象内逐期平均概率 a_t，在“一直有 / 第 s 期出现 / 一直没有”之间按对数似然选 s，中途出现多付代价 c；
  3) 对象外的像元一律非建筑。拆除不建模（MUDS 验证集里拆除占真变化 6%—19%，这部分会被放弃）。
τ、c 在同区验证上选，原样用到跨区验证。用法：python decode_footprint.py <tag> [--ws]"""
import os
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import ndi

RT = Path(os.environ.get("MUDS_RT", r"D:\Railway_project\work\公开数据_1102\scripts\muds_m3_1126\runtime"))
OUT = Path(os.environ.get("DISSECT_OUT", r"D:\Railway_project\work\公开数据_1102\runs_muds_dissect_1127"))
sys.path.insert(0, str(RT))
os.environ.setdefault("ST3D_REPO", str(RT / "upstream"))
T = 8
EPS = 1e-4
DEMO = True  # 允许“出现后又拆除”（11-27 第 2 版；第 1 版只允许出现）


def decode_block(pb, tau, c, ws, delta=0.0):
    H, W = pb.shape[1:]
    suffix = np.cumsum(pb[::-1], axis=0)[::-1] / np.arange(T, 0, -1)[:, None, None]
    M = suffix.max(0)
    mask = M > tau
    if not mask.any():
        return np.zeros((T, H, W), np.uint8)
    if ws:
        # skimage 的分水岭在本机被系统应用控制拦下（导入即退出），改用只靠 ndi.py（numpy + torch）的近似：
        # 欧氏距离变换的局部极大作种子（7×7 窗内最大且距离≥2），掩膜内每个像元归欧氏最近的种子（沃罗诺伊切分）。
        # ndi.edt 与 scipy 逐像元相同；ndi.nearest_label 只在等距像元上与 scipy 的取法可能不同（随机检验约 0.5%）
        dist = ndi.edt(mask)
        peaks = (dist == ndi.maxfilter(dist, 7)) & (dist >= 2) & mask
        seeds, ns = ndi.label(peaks, 4)
        if ns == 0:
            lab, k = ndi.label(mask, 4)
        else:
            lab = np.where(mask, ndi.nearest_label(seeds), 0)
            comp, nc = ndi.label(mask, 4)  # 没有种子的连通域单独成一个对象
            no_seed = mask & (lab == 0)
            if no_seed.any():
                lab = np.where(no_seed, comp + ns, lab)
            uniq, lab = np.unique(lab, return_inverse=True)
            lab = lab.reshape(mask.shape)
            if uniq[0] != 0:
                lab = lab + 1
            k = lab.max()
    else:
        lab, k = ndi.label(mask, 4)
    a = np.stack([ndi.mean_by_label(pb[t], lab, k) for t in range(T)], 1)  # [k,T]
    a = np.clip(a, EPS, 1 - EPS)
    if delta:
        a = 1 / (1 + np.exp(-(np.log(a / (1 - a)) + delta)))  # 对象内平均概率的对数几率整体加 δ：开工判定门槛前移
        a = np.clip(a, EPS, 1 - EPS)
    lp, ln = np.log(a), np.log(1 - a)
    cl = np.concatenate([np.zeros((k, 1)), np.cumsum(ln, 1)], 1)  # cl[:, s] = sum_{t<s} ln
    cp = np.concatenate([np.zeros((k, 1)), np.cumsum(lp, 1)], 1)
    best = np.full(k, -np.inf)
    bs = np.zeros(k, np.int64)
    be = np.zeros(k, np.int64)
    # 存在区间 [s, e)：s 期出现、e 期拆除；s=e 表示从没有过。DEMO=False 时只允许 e=T（只出现不拆除）
    for s in range(T + 1):
        for e in range(s, T + 1):
            if not DEMO and e < T and e > s:
                continue
            L = cl[:, s] + (cp[:, e] - cp[:, s]) + (cl[:, T] - cl[:, e])
            if s < e:
                L = L - c * ((0 < s) + (e < T))
            upd = L > best
            best = np.where(upd, L, best)
            bs = np.where(upd, s, bs)
            be = np.where(upd, e, be)
    S = np.full(k + 1, T, np.int64)
    E = np.full(k + 1, T, np.int64)
    S[1:], E[1:] = bs, be
    s_map, e_map = S[lab], E[lab]
    out = np.zeros((T, H, W), np.uint8)
    for t in range(T):
        out[t] = (s_map <= t) & (t < e_map) & (lab > 0)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tag")
    ap.add_argument("--ws", action="store_true")
    ap.add_argument("--nodemo", action="store_true", help="只允许出现、不允许拆除（第 1 版读法）")
    ap.add_argument("--save", default="", help="只跑这一组参数并把判读存成新 tag（画错题图用），格式 τ,c,δ，例如 0.5,0,0.7")
    a = ap.parse_args()
    global DEMO
    DEMO = not a.nodemo
    if a.save:
        tau, c, dl = (float(x) for x in a.save.split(","))
        meta = json.loads((OUT / a.tag / "meta.json").read_text("utf-8"))
        pb = np.load(OUT / a.tag / "pb.npy", mmap_mode="r")
        N = pb.shape[0]
        bits = np.zeros((N,) + pb.shape[2:], np.uint8)
        for i in range(N):
            p = decode_block(np.asarray(pb[i], dtype=np.float32), tau, c, a.ws, dl)
            bits[i] = (p.astype(np.uint8) << np.arange(T, dtype=np.uint8)[:, None, None]).sum(0).astype(np.uint8)
        new = OUT / f"{a.tag}_fp"
        new.mkdir(exist_ok=True)
        np.save(new / "pred.npy", bits)
        np.save(new / "pb.npy", np.asarray(pb))  # 概率沿用原 tag（只为让 analyze.py 能读）
        meta = dict(meta, note=f"{a.tag} 的逐期概率经“先定轮廓再定开工期”读法（τ={tau}, c={c}, δ={dl}, 切开相连的楼={a.ws}）后的判读")
        (new / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), "utf-8")
        print("已存", new)
        return
    import torch
    import st3d_repro as adapter
    from train_snt import RichSCDAccumulator
    meta = json.loads((OUT / a.tag / "meta.json").read_text("utf-8"))
    pb = np.load(OUT / a.tag / "pb.npy", mmap_mode="r")
    pred = np.load(OUT / a.tag / "pred.npy")
    local = OUT / a.tag / "gt.npy"
    gt = np.load(local if local.exists() else OUT / f"gt_val_{meta['domain']}.npy")
    N = pred.shape[0]
    variants = {"逐期原读法": None}
    for tau in (0.5, 0.6, 0.7):
        for c in (0.0, 1.0):
            for dl in (0.0, 0.7):
                variants[f"τ={tau},c={c},δ={dl}"] = (tau, c, dl)
    mets = {k: adapter.SCDMetric(num_classes=2, class_names=["not building", "building"], ignore_index=2) for k in variants}
    rich = {k: RichSCDAccumulator(2) for k in variants}
    for i in range(N):
        g = gt[i].astype(np.int64)
        p_blk = np.asarray(pb[i], dtype=np.float32)
        for name, spec in variants.items():
            if spec is None:
                p = ((pred[i][None] >> np.arange(T, dtype=np.uint8)[:, None, None]) & 1).astype(np.int64)
            else:
                p = decode_block(p_blk, spec[0], spec[1], a.ws, spec[2]).astype(np.int64)
            mets[name].update(torch.from_numpy(p)[None], torch.from_numpy(g)[None])
            rich[name].update(p[None], g[None])
        if (i + 1) % 160 == 0 or i + 1 == N:
            print(f"{i + 1}/{N}", flush=True)
    rows = {}
    for name in variants:
        s = {k: float(v) for k, v in mets[name].compute().items()}
        r = rich[name].compute(include_per_aoi=False)
        rows[name] = {"miou": s["miou"], "bc": s["bc"], "sc": s["sc"], "scs": s["scs"], "strict_f1": r["strict_f1"],
                      "recall": r["recall"], "stable_fpr": r["stable_fpr"], "alarm_ratio": r["alarms"] / max(r["true_changes"], 1)}
    print("读法\tmIoU\tBC\tSC\tSCS\t严格F1\t召回\t稳定误报\t报警倍数")
    for name, r in rows.items():
        print(name + "\t" + "\t".join(f"{r[k]:.2f}" for k in ("miou", "bc", "sc", "scs", "strict_f1", "recall", "stable_fpr", "alarm_ratio")))
    name = "footprint" + ("_ws" if a.ws else "") + ("_nodemo" if a.nodemo else "") + ".json"
    (OUT / a.tag / name).write_text(json.dumps(rows, ensure_ascii=False, indent=1), "utf-8")


if __name__ == "__main__":
    main()
