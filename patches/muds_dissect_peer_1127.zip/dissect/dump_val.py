# -*- coding: utf-8 -*-
"""MUDS 验证集逐像元导出（11-27，错题拆解用；只读验证集，不碰测试集）。

对一个权重：在它自己的域（best_in → 同区验证 80 块；best_out → 跨区验证 640 块）上逐块推理，保存
  pred.npy        uint8 [N,H,W]   第 t 位 = 第 t 期判为建筑
  pb.npy          float16 [N,T,H,W]  官方输出（新方法为时间链后验边际，骨干为 softmax）里“建筑”的概率
  新方法另存 unary.npy / psi.npy / ctx.npy（链前一元分数、成对势、骨干分数，float16），供零训练解码检验
  gt.npy          uint8 [N,T,H,W]  标签（0 非建筑 / 1 建筑 / 2 忽略），同一域只存一次
  meta.json       权重、轮次、SHA256、按官方 SCDMetric 与 RichSCD 重算的验证成绩
入口、数据类、模型构建全部用 MUDS 配对包 runtime（与甲乙训练同一份代码）。
用法：python dump_val.py --method m3|pse --weights <best_xx_epNNN.pth> --domain in|out --tag <名字> [--limit 块数]"""
import os
import argparse
import hashlib
import json
import sys
import time
from functools import lru_cache
from pathlib import Path

import numpy as np

RT = Path(os.environ.get("MUDS_RT", r"D:\Railway_project\work\公开数据_1102\scripts\muds_m3_1126\runtime"))
DATA = Path(os.environ.get("MUDS_DATA", r"D:\sitsscd_data\Muds"))
OUT = Path(os.environ.get("DISSECT_OUT", r"D:\Railway_project\work\公开数据_1102\runs_muds_dissect_1127"))
sys.path.insert(0, str(RT))

import torch  # noqa: E402
import train_muds as TM  # noqa: E402


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(2**20), b""):
            h.update(b)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--method", choices=("m3", "pse"), required=True)
    ap.add_argument("--weights", required=True)
    ap.add_argument("--domain", choices=("in", "out"), required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--device", default="cuda:0")
    a = ap.parse_args()
    torch.set_num_threads(2)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    dev = torch.device(a.device)
    if dev.type == "cuda":
        torch.cuda.set_per_process_memory_fraction(0.15, dev)
    adapter, cfg = TM.setup(argparse.Namespace(data=DATA, cache=None, seed=42, device=a.device))
    model = TM.build(adapter, cfg, a.method)
    st = torch.load(a.weights, map_location="cpu", weights_only=True)
    model.load_state_dict(st["model"], strict=True)
    model = model.to(dev).eval()
    ds = adapter.make_set(cfg, "val", domain_shift=a.domain == "out", cache=False)
    assert len(ds) == (640 if a.domain == "out" else 80)
    raw = lru_cache(maxsize=1)(ds.load_data)
    ds.load_data = lambda k, tile, months, path: raw(k, tile, tuple(months), path)
    n = a.limit or len(ds)
    out = OUT / a.tag
    out.mkdir(parents=True, exist_ok=True)
    gt_path = OUT / f"gt_val_{a.domain}.npy"
    T, H, W = 8, 128, 128
    pred = np.zeros((n, H, W), np.uint8)
    pb = np.zeros((n, T, H, W), np.float16)
    extra = {}
    if a.method == "m3":
        extra = {"unary": np.zeros((n, T, 2, H, W), np.float16), "psi": np.zeros((n, T - 1, 2, 2, H, W), np.float16),
                 "ctx": np.zeros((n, T, 2, H, W), np.float16)}
    gts = np.zeros((n, T, H, W), np.uint8)
    areas = []
    metric = adapter.SCDMetric(num_classes=2, class_names=["not building", "building"], ignore_index=2)
    from train_snt import RichSCDAccumulator
    rich = RichSCDAccumulator(2)
    t0 = time.monotonic()
    with torch.inference_mode():
        for i in range(n):
            item = ds[i]
            x = item["data"].unsqueeze(0).to(dev)
            pos = item["positions"].unsqueeze(0).to(dev)
            gt = item["gt"].unsqueeze(0)
            logits = model(x, pos)
            p = logits.argmax(2).cpu()
            metric.update(p, gt)
            rich.update(p.numpy(), gt.numpy())
            prob = torch.softmax(logits.float(), dim=2)[0, :, 1]  # 新方法输出是对数边际，softmax 等于原值
            pb[i] = prob.cpu().numpy().astype(np.float16)
            bits = (p[0].numpy().astype(np.uint8) << np.arange(T, dtype=np.uint8)[:, None, None]).sum(0)
            pred[i] = bits.astype(np.uint8)
            gts[i] = gt[0].numpy().astype(np.uint8)
            areas.append(ds.sits_ids[int(item["idx"])])
            if a.method == "m3":
                aux = model.last_aux
                extra["unary"][i] = aux["head"]["unary"][0].float().cpu().numpy().astype(np.float16)
                extra["psi"][i] = aux["head"]["psi"][0].float().cpu().numpy().astype(np.float16)
                extra["ctx"][i] = aux["u_ctx"][0].float().cpu().numpy().astype(np.float16)
            if i == 0 or (i + 1) % 80 == 0 or i + 1 == n:
                print(f"{a.tag} {a.domain} {i + 1}/{n} 块 {time.monotonic() - t0:.0f} 秒", flush=True)
    np.save(out / "pred.npy", pred)
    np.save(out / "pb.npy", pb)
    for k, v in extra.items():
        np.save(out / f"{k}.npy", v)
    if a.limit:
        np.save(out / "gt.npy", gts)  # 试跑只存在本 tag 目录
    elif not gt_path.exists():
        np.save(gt_path, gts)
        (OUT / f"areas_val_{a.domain}.json").write_text(json.dumps(areas), "utf-8")
    else:
        assert np.array_equal(np.load(gt_path), gts), "同一域的标签与已存的不一致"
    scores = {k: float(v) for k, v in metric.compute().items()}
    diag = rich.compute(include_per_aoi=False)
    meta = {"method": a.method, "domain": a.domain, "weights": str(a.weights), "weights_sha256": sha(a.weights),
            "epoch": int(st["epoch"]), "blocks": n, "official_val": scores,
            "rich_val": {k: (float(v) if isinstance(v, (int, float, np.floating, np.integer)) else v) for k, v in diag.items() if not isinstance(v, (list, dict))},
            "torch": str(torch.__version__), "seconds": time.monotonic() - t0}
    (out / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), "utf-8")
    print(a.tag, a.domain, "验证", {k: round(scores[k], 2) for k in ("miou", "bc", "sc", "scs")}, flush=True)


if __name__ == "__main__":
    main()
