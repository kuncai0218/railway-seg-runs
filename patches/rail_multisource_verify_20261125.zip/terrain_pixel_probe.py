"""Measure terrain ranking among candidates at comparable frozen optical scores."""
import argparse
from hashlib import sha256
from pathlib import Path
from time import perf_counter

import numpy as np
import torch
from torch import nn

from fusion_worker import indices, mean_scale, read, write


FOLDS = ("r3_2023a", "r3_2023b")
VARIANTS = ("aligned", "shifted", "within_scene_shuffle")
EDGES = np.array([.10, .20, .30, .35, .40, .45, .50, .55, .60, .65, .70, .80, .90])


def cells(groups):
    order = np.argsort(groups, kind="stable")
    ends = np.flatnonzero(np.diff(groups[order])) + 1
    return np.split(order, ends) if len(order) else []


def load_role(path, groups):
    with np.load(path) as data:
        x = data["x"]
        result = {
            "y": data["y"], "scene": data["scene"].astype(np.int64),
            "anchor": data["anchor"].astype(np.float32),
            "aligned": x[:, groups["terrain"]].astype(np.float32),
            "shifted": x[:, groups["wrong_terrain"]].astype(np.float32),
        }
    result["common"] = (
        np.isfinite(result["aligned"]).all(axis=1)
        & np.isfinite(result["shifted"]).all(axis=1)
        & np.isin(result["y"], (0, 1))
    )
    result["cell"] = result["scene"] * (len(EDGES) + 1) + np.searchsorted(EDGES, result["anchor"], side="right")
    return result


def within_scene_shuffle(role, seed):
    rng = np.random.default_rng(seed)
    valid = np.flatnonzero(role["common"])
    output = role["aligned"].copy()
    for group in cells(role["cell"][valid]):
        src = valid[group]
        output[src] = role["aligned"][rng.permutation(src)]
    return output


def rank_auc(score, label):
    pos = score[label == 1]
    neg = np.sort(score[label == 0])
    return float(
        (np.searchsorted(neg, pos, "left") + np.searchsorted(neg, pos, "right")).sum()
        / (2 * len(neg) * len(pos))
    )


def ranking(score, role, margin, condition):
    mask = role["common"].copy()
    if margin:
        mask &= (role["anchor"] >= .35) & (role["anchor"] < .65)
    by = role["cell"] if condition else role["scene"]
    y, order, scene = role["y"][mask], score[mask], role["scene"][mask]
    per_scene = {}
    positive, negative, number_of_cells, matched = 0, 0, 0, 0.0
    for group in cells(by[mask]):
        p = int(y[group].sum())
        n = len(group) - p
        if not p or not n:
            continue
        auc = rank_auc(order[group], y[group])
        entry = per_scene.setdefault(int(scene[group[0]]), {"positive": 0, "negative": 0, "auc_sum": 0.0})
        entry["positive"] += p
        entry["negative"] += n
        entry["auc_sum"] += p * auc
        matched += p * auc
        positive += p
        negative += n
        number_of_cells += 1
    for entry in per_scene.values():
        entry["auc"] = entry.pop("auc_sum") / entry["positive"]
    return {
        "auc": matched / positive if positive else None,
        "scene_macro_auc": float(np.mean([s["auc"] for s in per_scene.values()])) if per_scene else None,
        "matched_positive": positive, "matched_negative": negative, "cells": number_of_cells,
        "available_positive": int(y.sum()), "available_negative": int(len(y) - y.sum()),
        "scenes": per_scene,
    }


def report_scores(score, role):
    return {
        "same_scene": ranking(score, role, margin=False, condition=False),
        "same_scene_and_anchor_bin": ranking(score, role, margin=False, condition=True),
        "near_threshold_same_scene_and_anchor_bin": ranking(score, role, margin=True, condition=True),
    }


def fit(train, train_x, val_x, args, seed):
    start = perf_counter()
    torch.manual_seed(seed)
    x = train_x[train["common"]]
    m, s = mean_scale(x)
    x = torch.as_tensor(((x - m) / s).clip(-8, 8), device=args.device)
    y = torch.as_tensor(train["y"][train["common"]], dtype=torch.float32, device=args.device)
    model = nn.Sequential(nn.Linear(x.shape[1], 24), nn.SiLU(), nn.Linear(24, 1)).to(args.device)
    opt = torch.optim.AdamW(model.parameters(), lr=.002, weight_decay=.002)
    num_positive = y.sum().item()
    assert 0 < num_positive < len(y)
    positive_weight = y.new_tensor((len(y) - num_positive) / num_positive)
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=positive_weight)
    steps = 0
    for _ in range(args.epochs):
        for i in torch.randperm(len(y), device=args.device).split(8192):
            opt.zero_grad(set_to_none=True)
            loss = loss_fn(model(x[i]).squeeze(1), y[i])
            loss.backward()
            opt.step()
            steps += 1
    model.eval()
    with torch.inference_mode():
        scaled = np.nan_to_num(((val_x - m) / s).clip(-8, 8))
        scores = [model(chunk).squeeze(1).cpu().numpy()
                  for chunk in torch.as_tensor(scaled, device=args.device).split(8192)]
    result = np.concatenate(scores)
    if not np.isfinite(result).all():
        raise ValueError("Non-finite validation score")
    return result, steps, perf_counter() - start


def main(args):
    if args.device == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA is unavailable")
        torch.cuda.set_per_process_memory_fraction(args.memory_fraction)
    schema = read(args.data / "schema.json")
    groups = indices(schema["bands"])
    output = {
        "scope": "Common candidate pixels in development folds. Anchor scores frozen. No test data.",
        "endpoint": "Near-threshold AUC within each scene and fixed anchor score bin, averaged by eligible positive count.",
        "anchor_window": [.35, .65], "anchor_bin_edges": EDGES.tolist(), "seeds": args.seeds,
        "epochs": args.epochs, "device": torch.cuda.get_device_name() if args.device == "cuda" else args.device,
        "torch_version": torch.__version__, "folds": {}, "input_sha256": {},
    }
    for fold in FOLDS:
        roles = []
        for split in ("train", "val"):
            path = args.data / f"{fold}_{split}.npz"
            checksum = sha256()
            with path.open("rb") as stream:
                for block in iter(lambda: stream.read(1 << 20), b""):
                    checksum.update(block)
            digest = checksum.hexdigest()
            if digest != schema["sha256"][path.name]:
                raise ValueError(f"SHA256 mismatch: {path.name}")
            output["input_sha256"][path.name] = digest
            roles.append(load_role(path, groups))
        train, val = roles
        fold_output = {"archive": report_scores(val["anchor"], val), "fits": []}
        for seed in args.seeds:
            train["within_scene_shuffle"] = within_scene_shuffle(train, 2 * seed)
            val["within_scene_shuffle"] = within_scene_shuffle(val, 2 * seed + 1)
            for variant in VARIANTS:
                scores, steps, elapsed = fit(train, train[variant], val[variant], args, seed)
                results = report_scores(scores, val)
                fold_output["fits"].append({
                    "variant": variant, "seed": seed, "steps": steps, "seconds": elapsed,
                    "scores": results,
                })
                print(fold, variant, seed, steps, results["near_threshold_same_scene_and_anchor_bin"]["auc"], flush=True)
        output["folds"][fold] = fold_output
        write(args.output, output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seeds", nargs="+", type=int, default=[17, 73, 127])
    parser.add_argument("--epochs", type=int, default=14)
    parser.add_argument("--device", choices=("cuda", "cpu"), default="cuda")
    parser.add_argument("--memory-fraction", type=float, default=.12)
    options = parser.parse_args()
    if options.output.exists():
        parser.error(f"Output already exists: {options.output}")
    if options.epochs < 1 or not 0 < options.memory_fraction <= 1:
        parser.error("Epochs must be positive and memory fraction must be in (0, 1]")
    main(options)
