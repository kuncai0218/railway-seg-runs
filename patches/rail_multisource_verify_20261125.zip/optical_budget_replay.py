"""Replay fixed optical checkpoints at the archived development false-alarm budget."""
import argparse
from pathlib import Path

import numpy as np
import torch

from fusion_worker import Adapter, indices, infer, load_pack, metric, read, write


FOLDS = ("r3_2023a", "r3_2023b")


def validation_counts(pred, data):
    truth = data["y"] == 1
    original = data["anchor"] >= .5
    scene = data["scene"]
    positive_total = len(data["outside"])
    gained = np.bincount(scene[pred & ~original & truth], minlength=positive_total)
    lost = np.bincount(scene[~pred & original & truth], minlength=positive_total)
    true_positive = np.bincount(scene[pred & truth], minlength=positive_total)
    false_positive = np.bincount(scene[pred & ~truth], minlength=positive_total)
    false_negative = np.bincount(scene[~pred & truth], minlength=positive_total) + data["outside"][:, 0]
    counts = np.column_stack((true_positive, false_positive, false_negative))
    real_negative = int(data["negatives"][:, 0].sum())
    return {**metric(*map(int, counts.sum(axis=0)), real_negative),
            "gained_tp": int(gained.sum()), "lost_tp": int(lost.sum()), "scene_counts": counts.tolist(),
            "scene_gained_tp": gained.tolist(), "scene_lost_tp": lost.tolist()}


def pool(rows):
    summary = metric(*(sum(r[k] for r in rows) for k in ("tp", "fp", "fn", "negative")))
    summary.update({k: sum(r[k] for r in rows) for k in ("gained_tp", "lost_tp")})
    return summary


def main(args):
    torch.set_float32_matmul_precision("high")
    torch.cuda.set_per_process_memory_fraction(.12)
    schema = read(args.data / "schema.json")
    groups = indices(schema["bands"])
    supplied = dict(args.checkpoint)
    evaluated = {seed: {} for seed in supplied}
    original = {}
    for fold in FOLDS:
        _, _, norm = load_pack(args.data, fold + "_train", groups)
        valid, scores_data, _ = load_pack(args.data, fold + "_val", groups, norm)
        original[fold] = validation_counts(scores_data["anchor"] >= .5, scores_data)
        for seed, path in supplied.items():
            stem = f"{fold}_optical_context_s{seed}_e14_m1.60"
            trained = torch.load(path / (stem + ".pt"), map_location="cuda", weights_only=True)
            model = Adapter("optical_context", groups, 1.6).cuda().eval()
            if trained["epoch"] != 14 or trained["arm"] != "optical_context":
                raise ValueError(f"Unexpected checkpoint: {path / stem}")
            model.load_state_dict(trained["model"])
            scores = infer(model, valid)
            at_050 = validation_counts(scores >= .5, scores_data)
            saved = read(path / (stem + ".metrics.json"))["strata"]["all"]
            if any(at_050[key] != saved[key] for key in ("tp", "fp", "fn")):
                raise ValueError(f"Saved TP/FP/FN mismatch: {path / stem}")
            evaluated[seed][fold] = scores, scores_data, at_050
    reference = pool(list(original.values()))
    result = {"scope": "Budget oracle on two development folds with a common cutoff. No test data or deployment threshold.",
              "archive": reference, "archive_folds": original, "seeds": {}}
    for seed, by_fold in evaluated.items():
        negative_scores = np.concatenate([s[d["y"] == 0] for s, d, _ in by_fold.values()])
        position = len(negative_scores) - reference["fp"] - 1
        cut = float(np.partition(negative_scores, position)[position]) if position >= 0 else -1.0
        at_budget = {key: validation_counts(s > cut, d) for key, (s, d, _) in by_fold.items()}
        pooled = pool(list(at_budget.values()))
        if pooled["fp"] > reference["fp"]:
            raise ValueError("Replay exceeded the false-alarm budget")
        result["seeds"][seed] = {"strict_cutoff": cut, "at_050": pool([r[2] for r in by_fold.values()]),
                                 "matched_budget": pooled, "matched_budget_folds": at_budget}
        print(seed, {k: pooled[k] for k in ("tp", "fp", "fn", "gained_tp", "lost_tp")}, flush=True)
    write(args.output, result)


def checkpoint(value):
    seed, path = value.split("=", 1)
    return int(seed), Path(path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--checkpoint", action="append", type=checkpoint, required=True, metavar="SEED=DIR")
    parser.add_argument("--output", type=Path, required=True)
    options = parser.parse_args()
    if options.output.exists():
        parser.error(f"Output already exists: {options.output}")
    main(options)
