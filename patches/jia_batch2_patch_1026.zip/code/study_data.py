from pathlib import Path
import json
import os
import numpy as np

ROOT = Path(os.environ.get('RAIL_FRONTIER_ROOT', Path(__file__).resolve().parent))
RGB = [3, 2, 1]
# 辅助数据分组（22 层中的位置）：多年统计 7 层（水体频率、NDVI 10/50/90 分位、BSI 中位、耕作周期、观测期数）、往年同期偏离 7 层、地形 5 层、当期无云比例；20、21 层是两组的观测期数副本
AUX_GROUPS = {'multiyear': [0, 1, 2, 3, 4, 5, 6, 20], 'hist': [7, 8, 9, 10, 11, 12, 13, 21],
              'terrain': [14, 15, 16, 17, 18], 'clear': [19]}


class CausalView:
    def __init__(self, base, mode, before=None):
        self.base, self.mode = base, mode
        self.aux = None
        if mode.startswith('aux'):   # 10-26 第二批：辅助层由 inputs_f16 的第 12—30 层现算（与 10-18 的 aux_f16.npy 逐值相同），可只保留部分组
            self.clouds = np.load(ROOT / 'assets/clouds_u8.npy', mmap_mode='r')
            self.before = np.asarray(before, bool)
            groups = mode.split('-', 1)[1].split('+') if '-' in mode else list(AUX_GROUPS)
            assert all(g in AUX_GROUPS for g in groups), f'未知的辅助组 {groups}，可选 {list(AUX_GROUPS)}'
            self.keep = np.zeros(22, np.float32)
            for g in groups:
                self.keep[AUX_GROUPS[g]] = 1
        if mode == 'temporal':
            self.clouds = np.load(ROOT / 'assets/clouds_u8.npy', mmap_mode='r')
            self.frames = json.loads((ROOT / 'assets/temporal.json').read_text('utf-8'))
        self.channels = 34 if mode.startswith('aux') else {'bands': 12, 'rgb': 3, 'temporal': 56}[mode]
        self.shape = (480, self.channels, 256, 256)

    def __getitem__(self, key):
        i, channels, *slices = key
        r, c = slices if slices else (slice(None), slice(None))
        if self.mode == 'bands':
            return np.asarray(self.base[i, :12, r, c], np.float32)[channels]
        if self.mode == 'rgb':   # 10-26 同学包：只用红、绿、蓝（B4、B3、B2）
            return np.asarray(self.base[i, :12, r, c], np.float32)[RGB][channels]
        if self.mode.startswith('aux'):
            x = np.asarray(self.base[i, :, r, c], np.float32)
            a = np.empty((22,) + x.shape[1:], np.float32)
            a[:19] = x[12:31]
            if self.before[i]:          # 前期影像不用往年同期组（其中含后期影像的偏离特征）
                a[7:14] = 0
            a[19] = 1 - np.asarray(self.clouds[i, r, c], np.float32)
            a[20] = a[6]; a[21] = a[13]
            a *= self.keep[:, None, None]
            return np.concatenate([x[:12], a], 0)[channels]
        row = self.frames[i]
        blocks = []
        for j, valid, days in zip(row['indices'], row['valid'], row['days']):
            image = np.asarray(self.base[j, :12, r, c], np.float32)
            good = (1 - self.clouds[j, r, c]).astype(np.float32) * valid
            age = np.full_like(good, np.log1p(days) / np.log(182))
            blocks += [image, good[None], age[None]]
        return np.concatenate(blocks, 0)[channels]


def load_data(path, mode):
    base = np.load(path / 'inputs_f16.npy', mmap_mode='r')
    Y = np.load(path / 'labels_u8.npy', mmap_mode='r')
    keys = [tuple(k) for k in json.loads((path / 'index.json').read_text('utf-8'))['keys']]
    splits = json.loads((path / 'splits_periods.json').read_text('utf-8'))
    norm = json.loads((path / 'norm.json').read_text('utf-8'))
    assert base.shape == (480, 31, 256, 256) and Y.shape == (480, 256, 256)
    ix = json.loads((path / 'index.json').read_text('utf-8'))
    X = CausalView(base, mode, [w == 'before' for _, w in ix['src']])
    mean = np.asarray(norm['mean'][:12], np.float32)
    std = np.asarray(norm['std'][:12], np.float32)
    mean[RGB] = [.485, .456, .406]
    std[RGB] = [.229, .224, .225]
    if mode == 'rgb':
        mean, std = mean[RGB].copy(), std[RGB].copy()
    if mode.startswith('aux'):
        mean = np.r_[mean, np.zeros(22, np.float32)]
        std = np.r_[std, np.ones(22, np.float32)]
    elif mode == 'temporal':
        mean = np.tile(np.r_[mean, np.zeros(2, np.float32)], 4)
        std = np.tile(np.r_[std, np.ones(2, np.float32)], 4)
    return X, Y, keys, splits, list(range(X.channels)), mean, std
