"""SwinV2 encoder + U-Net decoder and matched controls on frozen c22 data.

10-26（Claude，同学分割实验包）：加 --amp fp16（GradScaler，供不支持 bf16 的 Titan RTX）、--accum 梯度累积、
--eval-every 在交叉拟合半期（A/B）的预测期上定期评 mIoU 并写 curve.json（训练曲线，只用来看是否训到头，不用于选检查点）、--input rgb。其余不变。

Same 480 periods, five classes and annual full/A/B splits as seg_multi_1017.
128/256 crops are separate configurations. Existing labels stay read-only.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import math
import os
import random
import time
import traceback
import numpy as np
import torch
import torch.nn.functional as F
from study_models import build, RGB, sha256
import study_data
from state_io import atomic_json

ROOT = Path(os.environ.get('RAIL_FRONTIER_ROOT', Path(__file__).resolve().parent))
DEFAULT_DATA = ROOT.parent / 'train_cd_20261005/口径统一_1008/本机_1009/分割后检测_1014/多分割方法_1017'
NC = 5
CUSTOM = None


def now():
    return datetime.datetime.now().astimezone().isoformat()


def write_json(path, obj):
    atomic_json(path,obj)


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def load_data(path, input_mode):
    return study_data.load_data(path, input_mode)


def indices_for_part(keys, splits, fold, part):
    lookup = {k: i for i, k in enumerate(keys)}
    if CUSTOM is not None:
        plan = CUSTOM[fold][part]
        tr = [lookup[tuple(k)] for k in plan['train']]
        pr = [lookup[tuple(k)] for k in plan['predict']]
        assert tr and pr and not set(tr) & set(pr)
        return tr, pr
    dev = [lookup[tuple(k)] for k in splits[fold]['dev']]
    test = [lookup[tuple(k)] for k in splits[fold]['test']]
    assert not set(dev) & set(test)
    if part == 'full':
        return dev, test
    half = lambda i: (int(keys[i][1][:4]) * 4 + (int(keys[i][1][5:7]) - 1) // 3) % 2
    h = 0 if part == 'A' else 1
    tr = [i for i in dev if half(i) == h]
    pr = [i for i in dev if half(i) != h]
    assert not set(tr) & set(pr)
    return tr, pr


def outputs(value):
    if isinstance(value, tuple):
        if len(value) != 2:
            raise ValueError('Unexpected auxiliary-head output')
        return value[0], value[1]
    if not isinstance(value, torch.Tensor):
        raise TypeError(type(value))
    return value, None


AMP_DTYPE = {'bf16': torch.bfloat16, 'fp16': torch.float16}


def autocast(args):
    return torch.autocast('cuda', dtype=AMP_DTYPE.get(args.amp, torch.float32), enabled=args.amp in AMP_DTYPE)


def check_stop(out):
    if (ROOT / 'STOP_ALL').exists() or (out / 'STOP').exists():
        raise InterruptedError('Stopped at a checkpoint by the local stop flag')


def save_checkpoint(path, model, optimizer, step, rng, signature, finished=False, scaler=None):
    saved_names = {name for name, p in model.named_parameters() if p.requires_grad}
    saved_names.update(name for name, _ in model.named_buffers())
    # Keep the frozen 1.2GB DINO-L backbone once, identified by its verified hash,
    # instead of duplicating it in nine fold/part checkpoints.
    state = {name: value for name, value in model.state_dict().items() if name in saved_names}
    payload = dict(model=state, optimizer=optimizer.state_dict(),
                   format='trainable_parameters_and_buffers_v1',
                   step=step, numpy_rng=rng.bit_generator.state,
                   torch_rng=torch.get_rng_state(), cuda_rng=torch.cuda.get_rng_state_all(),
                   signature=signature, finished=finished, scaler=scaler.state_dict() if scaler is not None else None)
    tmp = path.with_suffix('.tmp')
    torch.save(payload, tmp)
    tmp.replace(path)


def metrics(cm):
    cm = np.asarray(cm, np.int64)
    tp = np.diag(cm)
    union = cm.sum(0) + cm.sum(1) - tp
    iou = tp / np.maximum(union, 1)
    have = cm.sum(1) > 0
    return dict(mIoU=float(iou[have].mean()) if have.any() else None,
                IoU=iou.tolist(), OA=float(tp.sum() / max(cm.sum(), 1)),
                confusion_matrix=cm.tolist(), valid_pixels=int(cm.sum()))


def curve_point(args, model, X, Y, keys, pr, channels, mean_t, std_t, partdir, step, skipped):
    """训练曲线：在本半期的预测期（另一半训练期）里等间隔取至多 eval_max 期，算 mIoU，追加到 curve.json"""
    ids = pr[::max(1, len(pr) // args.eval_max)][:args.eval_max]
    cm = np.zeros((NC, NC), np.int64)
    model.eval()
    for j in range(0, len(ids), args.predict_batch):
        sub = ids[j:j + args.predict_batch]
        xb = np.stack([np.asarray(X[i, channels], np.float32) for i in sub])
        xt = (torch.from_numpy(xb).cuda() - mean_t) / std_t
        with torch.inference_mode(), autocast(args):
            p = outputs(model(xt))[0].float().argmax(1).cpu().numpy()
        for k, i in enumerate(sub):
            y = np.asarray(Y[i]); good = y < NC
            cm += np.bincount(y[good].astype(np.int64) * NC + p[k][good], minlength=NC * NC).reshape(NC, NC)
    model.train()
    path = partdir / 'curve.json'
    curve = json.loads(path.read_text('utf-8')) if path.exists() else []
    point = dict(step=step, periods=len(ids), fp16_skipped_steps=skipped)
    point.update({k: v for k, v in metrics(cm).items() if k in ('mIoU', 'IoU', 'OA')})
    curve = [c for c in curve if c['step'] < step] + [point]
    write_json(path, curve)
    print('CURVE', partdir.parent.name, partdir.name, step, round(point['mIoU'], 4), flush=True)


def train_part(args, X, Y, keys, splits, channels, mean, std, fold, part, out):
    partdir = out / fold / ('state_' + part)
    partdir.mkdir(parents=True, exist_ok=True)
    marker = partdir / 'complete.json'
    if marker.exists():
        completed = json.loads(marker.read_text('utf-8'))
        if completed['signature'] != args.signature:
            raise ValueError('Completed part belongs to different training settings')
        print('ALREADY_COMPLETE', fold, part, flush=True)
        return completed
    check_stop(out)
    seed = args.seed + {'full': 7, 'A': 0, 'B': 1, 'AA': 11, 'AB': 12, 'BA': 21, 'BB': 22}[part]
    seed_everything(seed)
    rng = np.random.default_rng(seed)
    tr, pr = indices_for_part(keys, splits, fold, part)
    print(f'START {args.name} {fold} {part}: train={len(tr)} predict={len(pr)}', flush=True)
    model, source = build(args.arch, args.input, args.backbone, args.weights)
    model = model.cuda().train()
    torch.cuda.reset_peak_memory_stats()
    mean_t = torch.tensor(mean, device='cuda')[None, :, None, None]
    std_t = torch.tensor(std, device='cuda')[None, :, None, None]
    cnt = np.zeros(NC, np.int64)
    for i in tr:
        y = np.asarray(Y[i])
        cnt += np.bincount(y[y < NC], minlength=NC)
    class_weights = (cnt / max(cnt.sum(), 1) + 1e-6) ** -.5
    class_weights /= class_weights.mean()
    weight_t = torch.tensor(class_weights, dtype=torch.float32, device='cuda')
    groups = {'encoder': [], 'head': []}
    for name, parameter in model.named_parameters():
        if parameter.requires_grad:
            key = 'encoder' if name.startswith(('encoder.', 'backbone.')) else 'head'
            groups[key].append(parameter)
    # Frozen DINO + LoRA follows the authors' same-LR adapter recipe; full ResT
    # fine tuning uses a smaller encoder LR. Controls use one shared LR.
    encoder_scale = 1. if args.arch == 'unet_control' else .1
    optimizer = torch.optim.AdamW([
        {'params': groups['encoder'], 'lr': args.lr * encoder_scale, 'initial_lr': args.lr * encoder_scale},
        {'params': groups['head'], 'lr': args.lr, 'initial_lr': args.lr}], weight_decay=1e-4)
    scaler = torch.amp.GradScaler('cuda', enabled=args.amp == 'fp16')
    skipped = 0
    checkpoint = partdir / 'last.pt'
    step0 = 0
    if checkpoint.exists():
        previous = torch.load(checkpoint, map_location='cpu', weights_only=False)
        if previous['signature'] != args.signature:
            raise ValueError('Checkpoint settings do not match this run')
        incompat = model.load_state_dict(previous['model'], strict=False)
        learnable = {n for n, p in model.named_parameters() if p.requires_grad}
        if incompat.unexpected_keys or set(incompat.missing_keys) & learnable:
            raise ValueError('Trainable checkpoint tensors are missing or unexpected')
        optimizer.load_state_dict(previous['optimizer'])
        rng.bit_generator.state = previous['numpy_rng']
        torch.set_rng_state(previous['torch_rng'])
        torch.cuda.set_rng_state_all(previous['cuda_rng'])
        step0 = previous['step']
        if previous.get('scaler'):
            scaler.load_state_dict(previous['scaler'])
        del previous
        print('RESUME', step0, flush=True)
    write_json(partdir / 'method.json', {**source, 'time': now(),
               'class_weights': class_weights.tolist(), 'train_keys': [keys[i] for i in tr],
               'predict_keys': [keys[i] for i in pr], 'signature': args.signature,
               'normalization_mean': mean.tolist(), 'normalization_std': std.tolist()})
    start = time.monotonic()
    last_loss = None
    for step in range(step0, args.iters):
        if step % 100 == 0:
            check_stop(out)
        factor = min(1., (step + 1) / 100) * .5 * (1 + math.cos(math.pi * step / args.iters))
        for group in optimizer.param_groups:
            group['lr'] = group['initial_lr'] * factor
        optimizer.zero_grad(set_to_none=True)
        loss_sum = 0.
        for micro in range(args.accum):
            xb = np.empty((args.batch, len(channels), args.crop, args.crop), np.float32)
            yb = np.empty((args.batch, args.crop, args.crop), np.int64)
            for b in range(args.batch):
                for attempt in range(10):
                    i = int(rng.choice(tr))
                    r, c = rng.integers(0, 257 - args.crop, 2)
                    y = np.asarray(Y[i, r:r + args.crop, c:c + args.crop])
                    if (y < NC).mean() >= .2:
                        break
                x = np.asarray(X[i, channels, r:r + args.crop, c:c + args.crop], np.float32)
                k = int(rng.integers(4))
                x, y = np.rot90(x, k, (1, 2)), np.rot90(y, k)
                if rng.random() < .5:
                    x, y = x[:, :, ::-1], y[:, ::-1]
                xb[b], yb[b] = x, y
            xt = (torch.from_numpy(xb).cuda() - mean_t) / std_t
            yt = torch.from_numpy(yb).cuda()
            with autocast(args):
                logits, aux = outputs(model(xt))
                loss = F.cross_entropy(logits.float(), yt, weight=weight_t, ignore_index=255)
                if aux is not None:
                    loss = loss + args.aux_weight * F.cross_entropy(aux.float(), yt, weight=weight_t, ignore_index=255)
            if not torch.isfinite(loss):
                raise FloatingPointError(f'Nonfinite loss at step {step + 1}; no silent skip')
            scaler.scale(loss / args.accum).backward()
            loss_sum += float(loss.detach()) / args.accum
        scaler.unscale_(optimizer)
        norm = torch.nn.utils.clip_grad_norm_((p for p in model.parameters() if p.requires_grad), 5.)
        if not torch.isfinite(norm):
            if args.amp != 'fp16':
                raise FloatingPointError(f'Nonfinite gradients at step {step + 1}')
            skipped += 1            # fp16 时损失缩放偶尔溢出：GradScaler 跳过这一步并调小缩放系数，属正常现象
            if skipped > max(20, args.iters // 20):
                raise FloatingPointError(f'fp16 overflow skipped {skipped} steps (>5%); rerun with --amp off')
        scaler.step(optimizer)
        scaler.update()
        loss = torch.tensor(loss_sum)
        if (step + 1) % 100 == 0 or step == step0 or step + 1 == args.iters:
            last_loss = float(loss.detach())
            progress = dict(time=now(), name=args.name, fold=fold, part=part,
                           stage='training', step=step + 1, total=args.iters, loss=last_loss,
                           seconds_this_session=round(time.monotonic() - start, 1),
                           peak_gpu_gb=round(torch.cuda.max_memory_allocated() / 2**30, 3))
            write_json(out / 'progress.json', progress)
            print(json.dumps(progress, ensure_ascii=False), flush=True)
        if args.eval_every and part in ('A', 'B') and ((step + 1) % args.eval_every == 0 or step + 1 == args.iters):
            curve_point(args, model, X, Y, keys, pr, channels, mean_t, std_t, partdir, step + 1, skipped)
        if (step + 1) % args.checkpoint_every == 0 or step + 1 == args.iters:
            save_checkpoint(checkpoint, model, optimizer, step + 1, rng, args.signature, step + 1 == args.iters, scaler)
    del optimizer
    torch.cuda.empty_cache()
    model.eval()
    pred_dir = out / fold
    cm = np.zeros((NC, NC), np.int64)
    tag = 'full' if part == 'full' else 'cf'
    for batch_start in range(0, len(pr), args.predict_batch):
        check_stop(out)
        ids = pr[batch_start:batch_start + args.predict_batch]
        xb = np.stack([np.asarray(X[i, channels], np.float32) for i in ids])
        xt = (torch.from_numpy(xb).cuda() - mean_t) / std_t
        with torch.inference_mode(), autocast(args):
            logits, _ = outputs(model(xt))
            p = logits.float().softmax(1).cpu().numpy()
        if p.shape != (len(ids), NC, 256, 256) or not np.isfinite(p).all():
            raise ValueError('Invalid predicted probability tensor')
        for k, i in enumerate(ids):
            y = np.asarray(Y[i]); pred = p[k].argmax(0); good = y < NC
            cm += np.bincount(y[good].astype(np.int64) * NC + pred[good], minlength=NC * NC).reshape(NC, NC)
            filename = pred_dir / f'{keys[i][0]}_{keys[i][1]}.npz'
            tmp = filename.with_suffix('.tmp.npz')
            np.savez_compressed(tmp, p=p[k].astype(np.float16), src=tag)
            tmp.replace(filename)
        write_json(out / 'progress.json', dict(time=now(), name=args.name, fold=fold, part=part,
                   stage='predicting', predicted=min(batch_start + len(ids), len(pr)), total=len(pr)))
    complete = dict(time=now(), signature=args.signature, fold=fold, part=part,
                    trained_steps=args.iters, training_periods=len(tr), prediction_periods=len(pr),
                    last_loss=last_loss, seconds_this_session=round(time.monotonic() - start, 1),
                    peak_gpu_gb=round(torch.cuda.max_memory_allocated() / 2**30, 3), **metrics(cm))
    write_json(marker, complete)
    del model
    torch.cuda.empty_cache()
    print('PART_COMPLETE', fold, part, complete['mIoU'], flush=True)
    return complete


def verify_and_evaluate(out, keys, splits, fold, Y):
    lookup = {k: i for i, k in enumerate(keys)}
    expected = {tuple(k) for sub in ('dev', 'test') for k in splits[fold][sub]}
    actual = {p.stem for p in (out / fold).glob('*.npz')}
    if actual != {f'{k[0]}_{k[1]}' for k in expected}:
        raise ValueError(f'{fold}: missing/extra prediction files')
    result = {'fold': fold, 'probability_files': len(actual), 'verified': True}
    for sub, title in [('dev', 'development_crossfit'), ('test', 'test')]:
        cm = np.zeros((NC, NC), np.int64)
        for k in map(tuple, splits[fold][sub]):
            with np.load(out / fold / f'{k[0]}_{k[1]}.npz') as z:
                p = z['p'].astype(np.float32); tag = str(z['src'])
            if p.shape != (5, 256, 256) or not np.isfinite(p).all() or p.min() < 0 or p.max() > 1:
                raise ValueError(f'Invalid probabilities for {k}')
            if np.max(np.abs(p.sum(0) - 1)) > .005:
                raise ValueError(f'Probability sum differs from one for {k}')
            if tag != ('cf' if sub == 'dev' else 'full'):
                raise ValueError(f'Wrong full/crossfit source for {k}')
            y = np.asarray(Y[lookup[k]]); good = y < NC; pred = p.argmax(0)
            cm += np.bincount(y[good].astype(np.int64) * NC + pred[good], minlength=25).reshape(5, 5)
        result[title] = dict(periods=len(splits[fold][sub]), **metrics(cm))
    write_json(out / fold / 'evaluation.json', result)
    return result


def main():
    global CUSTOM
    parser = argparse.ArgumentParser()
    parser.add_argument('--arch', choices=['swin_upernet', 'swin_optical', 'unet_control', 'fusion_concat', 'fusion_gated', 'temporal_mean', 'temporal_attention', 'segman_s'], required=True)
    parser.add_argument('--name', required=True)
    parser.add_argument('--input', default='bands')   # bands / rgb / temporal / aux（全部辅助）/ aux-组+组（只保留这些组，例 aux-multiyear、aux-multiyear+terrain）
    parser.add_argument('--parts', default='full,A,B')
    parser.add_argument('--custom-parts', type=Path)
    parser.add_argument('--backbone', choices=['small', 'large_sat'], default='small')
    parser.add_argument('--data', type=Path, default=DEFAULT_DATA)
    parser.add_argument('--out', type=Path, default=ROOT / 'results')
    parser.add_argument('--weights', type=Path, default=ROOT / 'weights')
    parser.add_argument('--folds', default='temporal_chg')
    parser.add_argument('--iters', type=int, default=4000)
    parser.add_argument('--batch', type=int, default=8)
    parser.add_argument('--predict-batch', type=int, default=2)
    parser.add_argument('--crop', type=int, default=128)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--seed', type=int, default=20261017)
    parser.add_argument('--amp', choices=['bf16', 'fp16', 'off'], default='bf16')
    parser.add_argument('--accum', type=int, default=1)
    parser.add_argument('--eval-every', type=int, default=0)
    parser.add_argument('--eval-max', type=int, default=40)
    parser.add_argument('--aux-weight', type=float, default=.4)
    parser.add_argument('--checkpoint-every', type=int, default=500)
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    if args.custom_parts:
        CUSTOM = json.loads(args.custom_parts.read_text('utf-8'))
    if not torch.cuda.is_available():
        raise RuntimeError('A CUDA GPU is required; refusing silent CPU formal training')
    torch.set_num_threads(6)
    torch.backends.cudnn.benchmark = True
    torch.backends.cuda.matmul.allow_tf32 = True
    X, Y, keys, splits, channels, mean, std = load_data(args.data, args.input)
    settings = {k: v for k, v in vars(args).items() if k not in ('folds', 'parts', 'custom_parts', 'smoke', 'data', 'out', 'weights')}
    settings.update(data_files={n: sha256(args.data / n) for n in ['labels_u8.npy', 'index.json', 'splits_periods.json', 'norm.json']},
                    model_code_sha256=sha256(Path(__file__).with_name('study_models.py')),
                    data_code_sha256=sha256(Path(__file__).with_name('study_data.py')),
                    segman_bridge_sha256=sha256(Path(__file__).with_name('segman_bridge.py')) if args.arch=='segman_s' else None,
                    segman_provenance=json.loads((ROOT/'results/segman_compatibility_verified.json').read_text('utf-8')) if args.arch=='segman_s' and not args.smoke else None,
                    asset_provenance_sha256=sha256(ROOT / 'assets/provenance.json'),
                    custom_parts_sha256=sha256(args.custom_parts) if args.custom_parts else None,
                    trainer_sha256=sha256(Path(__file__)),
                    state_io_sha256=sha256(Path(__file__).with_name('state_io.py')),
                    encoder_weights=json.loads((args.weights / 'encoders.json').read_text('utf-8')),
                    runtime_versions={n: __import__(n).__version__ for n in ['torch', 'timm', 'segmentation_models_pytorch']},
                    patch_budget=args.iters * args.batch,
                    note='Development crossfit mIoU selects models; test is report-only. Agreement with c22 labels.')
    args.signature = hashlib.sha256(json.dumps(settings, sort_keys=True).encode()).hexdigest()
    out = args.out / ('pred_' + args.name)
    out.mkdir(parents=True, exist_ok=True)
    if args.smoke:
        seed_everything(args.seed)
        model, method = build(args.arch, args.input, args.backbone, args.weights)
        model = model.cuda().train()
        xt = torch.randn(args.batch, len(channels), args.crop, args.crop, device='cuda')
        yt = torch.randint(0, 5, (args.batch, args.crop, args.crop), device='cuda')
        yt[:, :4] = 255
        torch.cuda.reset_peak_memory_stats()
        optimizer = torch.optim.AdamW((p for p in model.parameters() if p.requires_grad), lr=args.lr)
        timing = time.monotonic()
        for step in range(3):
            optimizer.zero_grad(set_to_none=True)
            with autocast(args):
                logits, aux = outputs(model(xt))
                assert logits.shape == (args.batch, 5, args.crop, args.crop)
                loss = F.cross_entropy(logits.float(), yt, ignore_index=255)
                if aux is not None:
                    loss += .4 * F.cross_entropy(aux.float(), yt, ignore_index=255)
            assert torch.isfinite(loss)
            loss.backward()
            assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
            optimizer.step()
        model.eval()
        with torch.inference_mode(), autocast(args):
            prediction, _ = outputs(model(torch.randn(1, len(channels), 256, 256, device='cuda')))
        assert prediction.shape == (1, 5, 256, 256) and torch.isfinite(prediction).all()
        proof = dict(time=now(), synthetic_smoke_only=True, formal_training=False,
                     train_shape=list(logits.shape), prediction_shape=list(prediction.shape),
                     finite_loss=float(loss.detach()), finite_gradients=True,
                     seconds=round(time.monotonic() - timing, 2),
                     peak_gpu_gb=round(torch.cuda.max_memory_allocated() / 2**30, 3), **method)
        write_json(ROOT / 'results' / ('smoke_' + args.name + '.json'), proof)
        print(json.dumps(proof, ensure_ascii=False), flush=True)
        return
    runfile = out / 'run.json'
    if runfile.exists() and json.loads(runfile.read_text('utf-8'))['signature'] != args.signature:
        raise ValueError('Existing run differs: use a new name; never overwrite a previous experiment')
    write_json(runfile, dict(time=now(), signature=args.signature, settings=settings,
               data=str(args.data), device=torch.cuda.get_device_name(0), torch_version=torch.__version__))
    results = {}
    try:
        for fold in args.folds.split(','):
            assert fold in splits
            for part in args.parts.split(','):
                train_part(args, X, Y, keys, splits, channels, mean, std, fold, part, out)
            if CUSTOM is None and set(args.parts.split(',')) == {'full', 'A', 'B'}:
                results[fold] = verify_and_evaluate(out, keys, splits, fold, Y)
            elif CUSTOM is None:   # 10-26：试学习率只跑部分半期，不做全套核验
                results[fold] = dict(fold=fold, parts=args.parts, partial=True, probability_files=len(list((out / fold).glob('*.npz'))))
            else:
                expected = {tuple(k) for part in args.parts.split(',') for k in CUSTOM[fold][part]['predict']}
                mini = {fold: dict(dev=sorted(expected), test=[])}
                results[fold] = verify_and_evaluate(out, keys, mini, fold, Y)
                results[fold]['calibration_only'] = True
                write_json(out / fold / 'evaluation.json', results[fold])
        write_json(out / 'evaluation.json', dict(time=now(), signature=args.signature,
                   completed_folds=results, complete_requested_folds=True))
        write_json(out / 'progress.json', dict(time=now(), stage='complete', name=args.name,
                   folds=list(results), verified_probability_files=sum(r['probability_files'] for r in results.values())))
        print('FORMAL_COMPLETE', args.name, list(results), flush=True)
    except BaseException as exc:
        write_json(out / 'failure.json', dict(time=now(), name=args.name, error=str(exc), traceback=traceback.format_exc()))
        raise


if __name__ == '__main__':
    main()
