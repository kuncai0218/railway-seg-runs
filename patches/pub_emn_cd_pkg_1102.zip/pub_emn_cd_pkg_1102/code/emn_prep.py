"""EuroMineNet 预处理：按官方划分，把 2018—2024 年每年的影像、前 3 年历史统计、标签切成 160×160 窗口，
存成可内存映射的大 .npy（D 盘机械盘上顺序读）。

波段顺序按作者 10 波段：B2 B3 B4 B5 B6 B7 B8 B8A B11 B12（去 B1、B9、B10）。
历史统计：目标年 t 的前 3 年（t-3..t-1）的 NDVI、MNDWI、BSI 的均值、最小、最大，共 9 通道，量化到 uint8。
标签：0 非矿、1 矿；补边区域记 255（不参与训练和评价）。
"""
import csv
import os
import sys
import time

import numpy as np
import rasterio

ROOT = sys.argv[1] if len(sys.argv) > 1 else r"D:\Railway_project\work\公开数据_1102\EuroMineNet\EuroMineNet"
OUT = sys.argv[2] if len(sys.argv) > 2 else r"D:\Railway_project\work\公开数据_1102\emn_prep"
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # 实验包里自带 train_val_test_splits.py
sys.path.insert(1, r"D:\Railway_project\work\公开数据_1102\code\EuroMineNet-main\datasets")
from train_val_test_splits import train_val_test_splits as SPLITS  # noqa: E402  作者官方划分

EXCLUDED = {"Spain_4", "Sweden_6", "Poland_16"}  # 作者 preprocess.py 中排除
TARGET_YEARS = list(range(2018, 2025))
HIST_K = 3
P = 160
B2, B3, B4, B8, B11 = 0, 1, 2, 6, 8


def read(path):
    with rasterio.open(path) as r:
        return r.read()


def indices(img):
    x = img.astype(np.float32)
    eps = 1e-6
    ndvi = (x[B8] - x[B4]) / (x[B8] + x[B4] + eps)
    mndwi = (x[B3] - x[B11]) / (x[B3] + x[B11] + eps)
    bsi = ((x[B11] + x[B4]) - (x[B8] + x[B2])) / ((x[B11] + x[B4]) + (x[B8] + x[B2]) + eps)
    return np.clip(np.stack([ndvi, mndwi, bsi]), -1, 1)


def q8(v):
    return np.round((v + 1) * 127.5).astype(np.uint8)


def windows(n):
    """覆盖长度 n 的 160 窗口起点；末尾窗口向内对齐（与官方“除边缘外不重叠”一致）。"""
    if n <= P:
        return [0]
    s = list(range(0, n - P + 1, P))
    if s[-1] != n - P:
        s.append(n - P)
    return s


def pad(a, h, w, fill):
    if a.shape[-2] >= h and a.shape[-1] >= w:
        return a
    out = np.full(a.shape[:-2] + (max(h, a.shape[-2]), max(w, a.shape[-1])), fill, dtype=a.dtype)
    out[..., :a.shape[-2], :a.shape[-1]] = a
    return out


def site_windows(site):
    years = list(range(2015, 2025))
    imgs = {y: read(os.path.join(ROOT, site, "image", f"Year{y}.tif")) for y in years}
    labs = {y: (read(os.path.join(ROOT, site, "label", f"Year{y}.tif"))[0] > 0).astype(np.uint8) for y in years}
    h, w = labs[2020].shape
    idx = {y: indices(imgs[y]) for y in years}
    H, W = max(h, P), max(w, P)
    rows = []
    for t in TARGET_YEARS:
        hist = np.stack([idx[y] for y in range(t - HIST_K, t)])  # (3年, 3指数, h, w)
        hstat = np.concatenate([hist.mean(0), hist.min(0), hist.max(0)])  # 9 通道
        img = pad(imgs[t], H, W, 0)
        hs = pad(q8(hstat), H, W, 127)
        lab = pad(labs[t], H, W, 255)
        for y0 in windows(H):
            for x0 in windows(W):
                rows.append((t, y0, x0, img[:, y0:y0 + P, x0:x0 + P], hs[:, y0:y0 + P, x0:x0 + P],
                             lab[y0:y0 + P, x0:x0 + P]))
    return rows, (h, w)


def main():
    os.makedirs(OUT, exist_ok=True)
    t0 = time.time()
    for split in ("train", "val", "test"):
        sites = [s for s in dict.fromkeys(SPLITS[split]) if s not in EXCLUDED]
        # 先数窗口数，再按总数开内存映射文件顺序写
        counts = {}
        for s in sites:
            with rasterio.open(os.path.join(ROOT, s, "label", "Year2020.tif")) as r:
                h, w = r.height, r.width
            counts[s] = len(windows(max(h, P))) * len(windows(max(w, P))) * len(TARGET_YEARS)
        n = sum(counts.values())
        img_mm = np.lib.format.open_memmap(os.path.join(OUT, f"img_{split}.npy"), "w+", np.int16, (n, 10, P, P))
        hist_mm = np.lib.format.open_memmap(os.path.join(OUT, f"hist_{split}.npy"), "w+", np.uint8, (n, 9, P, P))
        lab_mm = np.lib.format.open_memmap(os.path.join(OUT, f"lab_{split}.npy"), "w+", np.uint8, (n, P, P))
        k = 0
        with open(os.path.join(OUT, f"meta_{split}.csv"), "w", newline="", encoding="utf-8") as f:
            wr = csv.writer(f)
            wr.writerow(["i", "site", "year", "y0", "x0", "site_h", "site_w"])
            for s in sites:
                rows, (h, w) = site_windows(s)
                for (t, y0, x0, im, hs, lb) in rows:
                    img_mm[k], hist_mm[k], lab_mm[k] = im, hs, lb
                    wr.writerow([k, s, t, y0, x0, h, w])
                    k += 1
                print(f"{split} {s} 窗口 {len(rows)} 累计 {k}/{n} {time.time() - t0:.0f}s", flush=True)
        img_mm.flush(); hist_mm.flush(); lab_mm.flush()
        del img_mm, hist_mm, lab_mm
        print(f"== {split} 完成：{n} 个样本（{len(sites)} 个矿区）", flush=True)


if __name__ == "__main__":
    main()
