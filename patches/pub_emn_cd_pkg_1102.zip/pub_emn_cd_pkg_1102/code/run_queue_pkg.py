"""实验包用的任务运行器（同学机器）：按任务文件依次训练，最多同时 N 个；已完成（有 done.json）的自动跳过；
每个任务训练完自动评价。运行记录写 results/logs/runner.log，汇总写 results/status.json。

用法（在实验包根目录）：
  python code/run_queue_pkg.py tasks/yi_emn_1102.json --data <预处理输出目录> --max 2
"""
import argparse
import json
import os
import subprocess
import sys
import time


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("task_file")
    ap.add_argument("--data", required=True)
    ap.add_argument("--max", type=int, default=2)
    a = ap.parse_args()
    root = os.getcwd()
    tasks = json.load(open(a.task_file, encoding="utf-8"))["jobs"]
    os.makedirs(os.path.join(root, "results", "logs"), exist_ok=True)
    runner_log = open(os.path.join(root, "results", "logs", "runner.log"), "a", encoding="utf-8")
    env = dict(os.environ, EMN_DATA=a.data, PYTHONIOENCODING="utf-8",
               TORCH_HOME=os.environ.get("TORCH_HOME", os.path.join(root, "weights")))

    def log(msg):
        line = time.strftime("%m-%d %H:%M:%S ") + msg
        print(line, flush=True); runner_log.write(line + "\n"); runner_log.flush()

    pending = [t for t in tasks if not os.path.exists(os.path.join(root, "results", t["id"], "done.json"))]
    log(f"任务文件 {a.task_file}：共 {len(tasks)} 个，待跑 {len(pending)} 个")
    running, status = {}, {}
    while pending or running:
        for jid, (p, t0) in list(running.items()):
            rc = p.poll()
            if rc is None:
                continue
            del running[jid]
            log(f"结束 {jid}，返回码 {rc}，{(time.time() - t0) / 60:.0f} 分钟")
            status[jid] = f"返回码 {rc}"
            if rc == 0:
                out = os.path.join(root, "results", jid)
                ev = next((t.get("eval", "emn_eval.py") for t in tasks if t["id"] == jid), "emn_eval.py")
                r = subprocess.run([sys.executable, "-X", "utf8", os.path.join(root, "code", ev), out],
                                   capture_output=True, text=True, encoding="utf-8", env=env)
                log(f"评价 {jid}：{(r.stdout or r.stderr).strip()[-300:]}")
        while pending and len(running) < a.max:
            t = pending.pop(0)
            out = os.path.join(root, "results", t["id"])
            os.makedirs(out, exist_ok=True)
            cmd = [sys.executable, "-X", "utf8", os.path.join(root, "code", t.get("script", "emn_train.py")),
                   "--data", a.data, "--out", out] + t["args"]
            p = subprocess.Popen(cmd, stdout=open(os.path.join(root, "results", "logs", t["id"] + ".log"), "a",
                                                  encoding="utf-8"), stderr=subprocess.STDOUT, env=env)
            running[t["id"]] = (p, time.time())
            status[t["id"]] = f"运行中 pid {p.pid}"
            log(f"开始 {t['id']}，pid {p.pid}")
        json.dump(status, open(os.path.join(root, "results", "status.json"), "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
        time.sleep(30)
    log("全部任务结束")


if __name__ == "__main__":
    main()
