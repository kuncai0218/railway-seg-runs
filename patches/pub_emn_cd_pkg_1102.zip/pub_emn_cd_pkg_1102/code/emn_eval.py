"""EuroMineNet 指标：把窗口概率拼回整幅矿区图，算逐年制图精度、两期稳定一致率、转移保持率、CA-TIoU、
分类后比较的变化 F1（相邻年份和各间隔），并按矿区给出可做配对自助抽样的计数。

用法：python emn_eval.py 运行目录 [模式 ...]   模式默认 img/hist；非对称用 "asym"（前一期 hist、后一期 nohist）。
"""
import csv
import json
import os
import sys
from collections import defaultdict

import numpy as np

DATA = os.environ.get("EMN_DATA", r"D:\Railway_project\work\公开数据_1102\emn_prep")
YEARS = list(range(2018, 2025))


def load_meta(split):
    rows = []
    with open(os.path.join(DATA, f"meta_{split}.csv"), encoding="utf-8") as f:
        for r in csv.DictReader(f):
            rows.append((int(r["i"]), r["site"], int(r["year"]), int(r["y0"]), int(r["x0"]),
                         int(r["site_h"]), int(r["site_w"])))
    return rows


def stitch(prob, lab, meta):
    """返回 {site: (P[年,h,w] 概率0-1, G[年,h,w] 0/1/255)}；重叠处概率取平均。"""
    by_site = defaultdict(list)
    for m in meta:
        by_site[m[1]].append(m)
    out = {}
    for site, ms in by_site.items():
        h, w = ms[0][5], ms[0][6]
        H, W = max(h, 160), max(w, 160)
        acc = np.zeros((len(YEARS), H, W), np.float32)
        cnt = np.zeros((len(YEARS), H, W), np.float32)
        G = np.full((len(YEARS), H, W), 255, np.uint8)
        for (i, _, t, y0, x0, _, _) in ms:
            k = YEARS.index(t)
            acc[k, y0:y0 + 160, x0:x0 + 160] += prob[i].astype(np.float32) / 255.0
            cnt[k, y0:y0 + 160, x0:x0 + 160] += 1
            G[k, y0:y0 + 160, x0:x0 + 160] = lab[i]
        P = acc / np.maximum(cnt, 1)
        out[site] = (P[:, :h, :w], G[:, :h, :w])
    return out


def pair_counts(p1, p2, g1, g2, thr=0.5):
    v = (g1 != 255) & (g2 != 255)
    b1, b2 = p1 >= thr, p2 >= thr
    gc = (g1 != g2) & v
    gu = (g1 == g2) & v
    pc = (b1 != b2) & v
    return {
        "chg": int(gc.sum()), "unc": int(gu.sum()),
        "tr": int((gc & pc).sum()),                                   # 转移保持
        "ctr": int((gc & (b1 == (g1 == 1)) & (b2 == (g2 == 1))).sum()),  # 两期都判对
        "stab": int((gu & ~pc).sum()),                                # 稳定一致
        "ca_num": int((b1 & b2 & gu).sum()), "ca_den": int(((b1 | b2) & gu).sum()),  # CA-TIoU
        "tp": int((gc & pc).sum()), "fp": int((pc & ~gc).sum()), "fn": int((gc & ~pc).sum()),
    }


def year_counts(p, g, thr=0.5):
    v = g != 255
    b = p >= thr
    gt = (g == 1) & v
    return {"tp": int((b & gt).sum()), "fp": int((b & ~gt & v).sum()), "fn": int((~b & gt).sum())}


def summarize(c):
    f1 = lambda tp, fp, fn: 2 * tp / max(1, 2 * tp + fp + fn)
    return {
        "转移保持率": c["tr"] / max(1, c["chg"]),
        "两期都判对": c["ctr"] / max(1, c["chg"]),
        "稳定一致率": c["stab"] / max(1, c["unc"]),
        "CA-TIoU": c["ca_num"] / max(1, c["ca_den"]),
        "变化F1": f1(c["tp"], c["fp"], c["fn"]),
        "变化精确率": c["tp"] / max(1, c["tp"] + c["fp"]),
        "变化召回率": c["tp"] / max(1, c["tp"] + c["fn"]),
    }


def mean_pairwise_ca(records):
    """Mean of date-pair ratios; undefined zero-union pairs are counted and excluded."""
    records = list(records)
    values = [r["ca_num"] / r["ca_den"] for r in records if r["ca_den"] > 0]
    return {"value": float(np.mean(values)) if values else None,
            "nonempty_pairs": len(values), "zero_union_pairs": len(records) - len(values)}


def evaluate(run_dir, split="test", mode1="img", mode2=None):
    mode2 = mode2 or mode1
    meta = load_meta(split)
    lab = np.load(os.path.join(DATA, f"lab_{split}.npy"), mmap_mode="r")
    p1 = np.load(os.path.join(run_dir, f"prob_{split}_{mode1}.npy"), mmap_mode="r")
    S1 = stitch(p1, lab, meta)
    S2 = S1 if mode2 == mode1 else stitch(np.load(os.path.join(run_dir, f"prob_{split}_{mode2}.npy"), mmap_mode="r"), lab, meta)
    per_site, tot_pair, tot_year = {}, defaultdict(int), defaultdict(int)
    gap_tot = defaultdict(lambda: defaultdict(int))
    date_pair_ca = defaultdict(lambda: defaultdict(int))
    for site in S1:
        P1, G = S1[site]
        P2, _ = S2[site]
        sp = defaultdict(int)
        for k in range(len(YEARS)):
            for kk, vv in year_counts(P1[k], G[k]).items():
                tot_year[kk] += vv
        for k in range(len(YEARS) - 1):          # 相邻年份：前一期用 mode1，后一期用 mode2
            c = pair_counts(P1[k], P2[k + 1], G[k], G[k + 1])
            for kk, vv in c.items():
                sp[kk] += vv; tot_pair[kk] += vv
        for k1 in range(len(YEARS)):             # 各间隔
            for k2 in range(k1 + 1, len(YEARS)):
                c = pair_counts(P1[k1], P2[k2], G[k1], G[k2])
                for kk in ("tp", "fp", "fn"):
                    gap_tot[k2 - k1][kk] += c[kk]
                pair = date_pair_ca[(YEARS[k1], YEARS[k2])]
                pair["ca_num"] += c["ca_num"]
                pair["ca_den"] += c["ca_den"]
        per_site[site] = dict(sp)
    f1 = lambda d: 2 * d["tp"] / max(1, 2 * d["tp"] + d["fp"] + d["fn"])
    res = {"相邻年份": summarize(tot_pair),
           "逐年制图": {"IoU": tot_year["tp"] / max(1, tot_year["tp"] + tot_year["fp"] + tot_year["fn"]),
                        "F1": f1(tot_year)},
           "各间隔变化F1": {g: f1(d) for g, d in sorted(gap_tot.items())},
           "像元数": {"变化": tot_pair["chg"], "未变": tot_pair["unc"]}}
    adjacent_ca = mean_pairwise_ca(r for (y1, y2), r in date_pair_ca.items() if y2 == y1 + 1)
    global_ca = mean_pairwise_ca(date_pair_ca.values())
    res["时间一致性补充"] = {
        "CA-TIoU_相邻微平均": res["相邻年份"]["CA-TIoU"],
        "LCA-TIoU_时间对宏平均": adjacent_ca,
        "GCA-TIoU_时间对宏平均": global_ca,
        "各日期对原始计数": {f"{a}-{b}": dict(v) for (a, b), v in sorted(date_pair_ca.items())},
    }
    res["评价协议"] = {
        "target_years": YEARS,
        "legacy_CA-TIoU": "sum numerators / sum denominators over sites and adjacent date pairs",
        "date_pair_macro": "pool pixels across sites within each date pair, then average date-pair ratios",
        "zero_union_policy": "exclude undefined pairs from macro mean and report their number; null if all undefined",
        "reference_equations": "https://arxiv.org/html/2510.14661v1#S3.SS4.SSS1",
        "full_decade_benchmark_comparison": "2018-2024 subset; do not directly rank against 2015-2024 results",
    }
    return res, per_site


if __name__ == "__main__":
    run = sys.argv[1]
    done = json.load(open(os.path.join(run, "done.json"), encoding="utf-8"))
    out, sites = {}, {}
    for m in done["modes"]:
        out[m], sites[m] = evaluate(run, "test", m, m)
    if "hist" in done["modes"] and "nohist" in done["modes"]:
        out["asym"], sites["asym"] = evaluate(run, "test", "hist", "nohist")
    json.dump(out, open(os.path.join(run, "eval_test.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(sites, open(os.path.join(run, "eval_test_sites.json"), "w", encoding="utf-8"), ensure_ascii=False)
    for m, r in out.items():
        a = r["相邻年份"]
        print(f"{os.path.basename(run)} {m}: IoU {r['逐年制图']['IoU']:.3f} 稳定一致 {a['稳定一致率']:.4f} "
              f"CA-TIoU {a['CA-TIoU']:.3f} 转移保持 {a['转移保持率']:.3f} 变化F1 {a['变化F1']:.3f}")
