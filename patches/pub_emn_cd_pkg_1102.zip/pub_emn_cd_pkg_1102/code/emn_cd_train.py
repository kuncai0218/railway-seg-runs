"""实验二：两期间隔漂移。EuroMineNet 同一窗口不同年份配对（2018—2024，间隔 1—6 年），孪生 U-Net 做二值变化检测。
训练方式：--gaps 指定训练用的间隔（如 1 / 5,6 / 1,2,3,4,5,6）；--cond 1 时把间隔（年）经 FiLM 调制解码器。
各配置训练步数相同（--steps）。训练后对验证、测试集每个间隔各存一份“变化 / 未变”概率直方图（256 档），
精确率、召回率、F1、AUROC、校准误差、最佳门槛、EM 先验校正都可由直方图精确算出（见 emn_cd_eval.py）。
"""
import argparse
import csv
import json
import os
import time
from collections import defaultdict

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from emn_train import AMP, MEAN, STD, Up, conv_bn_relu  # noqa: F401  同一份模型部件和归一化
import torchvision

R34_URL = "https://download.pytorch.org/models/resnet34-333f7ec4.pth"
YEARS = list(range(2018, 2025))


def pair_index(data, split):
    """同一矿区、同一窗口位置的不同年份配对：返回 {间隔: [(i1, i2), ...]}，i 为预处理数组下标。"""
    pos = {}
    with open(os.path.join(data, f"meta_{split}.csv"), encoding="utf-8") as f:
        for r in csv.DictReader(f):
            pos[(r["site"], int(r["y0"]), int(r["x0"]), int(r["year"]))] = int(r["i"])
    by_gap = defaultdict(list)
    keys = {(s, y, x) for (s, y, x, _) in pos}
    for (s, y, x) in sorted(keys):
        for a in YEARS:
            for b in YEARS:
                if b > a and (s, y, x, a) in pos and (s, y, x, b) in pos:
                    by_gap[b - a].append((pos[(s, y, x, a)], pos[(s, y, x, b)]))
    return by_gap


class PairDS(torch.utils.data.Dataset):
    def __init__(self, data, split, pairs, aug):
        self.data, self.split, self.pairs, self.aug = data, split, pairs, aug
        self.img = self.lab = None

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, k):
        if self.img is None:
            self.img = np.load(os.path.join(self.data, f"img_{self.split}.npy"), mmap_mode="r")
            self.lab = np.load(os.path.join(self.data, f"lab_{self.split}.npy"), mmap_mode="r")
        i1, i2, gap = self.pairs[k]
        x1 = (self.img[i1].astype(np.float32) - MEAN[:, None, None]) / STD[:, None, None]
        x2 = (self.img[i2].astype(np.float32) - MEAN[:, None, None]) / STD[:, None, None]
        g1, g2 = self.lab[i1], self.lab[i2]
        y = (g1 != g2).astype(np.int64)
        y[(g1 == 255) | (g2 == 255)] = 255
        if self.aug:
            r = np.random.randint(4)
            x1, x2, y = np.rot90(x1, r, (1, 2)), np.rot90(x2, r, (1, 2)), np.rot90(y, r, (0, 1))
            if np.random.rand() < 0.5:
                x1, x2, y = x1[:, :, ::-1], x2[:, :, ::-1], y[:, ::-1]
        t = lambda a: torch.from_numpy(np.ascontiguousarray(a))
        return t(x1), t(x2), t(y), gap


class FiLM(nn.Module):
    """按间隔（年）生成每个通道的缩放和平移；初始化为恒等。"""

    def __init__(self, ch):
        super().__init__()
        self.mlp = nn.Sequential(nn.Linear(1, 32), nn.ReLU(), nn.Linear(32, 2 * ch))
        nn.init.zeros_(self.mlp[2].weight); nn.init.zeros_(self.mlp[2].bias)

    def forward(self, x, gap):
        g, b = self.mlp(gap.float().view(-1, 1) / 6.0).chunk(2, 1)
        return x * (1 + g[:, :, None, None]) + b[:, :, None, None]


class SiamUNet(nn.Module):
    """孪生 U-Net：两期共享 ResNet-34 编码器，各级特征取差的绝对值后解码（FC-Siam-diff 的思路）。"""

    def __init__(self, cond=False):
        super().__init__()
        r = torchvision.models.resnet34(weights=None)
        r.load_state_dict(torch.hub.load_state_dict_from_url(R34_URL, progress=False))
        w = r.conv1.weight.data
        r.conv1 = nn.Conv2d(10, 64, 7, 2, 3, bias=False)
        r.conv1.weight.data = torch.stack([w[:, i % 3] for i in range(10)], 1) * 0.3
        self.stem, self.pool = nn.Sequential(r.conv1, r.bn1, r.relu), r.maxpool
        self.l1, self.l2, self.l3, self.l4 = r.layer1, r.layer2, r.layer3, r.layer4
        self.u4, self.u3 = Up(512, 256, 256), Up(256, 128, 128)
        self.u2, self.u1, self.u0 = Up(128, 64, 64), Up(64, 64, 32), Up(32, 0, 16)
        self.head = nn.Conv2d(16, 2, 3, padding=1)
        self.cond = cond
        if cond:
            self.f4, self.f3, self.f2 = FiLM(512), FiLM(256), FiLM(128)

    def enc(self, x):
        x0 = self.stem(x)
        x1 = self.l1(self.pool(x0))
        x2 = self.l2(x1)
        x3 = self.l3(x2)
        return x0, x1, x2, x3, self.l4(x3)

    def forward(self, a, b, gap=None):
        e = [torch.abs(p - q) for p, q in zip(self.enc(a), self.enc(b))]
        x0, x1, x2, x3, x4 = e
        if self.cond:
            x4, x3, x2 = self.f4(x4, gap), self.f3(x3, gap), self.f2(x2, gap)
        d = self.u0(self.u1(self.u2(self.u3(self.u4(x4, x3), x2), x1), x0))
        return self.head(d)


def histograms(model, data, split, by_gap, cond, bs=64):
    """每个间隔：变化像元、未变像元在 256 个概率档上的计数。"""
    pairs = [(i1, i2, g) for g, ps in sorted(by_gap.items()) for (i1, i2) in ps]
    dl = torch.utils.data.DataLoader(PairDS(data, split, pairs, False), batch_size=bs, shuffle=False, num_workers=2)
    pos = defaultdict(lambda: torch.zeros(256, dtype=torch.float64, device="cuda"))
    neg = defaultdict(lambda: torch.zeros(256, dtype=torch.float64, device="cuda"))
    model.eval()
    with torch.no_grad(), torch.autocast("cuda", dtype=AMP):
        for x1, x2, y, gap in dl:
            x1, x2, y, gap = x1.cuda(), x2.cuda(), y.cuda(), gap.cuda()
            p = torch.softmax(model(x1, x2, gap if cond else None).float(), 1)[:, 1]
            q = (p * 255).round().long().clamp(0, 255)
            for g in gap.unique().tolist():
                m = gap == g
                yy, qq = y[m], q[m]
                pos[g] += torch.bincount(qq[yy == 1], minlength=256).double()
                neg[g] += torch.bincount(qq[yy == 0], minlength=256).double()
    return {str(g): {"pos": pos[g].cpu().tolist(), "neg": neg[g].cpu().tolist()} for g in sorted(pos)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--gaps", required=True, help="训练用间隔，逗号分隔，如 1 或 5,6 或 1,2,3,4,5,6")
    ap.add_argument("--cond", type=int, default=0)
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--steps", type=int, default=12000)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--out", required=True)
    ap.add_argument("--smoke", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    torch.manual_seed(a.seed); np.random.seed(a.seed)
    gaps = [int(g) for g in a.gaps.split(",")]
    tr = pair_index(a.data, "train")
    pairs = [(i1, i2, g) for g in gaps for (i1, i2) in tr[g]]
    steps = 20 if a.smoke else a.steps
    sampler = torch.utils.data.RandomSampler(pairs, replacement=True, num_samples=steps * a.bs)
    dl = torch.utils.data.DataLoader(PairDS(a.data, "train", pairs, True), batch_size=a.bs, sampler=sampler,
                                     num_workers=4, drop_last=True, pin_memory=True)
    model = SiamUNet(cond=bool(a.cond)).cuda()
    opt = torch.optim.Adam(model.parameters(), lr=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=1e-7)
    scaler = torch.amp.GradScaler("cuda", enabled=(AMP == torch.float16))
    print(f"训练间隔 {gaps}，配对 {len(pairs)}，步数 {steps}，条件输入 {bool(a.cond)}，精度 {AMP}", flush=True)
    t0, tot, step = time.time(), 0.0, 0
    model.train()
    for x1, x2, y, gap in dl:
        x1, x2, y, gap = x1.cuda(non_blocking=True), x2.cuda(non_blocking=True), y.cuda(non_blocking=True), gap.cuda()
        with torch.autocast("cuda", dtype=AMP):
            loss = F.cross_entropy(model(x1, x2, gap if a.cond else None).float(), y, ignore_index=255)
        opt.zero_grad(set_to_none=True)
        scaler.scale(loss).backward()
        scaler.step(opt); scaler.update(); sched.step()
        tot += loss.item(); step += 1
        if step % 200 == 0:
            print(f"step {step}/{steps} loss {tot / 200:.4f} {time.time() - t0:.0f}s", flush=True); tot = 0.0
    torch.save(model.state_dict(), os.path.join(a.out, "model.pt"))
    res = {}
    for split in ("val", "test"):
        bg = pair_index(a.data, split)
        if a.smoke:
            bg = {g: ps[:8] for g, ps in bg.items()}
        res[split] = histograms(model, a.data, split, bg, bool(a.cond))
    json.dump(res, open(os.path.join(a.out, "hist_by_gap.json"), "w", encoding="utf-8"))
    json.dump(vars(a) | {"minutes": round((time.time() - t0) / 60, 1), "train_pairs": len(pairs)},
              open(os.path.join(a.out, "done.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("全部完成", flush=True)


if __name__ == "__main__":
    main()
