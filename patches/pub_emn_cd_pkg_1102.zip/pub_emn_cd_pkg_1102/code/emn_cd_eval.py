"""实验二评价：由 hist_by_gap.json（每个间隔“变化 / 未变”像元在 256 个概率档上的计数）算
变化比例、F1/精确率/召回率（门槛 0.5）、AUROC、AP、校准误差 ECE、最佳 F1 门槛，以及测试时 EM 先验校正后的 F1。
EM 按 Saerens 等（2002）：训练先验取验证集上训练所用间隔的变化比例；每个测试间隔单独估计变化比例。
用法：python emn_cd_eval.py 运行目录
"""
import json
import os
import sys

import numpy as np

CENT = (np.arange(256) + 0.5) / 256.0  # 每档的代表概率
_trapz = getattr(np, "trapezoid", None) or getattr(np, "trapz")  # numpy 2.x 改名为 trapezoid


def metrics(pos, neg, thr=0.5):
    pos, neg = np.asarray(pos), np.asarray(neg)
    k = int(np.ceil(thr * 255 - 1e-9))
    tp, fn = pos[k:].sum(), pos[:k].sum()
    fp = neg[k:].sum()
    f1 = 2 * tp / max(1, 2 * tp + fp + fn)
    # AUROC、AP：按门槛从高到低累积
    cp, cn = np.cumsum(pos[::-1]), np.cumsum(neg[::-1])
    tpr, fpr = cp / max(1, pos.sum()), cn / max(1, neg.sum())
    auroc = float(_trapz(np.r_[0, tpr], np.r_[0, fpr]))
    prec = cp / np.maximum(1, cp + cn)
    ap = float(np.sum(np.diff(np.r_[0, tpr]) * prec))
    # 最佳 F1 门槛
    f1s = 2 * cp / np.maximum(1, 2 * cp + cn + (pos.sum() - cp))
    j = int(np.argmax(f1s))
    # ECE（10 等宽概率区间）
    tot = pos + neg
    ece = 0.0
    for b in range(10):
        m = (CENT >= b / 10) & (CENT < (b + 1) / 10)
        n = tot[m].sum()
        if n:
            ece += n / tot.sum() * abs((pos[m].sum() / n) - (CENT[m] * tot[m]).sum() / n)
    return {"变化比例": float(pos.sum() / max(1, tot.sum())), "平均预测概率": float((CENT * tot).sum() / max(1, tot.sum())),
            "F1": float(f1), "精确率": float(tp / max(1, tp + fp)), "召回率": float(tp / max(1, tp + fn)),
            "AUROC": auroc, "AP": ap, "ECE": float(ece), "最佳F1": float(f1s[j]), "最佳门槛": float(1 - (j + 0.5) / 256)}


def em_adjust(pos, neg, prior_s, iters=200):
    """Saerens EM：估计测试变化比例，并把后验按新先验重算，返回调整后的计数。"""
    tot = np.asarray(pos) + np.asarray(neg)
    p = CENT.copy()
    pi = prior_s
    for _ in range(iters):
        a = pi / prior_s * p
        q = a / (a + (1 - pi) / (1 - prior_s) * (1 - p))
        new = float((q * tot).sum() / tot.sum())
        if abs(new - pi) < 1e-7:
            break
        pi = new
    a = pi / prior_s * p
    q = a / (a + (1 - pi) / (1 - prior_s) * (1 - p))
    # 调整后的后验可能跨档：把每档计数移到新概率所在档
    qb = np.clip((q * 256).astype(int), 0, 255)
    pos2, neg2 = np.zeros(256), np.zeros(256)
    np.add.at(pos2, qb, np.asarray(pos)); np.add.at(neg2, qb, np.asarray(neg))
    return pi, pos2, neg2


def main(run):
    d = json.load(open(os.path.join(run, "hist_by_gap.json"), encoding="utf-8"))
    done = json.load(open(os.path.join(run, "done.json"), encoding="utf-8"))
    tg = [g for g in done["gaps"].split(",")]
    vp = sum(np.asarray(d["val"][g]["pos"]) for g in tg if g in d["val"])
    vn = sum(np.asarray(d["val"][g]["neg"]) for g in tg if g in d["val"])
    prior_s = float(vp.sum() / (vp.sum() + vn.sum()))
    out = {"训练间隔": done["gaps"], "条件输入": done["cond"], "训练先验（验证集估计）": prior_s, "各间隔": {}}
    for g, h in sorted(d["test"].items(), key=lambda x: int(x[0])):
        m = metrics(h["pos"], h["neg"])
        pi, p2, n2 = em_adjust(h["pos"], h["neg"], prior_s)
        m2 = metrics(p2, n2)
        m.update({"EM估计变化比例": pi, "EM校正后F1": m2["F1"], "EM校正后精确率": m2["精确率"], "EM校正后召回率": m2["召回率"]})
        out["各间隔"][g] = m
    json.dump(out, open(os.path.join(run, "eval_cd_test.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for g, m in out["各间隔"].items():
        print(f"间隔{g}年 变化比例 {m['变化比例']:.4f} 预测 {m['平均预测概率']:.4f} F1 {m['F1']:.3f} AUROC {m['AUROC']:.3f} "
              f"ECE {m['ECE']:.4f} 最佳门槛 {m['最佳门槛']:.2f} EM后F1 {m['EM校正后F1']:.3f}")


if __name__ == "__main__":
    main(sys.argv[1])
