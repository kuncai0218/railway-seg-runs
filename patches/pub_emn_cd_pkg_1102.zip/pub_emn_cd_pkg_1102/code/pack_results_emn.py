"""打包回传：评价结果、按矿区计数、测试集概率图、日志、done.json；不含模型权重（model.pt 留在本机）。
用法（实验包根目录）：python code/pack_results_emn.py --name 同学乙
"""
import argparse
import os
import time
import zipfile

ap = argparse.ArgumentParser()
ap.add_argument("--name", required=True)
a = ap.parse_args()
out = f"回传_{a.name}_emn_1102_{time.strftime('%m%d_%H%M')}.zip"
n = 0
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for dp, _, fns in os.walk("results"):
        for fn in fns:
            if fn == "model.pt":
                continue
            if fn.endswith(".npy") and not fn.startswith("prob_test"):
                continue
            p = os.path.join(dp, fn)
            z.write(p); n += 1
print(f"已生成 {out}，{n} 个文件，{os.path.getsize(out) / 2**20:.0f} MB")
