"""EuroMineNet 逐年制图：单期 / 单期 + 历史 / 错位历史 / 随机丢弃历史。
训练固定轮数取最后一轮；训练后对验证、测试集推理，存矿区概率（uint8），供 emn_eval.py 算指标。

输入：影像 10 波段（官方均值方差归一化）；历史 9 通道（uint8 → [-1,1]）+ 1 个“有无历史”标记通道。
"""
import argparse
import csv
import json
import os
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision

R34_URL = "https://download.pytorch.org/models/resnet34-333f7ec4.pth"  # PyTorch 官方 ImageNet 权重


def conv_bn_relu(cin, cout):
    return nn.Sequential(nn.Conv2d(cin, cout, 3, padding=1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True))


class Up(nn.Module):
    def __init__(self, cin, cskip, cout):
        super().__init__()
        self.c = nn.Sequential(conv_bn_relu(cin + cskip, cout), conv_bn_relu(cout, cout))

    def forward(self, x, skip=None):
        x = F.interpolate(x, scale_factor=2, mode="nearest")
        if skip is not None:
            x = torch.cat([x, skip], 1)
        return self.c(x)


class UNetR34(nn.Module):
    """U-Net（ResNet-34 编码器，解码器通道 256/128/64/32/16，与 segmentation_models_pytorch 的 Unet 相同结构）。
    只依赖 torchvision；多光谱输入时第一层按“循环复制 RGB 权重 × 3/通道数”初始化（与 smp 的做法相同）。"""

    def __init__(self, in_ch, n_cls=2):
        super().__init__()
        r = torchvision.models.resnet34(weights=None)
        r.load_state_dict(torch.hub.load_state_dict_from_url(R34_URL, progress=False))
        w = r.conv1.weight.data
        new = torch.stack([w[:, i % 3] for i in range(in_ch)], 1) * (3.0 / in_ch)
        r.conv1 = nn.Conv2d(in_ch, 64, 7, 2, 3, bias=False)
        r.conv1.weight.data = new
        self.stem = nn.Sequential(r.conv1, r.bn1, r.relu)
        self.pool = r.maxpool
        self.l1, self.l2, self.l3, self.l4 = r.layer1, r.layer2, r.layer3, r.layer4
        self.u4, self.u3 = Up(512, 256, 256), Up(256, 128, 128)
        self.u2, self.u1, self.u0 = Up(128, 64, 64), Up(64, 64, 32), Up(32, 0, 16)
        self.head = nn.Conv2d(16, n_cls, 3, padding=1)

    def forward(self, x):
        x0 = self.stem(x)
        x1 = self.l1(self.pool(x0))
        x2 = self.l2(x1)
        x3 = self.l3(x2)
        x4 = self.l4(x3)
        d = self.u0(self.u1(self.u2(self.u3(self.u4(x4, x3), x2), x1), x0))
        return self.head(d)


AMP = torch.bfloat16 if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else torch.float16

MEAN = np.array([1089.74398414, 1004.04424665, 912.91169804, 1157.54372767, 1956.3718531,
                 2314.40816642, 2249.62494194, 2551.81568494, 1920.88963249, 1185.54458012], np.float32)
STD = np.array([220.01112071, 258.62166282, 385.29996291, 352.84198064, 433.08390432,
                555.78649618, 556.49755492, 616.86119128, 615.74838491, 531.51408023], np.float32)


def shuffled_partner(meta_path, seed=12345):
    """错位历史：跨矿区一一配对；每次交换至少修复一个冲突，避免原修复循环卡住。"""
    with open(meta_path, encoding="utf-8") as f:
        sites = np.array([r["site"] for r in csv.DictReader(f)])
    _, counts = np.unique(sites, return_counts=True)
    if len(counts) < 2 or int(counts.max()) * 2 > len(sites):
        raise ValueError("无法构造跨矿区的一一配对：至少需要两个矿区，且最大矿区样本数不能超过一半")
    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(sites))
    for i in np.flatnonzero(sites[perm] == sites):
        if sites[perm[i]] != sites[i]:
            continue
        # i 当前配到自身矿区。选 j，使交换后 i 和 j 都不会配到自身矿区。
        eligible = np.flatnonzero((sites != sites[i]) & (sites[perm] != sites[i]))
        if len(eligible) == 0:
            raise ValueError("跨矿区配对无法修复；请检查矿区样本分布")
        j = eligible[rng.integers(len(eligible))]
        perm[i], perm[j] = perm[j], perm[i]
    return perm


class DS(torch.utils.data.Dataset):
    def __init__(self, root, split, use_hist, shuffle_hist, aug):
        self.root, self.split = root, split
        self.use_hist, self.aug = use_hist, aug
        self.perm = shuffled_partner(os.path.join(root, f"meta_{split}.csv")) if shuffle_hist else None
        self.n = np.load(os.path.join(root, f"lab_{split}.npy"), mmap_mode="r").shape[0]
        self.img = self.hist = self.lab = None

    def _open(self):
        if self.img is None:
            self.img = np.load(os.path.join(self.root, f"img_{self.split}.npy"), mmap_mode="r")
            self.hist = np.load(os.path.join(self.root, f"hist_{self.split}.npy"), mmap_mode="r")
            self.lab = np.load(os.path.join(self.root, f"lab_{self.split}.npy"), mmap_mode="r")

    def __len__(self):
        return self.n

    def __getitem__(self, i):
        self._open()
        x = (self.img[i].astype(np.float32) - MEAN[:, None, None]) / STD[:, None, None]
        y = self.lab[i].astype(np.int64)
        if self.use_hist:
            j = self.perm[i] if self.perm is not None else i
            h = self.hist[j].astype(np.float32) / 127.5 - 1.0
            x = np.concatenate([x, h], 0)
        if self.aug:
            k = np.random.randint(4)
            x, y = np.rot90(x, k, (1, 2)), np.rot90(y, k, (0, 1))
            if np.random.rand() < 0.5:
                x, y = x[:, :, ::-1], y[:, ::-1]
        return torch.from_numpy(np.ascontiguousarray(x)), torch.from_numpy(np.ascontiguousarray(y)), i


def add_flag(x, use_hist, drop_p, training):
    """历史通道后面加“有无历史”标记；训练时按概率整组置零（随机丢弃历史）。"""
    if not use_hist:
        return x
    b = x.shape[0]
    flag = torch.ones(b, 1, 1, 1, device=x.device)
    if training and drop_p > 0:
        flag = (torch.rand(b, 1, 1, 1, device=x.device) >= drop_p).float()
    x = torch.cat([x[:, :10], x[:, 10:] * flag], 1)
    return torch.cat([x, flag.expand(-1, 1, x.shape[2], x.shape[3])], 1)


def infer(model, root, split, use_hist, shuffle_hist, mode, out_path, bs=64):
    ds = DS(root, split, use_hist, shuffle_hist, aug=False)
    dl = torch.utils.data.DataLoader(ds, batch_size=bs, shuffle=False, num_workers=2)
    out = np.lib.format.open_memmap(out_path, "w+", np.uint8, (len(ds), 160, 160))
    model.eval()
    with torch.no_grad(), torch.autocast("cuda", dtype=AMP):
        for x, _, idx in dl:
            x = x.cuda(non_blocking=True)
            if use_hist:
                x = add_flag(x, True, 0.0, False)
                if mode == "nohist":
                    x[:, 10:] = 0.0  # 历史与标记都置零
            p = torch.softmax(model(x).float(), 1)[:, 1]
            out[idx.numpy()] = (p * 255).round().byte().cpu().numpy()
    out.flush()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=r"D:\Railway_project\work\公开数据_1102\emn_prep")
    ap.add_argument("--config", choices=["single", "hist", "histshuf", "drop"], required=True)
    ap.add_argument("--p", type=float, default=0.0)
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--out", required=True)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--skip_infer", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    torch.manual_seed(a.seed); np.random.seed(a.seed)
    use_hist = a.config != "single"
    shuffle_hist = a.config == "histshuf"
    drop_p = a.p if a.config == "drop" else 0.0
    in_ch = 10 + (10 if use_hist else 0)

    ds = DS(a.data, "train", use_hist, shuffle_hist, aug=True)
    if a.smoke:
        ds = torch.utils.data.Subset(ds, list(range(0, len(ds), max(1, len(ds) // 256))))
    dl = torch.utils.data.DataLoader(ds, batch_size=a.bs, shuffle=True, num_workers=4, drop_last=True,
                                     persistent_workers=True, pin_memory=True)
    model = UNetR34(in_ch).cuda()
    opt = torch.optim.Adam(model.parameters(), lr=1e-4)
    scaler = torch.amp.GradScaler("cuda", enabled=(AMP == torch.float16))
    print(f"混合精度 {AMP}，输入通道 {in_ch}", flush=True)
    epochs = 1 if a.smoke else a.epochs
    total = epochs * len(dl)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=total, eta_min=1e-7)
    t0, step = time.time(), 0
    for ep in range(epochs):
        model.train()
        tot = 0.0
        for x, y, _ in dl:
            x, y = x.cuda(non_blocking=True), y.cuda(non_blocking=True)
            x = add_flag(x, use_hist, drop_p, True)
            with torch.autocast("cuda", dtype=AMP):
                loss = F.cross_entropy(model(x).float(), y, ignore_index=255)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.step(opt); scaler.update(); sched.step()
            tot += loss.item(); step += 1
            if step % 100 == 0:
                print(f"ep {ep} step {step}/{total} loss {tot / max(1, (step - ep * len(dl))):.4f} {time.time() - t0:.0f}s", flush=True)
        print(f"== ep {ep} done loss {tot / len(dl):.4f} {time.time() - t0:.0f}s", flush=True)
    torch.save(model.state_dict(), os.path.join(a.out, "model.pt"))
    modes = ["img"] if not use_hist else (["hist", "nohist"] if a.config == "drop" else ["hist"])
    for split in (() if a.skip_infer else ("val", "test")):
        for m in modes:
            infer(model, a.data, split, use_hist, shuffle_hist, m, os.path.join(a.out, f"prob_{split}_{m}.npy"))
    json.dump(vars(a) | {"modes": modes, "minutes": round((time.time() - t0) / 60, 1)},
              open(os.path.join(a.out, "done.json"), "w"), ensure_ascii=False, indent=1)
    print("全部完成", flush=True)


if __name__ == "__main__":
    main()
