# -*- coding: utf-8 -*-
"""同一种子的原版与 PSE 顺序执行：冒烟两组 → 正式原版 → 正式 PSE。一次一个；失败即停；可重复运行（已完成的跳过，有 last.pth 的续跑）。
用法：python -X utf8 run_pair.py --seed 43 --runs D:\\t34_runs
需要先设好环境变量 T34_DATA、T34_CACHE，并已运行过 stage_den_cache.py。"""
import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent


def now():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, choices=[43, 44], required=True)
    ap.add_argument("--runs", required=True)
    a = ap.parse_args()
    runs = Path(a.runs)
    runs.mkdir(parents=True, exist_ok=True)
    state_path = runs / f"pair_s{a.seed}_state.json"
    state = {"seed": a.seed, "started": now(), "steps": []}

    def save():
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), "utf-8")

    plan = [("smoke", "orig"), ("smoke", "pse"), ("formal", "orig"), ("formal", "pse")]
    for kind, method in plan:
        out = runs / (f"_smoke_{method}_s{a.seed}" if kind == "smoke" else f"den_planet_{method}_s{a.seed}")
        if kind == "smoke" and (out / "status.json").exists() and "smoke_complete" in (out / "status.json").read_text("utf-8"):
            continue
        if kind == "formal" and (out / "official_test.json").exists():
            continue
        args = [sys.executable, "-B", "-u", "-X", "utf8", str(HERE / "train_t34.py"), "--seed", str(a.seed), "--method", method, "--out", str(out)]
        if kind == "smoke":
            args += ["--smoke_steps", "20"]
        elif (out / "last.pth").exists():
            args.append("--resume")
        log = runs / f"{out.name}_{datetime.now():%Y%m%d_%H%M%S}.log"
        rec = {"step": kind + "_" + method, "args": args[5:], "log": str(log), "start": now()}
        state["steps"].append(rec)
        save()
        with open(log, "w", encoding="utf-8") as fh:
            rc = subprocess.call(args, cwd=str(HERE), stdout=fh, stderr=subprocess.STDOUT)
        rec.update(end=now(), returncode=rc)
        save()
        if rc != 0:
            state["stopped"] = f"{kind}_{method} 返回码 {rc}，见日志，未自动重试"
            save()
            sys.exit(rc)
    state["done"] = now()
    save()


if __name__ == "__main__":
    main()
