"""Stage lossless DEN RGB+NIR training/validation tiles using the pinned decoder."""
import hashlib
import json
import os
import shutil
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "2")
import numpy as np
import torch
import torchvision

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "upstream"))
from data.data import get_monthly_dates_dict

SOURCE_DATA = Path(os.environ["T34_DATA"])  # SitsSCD 版 DynamicEarthNet 根目录（含 train/val/test/labels/split.json）
CACHE = Path(os.environ["T34_CACHE"])  # 本机 SSD 上的解码缓存目录
SPLITS = {"train": 55, "val": 10}


def write_json(path, value):
    tmp = path.with_suffix(".writing")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def build(spec):
    partition, tile, days = spec
    destination = CACHE / "DynamicEarthNet" / partition / (tile + ".blk.npy")
    receipt = destination.with_suffix(".verified.json")
    if receipt.exists() and destination.exists():
        note = json.loads(receipt.read_text("utf-8"))
        if note["bytes"] == destination.stat().st_size and note["days"] == days and note["torchvision"] == torchvision.__version__:
            if digest(destination) == note["sha256"]:
                return note
    image_folder = SOURCE_DATA / partition / tile
    blocks = np.empty((8, 8, len(days), 128, 128, 4), dtype=np.uint8)
    for i, day in enumerate(days):
        base = image_folder / f"{tile}_{day}"
        rgb = torchvision.io.read_image(str(base) + "_rgb.jpeg").numpy()
        nir = torchvision.io.read_image(str(base) + "_infra.jpeg").numpy()[0]
        pixels = np.concatenate((rgb, nir[None]), axis=0)
        blocks[:, :, i] = pixels.reshape(4, 8, 128, 8, 128).transpose(1, 3, 2, 4, 0)
    temporary = destination.with_suffix(".incomplete")
    # Use the same block order and exact uint8 bytes as the already validated cache reader.
    with temporary.open("wb") as stream:
        np.save(stream, blocks, allow_pickle=False)
    temporary.replace(destination)
    row = {"partition": partition, "tile": tile, "days": days,
           "bytes": destination.stat().st_size, "sha256": digest(destination),
           "mtime_ns": destination.stat().st_mtime_ns, "torchvision": torchvision.__version__}
    write_json(receipt, row)
    return row


def main():
    assert torchvision.__version__ == "0.18.0+cu121"
    torch.set_num_threads(2)
    labels = SOURCE_DATA / "split.json"
    split = json.loads(labels.read_text("utf-8"))
    month_indices = np.linspace(0, 23, 8).astype(int).tolist()
    month_days = [get_monthly_dates_dict()[m] for m in month_indices]
    sampling_days = {
        "train": sorted({max(0, t + delta) for t in month_days for delta in range(-2, 3)}),
        "val": month_days,
    }
    tasks = []
    for part, expected_count in SPLITS.items():
        assert len(set(split[part])) == expected_count
        folder = CACHE / "DynamicEarthNet" / part
        folder.mkdir(parents=True, exist_ok=True)
        tasks.extend((part, sid, sampling_days[part]) for sid in sorted(split[part]))
    if shutil.disk_usage(CACHE).free < 15 * 2**30:
        raise RuntimeError(f"Insufficient free disk space for DEN decode cache on {CACHE}")
    rows = {}
    with ThreadPoolExecutor(max_workers=4) as pool:
        for idx, row in enumerate(pool.map(build, tasks), 1):
            rows[row["tile"]] = row
            if idx == 1 or idx % 5 == 0:
                print(f"[DEN_CACHE] {idx}/{len(tasks)} decoded", flush=True)
    for part in SPLITS:
        write_json(CACHE / "DynamicEarthNet" / part / "index.json",
                   {"days": sampling_days[part], "tiles": sorted(split[part])})
    write_json(HERE / "decode_cache.json", {"created":datetime.now().astimezone().isoformat(),
                 "cache":str(CACHE), "source":str(SOURCE_DATA), "split_sha256":digest(labels),
                 "recipe_sha256":digest(Path(__file__)), "torchvision":torchvision.__version__,
                 "used_months":month_indices, "tiles":rows})
    print(f"[DEN_CACHE] Complete {len(rows)} tiles, {sum(x['bytes'] for x in rows.values())/2**30:.2f} GiB on {CACHE.drive}",flush=True)


if __name__ == "__main__":
    main()

