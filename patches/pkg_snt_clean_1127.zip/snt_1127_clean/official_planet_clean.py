# -*- coding: utf-8 -*-
"""修正版各臂（Planet）的正式测试：同区按 val_in 最佳 mIoU 轮、跨区按 val_out 最佳 mIoU 轮，另测固定末轮。

选轮只读训练作业 status.json 里的 best（训练时按验证 mIoU 记录），不看测试集。
每个（轮次, 划分）调用一次同目录的 midtest_v2.py（按 config_snt.json 原样重建模型），结果写在作业目录：
  midtest_epNNN_test_in.json / midtest_epNNN_test_out.json，汇总写 official_clean.json。
幂等：已有的结果文件跳过。
用法：python official_planet_clean.py --run <作业目录>
"""
import argparse
import json
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
MID = HERE / "midtest_v2.py"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    a = ap.parse_args()
    run = Path(a.run).resolve()
    st = json.loads((run / "status.json").read_text(encoding="utf-8"))
    cfg = json.loads((run / "config_snt.json").read_text(encoding="utf-8"))["args"]
    assert cfg["dataset"] == "planet" and cfg["select_metric"] == "miou", cfg
    rows = json.loads((run / "epochs.json").read_text(encoding="utf-8"))
    last = int(rows[-1]["epoch"])
    assert last == int(cfg["epochs"]), f"作业未跑完：{last}/{cfg['epochs']}"
    picks = [("test_in", int(st["best"]["in"]["epoch"]), "同区按验证mIoU"),
             ("test_out", int(st["best"]["out"]["epoch"]), "跨区按验证mIoU"),
             ("test_in", last, "固定末轮"), ("test_out", last, "固定末轮")]
    summary = {"作业": str(run), "时间": datetime.now().astimezone().isoformat(timespec="seconds"),
               "选轮": {"in": st["best"]["in"], "out": st["best"]["out"], "末轮": last}, "结果": []}
    rc_all = 0
    for split, ep, why in picks:
        out = run / f"midtest_ep{ep:03d}_{split}.json"
        if not out.exists():
            t0 = time.time()
            r = subprocess.run([sys.executable, "-u", "-X", "utf8", str(MID), "--run", str(run), "--epoch", str(ep), "--split", split],
                               capture_output=True, text=True, encoding="utf-8", errors="replace")
            print(f"[正式测试] {run.name} ep{ep} {split}（{why}）rc={r.returncode} {(time.time() - t0) / 60:.1f} 分钟", flush=True)
            if r.returncode != 0:
                print((r.stderr or r.stdout)[-600:], flush=True)
                rc_all = 1
                continue
        res = json.loads(out.read_text(encoding="utf-8")) if out.exists() else None
        summary["结果"].append({"划分": split, "轮次": ep, "选轮依据": why, "文件": out.name, "指标": res})
    (run / "official_clean.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return rc_all


if __name__ == "__main__":
    sys.exit(main())
