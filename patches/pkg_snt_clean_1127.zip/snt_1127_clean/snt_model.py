# -*- coding: utf-8 -*-
"""Unified SNTNet (v2): wraps any PSENet / A1 / PSE+BN backbone cleanly via forward hooks."""
import torch
import torch.nn as nn

from normalcy_crf import NormalcyTransitionCRFHead
from scene_proto_cal import SceneConsistentRadiometricAug, SceneProtoCalibrator


class SNTNet(nn.Module):
    def __init__(
        self,
        backbone: nn.Module,
        in_channels: int,
        num_classes: int,
        head_mode: str = "h3",
        use_scpc: bool = False,
        use_rad_aug: bool = False,
        freeze_backbone: bool = False,
        causal: bool = False,
        ignore_index: int = 6,
        drop: float = 0.15,
        c_s0: int | None = None,
        c_s2: int | None = None,
        c_d: int | None = None,
    ):
        super().__init__()
        assert head_mode in ("none", "h0", "hdir", "h1", "h2", "h3", "h3_nos0")
        self.backbone = backbone
        self.in_channels = in_channels
        self.num_classes = num_classes
        self.head_mode = head_mode
        self.use_scpc = use_scpc
        self.use_rad_aug = use_rad_aug
        self.freeze_backbone = freeze_backbone
        self.causal = causal
        self.ignore_index = ignore_index

        def _infer_out_c(mod, fallback):
            last_c = None
            for sub in mod.modules():
                if isinstance(sub, nn.Conv2d):
                    last_c = sub.out_channels
            return last_c if last_c is not None else fallback

        c_s0 = c_s0 if c_s0 is not None else _infer_out_c(self.backbone.stem, 32)
        c_s2 = c_s2 if c_s2 is not None else _infer_out_c(self.backbone.d2, 64)
        c_d = c_d if c_d is not None else _infer_out_c(self.backbone.r0, 32)

        if causal:
            for attr in ("t24", "t48"):
                blk = getattr(self.backbone, attr, None)
                if blk is not None and hasattr(blk, "causal"):
                    blk.causal = True

        self._taps = {}
        self._hooks = [
            self.backbone.stem.register_forward_hook(self._make_hook("s0")),
            self.backbone.d2.register_forward_hook(self._make_hook("s2")),
            self.backbone.r0.register_forward_hook(self._make_hook("d")),
        ]

        if freeze_backbone:
            for p in self.backbone.parameters():
                p.requires_grad = False
            self.backbone.eval()

        self.rad_aug = SceneConsistentRadiometricAug(prob=0.5) if use_rad_aug else None

        self.scpc = (
            SceneProtoCalibrator(in_channels=in_channels, c_s0=c_s0, num_classes=num_classes, tau_max=1.0, causal=causal)
            if use_scpc
            else None
        )

        self.head = (
            NormalcyTransitionCRFHead(
                in_channels=in_channels,
                num_classes=num_classes,
                c_s0=c_s0,
                c_s2=c_s2,
                c_d=c_d,
                mode=head_mode,
                causal=causal,
                ignore_index=ignore_index,
                drop=drop,
            )
            if head_mode != "none"
            else None
        )

        self.last_aux = {}

    def _make_hook(self, name: str):
        def _fn(_module, _inp, output):
            self._taps[name] = output
        return _fn

    def train(self, mode: bool = True):
        super().train(mode)
        if self.freeze_backbone:
            self.backbone.eval()
        return self

    def extract_scene_tokens(self, x: torch.Tensor, batch_positions=None) -> torch.Tensor:
        assert self.scpc is not None
        B, T, C, H, W = x.shape
        with torch.no_grad():
            s0 = self.backbone.stem(x.flatten(0, 1)).view(B, T, -1, H, W)
            return self.scpc.extract_raw_tokens(x, s0)

    def forward(self, x: torch.Tensor, batch_positions=None, scene_bank_tokens: torch.Tensor | None = None):
        if self.training and self.rad_aug is not None:
            x = self.rad_aug(x)

        B, T, C, H, W = x.shape
        self._taps.clear()

        if self.freeze_backbone:
            with torch.no_grad():
                u_ctx = self.backbone(x, batch_positions)
            s0 = self._taps["s0"].detach().view(B, T, -1, H, W)
            s2 = self._taps["s2"].detach().view(B, T, -1, H // 4, W // 4)
            d = self._taps["d"].detach().view(B, T, -1, H, W)
            u_ctx = u_ctx.detach()
        else:
            u_ctx = self.backbone(x, batch_positions)
            s0 = self._taps["s0"].view(B, T, -1, H, W)
            s2 = self._taps["s2"].view(B, T, -1, H // 4, W // 4)
            d = self._taps["d"].view(B, T, -1, H, W)

        scpc_aux = None
        if self.scpc is not None:
            u_cal, scpc_aux = self.scpc(x, s0, u_ctx, scene_bank_tokens=scene_bank_tokens)
        else:
            u_cal = u_ctx

        head_aux = None
        if self.head is not None:
            head_aux = self.head(x, batch_positions, s0, s2, d, u_cal)
            out_logits = head_aux["logits"]
        else:
            out_logits = u_cal

        self.last_aux = {"u_ctx": u_ctx, "u_cal": u_cal, "scpc": scpc_aux, "head": head_aux}
        return out_logits

    def compute_total_loss(
        self,
        logits: torch.Tensor,
        y: torch.Tensor,
        main_loss_fn,
        cls_weight: torch.Tensor | None = None,
        w_backbone_event: float = 1.0,
        w_crf: float = 1.0,
        w_ep: float = 0.5,
        w_norm: float = 0.3,
        crf_weighted: bool = True,
        crf_chg_boost: float = 2.5,
    ) -> tuple[torch.Tensor, dict]:
        parts = {}
        total = torch.zeros((), device=y.device, dtype=logits.dtype)

        if self.head is not None:
            l_unary = main_loss_fn(self.last_aux["head"]["unary"], y)
            parts["unary_ce"] = l_unary
            if not self.freeze_backbone:
                # Direct backbone anchor CE (v2.1): keeps u_ctx healthy A1-grade
                # so SCPC + Normalcy-CRF strictly learn residual calibration & dynamics.
                l_ctx = main_loss_fn(self.last_aux["u_ctx"], y)
                parts["ctx_ce"] = l_ctx
                total = total + 0.5 * l_ctx + 0.5 * l_unary
            else:
                total = total + l_unary
            l_head, hparts = self.head.compute_losses(
                self.last_aux["head"],
                y,
                cls_weight=cls_weight,
                w_crf=w_crf,
                w_ep=w_ep,
                w_norm=w_norm,
                crf_weighted=crf_weighted,
                crf_chg_boost=crf_chg_boost,
            )
            parts.update(hparts)
            total = total + l_head
        else:
            l_main = main_loss_fn(logits, y)
            parts["main_ce"] = l_main
            if (not self.freeze_backbone) and self.scpc is not None:
                l_ctx = main_loss_fn(self.last_aux["u_ctx"], y)
                parts["ctx_ce"] = l_ctx
                total = total + 0.5 * l_ctx + 0.5 * l_main
            else:
                total = total + l_main

        if (not self.freeze_backbone) and hasattr(self.backbone, "aux_loss"):
            b_aux, b_parts = self.backbone.aux_loss(y, main_loss_fn, w_prior=0.3, w_event=w_backbone_event)
            if isinstance(b_aux, torch.Tensor):
                total = total + b_aux
                for k, v in b_parts.items():
                    parts[f"bb_{k}"] = v

        parts["loss"] = total
        return total, parts
