# -*- coding: utf-8 -*-
"""[snt_clean_1127] 修正版：端点证据按每期类均值中心化（对共同平移不变）；端点交叉熵类别权只乘一次；
新增同头消融臂 h0（只有静态转移表）与 hdir（有向观测、不建常态）。其余与 snt_1123_v2 相同。

Module 1 (v2): Unmixed Pre-Temporal Endpoint Witness + Heteroscedastic Generative Normalcy
+ Directed Transition Energy + Class- & Change-Weighted Linear-Chain CRF.

Upgrades over v1 (directly from Phase-1 s42 weight & curve X-ray):
  1. Weighted sequence CRF NLL (crf_weighted=True, crf_chg_boost=2.5): weights each pixel trajectory
     by its mean class weight cls_w[y] and boosts trajectories containing true transitions, aligning
     CRF optimization with official macro-class SCS & preventing conservative recall collapse.
  2. Non-negative bounded endpoint fusion:
       lambda_loc = 0.5 * sigmoid(lambda_loc_raw) in (0, 0.5)   [prevents -0.43 sign-flip & >1.0 overfit]
       ep_witness_scale = softplus(ep_witness_raw) > 0          [prevents sign-flip]
  3. Mild Dropout2d(0.15) in lightweight heads to curb source-AOI memorization on frozen s0/s2.
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def _gn(c: int) -> nn.GroupNorm:
    return nn.GroupNorm(max(1, min(8, c // 8)), c)


def compute_physical_descriptors(x: torch.Tensor) -> torch.Tensor:
    """Sensor-agnostic per-pixel physical descriptor from normalized input x [B, T, C, H, W].
    Returns [B, T, C + 3, H, W]: normalized bands + registration-tolerant (+/-2px) spatial gradients (gx, gy, |g|).
    """
    B, T, C, H, W = x.shape
    lum = x.mean(dim=2, keepdim=True)
    lum_pad = F.pad(lum.flatten(0, 1), (2, 2, 2, 2), mode="replicate")
    gx = 0.5 * (lum_pad[:, :, 2:-2, 4:] - lum_pad[:, :, 2:-2, :-4])
    gy = 0.5 * (lum_pad[:, :, 4:, 2:-2] - lum_pad[:, :, :-4, 2:-2])
    gmag = torch.sqrt(gx * gx + gy * gy + 1e-6)
    grad = torch.cat([gx, gy, gmag], dim=1).view(B, T, 3, H, W)
    return torch.cat([x, grad], dim=2)


class TimePairEncoder(nn.Module):
    def __init__(self, d_time: int = 16):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(6, d_time),
            nn.GELU(),
            nn.Linear(d_time, d_time),
            nn.GELU(),
        )

    def forward(self, pos: torch.Tensor | None, B: int, T: int, device, dtype) -> torch.Tensor:
        if pos is None:
            p0 = torch.zeros(B, T - 1, device=device, dtype=torch.float32)
            p1 = torch.full((B, T - 1), 30.0, device=device, dtype=torch.float32)
        else:
            p0 = pos[:, :-1].float()
            p1 = pos[:, 1:].float()
        ang0 = p0 * (2.0 * math.pi / 365.25)
        ang1 = p1 * (2.0 * math.pi / 365.25)
        dt = (p1 - p0).clamp(-730.0, 730.0)
        feats = torch.stack(
            [ang0.sin(), ang0.cos(), ang1.sin(), ang1.cos(), dt / 90.0, torch.log1p(dt.abs() / 30.0)],
            dim=-1,
        ).to(dtype)
        return self.net(feats)


class UnmixedLocalEncoder(nn.Module):
    def __init__(self, c_s0: int, c_s2: int, d_loc: int = 32, drop: float = 0.15):
        super().__init__()
        self.proj_s2 = nn.Sequential(
            nn.Conv2d(c_s2, d_loc, 1, bias=False),
            _gn(d_loc),
            nn.GELU(),
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(c_s0 + d_loc, d_loc, 3, padding=1, bias=False),
            _gn(d_loc),
            nn.GELU(),
            nn.Dropout2d(drop),
            nn.Conv2d(d_loc, d_loc, 1, bias=False),
            _gn(d_loc),
            nn.GELU(),
        )

    def forward(self, s0: torch.Tensor, s2: torch.Tensor) -> torch.Tensor:
        B, T, _, H, W = s0.shape
        s2p = self.proj_s2(s2.flatten(0, 1))
        s2u = F.interpolate(s2p, size=(H, W), mode="bilinear", align_corners=False)
        h = self.fuse(torch.cat([s0.flatten(0, 1), s2u], dim=1))
        return h.view(B, T, -1, H, W)


class NormalcyTransitionCRFHead(nn.Module):
    def __init__(
        self,
        in_channels: int,
        num_classes: int,
        c_s0: int = 32,
        c_s2: int = 64,
        c_d: int = 32,
        d_loc: int = 32,
        d_lat: int = 8,
        d_time: int = 16,
        mode: str = "h3",
        causal: bool = False,
        ignore_index: int = 6,
        drop: float = 0.15,
        center_witness: bool = True,
        cw_once: bool = True,
    ):
        super().__init__()
        assert mode in ("h0", "hdir", "h1", "h2", "h3", "h3_nos0"), f"Unknown mode: {mode}"
        self.center_witness = bool(center_witness)  # 1127 修正 2：端点证据减去每期类均值，去掉任意零点
        self.cw_once = bool(cw_once)  # 1127 修正 1：端点交叉熵的类别权只乘一次
        self.C = in_channels
        self.K = num_classes
        self.mode = mode
        self.causal = causal
        self.ignore_index = ignore_index
        self.d_loc = d_loc
        self.d_lat = d_lat
        self.d_e = in_channels + 3 + d_lat

        self.time_enc = TimePairEncoder(d_time)

        if mode == "h3_nos0":
            self.loc_enc = nn.Sequential(
                nn.Conv2d(c_d, d_loc, 3, padding=1, bias=False),
                _gn(d_loc),
                nn.GELU(),
                nn.Dropout2d(drop),
            )
        else:
            self.loc_enc = UnmixedLocalEncoder(c_s0, c_s2, d_loc, drop=drop)

        self.target_proj = nn.Conv2d(d_loc, d_lat, 1, bias=False)

        self.ep_head = nn.Sequential(
            nn.Conv2d(d_loc, d_loc, 3, padding=1, bias=False),
            _gn(d_loc),
            nn.GELU(),
            nn.Dropout2d(drop),
            nn.Conv2d(d_loc, num_classes, 1),
        )
        # Strictly non-negative & bounded in (0, 0.5): init sigmoid(-0.85)*0.5 ~= 0.15
        self.lambda_loc_raw = nn.Parameter(torch.tensor(-0.85))

        # Static transition prior matrix W [K, K]
        self.trans_W = nn.Parameter(torch.eye(num_classes) * 0.25)

        if mode == "h1":
            in_pair = 3 * d_loc + 3 * c_d + self.d_e + d_time
            self.h1_pair = nn.Sequential(
                nn.Conv2d(in_pair, 96, 1, bias=False),
                _gn(96),
                nn.GELU(),
                nn.Dropout2d(drop),
                nn.Conv2d(96, 64, 1, bias=False),
                _gn(64),
                nn.GELU(),
                nn.Conv2d(64, num_classes * num_classes, 1),
            )
            nn.init.zeros_(self.h1_pair[-1].weight)
            nn.init.zeros_(self.h1_pair[-1].bias)
        elif mode in ("h2", "h3", "h3_nos0"):
            in_norm = d_loc + self.d_e + d_time
            self.norm_trunk = nn.Sequential(
                nn.Conv2d(in_norm, 64, 1, bias=False),
                _gn(64),
                nn.GELU(),
                nn.Dropout2d(drop),
                nn.Conv2d(64, 48, 1, bias=False),
                _gn(48),
                nn.GELU(),
            )
            self.norm_shared_mu = nn.Conv2d(48, self.d_e, 1)
            self.norm_shared_lv = nn.Conv2d(48, self.d_e, 1)
            nn.init.zeros_(self.norm_shared_mu.weight)
            nn.init.zeros_(self.norm_shared_mu.bias)
            nn.init.zeros_(self.norm_shared_lv.weight)
            nn.init.constant_(self.norm_shared_lv.bias, -0.5)

            if mode in ("h3", "h3_nos0"):
                self.norm_cls_mu = nn.Conv2d(48, num_classes * self.d_e, 1)
                self.norm_cls_lv = nn.Conv2d(48, num_classes * self.d_e, 1)
                nn.init.zeros_(self.norm_cls_mu.weight)
                nn.init.zeros_(self.norm_cls_mu.bias)
                nn.init.zeros_(self.norm_cls_lv.weight)
                nn.init.zeros_(self.norm_cls_lv.bias)

            self.stay_scale_raw = nn.Parameter(torch.tensor(0.0))  # softplus(0) ~ 0.69
            self.stay_bias = nn.Parameter(torch.zeros(num_classes))

            # Strictly non-negative endpoint witness scale: softplus(-1.25) ~= 0.25
            self.ep_witness_raw = nn.Parameter(torch.tensor(-1.25))
            in_dir = 3 * d_loc + self.d_e + d_time
            self.dir_head = nn.Sequential(
                nn.Conv2d(in_dir, 64, 1, bias=False),
                _gn(64),
                nn.GELU(),
                nn.Dropout2d(drop),
                nn.Conv2d(64, num_classes * num_classes, 1),
            )
            nn.init.zeros_(self.dir_head[-1].weight)
            nn.init.zeros_(self.dir_head[-1].bias)

        if mode == "hdir":  # 1127 有向观测臂：有向边 + 端点证据，与 h2/h3 同一实现，但不建常态（保持势只剩每类常数偏置）
            self.stay_bias = nn.Parameter(torch.zeros(num_classes))
            self.ep_witness_raw = nn.Parameter(torch.tensor(-1.25))
            in_dir = 3 * d_loc + self.d_e + d_time
            self.dir_head = nn.Sequential(
                nn.Conv2d(in_dir, 64, 1, bias=False),
                _gn(64),
                nn.GELU(),
                nn.Dropout2d(drop),
                nn.Conv2d(64, num_classes * num_classes, 1),
            )
            nn.init.zeros_(self.dir_head[-1].weight)
            nn.init.zeros_(self.dir_head[-1].bias)
        # mode == "h0"：固定转移臂，只用可学的静态转移表 trans_W（不看影像）；一元势与其他臂相同

    def _witness_scores(self, u_loc: torch.Tensor) -> torch.Tensor:
        """端点证据进入有向边前的分数。修正版减去每期 K 类的均值：所有类同加常数时边势不变。"""
        if self.center_witness:
            return u_loc - u_loc.mean(dim=2, keepdim=True)
        return u_loc

    @property
    def lambda_loc(self) -> torch.Tensor:
        return 0.5 * torch.sigmoid(self.lambda_loc_raw)

    @property
    def ep_witness_scale(self) -> torch.Tensor:
        return F.softplus(self.ep_witness_raw)

    def _build_local(self, s0: torch.Tensor, s2: torch.Tensor, d: torch.Tensor) -> torch.Tensor:
        if self.mode == "h3_nos0":
            B, T, _, H, W = d.shape
            return self.loc_enc(d.flatten(0, 1)).view(B, T, self.d_loc, H, W)
        return self.loc_enc(s0, s2)

    def _build_target(self, x: torch.Tensor, h_loc: torch.Tensor) -> torch.Tensor:
        phys = compute_physical_descriptors(x)
        B, T, _, H, W = h_loc.shape
        with torch.no_grad():
            lat = self.target_proj(h_loc.detach().flatten(0, 1))
            lat = F.layer_norm(lat.permute(0, 2, 3, 1), (self.d_lat,)).permute(0, 3, 1, 2)
            lat = lat.view(B, T, self.d_lat, H, W)
        return torch.cat([phys, lat], dim=2)

    @staticmethod
    def _crf_flat(u: torch.Tensor, psi: torch.Tensor):
        B, T, K, H, W = u.shape
        uf = u.permute(0, 3, 4, 1, 2).reshape(-1, T, K).float()
        pf = psi.permute(0, 4, 5, 1, 2, 3).reshape(-1, T - 1, K, K).float()
        return uf, pf

    @staticmethod
    def _crf_log_partition(uf: torch.Tensor, pf: torch.Tensor) -> torch.Tensor:
        a = uf[:, 0]
        for t in range(1, uf.shape[1]):
            a = uf[:, t] + torch.logsumexp(a[:, :, None] + pf[:, t - 1], dim=1)
        return torch.logsumexp(a, dim=1)

    def crf_marginals(self, u: torch.Tensor, psi: torch.Tensor) -> torch.Tensor:
        B, T, K, H, W = u.shape
        uf, pf = self._crf_flat(u, psi)
        al = [uf[:, 0]]
        for t in range(1, T):
            al.append(uf[:, t] + torch.logsumexp(al[-1][:, :, None] + pf[:, t - 1], dim=1))
        be = [torch.zeros_like(uf[:, 0])]
        for t in range(T - 2, -1, -1):
            be.insert(0, torch.logsumexp(pf[:, t] + (uf[:, t + 1] + be[0])[:, None, :], dim=2))
        logZ = torch.logsumexp(al[-1], dim=1, keepdim=True)
        mg = torch.stack([al[t] + be[t] - logZ for t in range(T)], dim=1)
        return mg.view(B, H, W, T, K).permute(0, 3, 4, 1, 2).to(u.dtype)

    def crf_forward_filter(self, u: torch.Tensor, psi: torch.Tensor) -> torch.Tensor:
        B, T, K, H, W = u.shape
        uf, pf = self._crf_flat(u, psi)
        al = [uf[:, 0]]
        for t in range(1, T):
            al.append(uf[:, t] + torch.logsumexp(al[-1][:, :, None] + pf[:, t - 1], dim=1))
        filt = torch.stack([a - torch.logsumexp(a, dim=1, keepdim=True) for a in al], dim=1)
        return filt.view(B, H, W, T, K).permute(0, 3, 4, 1, 2).to(u.dtype)

    def forward(
        self,
        x: torch.Tensor,
        pos: torch.Tensor | None,
        s0: torch.Tensor,
        s2: torch.Tensor,
        d: torch.Tensor,
        u_ctx: torch.Tensor,
    ) -> dict:
        B, T, K, H, W = u_ctx.shape
        h_loc = self._build_local(s0, s2, d)
        e_all = self._build_target(x, h_loc)
        u_loc = self.ep_head(h_loc.flatten(0, 1)).view(B, T, K, H, W)

        unary = u_ctx + self.lambda_loc * u_loc

        tfeat = self.time_enc(pos, B, T, x.device, x.dtype)
        tmap = tfeat[:, :, :, None, None].expand(B, T - 1, -1, H, W).reshape(B * (T - 1), -1, H, W)

        h0 = h_loc[:, :-1].reshape(B * (T - 1), self.d_loc, H, W)
        h1 = h_loc[:, 1:].reshape(B * (T - 1), self.d_loc, H, W)
        e0 = e_all[:, :-1].reshape(B * (T - 1), self.d_e, H, W)
        e1 = e_all[:, 1:].reshape(B * (T - 1), self.d_e, H, W)
        de = e1 - e0

        normalcy_aux = None
        if self.mode == "h1":
            d0 = d[:, :-1].reshape(B * (T - 1), -1, H, W)
            d1 = d[:, 1:].reshape(B * (T - 1), -1, H, W)
            pair_in = torch.cat([h0, h1, h1 - h0, d0, d1, d1 - d0, de, tmap], dim=1)
            E = self.h1_pair(pair_in).view(B, T - 1, K, K, H, W)
            psi = self.trans_W.view(1, 1, K, K, 1, 1) + E
        elif self.mode == "h0":
            psi = self.trans_W.view(1, 1, K, K, 1, 1).expand(B, T - 1, K, K, H, W)
        elif self.mode == "hdir":
            u_w = self._witness_scores(u_loc)
            dir_in = torch.cat([h0, h1, h1 - h0, de, tmap], dim=1)
            E_dir = self.dir_head(dir_in).view(B, T - 1, K, K, H, W)
            ep_w = self.ep_witness_scale * (u_w[:, :-1, :, None, :, :] + u_w[:, 1:, None, :, :, :])
            eye = torch.eye(K, device=x.device, dtype=x.dtype).view(1, 1, K, K, 1, 1)
            off = 1.0 - eye
            stay = self.stay_bias.view(1, 1, K, 1, 1).expand(B, T - 1, K, H, W)
            diag_pot = torch.diag_embed(stay.permute(0, 1, 3, 4, 2)).permute(0, 1, 4, 5, 2, 3)
            psi = self.trans_W.view(1, 1, K, K, 1, 1) + diag_pot + off * (E_dir + ep_w)
        else:
            norm_in = torch.cat([h0, e0, tmap], dim=1)
            nf = self.norm_trunk(norm_in)
            mu_sh = e0 + self.norm_shared_mu(nf)
            lv_sh = self.norm_shared_lv(nf)

            if self.mode == "h2":
                lv_sh_c = lv_sh.clamp(-4.0, 3.0)
                mu_k = mu_sh[:, None].expand(-1, K, -1, -1, -1)
                lv_k = lv_sh_c[:, None].expand(-1, K, -1, -1, -1)
                res_mu = res_lv = None
            else:
                res_mu = self.norm_cls_mu(nf).view(-1, K, self.d_e, H, W)
                res_lv = self.norm_cls_lv(nf).view(-1, K, self.d_e, H, W)
                mu_k = mu_sh[:, None] + res_mu
                lv_k = (lv_sh[:, None] + res_lv).clamp(-4.0, 3.0)

            inv_var = torch.exp(-lv_k)
            sq_err = (e1[:, None] - mu_k) ** 2
            nll_per_dim = 0.5 * (sq_err * inv_var + lv_k)
            ll_stay = -nll_per_dim.mean(dim=2).clamp(-2.0, 8.0)
            ll_stay = ll_stay.view(B, T - 1, K, H, W)

            stay_scale = F.softplus(self.stay_scale_raw)
            stay_pot = stay_scale * ll_stay + self.stay_bias.view(1, 1, K, 1, 1)

            dir_in = torch.cat([h0, h1, h1 - h0, de, tmap], dim=1)
            E_dir = self.dir_head(dir_in).view(B, T - 1, K, K, H, W)
            u_w = self._witness_scores(u_loc)
            ep_w = self.ep_witness_scale * (
                u_w[:, :-1, :, None, :, :] + u_w[:, 1:, None, :, :, :]
            )

            eye = torch.eye(K, device=x.device, dtype=x.dtype).view(1, 1, K, K, 1, 1)
            off = 1.0 - eye
            diag_pot = torch.diag_embed(stay_pot.permute(0, 1, 3, 4, 2)).permute(0, 1, 4, 5, 2, 3)

            psi = self.trans_W.view(1, 1, K, K, 1, 1) + diag_pot + off * (E_dir + ep_w)

            normalcy_aux = {
                "nll_per_dim": nll_per_dim.view(B, T - 1, K, self.d_e, H, W),
                "res_mu": res_mu,
                "res_lv": res_lv,
            }

        decoded = self.crf_forward_filter(unary, psi) if self.causal else self.crf_marginals(unary, psi)
        return {
            "unary": unary,
            "psi": psi,
            "u_loc": u_loc,
            "logits": decoded,
            "normalcy": normalcy_aux,
        }

    def compute_losses(
        self,
        out: dict,
        y: torch.Tensor,
        cls_weight: torch.Tensor | None = None,
        w_crf: float = 1.0,
        w_ep: float = 0.5,
        w_norm: float = 0.3,
        w_res: float = 1e-3,
        ep_chg_boost: float = 2.0,
        crf_weighted: bool = True,
        crf_chg_boost: float = 2.5,
    ) -> tuple[torch.Tensor, dict]:
        """Compute aligned multi-objective losses:
          - crf_nll  : Class- & change-trajectory-weighted partial-label Linear-Chain CRF NLL
          - ep_ce    : Independent single-date endpoint CE (change-endpoint boosted)
          - norm_nll : Class-balanced heteroscedastic Gaussian NLL strictly on stable pairs
          - res_reg  : Mild L2 shrinkage on class normalcy residuals
        """
        B, T, H, W = y.shape
        device = y.device
        dtype = out["unary"].dtype
        ignore = self.ignore_index
        cw = cls_weight.to(device=device, dtype=dtype) if cls_weight is not None else None

        parts = {}
        total = torch.zeros((), device=device, dtype=dtype)

        # 1) Weighted partial-label Linear-Chain CRF NLL
        uf, pf = self._crf_flat(out["unary"], out["psi"])
        yy = y.permute(0, 2, 3, 1).reshape(-1, T)
        lab = yy != ignore
        keep = lab.any(dim=1)
        if keep.any():
            uf_k, pf_k, yy_k, lab_k = uf[keep], pf[keep], yy[keep], lab[keep]
            gold = F.one_hot(yy_k.clamp(0, self.K - 1), self.K).bool()
            uc = torch.where(lab_k[..., None] & ~gold, torch.full_like(uf_k, -1e4), uf_k)
            nll_seq = (self._crf_log_partition(uf_k, pf_k) - self._crf_log_partition(uc, pf_k))  # [N]

            if crf_weighted:
                # Per-sequence weight = mean official class weight over valid steps * change-trajectory boost
                seq_w = torch.ones_like(nll_seq)
                if cw is not None:
                    cw_f = cw.float()
                    w_t = cw_f[yy_k.clamp(0, self.K - 1)] * lab_k.float()
                    seq_w = w_t.sum(dim=1) / lab_k.float().sum(dim=1).clamp_min(1.0)
                if T > 1 and crf_chg_boost != 1.0:
                    has_chg = ((yy_k[:, 1:] != yy_k[:, :-1]) & lab_k[:, 1:] & lab_k[:, :-1]).any(dim=1)
                    seq_w = torch.where(has_chg, seq_w * float(crf_chg_boost), seq_w)
                crf_nll = ((nll_seq * seq_w).sum() / seq_w.sum().clamp_min(1e-6)).to(dtype)
            else:
                crf_nll = nll_seq.mean().to(dtype)

            parts["crf_nll"] = crf_nll
            total = total + w_crf * crf_nll

        # 2) Independent single-date endpoint CE
        u_loc = out["u_loc"]
        v = y != ignore
        chg_step = (y[:, 1:] != y[:, :-1]) & v[:, 1:] & v[:, :-1]
        is_ep = torch.zeros_like(v)
        is_ep[:, 1:] |= chg_step
        is_ep[:, :-1] |= chg_step
        lmap = F.cross_entropy(
            u_loc.flatten(0, 1),
            y.flatten(0, 1),
            weight=None if self.cw_once else cw,  # 修正 1：类别权只在下面的像元权里乘一次
            ignore_index=ignore,
            reduction="none",
        ).view(B, T, H, W)
        pw = torch.where(is_ep, torch.full_like(lmap, ep_chg_boost), torch.ones_like(lmap)) * v.to(dtype)
        if cw is not None:
            pw = pw * cw[y.clamp(0, self.K - 1)]
        ep_ce = (lmap * pw).sum() / pw.sum().clamp_min(1.0)
        parts["ep_ce"] = ep_ce
        total = total + w_ep * ep_ce

        # 3) Explicit Heteroscedastic Normalcy NLL strictly on true STABLE pairs (y_{t-1} == y_t == a)
        norm = out.get("normalcy")
        if norm is not None and w_norm > 0:
            nll_map = norm["nll_per_dim"].mean(dim=3)
            y0, y1 = y[:, :-1], y[:, 1:]
            stable = (y0 == y1) & (y0 != ignore) & (y1 != ignore)
            if stable.any():
                idx = y0.clamp(0, self.K - 1).unsqueeze(2)
                nll_gt = nll_map.gather(2, idx).squeeze(2)
                cls_losses = []
                for c in range(self.K):
                    mc = stable & (y0 == c)
                    if mc.any():
                        cls_losses.append(nll_gt[mc].mean())
                if cls_losses:
                    norm_nll = torch.stack(cls_losses).mean()
                    parts["norm_nll"] = norm_nll
                    total = total + w_norm * norm_nll

            if norm.get("res_mu") is not None and w_res > 0:
                res_reg = (norm["res_mu"] ** 2).mean() + (norm["res_lv"] ** 2).mean()
                parts["res_reg"] = res_reg
                total = total + w_res * res_reg

        parts["head_total"] = total
        return total, parts
