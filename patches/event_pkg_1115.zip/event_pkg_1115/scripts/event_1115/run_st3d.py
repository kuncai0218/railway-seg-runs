# -*- coding: utf-8 -*-
"""T22：原样执行 scripts/st3d_repro.py 的 main()（参数原样传入），只在执行前装上 _env_fix 的占位（本机 scipy.signal 被策略拦截时才生效）。
用“导入后调用 main()”而不是 runpy：Windows 下数据加载的子进程会重新导入主模块，这样子进程导入的是本文件（先装占位），不会再撞上拦截。
不改 st3d_repro.py 的任何内容；其他机器上与直接运行 st3d_repro.py 完全相同。"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import _env_fix  # noqa: E402,F401

if __name__ == "__main__":
    import st3d_repro  # noqa: E402
    sys.argv[0] = os.path.abspath(st3d_repro.__file__)
    st3d_repro.main()
