"""ST3DUNet（Xie 等，IEEE TGRS 2026）官方代码复现（11-03 写）。模型、数据集类、损失、指标、优化器全部直接 import 官方仓库
（code\\ST3DUNet，提交 840f76e），只改下面几处：

1. 官方 train_epochs 写日志时引用了不存在的 self.best_score，第 1 轮结束就会报错 → 本脚本自己写训练循环，逐步调用官方 train_one_epoch。
2. 官方代码建了 CosineAnnealingLR 却从未调用 scheduler.step()，实际是恒定学习率（main.py 默认 1e-3，权重衰减 1e-3）；
   论文写的是 1e-4 余弦降到 1e-6、250 轮。用 --sched 选：code = 与公开代码行为一致（恒定）；paper = 每轮 step 一次余弦。
3. 评测加载器加多进程读图（官方 num_workers=0；评测无随机性，数值不变）；训练加载器 persistent_workers（Windows 下每轮不重新拷数据）。
3a. 官方损失把 MUDS 的类别权重写死在 cuda:2 上（单卡机器报错），改建在 CPU，数值不变。
3b. 官方 LTAE3D.forward 引用了从未赋值的 self.attn_mode（第一次前向就报错）；只有 "ltae" 分支的输出形状与下游一致，故设为 "ltae"。
3c. 从解码缓存读（den_st3d_cache.py / muds_st3d_cache.py 解码，再由 st3d_blockify.py 转成 128² 分块布局，机械盘上随机裁块也快；
    官方类每个 128 小块要解码 16 张 1024² JPEG，只有 2.6 步/秒）。缓存类继承官方类，
    日期扰动、裁剪、翻转、旋转、缩放裁剪的随机数调用顺序与官方逐个相同，只是先裁剪再转浮点；st3d_cache_check.py 逐样本核对与官方完全相等。
    cudnn 用 benchmark 模式（官方是 deterministic；纯模型 8.8 对 6.1 步/秒），不影响方法本身。
4. 官方只在 split="val" 上评测（同区域 = 训练区右下角 (7,7)(6,6) 两块；跨区域 = 10 个验证区全图），并在同一集合上按 mIoU 选最好的一轮
   报告。本脚本照做（val 逐轮记录、存 best_in / best_out），另外训练结束后用这两个检查点和最后一轮在官方测试集
   （split="test"：同区域 (7,6)(6,7) 两块；跨区域 = 10 个测试区）上再评一次，即“验证集选、测试集报”。
用法：python -X utf8 st3d_repro.py --data dynamicearthnet --seed 42 --sched paper --epochs 250 --lr 1e-4 --out <目录>
     加 --bench 200 只跑 200 步训练 + 一次完整评测，用来测速和显存。
"""
import argparse
import json
import os
import random
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

REPO = os.environ.get("ST3D_REPO", r"D:\Railway_project\work\公开数据_1102\code\ST3DUNet")  # 路径可用环境变量覆盖（云服务器）
DATA_ROOT = os.environ.get("ST3D_DATA", r"D:\sitsscd_data")
CACHE_ROOT = os.environ.get("ST3D_CACHE", r"D:\st3d_cache")
sys.path.insert(0, REPO)
from data.data import DynamicEarthNet, Muds, collate_fn  # noqa: E402
from data.transforms import random_fliph, random_flipv, random_resize_crop, random_rotate  # noqa: E402
from metrics.scd_metrics import SCDMetric  # noqa: E402
from models.losses import Losses  # noqa: E402
from models.ltae3d import LTAE3D  # noqa: E402
from train import SitsScdWrapper  # noqa: E402
from utils.wrapper import load_model, load_yaml  # noqa: E402

LTAE3D.attn_mode = "ltae"

import models.losses as _official_losses  # noqa: E402

_ce_init = _official_losses.CrossEntropyLoss.__init__


def _ce_init_fixed(self, ignore_index=None):
    """官方把 MUDS（ignore_index=2）的类别权重 [0.25, 0.75] 写死在 cuda:2 上，单卡机器直接报错；
    改建在 CPU 上（forward 里本来就会搬到 logits 所在设备），数值不变。DEN 走官方原逻辑。"""
    if ignore_index != 2:
        return _ce_init(self, ignore_index)
    torch.nn.Module.__init__(self)
    self.ignore_index = ignore_index
    self.register_buffer("class_weights", torch.tensor([0.25, 0.75], dtype=torch.float32))
    self.loss = torch.nn.CrossEntropyLoss(weight=self.class_weights, ignore_index=ignore_index)


_official_losses.CrossEntropyLoss.__init__ = _ce_init_fixed

DATA = {"dynamicearthnet": (DynamicEarthNet, os.path.join(DATA_ROOT, "DynamicEarthNet")), "muds": (Muds, os.path.join(DATA_ROOT, "Muds"))}
CACHE = {"dynamicearthnet": os.path.join(CACHE_ROOT, "DynamicEarthNet"), "muds": os.path.join(CACHE_ROOT, "Muds")}


class _Lazy:
    def __init__(self, mm, rows, keep=None):
        self.mm, self.rows, self.keep = mm, rows, keep


_GT = {}


class _CachedCrop:
    """官方数据集类只把读图换成从解码缓存裁小块：随机数调用顺序与官方 load_data → transform 相同，只是先裁剪再转浮点。
    另外同一组区域的标签只载入一份（官方类载两遍，同区域验证/测试又各存一份训练区标签，单进程 12 GB，两个进程就把提交内存用完）。"""

    def load_ground_truth(self, split):
        key = (self.path, split if self.domain_shift else "train")
        if key not in _GT:
            _GT[key] = super().load_ground_truth(split)
        return _GT[key]

    def _open(self, cache_root, sits_id):  # 分块布局 [8, 8, 期, 128, 128, 通道]（st3d_blockify.py；机械盘上随机裁块快）
        if not hasattr(self, "_mm"):
            self._mm, self.cache_dir = {}, os.path.join(cache_root, self.split if self.domain_shift else "train")
        if sits_id not in self._mm:
            self._mm[sits_id] = np.load(os.path.join(self.cache_dir, sits_id + ".blk.npy"), mmap_mode="r")
        return self._mm[sits_id]

    def __getstate__(self):  # 传给读数子进程时不带已打开的内存映射（否则会整块拷贝）
        st = self.__dict__.copy()
        st.pop("_mm", None)
        return st

    @staticmethod
    def _crop(mm, rows, i, j, s):
        b = mm.shape[3]
        bi, bj = range(i // b, (i + s - 1) // b + 1), range(j // b, (j + s - 1) // b + 1)
        region = np.empty((len(rows), len(bi) * b, len(bj) * b, mm.shape[5]), dtype=np.uint8)
        for a, r in enumerate(bi):
            for c, q in enumerate(bj):
                region[:, a * b:(a + 1) * b, c * b:(c + 1) * b] = mm[r, q, rows]
        y0, x0 = i - bi[0] * b, j - bj[0] * b
        return region[:, y0:y0 + s, x0:x0 + s].transpose(0, 3, 1, 2)  # T C H W

    def transform(self, data, gt=None, patch_loc_i=None, patch_loc_j=None):
        s, n = self.img_size, self.true_size
        if self.split == "train":  # 同官方 random_crop 的两次 randint
            i = random.randint(0, n - s - 1)
            j = random.randint(0, n - (1 + 2 * int(i >= n - 3 * s)) * s - 1)
        else:
            i, j = patch_loc_i * s, patch_loc_j * s
        x = torch.from_numpy(np.ascontiguousarray(self._crop(data.mm, data.rows, i, j, s))).float()
        if data.keep is not None:  # MUDS：不在可用月份表里的月份，官方类留 0
            x[~torch.tensor(data.keep)] = 0
        gt = gt[..., i:i + s, j:j + s]
        if self.split == "train":
            x, gt = random_fliph(x, gt)
            x, gt = random_flipv(x, gt)
            x, gt = random_rotate(x, gt)
            x, gt = random_resize_crop(x, gt)
        return x, gt


class DENCached(_CachedCrop, DynamicEarthNet):
    def __init__(self, cache_root, **kw):
        super().__init__(**kw)
        self.cache_root = cache_root
        d = os.path.join(cache_root, self.split if self.domain_shift else "train")
        self.day_pos = {x: k for k, x in enumerate(json.load(open(os.path.join(d, "index.json")))["days"])}

    def load_data(self, sits_number, sits_id, months, curr_sits_path):
        days = [self.random_date_augmentation(month) for month in months]
        mm = self._open(self.cache_root, sits_id)
        return _Lazy(mm, [self.day_pos[x] for x in days]), days, [f"{sits_id}_{x}_rgb.jpeg" for x in days]


class MudsCached(_CachedCrop, Muds):
    def __init__(self, cache_root, **kw):
        super().__init__(**kw)
        self.cache_root = cache_root

    def load_data(self, sits_number, sits_id, months, curr_sits_path):
        keep = [m in self.month_list[sits_number] for m in months]
        days = [self.monthly_dates[m] for m in months]
        return _Lazy(self._open(self.cache_root, sits_id), list(months), keep), days, [f"{sits_id}_{self.month_string[m]}.jpg" for m in months]


def seed_all(seed, deterministic=False):  # 同官方 main.seed_all；cudnn 模式见文件头 3c
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = deterministic
    torch.backends.cudnn.benchmark = not deterministic


def make_set(cfg, split, domain_shift=None, cache=True):
    d = cfg["dataset"]
    name = d["name"].lower()
    kw = dict(path=d["path"], split=split, num_channels=d["num_channels"], num_classes=d["num_classes"], img_size=d["image_size"],
              true_size=d["true_size"], train_length=d["seq_len"], date_aug_range=d["data_aug_range"], sampling_mode=d["sampling_mode"])
    if domain_shift is not None:
        kw["domain_shift"] = domain_shift
    if cache and name in CACHE:
        return {"dynamicearthnet": DENCached, "muds": MudsCached}[name](CACHE[name], **kw)
    return DATA[name][0](**kw)


class CtxDrop(torch.utils.data.Dataset):
    """训练时随机去掉时间上下文（11-04 加；方法原型）：每个样本以概率 p 换成“第 j 期影像重复 T 次、标签也取第 j 期”，
    日期保持原样。这样同一个网络既学会带上下文判，也学会只凭一期判（推理时 st3d_dump.py 的 static 方式即对应后者）。
    p=0 时与原训练完全相同；随机数用 Python random（读数子进程各自独立播种）。
    只从有有效标签的期里抽 j：MUDS 缺测月份整期标签都是忽略值，抽中它会让整个样本没有监督，一批全是这样时损失为 nan
    （11-04 实测 1 轮 loss=nan、模型塌成全判背景，即此原因）；一期有效标签都没有时不替换。"""

    def __init__(self, base, p, ignore_index):
        self.base, self.p, self.ign = base, p, ignore_index

    def __len__(self):
        return len(self.base)

    def __getitem__(self, i):
        out = self.base[i]
        if self.p > 0 and random.random() < self.p:
            T = out["data"].shape[0]
            ok = [t for t in range(T) if bool((out["gt"][t] != self.ign).any())]
            if not ok:
                return out
            j = random.choice(ok)
            out["data"] = out["data"][j:j + 1].expand(T, *out["data"].shape[1:]).clone()
            out["gt"] = out["gt"][j:j + 1].expand(T, *out["gt"].shape[1:]).clone()
        return out


class TempPaste(torch.utils.data.Dataset):
    """时间维剪贴增强（11-05 加；方法原型）：以概率 p，从**同一训练区、同一批月份**的另一个随机裁块 B 里，
    取某一期 t0 上某个地类的形状（B 的真值里该类在一个随机窗口内的像元），把 B 在这些像元上的影像和真值贴到当前样本 A：
    70% 贴到 t0 及以后各期（持续变化），30% 只贴 t0 起的 1—2 期（往返变化）。
    同区域同月份，光照和季节一致，模型难以靠拼贴痕迹偷懒；目的是让训练中出现更多、更多样的真实外观变化，
    避免学到“这里几乎不变”的僵硬时间先验（诊断：跨区域时上下文把真实变化压掉）。只用于训练集；p=0 时与原训练相同。"""

    def __init__(self, base, p, ignore_index, per_tile):
        self.base, self.p, self.ign, self.per = base, p, ignore_index, per_tile

    def __len__(self):
        return len(self.base)

    def __getitem__(self, i):
        out = self.base[i]
        if self.p <= 0 or random.random() >= self.p:
            return out
        tile = i // self.per
        b = self.base[tile * self.per + random.randrange(self.per)]  # 同一区、同一批月份的另一个随机裁块（含它自己的随机增强）
        T, H, W = out["gt"].shape
        t0 = random.randrange(1, T)
        frames = list(range(t0, T)) if random.random() < 0.7 else list(range(t0, min(T, t0 + random.randint(1, 2))))
        s = random.randint(H // 8, H // 2)
        y0, x0 = random.randrange(0, H - s + 1), random.randrange(0, W - s + 1)
        win = b["gt"][t0, y0:y0 + s, x0:x0 + s]
        cls = [int(c) for c in torch.unique(win) if int(c) != self.ign]
        if not cls:
            return out
        k = random.choice(cls)
        mask = torch.zeros(H, W, dtype=torch.bool)
        mask[y0:y0 + s, x0:x0 + s] = win == k
        if mask.sum() < 16:
            return out
        data, gt = out["data"].clone(), out["gt"].clone()
        for t in frames:
            data[t][:, mask] = b["data"][t][:, mask]
            gt[t][mask] = b["gt"][t][mask]
        out["data"], out["gt"] = data, gt
        return out


def build_model(cfg, arch="st3d"):
    model = load_model(cfg)
    if arch == "mono":
        from st3d_mono import make_mono
        model = make_mono(model)
    return model


def load_run_model(ckpt_path, device="cuda"):
    """按运行目录里的 config.json 建模（数据集、原版 / 单期）并载入检查点；返回 (model, cfg, data, 轮次)。"""
    conf = json.load(open(os.path.join(os.path.dirname(os.path.abspath(ckpt_path)), "config.json"), encoding="utf-8"))
    args = conf["args"]
    cfg = load_yaml(os.path.join(REPO, "configs", f"{args['data']}.yaml"))
    cfg["dataset"]["path"] = DATA[args["data"]][1]
    model = build_model(cfg, args.get("arch", "st3d")).to(device)
    ck = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(ck["model"])
    model.eval()
    return model, cfg, args["data"], ck.get("epoch")


@torch.no_grad()
def run_eval(model, loader, metric, device):
    """与官方 SitsScdWrapper.evaluate 的单个集合部分逐行一致，只是把指标返回出来。"""
    model.eval()
    metric.reset()
    for batch in loader:
        x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
        pred = model(x, date).argmax(2).view_as(y)
        metric.update(pred.cpu(), y.cpu())
    return {k: float(v) for k, v in metric.compute().items()}


def rb_logits(model, x, date, rb, idx):
    """区当标注者（--rbias）：每个训练区一组类别偏置，减去各区平均后加到输出上（平均标法由主干承担）。"""
    out = model(x, date)  # [B, T, K, H, W]
    b = rb - rb.mean(0, keepdim=True)
    return out + b[idx][:, None, :, None, None], b


def train_epoch_rb(model, loader, wrapper, optimizer, rb, lam, device, epoch, max_steps=None):
    """同官方 train_one_epoch，只多了区偏置与其 L2 惩罚。"""
    model.train()
    sums, n = {}, 0
    for step, batch in enumerate(loader):
        if max_steps and step >= max_steps:
            break
        x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
        idx = torch.as_tensor(batch["idx"], device=device).long()
        logits, b = rb_logits(model, x, date, rb, idx)
        losses = wrapper.compute_loss(pred=logits, batch=y, average=True)
        pen = lam * (b ** 2).sum(1).mean()
        loss = losses["loss"] + pen
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        for k, v in {**losses, "rb_pen": pen}.items():
            sums[k] = sums.get(k, 0.0) + float(v.detach())
        n += 1
        if (step + 1) % max(1, len(loader) // 3) == 0:
            print(f"[Epoch {epoch}] Step [{step + 1}/{len(loader)}], loss: {float(loss):.4f}, 区偏置幅度 {float(b.abs().mean()):.3f}", flush=True)
    return {k: v / max(n, 1) for k, v in sums.items()}


@torch.no_grad()
def run_eval_rb(model, loader, metric, device, b):
    """同 run_eval，但给每个样本加上它所在训练区学到的偏置（只用于同区域验证集）。"""
    model.eval()
    metric.reset()
    for batch in loader:
        x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
        idx = torch.as_tensor(batch["idx"], device=device).long()
        pred = (model(x, date) + b[idx][:, None, :, None, None]).argmax(2).view_as(y)
        metric.update(pred.cpu(), y.cpu())
    return {k: float(v) for k, v in metric.compute().items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="dynamicearthnet")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=None, help="默认用官方配置（DEN 500、MUDS 100）")
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--wd", type=float, default=1e-3)
    ap.add_argument("--sched", choices=["code", "paper"], default="code")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--eval_workers", type=int, default=0)
    ap.add_argument("--eval_batch", type=int, default=1, help="评测批大小（推理时 BatchNorm 用固定统计量，结果与批大小无关）")
    ap.add_argument("--bench", type=int, default=0)
    ap.add_argument("--test_every", type=int, default=1, help="每几轮顺带在测试集上评一次（只记录，不参与选模）")
    ap.add_argument("--no_cache", action="store_true")
    ap.add_argument("--deterministic", action="store_true")
    ap.add_argument("--arch", choices=["st3d", "mono"], default="st3d", help="mono = 同网络去掉一切时间运算（st3d_mono.py，论文图 12 的单期版）")
    ap.add_argument("--ctx_drop", type=float, default=0.0, help="训练时以此概率把样本换成单期重复（CtxDrop，方法原型）；0 = 原训练")
    ap.add_argument("--tpaste", type=float, default=0.0, help="训练时以此概率做时间维剪贴增强（TempPaste，方法原型）；0 = 原训练")
    ap.add_argument("--rbias", type=float, default=0.0, help="区当标注者：每个训练区一组类别偏置的 L2 惩罚系数；0 = 不用（11-07 方法原型）")
    ap.add_argument("--rbias_lr_mult", type=float, default=10.0, help="区偏置的学习率倍数")
    ap.add_argument("--max_steps", type=int, default=0, help="冒烟测试：每轮只跑这么多步")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    cfg = load_yaml(os.path.join(REPO, "configs", f"{a.data}.yaml"))
    cfg["dataset"]["path"] = DATA[a.data][1]
    epochs = a.epochs or cfg["trainer"]["max_epochs"]
    device = "cuda:0"
    os.makedirs(a.out, exist_ok=True)
    json.dump({"args": vars(a), "epochs": epochs, "cfg": cfg}, open(os.path.join(a.out, "config.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    seed_all(a.seed, a.deterministic)

    t0 = time.time()
    cache = not a.no_cache
    trainset = make_set(cfg, "train", cache=cache)
    if a.tpaste > 0:
        trainset = TempPaste(trainset, a.tpaste, cfg["dataset"]["ignore_index"], len(trainset) // len(trainset.sits_ids))
    if a.ctx_drop > 0:
        trainset = CtxDrop(trainset, a.ctx_drop, cfg["dataset"]["ignore_index"])
    sets = {"val_in": make_set(cfg, "val", False, cache), "val_out": make_set(cfg, "val", True, cache),
            "test_in": make_set(cfg, "test", False, cache), "test_out": make_set(cfg, "test", True, cache)}
    print(f"数据载入 {time.time() - t0:.0f} 秒；训练 {len(trainset)}，" + "，".join(f"{k} {len(v)}" for k, v in sets.items()), flush=True)
    bs = cfg["dataset"]["global_batch_size"]
    train_loader = DataLoader(trainset, batch_size=bs, shuffle=True, drop_last=True, pin_memory=False, num_workers=a.workers,
                              collate_fn=collate_fn, persistent_workers=a.workers > 0)
    loaders = {k: DataLoader(v, batch_size=a.eval_batch, shuffle=False, pin_memory=False, num_workers=a.eval_workers, collate_fn=collate_fn,
                             persistent_workers=a.eval_workers > 0) for k, v in sets.items()}

    model = build_model(cfg, a.arch)
    print(f"参数量 {sum(p.numel() for p in model.parameters() if p.requires_grad) / 1e6:.2f} M", flush=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=a.wd)
    rb = None
    if a.rbias > 0:
        rb = torch.nn.Parameter(torch.zeros(len(trainset.sits_ids), cfg["dataset"]["num_classes"], device=device))
        optimizer.add_param_group({"params": [rb], "lr": a.lr * a.rbias_lr_mult, "weight_decay": 0.0})
        print(f"区当标注者：{len(trainset.sits_ids)} 个训练区 × {cfg['dataset']['num_classes']} 类偏置，λ={a.rbias}", flush=True)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=a.lr * 0.01, last_epoch=-1)
    metric = SCDMetric(num_classes=cfg["dataset"]["num_classes"], ignore_index=cfg["dataset"]["ignore_index"],
                       class_names=cfg["dataset"]["class_names"])
    wrapper = SitsScdWrapper(model=model, loss_fn=Losses(mix=cfg["loss"]["mix"], ignore_index=cfg["loss"]["ignore_index"]),
                             val_metrics=metric, trainloader=train_loader, testloader_in=loaders["val_in"],
                             testloader_out=loaders["val_out"], optimizer=optimizer, scheduler=scheduler, device=device,
                             seq_len=cfg["dataset"]["seq_len"], save_ckpt_path=a.out, save_log_path=a.out)

    if a.bench:
        torch.cuda.reset_peak_memory_stats()
        it = iter(train_loader)
        model.train()
        t1 = time.time()
        for step in range(a.bench):
            batch = next(it)
            x, y, date = batch["data"].to(device), batch["gt"].to(device), batch["positions"].to(device)
            loss = wrapper.compute_loss(pred=model(x, date), batch=y, average=True)["loss"]
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            if step == 19:
                torch.cuda.synchronize()
                t1 = time.time()
        torch.cuda.synchronize()
        sps = (a.bench - 20) / (time.time() - t1)
        res = {"训练 步/秒": round(sps, 2), "每轮步数": len(train_loader), "每轮训练分钟": round(len(train_loader) / sps / 60, 1),
               "训练显存峰值 GB": round(torch.cuda.max_memory_allocated() / 2 ** 30, 2), "loss": float(loss)}
        for k in ("val_in", "val_out"):
            t2 = time.time()
            m = run_eval(model, loaders[k], metric, device)
            res[f"{k} 评测分钟"] = round((time.time() - t2) / 60, 2)
            res[f"{k} miou"] = round(m["miou"], 2)
        print(json.dumps(res, ensure_ascii=False), flush=True)
        json.dump(res, open(os.path.join(a.out, "bench.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        return

    log = open(os.path.join(a.out, "epochs.jsonl"), "a", encoding="utf-8")
    best, start = {"in": -1.0, "out": -1.0}, 1
    if os.path.exists(os.path.join(a.out, "last.pth")):  # 断点续跑（Python random 状态不恢复）
        ck = torch.load(os.path.join(a.out, "last.pth"), map_location=device)
        model.load_state_dict(ck["model"])
        optimizer.load_state_dict(ck["optimizer"])
        scheduler.load_state_dict(ck["scheduler"])
        best, start = ck["best"], ck["epoch"] + 1
        if rb is not None and "rb" in ck:
            rb.data.copy_(ck["rb"])
        print(f"从第 {start} 轮接着跑", flush=True)
    for epoch in range(start, epochs + 1):
        t1 = time.time()
        if rb is not None:
            model.to(device)
            losses = train_epoch_rb(model, train_loader, wrapper, optimizer, rb, a.rbias, device, epoch, a.max_steps or None)
        else:
            losses = wrapper.train_one_epoch(epoch)  # 官方训练一轮
        if a.sched == "paper":
            scheduler.step()
        rec = {"epoch": epoch, "lr": optimizer.param_groups[0]["lr"], "loss": losses.get("loss"), "train_min": round((time.time() - t1) / 60, 2)}
        if rb is not None:
            rec["rb_pen"] = losses.get("rb_pen")
            rec["rb_abs"] = float((rb - rb.mean(0)).abs().mean())
        for io in ("in", "out"):  # 官方选模规则：val 上 mIoU 创新高就存 best_{io}
            m = run_eval(model, loaders[f"val_{io}"], metric, device)
            rec[f"val_{io}"] = m
            if m["miou"] > best[io]:
                best[io] = m["miou"]
                torch.save({"model": model.state_dict(), "epoch": epoch, "val": m}, os.path.join(a.out, f"best_{io}.pth"))
        if a.test_every and epoch % a.test_every == 0:
            for io in ("in", "out"):
                rec[f"test_{io}"] = run_eval(model, loaders[f"test_{io}"], metric, device)
        if epoch % cfg["trainer"]["ckpt_interval"] == 0:  # 同官方每 10 轮存一次
            torch.save({"model": model.state_dict(), "epoch": epoch}, os.path.join(a.out, f"epoch{epoch}.pth"))
        rec["min"] = round((time.time() - t1) / 60, 2)
        log.write(json.dumps(rec, ensure_ascii=False) + "\n")
        log.flush()
        print(f"第 {epoch} 轮 loss {rec['loss']:.4f} val_in mIoU {rec['val_in']['miou']:.2f} SCS {rec['val_in']['scs']:.2f} | "
              f"val_out mIoU {rec['val_out']['miou']:.2f} SCS {rec['val_out']['scs']:.2f} | {rec['min']} 分钟", flush=True)
        torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(), "scheduler": scheduler.state_dict(),
                    "epoch": epoch, "best": best, **({"rb": rb.detach().cpu()} if rb is not None else {})}, os.path.join(a.out, "last.pth"))

    final = {}
    # --test_every 0（方法开发阶段，评价规范第 6 条）：结束时也只评验证集，测试集等冻结后用 st3d_dump.py 显式跑一次
    final_sets = ("val_in", "val_out", "test_in", "test_out") if a.test_every else ("val_in", "val_out")
    for name in ("best_in", "best_out", "last"):
        ck = torch.load(os.path.join(a.out, f"{name}.pth"), map_location=device)
        model.load_state_dict(ck["model"])
        final[name] = {"epoch": ck["epoch"]}
        for k in final_sets:
            final[name][k] = run_eval(model, loaders[k], metric, device)
        if rb is not None and name == "last":  # 同区域：再用本区学到的偏置评一次（区已知时的上限）
            assert list(sets["val_in"].sits_ids) == list(trainset.sits_ids), "同区域验证集的区顺序与训练集不同"
            b = (rb - rb.mean(0)).detach()
            final[name]["val_in_rb"] = run_eval_rb(model, loaders["val_in"], metric, device, b)
            torch.save(b.cpu(), os.path.join(a.out, "rbias.pt"))
    json.dump(final, open(os.path.join(a.out, "final.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("完成", flush=True)


if __name__ == "__main__":
    main()
