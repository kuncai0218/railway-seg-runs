# WorkBuddy 执行手册（Phase 0 最小消融 + Phase 1/2 新模型 SNT）

> **生成时间**：2026-11-22 23:52 ｜ **主线维护**：Antigravity ｜ **运维执行**：WorkBuddy  
> **硬纪律**：
> 1. 严禁修改 `scripts/t34_1119/` 下任何冻结文件（`train_t34.py`、`pse_net.py`、`extra_metrics.py`、`test_last.py`）；
> 2. 本机 RTX 3090（Windows）**严禁同时跑两个训练进程**；云端 RTX 5090（Linux）最多 **2 路并行**；
> 3. Phase 1 和 Phase 2 **严禁传入 `--run_official_test`**（默认已锁死不碰 official test，只评 `val_in` / `val_out`）。

---

## 一、今晚立即执行（Phase 0：结清旧账 + 闭合 `PSE+BN` 2×2 因子表）

### 任务 W1：云端 RTX 5090 (`connect.westd:34043`) 瘦身提速
1. 先跑 `/root/autodl-tmp/envs/t34_cu128/bin/python /root/autodl-tmp/t34/cloud/abl_status.py` 记下 6 作业当前轮次；
2. **停止** `abl_A4_s42`、`abl_A4_s43`（不删目录）；
3. **暂停** `abl_A2_s42`、`abl_A2_s43`（**务必保留 `last.pth`**，需要时可 `--resume`）；
4. **保持运行** `abl_A1_s42`、`abl_A1_s43`（2 路并行，单轮将回落至 ~3.5–4 分钟）；
5. 等 `abl_A1_s42/s43` 到 **第 120 轮** 后，记录前 120 轮最优轮次并跑一次中期评测，更新 `R34_进度.md`。

### 任务 W2：核查并回收同学乙 `Orig + GN s44`
- 查乙的 ntfy 状态与附件；完成后校验 SHA256、拷入 `补充指标/`，重跑 `table_3way.py`。

### 任务 W3：本机 RTX 3090 自动收尾 `den_s2_orig_s44` → 单作业接跑 `PSE + BN s42`（120 轮）
直接启动已写好的守候脚本（不抢当前 GPU，等 `den_s2_orig_s44` 01:45 跑完后再自动跑 `finish_moved_1122.py` 和 `PSE+BN s42`）：
```powershell
D:\Railway_project\envs\st3dunet_paper_1119\Scripts\python.exe -u -X utf8 `
  D:\Railway_project\work\公开数据_1102\scripts\snt_1123\phase0_psebn\run_local_after_s2_s44.py `
  > D:\Railway_project\work\公开数据_1102\runs_t34\phase0_local_handoff.log 2>&1
```
- 预计时间：01:45 收尾 `den_s2_orig_s44`（~15 分钟）→ 02:00 冒烟 + 跑 `PSE+BN s42`（120 轮，`T_max=250`，~4 小时）→ **明早 06:15 完成**。

### 任务 W4：向当前空闲的同学甲派发 `PSE + BN s43`（120 轮，严格同机配对）
- 从 `pkg_phase0_psebn_1122.zip` 取出 `train_t34_psebn_peer.py` 与 `extra_metrics_psebn.py`，放入甲现有的 `t34_peer_1119/` 目录（与 `pse_net.py`、`st3d_repro.py`、`upstream/` 同级）；
- 环境变量沿用甲原有 `T34_DATA`、`T34_CACHE`，按既有仓库 + ntfy 流程下发：
```bash
# 1) 冒烟（2轮×20步）
python -B -u -X utf8 train_t34_psebn_peer.py --seed 43 --method pse --smoke_steps 20 --out runs/smoke_psebn_s43
# 2) 正式跑 120 轮（保持 T_max=250 余弦学习率曲线不变）
python -B -u -X utf8 train_t34_psebn_peer.py --seed 43 --method pse --stop_epoch 120 --out runs/abl_psebn_s43
# 3) 补充指标（selected + epoch120）
python -u -X utf8 extra_metrics_psebn.py --entry train_t34_psebn_peer.py --out runs/abl_psebn_s43 --seed 43 --stop_epoch 120 --save runs/planet_psebn_s43_ep120.json
```
- 完成后经 ntfy 附件回传 `official_test.json`、`test_selected_checkpoints.json`、`epochs.json`、`planet_psebn_s43_ep120.json`。

---

## 二、明早决策门 1 之后执行（Phase 1：新模型 SNT 冻结底座 4 组公平单挑）

> 先把 `pkg_phase12_snt_1123.zip` 上传解压到云端 `/root/autodl-tmp/t34/snt_1123/`（本机已在 `D:\Railway_project\work\公开数据_1102\scripts\snt_1123\`）。  
> 根据明早决策门 1 的裁决，将 `<BB_CKPT_42>` / `<BB_CKPT_43>` 和 `<BB_OPTS>` 设为最终底座（PSE 用 `""`，A1 用 `"event=0,gate=0"`）。

### 本机 RTX 3090（串行跑 `s42`，每组 60 轮约 1.5–2h，共 ~5.5h）
```powershell
$PY = "D:\Railway_project\envs\st3dunet_paper_1119\Scripts\python.exe"
$SNT = "D:\Railway_project\work\公开数据_1102\scripts\snt_1123\train_snt.py"
$BB42 = "D:\Railway_project\work\公开数据_1102\runs_t34\den_planet_pse_s42\epoch022.pth" # 若选 A1 则换为 A1_s42 选轮权重
$OPTS = "" # 若选 A1 则改为 "event=0,gate=0"

# 1) H1 强公平对照（s0/s2 + 36对 crfpair + CRF）
& $PY -u -X utf8 $SNT --seed 42 --head h1 --freeze_backbone --backbone_ckpt $BB42 --backbone_opts $OPTS --epochs 60 --lr_tmax 60 --lr 3e-4 --out D:\Railway_project\work\公开数据_1102\runs_snt\p1_h1_s42
# 2) H2 共享生成式常态 + 有向 CRF
& $PY -u -X utf8 $SNT --seed 42 --head h2 --freeze_backbone --backbone_ckpt $BB42 --backbone_opts $OPTS --epochs 60 --lr_tmax 60 --lr 3e-4 --out D:\Railway_project\work\公开数据_1102\runs_snt\p1_h2_s42
# 3) H3 类条件（共享+残差）异方差常态 + 有向 CRF
& $PY -u -X utf8 $SNT --seed 42 --head h3 --freeze_backbone --backbone_ckpt $BB42 --backbone_opts $OPTS --epochs 60 --lr_tmax 60 --lr 3e-4 --out D:\Railway_project\work\公开数据_1102\runs_snt\p1_h3_s42
```

### 云端 RTX 5090（2 路并行跑 `s43` + `H3_nos0` 消融，共两波 ~4.5h）
```bash
export SNT_T34_DIR=/root/autodl-tmp/t34/peer_v2/t34_peer_1119
export SNT_HERE_DIR=/root/autodl-tmp/t34/peer_v2/t34_peer_1119
export T34_DATA=/root/autodl-tmp/t34/data/sitsscd/DynamicEarthNet
export T34_CACHE=/root/autodl-tmp/t34/cache
PY=/root/autodl-tmp/envs/t34_cu128/bin/python
SNT=/root/autodl-tmp/t34/snt_1123/train_snt.py
# 注：按决策门 1 替换 BB43（A1_s43 或回传的 PSE_s43）与 OPTS

# 第一波（2 路并行）：H1_s43 + H2_s43
nohup $PY -u -X utf8 $SNT --seed 43 --head h1 --freeze_backbone --backbone_ckpt "$BB43" --backbone_opts "$OPTS" --epochs 60 --lr_tmax 60 --lr 3e-4 --out /root/autodl-tmp/t34/runs_snt/p1_h1_s43 > /root/autodl-tmp/t34/runs_snt/p1_h1_s43.log 2>&1 &
nohup $PY -u -X utf8 $SNT --seed 43 --head h2 --freeze_backbone --backbone_ckpt "$BB43" --backbone_opts "$OPTS" --epochs 60 --lr_tmax 60 --lr 3e-4 --out /root/autodl-tmp/t34/runs_snt/p1_h2_s43 > /root/autodl-tmp/t34/runs_snt/p1_h2_s43.log 2>&1 &

# 第一波结束后第二波（2 路并行）：H3_s43 + H3_nos0_s42（验证融合前 s0/s2 贡献）
nohup $PY -u -X utf8 $SNT --seed 43 --head h3 --freeze_backbone --backbone_ckpt "$BB43" --backbone_opts "$OPTS" --epochs 60 --lr_tmax 60 --lr 3e-4 --out /root/autodl-tmp/t34/runs_snt/p1_h3_s43 > /root/autodl-tmp/t34/runs_snt/p1_h3_s43.log 2>&1 &
nohup $PY -u -X utf8 $SNT --seed 42 --head h3_nos0 --freeze_backbone --backbone_ckpt "$BB42_CLOUD" --backbone_opts "$OPTS" --epochs 60 --lr_tmax 60 --lr 3e-4 --out /root/autodl-tmp/t34/runs_snt/p1_h3_nos0_s42 > /root/autodl-tmp/t34/runs_snt/p1_h3_nos0_s42.log 2>&1 &
```

---

## 三、决策门 2 通过后执行（Phase 2：端到端 120 轮快筛 + SCPC + 因果审计）

设 Phase 1 胜出时间头为 `<HSTAR>`（`h3` 或 `h2`）：
- **M1（端到端 `底座 + H*`）**：`--head <HSTAR> --scpc 0 --rad_aug 0 --epochs 120 --lr_tmax 250 --lr 1e-4 --head_lr 3e-4`
- **M2（端到端 `底座 + SCPC`）**：`--head none --scpc 1 --rad_aug 1 --eval_aoi_bank 1 --epochs 120 --lr_tmax 250 --lr 1e-4 --head_lr 3e-4`
- **M3（完整双模块 `底座 + SCPC + H*`）**：`--head <HSTAR> --scpc 1 --rad_aug 1 --eval_aoi_bank 1 --epochs 120 --lr_tmax 250 --lr 1e-4 --head_lr 3e-4`
- 完成后在 `M2 / M3` 上运行 4 项因果审计：
```powershell
& $PY -u -X utf8 D:\Railway_project\work\公开数据_1102\scripts\snt_1123\eval_causal_interventions.py --run_dir <M3_dir> --device cpu --max_tiles 160
```
