# -*- coding: utf-8 -*-
"""Local RTX 3090 hands-off handoff runner for WorkBuddy (Zero GPU conflict):
1. Polls every 60s until runs_t34/den_s2_orig_s44 completes official_test.json AND its training PID exits.
2. Runs cloud/finish_moved_1122.py to finish S2 Orig s44 ep250 test + extra metrics.
3. Launches single-job PSE+BN s42 (stop_epoch=120, T_max=250) on Local RTX 3090.
4. Runs extra_metrics_psebn.py and saves JSON into 补充指标/planet_psebn_s42_ep120.json.

Usage (WorkBuddy runs in background):
  D:\Railway_project\envs\st3dunet_paper_1119\Scripts\python.exe -u -X utf8 run_local_after_s2_s44.py
"""
import json
import subprocess
import sys
import time
from pathlib import Path
import psutil

PY = r"D:\Railway_project\envs\st3dunet_paper_1119\Scripts\python.exe"
PROJECT = Path(r"D:\Railway_project\work\公开数据_1102")
S2_RUN = PROJECT / "runs_t34/den_s2_orig_s44"
PSEBN_RUN = PROJECT / "runs_t34/abl_psebn_s42"
FINISH_S2 = PROJECT / "scripts/t34_1119/cloud/finish_moved_1122.py"
PHASE0_DIR = Path(__file__).resolve().parent
PSEBN_ENTRY = PHASE0_DIR / "train_t34_psebn_local.py"
PSEBN_EXTRA = PHASE0_DIR / "extra_metrics_psebn.py"
EXTRA_SAVE = PROJECT / "总账_1110/结果/T34_DEN原版与联合解码_1119/补充指标/planet_psebn_s42_ep120.json"


def wait_for_s2_orig_s44():
    print("[WAIT] Monitoring den_s2_orig_s44 until official_test.json exists and training PID exits...", flush=True)
    while True:
        off_test = S2_RUN / "official_test.json"
        st_path = S2_RUN / "status.json"
        pid_alive = False
        phase, ep = "?", "?"
        if st_path.exists():
            try:
                st = json.loads(st_path.read_text("utf-8"))
                phase = st.get("phase", "?")
                ep = st.get("epoch", "?")
                pid = st.get("pid")
                if pid and psutil.pid_exists(pid):
                    p = psutil.Process(pid)
                    pid_alive = p.is_running() and p.status() != psutil.STATUS_ZOMBIE
            except Exception:
                pass
        if off_test.exists() and not pid_alive:
            print(f"[DONE] den_s2_orig_s44 finished (phase={phase}, official_test.json present).", flush=True)
            return
        print(f"  [{time.strftime('%H:%M:%S')}] den_s2_orig_s44: phase={phase}, epoch={ep}, pid_alive={pid_alive}", flush=True)
        time.sleep(60)


def run_cmd(cmd, label):
    print(f"\n[RUN] {label}:\n  {' '.join(cmd)}", flush=True)
    rc = subprocess.call(cmd)
    if rc != 0:
        raise RuntimeError(f"{label} failed with exit code {rc}")
    print(f"[OK] {label} finished cleanly.", flush=True)


def main():
    wait_for_s2_orig_s44()

    # Step 1: Finish S2 Orig s44 ep250 test + extra metrics (if not already done)
    s2_extra_json = PROJECT / "总账_1110/结果/T34_DEN原版与联合解码_1119/补充指标/s2_orig_s44.json"
    if not s2_extra_json.exists():
        run_cmd(
            [PY, "-u", "-X", "utf8", str(FINISH_S2), "den_s2_orig_s44", "44", "orig", "s2_orig_s44.json"],
            "finish_moved_1122 (den_s2_orig_s44)",
        )
    else:
        print("[SKIP] s2_orig_s44.json already exists.", flush=True)

    # Step 2: 2-epoch x 20-step smoke test on PSE+BN s42 (into isolated _smoke dir)
    smoke_dir = PROJECT / "runs_t34/_smoke_psebn_s42"
    if not (smoke_dir / "status.json").exists():
        run_cmd(
            [PY, "-B", "-u", "-X", "utf8", str(PSEBN_ENTRY), "--seed", "42", "--method", "pse", "--smoke_steps", "20", "--out", str(smoke_dir)],
            "PSE+BN s42 smoke test",
        )

    # Step 3: Launch formal PSE+BN s42 (stop_epoch=120, T_max=250)
    cmd = [PY, "-B", "-u", "-X", "utf8", str(PSEBN_ENTRY), "--seed", "42", "--method", "pse", "--stop_epoch", "120", "--out", str(PSEBN_RUN)]
    if (PSEBN_RUN / "last.pth").exists() and not (PSEBN_RUN / "official_test.json").exists():
        cmd.append("--resume")
    if not (PSEBN_RUN / "official_test.json").exists():
        run_cmd(cmd, "PSE+BN s42 (120 epochs, T_max=250)")

    # Step 4: Extra metrics (selected + epoch120)
    run_cmd(
        [
            PY, "-u", "-X", "utf8", str(PSEBN_EXTRA),
            "--entry", str(PSEBN_ENTRY),
            "--out", str(PSEBN_RUN),
            "--seed", "42",
            "--stop_epoch", "120",
            "--save", str(EXTRA_SAVE),
        ],
        "extra_metrics_psebn (s42)",
    )
    print("\n[ALL COMPLETE] Local Phase-0 handoff finished cleanly!", flush=True)


if __name__ == "__main__":
    main()
