"""实验二评价（11-02 修订）：由 hist_by_gap.json（每个间隔“变化 / 未变”像元在 256 个概率档上的计数）计算。

每个测试间隔报四组：
1. 区分能力（与门槛无关）：AUROC、AP；
2. 统一门槛 0.5 的 F1、精确率、召回率（主成绩口径）；最佳 F1 及其门槛只作上限参考；
3. 校准：ECE（10 等宽区间）、平均预测概率与真实变化比例之差；
4. 变化比例估计（量化）：门槛计数、平均概率、源域校准后平均概率、EM 估计，各自与真实比例的绝对误差。

先验校正分两步，都只用源域（训练所用间隔）的验证区域：
- 基础校准：在验证区域训练间隔的直方图上做保序回归（PAV），得到每个概率档的校准概率；
- EM（Saerens 等，2002）：以校准后概率和验证区域变化比例为源先验，对每个测试间隔估计变化比例并重算后验。
EM 只依赖测试样本的预测，不用其标签；按间隔整体估计，属于离线转导协议，不是逐景在线结果。
旧版把 EM 校正后的门槛 0.5 F1 当作主要对比，混淆了校准与门槛选择，已改为以校准与比例估计为主，F1 仅附报。

用法：python emn_cd_eval.py 运行目录
"""
import json
import os
import sys

import numpy as np

CENT = np.arange(256) / 255.0  # 每档的代表概率（训练脚本按 round(p×255) 分档）


def pav(y, w):
    """加权保序回归（递增）。y、w 为按横坐标排好序的目标与权重；返回拟合值。"""
    vals, wts, cnt = [], [], []
    for yi, wi in zip(y, w):
        vals.append(yi); wts.append(wi); cnt.append(1)
        while len(vals) > 1 and vals[-2] > vals[-1]:
            v = (vals[-2] * wts[-2] + vals[-1] * wts[-1]) / (wts[-2] + wts[-1])
            wsum, c = wts[-2] + wts[-1], cnt[-2] + cnt[-1]
            vals[-2:], wts[-2:], cnt[-2:] = [v], [wsum], [c]
    return np.repeat(vals, cnt)


def calibrator(pos, neg):
    """由源域验证直方图拟合每档的校准概率（空档沿用相邻非空档）。"""
    tot = pos + neg
    nz = np.flatnonzero(tot > 0)
    fit = pav(pos[nz] / tot[nz], tot[nz])
    q = np.interp(np.arange(256), nz, fit)
    return np.clip(q, 1e-6, 1 - 1e-6)


def metrics(q, pos, neg, thr=0.5):
    """q：每档的概率；pos、neg：每档变化、未变像元数。"""
    pos, neg, q = np.asarray(pos, float), np.asarray(neg, float), np.asarray(q, float)
    tot = pos + neg
    P, N = pos.sum(), neg.sum()
    sel = q >= thr
    tp, fp = pos[sel].sum(), neg[sel].sum()
    fn = P - tp
    order = np.argsort(-q, kind="stable")
    cp, cn = np.cumsum(pos[order]), np.cumsum(neg[order])
    tpr, fpr = cp / max(1, P), cn / max(1, N)
    auroc = float(np.sum(np.diff(np.r_[0, fpr]) * (np.r_[0, tpr][1:] + np.r_[0, tpr][:-1]) / 2))
    prec = cp / np.maximum(1, cp + cn)
    ap = float(np.sum(np.diff(np.r_[0, tpr]) * prec))
    f1s = 2 * cp / np.maximum(1, 2 * cp + cn + (P - cp))
    j = int(np.argmax(f1s))
    ece = 0.0
    for b in range(10):
        m = (q >= b / 10) & ((q < (b + 1) / 10) if b < 9 else (q <= 1))
        n = tot[m].sum()
        if n:
            ece += n / tot.sum() * abs(pos[m].sum() / n - (q[m] * tot[m]).sum() / n)
    prev = P / max(1, tot.sum())
    mean_q = float((q * tot).sum() / max(1, tot.sum()))
    return {"变化比例": float(prev), "平均预测概率": mean_q, "门槛计数比例": float((tot[sel]).sum() / max(1, tot.sum())),
            "F1": float(2 * tp / max(1, 2 * tp + fp + fn)), "精确率": float(tp / max(1, tp + fp)),
            "召回率": float(tp / max(1, P)), "AUROC": auroc, "AP": ap, "ECE": float(ece),
            "最佳F1(上限参考)": float(f1s[j]), "最佳门槛": float(q[order][j])}


def em(q, tot, prior_s, iters=500):
    """Saerens EM：q 为源先验 prior_s 下的（校准后）后验；返回估计的目标先验和调整后后验。"""
    pi = prior_s
    for _ in range(iters):
        a = pi / prior_s * q
        q2 = a / (a + (1 - pi) / (1 - prior_s) * (1 - q))
        new = float((q2 * tot).sum() / tot.sum())
        if abs(new - pi) < 1e-9:
            pi = new
            break
        pi = new
    a = pi / prior_s * q
    return pi, a / (a + (1 - pi) / (1 - prior_s) * (1 - q))


def main(run):
    d = json.load(open(os.path.join(run, "hist_by_gap.json"), encoding="utf-8"))
    done = json.load(open(os.path.join(run, "done.json"), encoding="utf-8"))
    tg = done["gaps"].split(",")
    vp = sum(np.asarray(d["val"][g]["pos"], float) for g in tg if g in d["val"])
    vn = sum(np.asarray(d["val"][g]["neg"], float) for g in tg if g in d["val"])
    prior_s = float(vp.sum() / (vp.sum() + vn.sum()))
    qcal = calibrator(vp, vn)
    out = {"训练间隔": done["gaps"], "条件输入": done["cond"], "源域验证变化比例": prior_s,
           "说明": "主成绩为门槛 0.5 的 F1；EM 与校准以 ECE 和变化比例估计误差评价", "各间隔": {}}
    for g, h in sorted(d["test"].items(), key=lambda x: int(x[0])):
        pos, neg = np.asarray(h["pos"], float), np.asarray(h["neg"], float)
        tot = pos + neg
        raw = metrics(CENT, pos, neg)
        cal = metrics(qcal, pos, neg)
        pi_em, qem = em(qcal, tot, prior_s)
        emm = metrics(qem, pos, neg)
        prev = raw["变化比例"]
        out["各间隔"][g] = {
            "原始": raw,
            "源域校准后": {k: cal[k] for k in ("平均预测概率", "ECE", "F1", "精确率", "召回率")},
            "EM后": {"估计变化比例": pi_em, **{k: emm[k] for k in ("ECE", "F1", "精确率", "召回率")}},
            "变化比例估计绝对误差": {"门槛计数": abs(raw["门槛计数比例"] - prev), "平均概率": abs(raw["平均预测概率"] - prev),
                             "校准后平均概率": abs(cal["平均预测概率"] - prev), "EM": abs(pi_em - prev)}}
    json.dump(out, open(os.path.join(run, "eval_cd_test.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for g, m in out["各间隔"].items():
        r, e = m["原始"], m["变化比例估计绝对误差"]
        print(f"间隔{g}年 比例 {r['变化比例']:.4f} 平均概率 {r['平均预测概率']:.4f} EM估计 {m['EM后']['估计变化比例']:.4f} | "
              f"F1@0.5 {r['F1']:.3f} AUROC {r['AUROC']:.3f} AP {r['AP']:.3f} ECE {r['ECE']:.4f}→校准 {m['源域校准后']['ECE']:.4f}→EM {m['EM后']['ECE']:.4f} | "
              f"比例误差 平均概率 {e['平均概率']:.4f} 校准 {e['校准后平均概率']:.4f} EM {e['EM']:.4f}")


if __name__ == "__main__":
    main(sys.argv[1])
