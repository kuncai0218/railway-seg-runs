"""Train a short source-only A1 reference where no compatible PSE weights are on disk."""

import argparse
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from extract_features import DAYS, MONTHS, NORMALIZATION, TRAIN_TILES, cached_or_original, released_split, save_json, sha256
from pse_net import make_pse


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--cache", type=Path)
    parser.add_argument("--sensor", choices=("s2", "planet"), required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--steps", type=int, default=768)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    if args.steps < 1:
        parser.error("Expected a positive step budget")
    torch.set_num_threads(2)
    torch.manual_seed(args.seed)
    torch.backends.cudnn.allow_tf32 = False
    rng = np.random.default_rng(args.seed)
    split = released_split(args.data, args.sensor)
    chans = len(NORMALIZATION[args.sensor][0])
    cfg = {"model": {"num_channels": chans}, "ST3DUNET": {"INPUT_CHANNELS": chans},
           "dataset": {"num_classes": 6, "ignore_index": 6}}
    opts = "event=0,gate=0"
    model = make_pse(cfg, opts).to(args.device).train()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-3)
    positions = torch.tensor([DAYS, DAYS], device=args.device)
    mean, std = [torch.tensor(value, device=args.device).reshape(1, 1, -1, 1, 1)
                 for value in NORMALIZATION[args.sensor]]
    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    config = {"sensor": args.sensor, "seed": args.seed, "steps": args.steps, "opts": opts,
              "split_sha256": sha256(args.data / "split.json"), "torch": str(torch.__version__),
              "device": args.device, "purpose": "short A1 fallback for within-checkpoint mechanism comparisons"}
    save_json(out / "protocol.json", config)
    areas = sorted(split["train"])
    step = 0
    while step < args.steps:
        for site in rng.permutation(areas):
            image, times = cached_or_original(args.data, args.cache, args.sensor, "train", site)
            labels = np.load(args.data / "labels" / f"{site}.npy", mmap_mode="r", allow_pickle=False)
            for _ in range(8):
                xs, ys = [], []
                for index in rng.choice(len(TRAIN_TILES), size=2, replace=False):
                    r, c = TRAIN_TILES[index]
                    rows, cols = slice(128*r, 128*(r+1)), slice(128*c, 128*(c+1))
                    x = image[list(times), :, rows, cols]
                    y = labels[list(MONTHS), rows, cols]
                    if rng.integers(2):
                        x = x[..., ::-1]
                        y = y[..., ::-1]
                    xs.append(x)
                    ys.append(y)
                x = torch.as_tensor(np.stack(xs), device=args.device, dtype=torch.float32)
                valid_x = torch.isfinite(x).all(2, keepdim=True) & (x != 0).any(2, keepdim=True)
                x = (torch.where(valid_x, x, mean) - mean)/std
                y = torch.as_tensor(np.stack(ys), device=args.device, dtype=torch.long)
                y = y.masked_fill((y < 0) | (y >= 6), 6)
                if not (y != 6).any():
                    continue
                logits = model(x, positions)
                loss = F.cross_entropy(logits.flatten(0, 1), y.flatten(0, 1), ignore_index=6)
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5., error_if_nonfinite=True)
                optimizer.step()
                step += 1
                if step == 1 or step % 32 == 0 or step == args.steps:
                    print(f"[A1] update={step}/{args.steps} source={site} loss={loss.detach().item():.5f}", flush=True)
                if step == args.steps:
                    break
            if step == args.steps:
                break
    tmp = out / "last.tmp"
    torch.save({"model": model.state_dict(), "optimizer_updates": step}, tmp)
    tmp.replace(out / "last.pth")
    save_json(out / "complete.json", {"updates": step, "sha256": sha256(out / "last.pth")})


if __name__ == "__main__":
    main()
