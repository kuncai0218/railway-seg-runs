"""打包回传（11-04 写）。在实验包目录里运行：python -X utf8 scripts/pack_st3d.py --name 同学乙
把 ..\\st3d_runs 下各任务的 config.json、epochs.jsonl、final.json、train.log、best_in.pth、best_out.pth、last.pth，
以及 queue.log、两个测速结果打成 ..\\回传_<名字>_st3d_1104_<月日_时分>.zip（每 10 轮的中间检查点不打包，留在本机）。
"""
import argparse
import os
import time
import zipfile

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.dirname(PKG)
RUNS = os.path.join(WORK, "st3d_runs")
KEEP = ("config.json", "epochs.jsonl", "final.json", "train.log", "best_in.pth", "best_out.pth", "last.pth", "bench.json", "queue.log",
        "status.json", "bench_config.json", "initial_validation.json")  # 后三个：11-07 加，Codex A/B 的输出

ap = argparse.ArgumentParser()
ap.add_argument("--name", required=True)
a = ap.parse_args()
out = os.path.join(WORK, f"回传_{a.name}_st3d_1104_{time.strftime('%m%d_%H%M')}.zip")
n = 0
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(RUNS):
        for f in files:
            if f in KEEP:
                p = os.path.join(root, f)
                z.write(p, os.path.relpath(p, WORK))
                n += 1
print(f"已打包 {n} 个文件 → {out}（{os.path.getsize(out):,} 字节）")
