"""ST3DUNet 复现的逐轮曲线（11-04 写）：每 k 轮一行，列学习率与四个评测集的 mIoU / SCS（取该段 k 轮的平均，减少单轮抖动）。
用法：python -X utf8 st3d_traj.py <运行目录> [k=5]
"""
import json
import os
import sys

run = sys.argv[1]
k = int(sys.argv[2]) if len(sys.argv) > 2 else 5
recs = [json.loads(x) for x in open(os.path.join(run, "epochs.jsonl"), encoding="utf-8")]
sets = [s for s in ("val_in", "test_in", "val_out", "test_out") if s in recs[0]]
print(f"{os.path.basename(run)}：每 {k} 轮平均（mIoU/SCS），最后一列为该段 val_out 最高单轮")
print("轮次      lr       " + "  ".join(f"{s:>13}" for s in sets) + "   val_out最高")
for i in range(0, len(recs), k):
    seg = recs[i:i + k]
    cells = []
    for s in sets:
        m = sum(r[s]["miou"] for r in seg) / len(seg)
        c = sum(r[s]["scs"] for r in seg) / len(seg)
        cells.append(f"{m:6.2f}/{c:6.2f}")
    top = max(r["val_out"]["miou"] for r in seg)
    print(f"{seg[0]['epoch']:>3}-{seg[-1]['epoch']:<3}  {seg[0]['lr']:.1e}  " + "  ".join(f"{x:>13}" for x in cells) + f"   {top:6.2f}")
