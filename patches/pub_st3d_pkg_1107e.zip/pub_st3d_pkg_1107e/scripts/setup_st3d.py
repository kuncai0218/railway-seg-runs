"""同学机器上的 ST3DUNet（MUDS）准备（11-04 写，Windows）。在实验包目录里运行：python -X utf8 scripts/setup_st3d.py
目录约定（都在实验包的上一级 work_st3d\\ 下）：
  st3d_data\\Muds.zip      官方 MUDS 压缩包（SitsSCD 作者 Google Drive，245,211,794 字节）
  st3d_data\\Muds\\        解压结果
  st3d_cache\\Muds\\       解码缓存（约 4.3 GB）
  st3d_runs\\             训练输出
步骤：1 检查依赖与显卡；2 核对压缩包 SHA256 并解压；3 建解码缓存；4 缓存版与官方数据集类逐样本核对；5 原版、单期各测速 200 步。
任何一步失败就停下，把输出原样报告给组长。
"""
import hashlib
import os
import subprocess
import sys
import zipfile

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.dirname(PKG)
DATA = os.path.join(WORK, "st3d_data")
CACHE = os.path.join(WORK, "st3d_cache")
RUNS = os.path.join(WORK, "st3d_runs")
ZIP_SHA256 = "3c544aa1693f1e8e41c0973d0be01c5ed217f709ff2e477f6151a348af2962e5"
ENV = dict(os.environ, ST3D_REPO=os.path.join(PKG, "ST3DUNet"), ST3D_DATA=DATA, ST3D_CACHE=CACHE, TQDM_DISABLE="1", PYTHONIOENCODING="utf-8")


def step(title):
    print(f"\n== {title}", flush=True)


def run(args):
    r = subprocess.run([sys.executable, "-X", "utf8"] + args, cwd=PKG, env=ENV)
    if r.returncode != 0:
        sys.exit(f"失败：{' '.join(args)}（返回码 {r.returncode}），停下报告组长")


step("1 依赖与显卡")
missing = []
for mod in ("torch", "torchvision", "torchmetrics", "pandas", "yaml", "tqdm", "numpy"):
    try:
        __import__(mod)
    except ImportError:
        missing.append(mod)
if missing:
    sys.exit(f"缺少：{missing}。按说明用 pip 装（yaml 对应 pyyaml），装好再运行本脚本")
import torch  # noqa: E402
print("torch", torch.__version__, "CUDA", torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else "")

step("2 核对 Muds.zip 并解压")
z = os.path.join(DATA, "Muds.zip")
if not os.path.exists(os.path.join(DATA, "Muds", "split.json")):
    if not os.path.exists(z):
        sys.exit(f"找不到 {z}，先按说明下载")
    h = hashlib.sha256()
    with open(z, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    if h.hexdigest() != ZIP_SHA256:
        sys.exit(f"SHA256 不一致：{h.hexdigest()}，停下报告组长")
    zipfile.ZipFile(z).extractall(DATA)
print("Muds 数据就绪：", os.path.join(DATA, "Muds"))

step("3 建解码缓存（约 4.3 GB）")
run([os.path.join("scripts", "muds_st3d_cache.py"), "4"])

step("4 缓存版与官方数据集类逐样本核对（最后一行应为“缓存版与官方逐样本完全相等”）")
run([os.path.join("scripts", "st3d_cache_check.py"), "muds"])

step("5 测速：原版、单期各 200 步")
os.makedirs(RUNS, exist_ok=True)
for arch in ("st3d", "mono"):
    run([os.path.join("scripts", "st3d_repro.py"), "--data", "muds", "--arch", arch, "--bench", "200", "--workers", "4",
         "--eval_workers", "0", "--out", os.path.join(RUNS, f"_bench_muds_{arch}")])
print("\n准备完成。把第 1、4、5 步的输出写进同步状态，然后按说明启动运行器。")
