"""核对解码缓存版数据集与官方数据集类逐样本完全相等（11-03 写）。
训练集：同一种子下取同一下标，比较图像、标签、日期；验证/测试四个集合各抽若干下标比较。
用法：python -X utf8 st3d_cache_check.py [dynamicearthnet|muds]"""
import os
import random
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from st3d_repro import DATA, REPO, load_yaml, make_set  # noqa: E402

data = sys.argv[1] if len(sys.argv) > 1 else "dynamicearthnet"
cfg = load_yaml(os.path.join(REPO, "configs", f"{data}.yaml"))
cfg["dataset"]["path"] = DATA[data][1]


def same(a, b):
    return torch.equal(a["data"], b["data"]) and torch.equal(a["gt"], b["gt"]) and torch.equal(a["positions"], b["positions"])


def get(ds, i, seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    return ds[i]


bad = 0
for split, shift in [("train", None), ("val", False), ("val", True), ("test", False), ("test", True)]:
    off = make_set(cfg, split, shift, cache=False)
    cac = make_set(cfg, split, shift, cache=True)
    n = len(off)
    idx = sorted({0, 1, n // 3, n // 2, n - 1} | set(range(7, n, max(1, n // 20))))
    for k, i in enumerate(idx):
        a, b = get(off, i, 1000 + k), get(cac, i, 1000 + k)
        if not same(a, b):
            bad += 1
            print("不相等", split, shift, i, (a["data"] - b["data"]).abs().max().item(), a["positions"].tolist(), b["positions"].tolist())
    print(split, "跨区域" if shift else ("同区域" if shift is False else ""), f"核对 {len(idx)} 个样本（共 {n}）", "累计不相等", bad, flush=True)
print("结论：", "缓存版与官方逐样本完全相等" if bad == 0 else f"有 {bad} 个样本不相等")
