"""同学机器上跑 Codex 的“历史分用途读取”A/B 筛选（11-07 写，Windows）。在实验包目录里运行：
  python -X utf8 scripts/run_ab_st3d.py prep [--procs 6]   建 DynamicEarthNet 解码缓存（先把官方 DynamicEarthNet.zip 解压到 ..\\st3d_data\\DynamicEarthNet\\）
  python -X utf8 scripts/run_ab_st3d.py check              缓存版与官方数据集类逐样本核对
  python -X utf8 scripts/run_ab_st3d.py bench --seed 43    测速 200 步（只写 bench 结果，不训练）
  python -X utf8 scripts/run_ab_st3d.py train --seed 43    正式跑：A（统一读取历史）与 B（按用途读取历史）同批次配对训练 50 轮，只评验证集
目录约定同 setup_st3d.py（都在实验包的上一级 work_st3d\\ 下）：st3d_data、st3d_cache、st3d_runs。
冻结编码器用实验包 weights\\den_mono_s<种子>\\last_pbn.pth（组长本机训好、已用训练集重估 BN 的单期模型）。
训练脚本 experiments\\history_roles_20261106\\ 由 Codex 编写，原样拷贝，不要改动；中途停掉后重跑同一条 train 命令会接着跑。
任何一步失败就停下，把输出最后 30 行报告给组长。
"""
import argparse
import os
import subprocess
import sys

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.dirname(PKG)
ENV = dict(os.environ, ST3D_REPO=os.path.join(PKG, "ST3DUNet"), ST3D_DATA=os.path.join(WORK, "st3d_data"),
           ST3D_CACHE=os.path.join(WORK, "st3d_cache"), TQDM_DISABLE="1", PYTHONIOENCODING="utf-8")
AB = os.path.join(PKG, "experiments", "history_roles_20261106", "train_ab.py")


def run(args):
    print(">>", " ".join(args), flush=True)
    r = subprocess.run([sys.executable, "-X", "utf8"] + args, cwd=PKG, env=ENV)
    if r.returncode:
        sys.exit(f"失败（返回码 {r.returncode}），请把上面最后 30 行报告给组长")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("what", choices=["prep", "check", "bench", "train"])
    ap.add_argument("--seed", type=int, default=43)
    ap.add_argument("--procs", type=int, default=6)
    a = ap.parse_args()
    if a.what == "prep":
        src = os.path.join(WORK, "st3d_data", "DynamicEarthNet")
        if not os.path.isdir(os.path.join(src, "labels")):
            sys.exit(f"没找到 {src}\\labels：请先把官方 DynamicEarthNet.zip 解压到 {os.path.join(WORK, 'st3d_data')}")
        run([os.path.join(PKG, "scripts", "den_st3d_cache.py"), str(a.procs)])
        return
    if a.what == "check":
        run([os.path.join(PKG, "scripts", "st3d_cache_check.py"), "dynamicearthnet"])
        return
    ck = os.path.join(PKG, "weights", f"den_mono_s{a.seed}", "last_pbn.pth")
    if not os.path.exists(ck):
        sys.exit(f"没有 {ck}：本包只带了种子 43、44 的冻结编码器")
    out = os.path.join(WORK, "st3d_runs", f"ab_den_s{a.seed}" + ("_bench" if a.what == "bench" else ""))
    args = [AB, "--checkpoint", ck, "--seed", str(a.seed), "--out", out]
    if a.what == "bench":
        args += ["--bench", "200"]
    run(args)


if __name__ == "__main__":
    main()
