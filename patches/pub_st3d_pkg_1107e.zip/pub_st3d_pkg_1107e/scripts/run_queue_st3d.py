"""ST3DUNet 任务运行器（11-04 写，Windows）。在实验包目录里运行：
  python -X utf8 scripts/run_queue_st3d.py tasks/<任务文件>.json [--max 1]
- 任务文件里每条：{"名称": ..., "参数": [...]}，输出到 ..\\st3d_runs\\<名称>\\（train.log、epochs.jsonl、检查点、final.json）。
- 已有 final.json 的任务跳过；中途停掉后重新运行本命令，会从 last.pth 接着跑（st3d_repro.py 自带断点续跑）。
- 同一任务失败自动重试一次（接着跑）；再失败就停下，不再接后面的任务，等组长处理。
- 运行器日志：..\\st3d_runs\\queue.log（开始、结束、返回码、进程号）。
"""
import argparse
import json
import os
import subprocess
import sys
import time

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.dirname(PKG)
RUNS = os.path.join(WORK, "st3d_runs")
ENV = dict(os.environ, ST3D_REPO=os.path.join(PKG, "ST3DUNet"), ST3D_DATA=os.path.join(WORK, "st3d_data"),
           ST3D_CACHE=os.path.join(WORK, "st3d_cache"), TQDM_DISABLE="1", PYTHONIOENCODING="utf-8")


def log(msg):
    line = time.strftime("%m-%d %H:%M:%S ") + msg
    print(line, flush=True)
    with open(os.path.join(RUNS, "queue.log"), "a", encoding="utf-8") as f:
        f.write(line + "\n")


def start(task):
    out = os.path.join(RUNS, task["名称"])
    os.makedirs(out, exist_ok=True)
    f = open(os.path.join(out, "train.log"), "a", encoding="utf-8")
    p = subprocess.Popen([sys.executable, "-X", "utf8", os.path.join("scripts", "st3d_repro.py")] + task["参数"] + ["--out", out],
                         cwd=PKG, env=ENV, stdout=f, stderr=subprocess.STDOUT)
    log(f"开始 {task['名称']}，进程号 {p.pid}")
    return p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tasks")
    ap.add_argument("--max", type=int, default=1)
    a = ap.parse_args()
    os.makedirs(RUNS, exist_ok=True)
    tasks = json.load(open(os.path.join(PKG, a.tasks), encoding="utf-8"))["任务"]
    todo = [t for t in tasks if not os.path.exists(os.path.join(RUNS, t["名称"], "final.json"))]
    for t in tasks:
        if t not in todo:
            log(f"{t['名称']} 已完成，跳过")
    running, tries = {}, {}
    while todo or running:
        while todo and len(running) < a.max:
            t = todo.pop(0)
            tries[t["名称"]] = tries.get(t["名称"], 0) + 1
            running[t["名称"]] = (t, start(t))
        time.sleep(30)
        for name, (t, p) in list(running.items()):
            rc = p.poll()
            if rc is None:
                continue
            del running[name]
            if rc == 0 and os.path.exists(os.path.join(RUNS, name, "final.json")):
                log(f"结束 {name}，正常完成")
            elif tries[name] < 2:
                log(f"结束 {name}，返回码 {rc}，自动重试一次（接着跑）")
                todo.insert(0, t)
            else:
                log(f"结束 {name}，返回码 {rc}，第二次失败：停止接新任务，等组长处理（看 {name}\\train.log 末尾）")
                todo.clear()
    log("运行器退出")


if __name__ == "__main__":
    main()
