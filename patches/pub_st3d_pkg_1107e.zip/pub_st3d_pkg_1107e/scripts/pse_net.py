"""先验引导的状态—事件时序网络（11-07 晚写，第一版原型）。设计见 设计_1103\\新模型设计_1107.md。

针对 ST3DUNet 拆解出的问题，逐条对应：
- 时间维不压缩：所有下采样只在空间上做（ST3DUNet 时间 8→4→2→1，瓶颈时间注意力只对 1 个时间步做）；
- 逐月先 2D 编码，时间交互只发生在显式的时间模块里（ST3DUNet 第一层 3×3×3 卷积就把前后月混在一起）；
- 多源先验（S2、OlmoEarth 等，已放大到 3 米拼在输入后面）先 4×4 平均回 12 米，在 12/24/48 米三层用调制注入
  （缩放 + 偏移，零初始化，开始时等于不注入），不在 3 米输入层硬拼；
- 变化头：相邻两月的高分特征差、先验差 → 每对相邻月的变化概率，直接用真值变化监督；
- 变化门控时间注意力（24、48 米）：月份 t 读月份 s 的注意力加上 α·log P(t 与 s 之间不变)，
  P 由变化头给出；跨过高概率变化点的历史自动被压低（“历史只在同一状态段内借用”）；可选因果掩码；
- 先验支路自带分类输出（12 米），与高分支路按像元门控相加（把已验证有效的后融合学进网络）；
- 归一化用组归一化（ST3DUNet 批大小 2 下 BatchNorm 统计量很噪）。
输入：x [B, T, C, H, W]，前 in_planet 个通道是 Planet，其余是先验；positions [B, T] 为自 2018-01-01 起的天数。
输出：对数几率 [B, T, K, H, W]；训练时 self.aux 存先验支路对数几率与变化头对数几率，供 aux_loss 用。
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def gn(c):
    return nn.GroupNorm(max(1, min(8, c // 8)), c)


class ConvGN(nn.Sequential):
    def __init__(self, cin, cout, k=3, s=1):
        super().__init__(nn.Conv2d(cin, cout, k, s, k // 2, bias=False), gn(cout), nn.GELU())


class Res(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.a, self.b = ConvGN(c, c), nn.Sequential(nn.Conv2d(c, c, 3, 1, 1, bias=False), gn(c))

    def forward(self, x):
        return F.gelu(x + self.b(self.a(x)))


class Down(nn.Sequential):
    def __init__(self, cin, cout):
        super().__init__(ConvGN(cin, cout, 3, 2), Res(cout))


class FiLM(nn.Module):
    """先验调制：s ← s ⊙ (1 + tanh γ(q)) + β(q)，γ、β 零初始化（开始时不改变高分支路）。"""

    def __init__(self, cq, cs):
        super().__init__()
        self.g, self.b = nn.Conv2d(cq, cs, 1), nn.Conv2d(cq, cs, 1)
        for m in (self.g, self.b):
            nn.init.zeros_(m.weight)
            nn.init.zeros_(m.bias)

    def forward(self, s, q):
        return s * (1 + torch.tanh(self.g(q))) + self.b(q)


def time_enc(pos, d):
    """天数 → 正弦编码，周期按几何级数从 30 天到 4 年（含 1 年的季节周期附近）。pos [B, T] → [B, T, d]"""
    n = d // 2
    i = torch.arange(n, device=pos.device, dtype=torch.float32)
    period = 30.0 * (1460.0 / 30.0) ** (i / max(1, n - 1))
    ang = pos.float()[..., None] * (2 * math.pi / period)
    return torch.cat([ang.sin(), ang.cos()], -1)


class GatedTemporal(nn.Module):
    """逐位置的时间注意力（1 层，前置层归一化）。bias[t, s] = α · log P(t 与 s 之间不变)，P 来自变化头；可选因果。"""

    def __init__(self, c, heads=4, causal=False, gate=True, trans=False):
        super().__init__()
        self.h, self.causal, self.gate = heads, causal, gate
        self.n1, self.n2 = nn.LayerNorm(c), nn.LayerNorm(c)
        self.qkv, self.o = nn.Linear(c, 3 * c), nn.Linear(c, c)
        self.ff = nn.Sequential(nn.Linear(c, 2 * c), nn.GELU(), nn.Linear(2 * c, c))
        self.te = nn.Linear(c, c)
        self.alpha = nn.Parameter(torch.tensor(1.0))
        if trans:  # 只有区分往返时才有这个参数（旧检查点里没有，不能无条件新建）
            self.beta = nn.Parameter(torch.tensor(1.0))

    def forward(self, x, pos, pchg, ptrans=None):
        """x [B, T, C, h, w]；pos [B, T]；pchg [B, T, h, w]（第 t 个 = P(t−1→t 持久变化)，第 0 个为 0）或 None；
        ptrans [B, T, h, w]：P(第 s 期是一期往返的暂时状态)，读别的月份时降低对这些月份的借用（键偏置 log(1 − p)，不含自身）。"""
        B, T, C, h, w = x.shape
        z = x.permute(0, 3, 4, 1, 2).reshape(B * h * w, T, C)
        z = z + self.te(time_enc(pos, C)).repeat_interleave(h * w, 0)
        q, k, v = self.qkv(self.n1(z)).chunk(3, -1)
        sh = lambda t: t.view(B * h * w, T, self.h, C // self.h).transpose(1, 2)  # noqa: E731
        q, k, v = sh(q), sh(k), sh(v)
        att = q @ k.transpose(-1, -2) / math.sqrt(C // self.h)  # [N, H, T, T]
        if self.gate and pchg is not None:
            L = torch.cumsum(torch.log1p(-pchg.clamp(0, 0.999)), 1)  # [B, T, h, w]，log P(0..t 不变)
            L = L.permute(0, 2, 3, 1).reshape(B * h * w, T)
            bias = -(L[:, :, None] - L[:, None, :]).abs()  # log P(t 与 s 之间不变) ≤ 0
            att = att + F.softplus(self.alpha) * bias[:, None]
        if self.gate and ptrans is not None:
            kb = torch.log1p(-ptrans.clamp(0, 0.999)).permute(0, 2, 3, 1).reshape(B * h * w, 1, T).expand(B * h * w, T, T)
            kb = kb * (1 - torch.eye(T, device=x.device, dtype=kb.dtype))  # 自身不受影响
            att = att + F.softplus(self.beta) * kb[:, None]
        if self.causal:
            m = torch.ones(T, T, device=x.device, dtype=torch.bool).triu(1)
            att = att.masked_fill(m, float("-inf"))
        y = (att.softmax(-1) @ v).transpose(1, 2).reshape(B * h * w, T, C)
        z = z + self.o(y)
        z = z + self.ff(self.n2(z))
        return z.view(B, h, w, T, C).permute(0, 3, 4, 1, 2)


class PSENet(nn.Module):
    def __init__(self, in_planet=4, in_prior=0, K=6, widths=(32, 48, 64, 96, 128), qw=(64, 96, 128),
                 event=True, gate=True, prior_gate=True, causal=False, film=True, heads=4, text_emb=None,
                 concat=False, mdrop=0.0, chgw=0.0, trans=False, asym=0.0, ignore=6):
        super().__init__()
        self.ip, self.iq, self.K = in_planet, in_prior, K
        self.event, self.prior_gate, self.film = event, prior_gate and in_prior > 0, film and in_prior > 0
        self.concat = in_prior > 0 and (concat or not film)  # 先验在 3 米输入层拼接（film=0 时只拼接；concat=1 时拼接 + 中层调制两路）
        self.mdrop, self.chgw = float(mdrop), float(chgw)  # 训练时整段遮掉 Planet 的概率；变化像元额外交叉熵的权重
        self.trans = bool(trans) and event and not causal  # 区分“持久变化”与“一期往返”（判第 t 期是否往返要看 t+1，因果版不用）
        self.asym = float(asym)  # 只扰动 Planet 外观、不动先验的训练增强概率（逼模型在外观变了时依靠先验）
        self.ignore = int(ignore)  # 标签里的忽略值（DEN 6，MUDS 2），辅助损失用
        w = widths
        self.stem = nn.Sequential(ConvGN(in_planet, w[0]), ConvGN(w[0], w[0]))  # 3 米
        self.d1, self.d2, self.d3, self.d4 = Down(w[0], w[1]), Down(w[1], w[2]), Down(w[2], w[3]), Down(w[3], w[4])  # 6/12/24/48 米
        if in_prior > 0:
            self.q12 = nn.Sequential(ConvGN(in_prior, qw[0], 1), Res(qw[0]))
            self.q24, self.q48 = Down(qw[0], qw[1]), Down(qw[1], qw[2])
            self.qhead = nn.Conv2d(qw[0], K, 1)
            if self.film:
                self.f12, self.f24, self.f48 = FiLM(qw[0], w[2]), FiLM(qw[1], w[3]), FiLM(qw[2], w[4])
            if self.concat:  # 先验在 3 米输入层直接拼接（与 ST3DUNet 三源做法相同）
                self.stem = nn.Sequential(ConvGN(in_planet + in_prior, w[0]), ConvGN(w[0], w[0]))
        if event:
            ce = w[3]
            cin = (5 if self.trans else 3) * ce + (qw[1] * (2 if self.trans else 1) if in_prior > 0 else 0)
            self.ev = nn.Sequential(ConvGN(cin, ce, 1), ConvGN(ce, ce), nn.Conv2d(ce, 2 if self.trans else 1, 1))
        self.t24 = GatedTemporal(w[3], heads, causal, gate and event, self.trans)
        self.t48 = GatedTemporal(w[4], heads, causal, gate and event, self.trans)
        self.u3, self.u2, self.u1, self.u0 = (ConvGN(w[4] + w[3], w[3]), ConvGN(w[3] + w[2], w[2]),
                                              ConvGN(w[2] + w[1], w[1]), ConvGN(w[1] + w[0], w[0]))
        self.r3, self.r2, self.r1, self.r0 = Res(w[3]), Res(w[2]), Res(w[1]), Res(w[0])
        self.head = nn.Conv2d(w[0], K, 1)
        self.texthead = text_emb is not None
        if self.texthead:  # 文本锚定的分类头（11-07 晚）：类别中心固定在六类文字嵌入处，只许小幅偏移（偏移量在 aux_loss 里加 L2）
            te = F.normalize(torch.as_tensor(text_emb, dtype=torch.float32), dim=-1)
            self.register_buffer("T", te)
            self.head = nn.Conv2d(w[0], te.shape[1], 1)
            self.dT = nn.Parameter(torch.zeros_like(te))
            self.tau = nn.Parameter(torch.tensor(math.log(10.0)))
            self.tb = nn.Parameter(torch.zeros(K))
        if self.prior_gate:
            self.pg = nn.Conv2d(w[0], 1, 1)
            nn.init.zeros_(self.pg.weight)
            nn.init.constant_(self.pg.bias, -2.0)
        self.aux = {}

    def _asym_aug(self, x):
        """只扰动 Planet 通道（已标准化）：①每个样本每个波段的增益与偏移（整段共用，模拟换区后的辐射与季节差）；
        ②与同批另一个样本交换低频振幅（傅里叶域适应 FDA 的做法，保留相位即保留地物结构）。先验通道不动。"""
        B = x.shape[0]
        xp = x[:, :, :self.ip]
        sel = (torch.rand(B, 1, 1, 1, 1, device=x.device) < self.asym).to(x.dtype)
        a = 1 + (torch.rand(B, 1, self.ip, 1, 1, device=x.device) * 2 - 1) * 0.25
        b = (torch.rand(B, 1, self.ip, 1, 1, device=x.device) * 2 - 1) * 0.3
        xa = xp * a + b
        if B > 1:
            Fx = torch.fft.fft2(xa.float())
            amp, pha = Fx.abs(), Fx.angle()
            other = amp.roll(1, 0)
            H, W = xa.shape[-2:]
            r = max(1, int(0.03 * min(H, W)))
            mask = torch.zeros(H, W, device=x.device)
            mask[:r, :r] = 1
            mask[:r, -r:] = 1
            mask[-r:, :r] = 1
            mask[-r:, -r:] = 1  # 四角即低频（未移频）
            lam = torch.rand(B, 1, 1, 1, 1, device=x.device)
            amp = amp * (1 - lam * mask) + other * lam * mask
            xa = torch.fft.ifft2(torch.polar(amp, pha)).real.to(x.dtype)
        xp = xp * (1 - sel) + xa * sel
        return torch.cat([xp, x[:, :, self.ip:]], 2)

    @staticmethod
    def _up(x, ref):
        return F.interpolate(x, size=ref.shape[-2:], mode="bilinear", align_corners=False)

    def forward(self, x, batch_positions=None):
        B, T, C, H, W = x.shape
        pos = batch_positions if batch_positions is not None else torch.arange(T, device=x.device)[None].expand(B, T) * 30
        if self.training and self.asym > 0:
            x = self._asym_aug(x)
        if self.training and self.mdrop > 0 and self.iq > 0:  # 模态丢弃：整段样本的 Planet 置零（已标准化，0 = 均值），逼模型单靠先验认类
            keep = (torch.rand(B, 1, 1, 1, 1, device=x.device) >= self.mdrop).to(x.dtype)
            x = torch.cat([x[:, :, :self.ip] * keep, x[:, :, self.ip:]], 2)
        xp = x[:, :, :self.ip].reshape(B * T, self.ip, H, W)
        xq = x[:, :, self.ip:].reshape(B * T, C - self.ip, H, W) if self.iq > 0 else None
        s0 = self.stem(x.reshape(B * T, C, H, W) if self.concat else xp)
        s1 = self.d1(s0)
        s2 = self.d2(s1)
        q12 = q24 = q48 = qlog = None
        if self.iq > 0:
            q12 = self.q12(F.avg_pool2d(xq, 4))
            q24 = self.q24(q12)
            q48 = self.q48(q24)
            qlog = self.qhead(q12)  # [BT, K, H/4, W/4]
            if self.film:
                s2 = self.f12(s2, q12)
        s3 = self.d3(s2)
        if self.film:
            s3 = self.f24(s3, q24)
        s4 = self.d4(s3)
        if self.film:
            s4 = self.f48(s4, q48)
        h3, w3 = s3.shape[-2:]
        s3v = s3.view(B, T, -1, h3, w3)
        elog, pchg24, pchg48, ptr24, ptr48 = None, None, None, None, None
        if self.event:
            prev = torch.cat([s3v[:, :1], s3v[:, :-1]], 1)
            parts = [s3v, prev, (s3v - prev).abs()]
            if self.trans:
                nxt = torch.cat([s3v[:, 1:], s3v[:, -1:]], 1)
                parts += [(s3v - nxt).abs(), (prev - nxt).abs()]
            if q24 is not None:
                q24v = q24.view(B, T, -1, h3, w3)
                parts.append((q24v - torch.cat([q24v[:, :1], q24v[:, :-1]], 1)).abs())
                if self.trans:
                    parts.append((q24v - torch.cat([q24v[:, 1:], q24v[:, -1:]], 1)).abs())
            elog = self.ev(torch.cat(parts, 2).flatten(0, 1)).view(B, T, -1, h3, w3)
            p = torch.sigmoid(elog[:, :, 0])
            p = torch.cat([torch.zeros_like(p[:, :1]), p[:, 1:]], 1)  # 第 0 期之前无变化
            pchg24 = p
            pchg48 = F.max_pool2d(p.flatten(0, 1)[:, None], 2).view(B, T, h3 // 2, w3 // 2)
            if self.trans:
                pt = torch.sigmoid(elog[:, :, 1])
                pt = torch.cat([torch.zeros_like(pt[:, :1]), pt[:, 1:-1], torch.zeros_like(pt[:, :1])], 1)  # 首末期无法判往返
                ptr24 = pt
                ptr48 = F.max_pool2d(pt.flatten(0, 1)[:, None], 2).view(B, T, h3 // 2, w3 // 2)
            elog = elog if self.trans else elog[:, :, 0]
        s3 = self.t24(s3v, pos, pchg24, ptr24).flatten(0, 1)
        s4 = self.t48(s4.view(B, T, -1, *s4.shape[-2:]), pos, pchg48, ptr48).flatten(0, 1)
        d = self.r3(self.u3(torch.cat([self._up(s4, s3), s3], 1)))
        d = self.r2(self.u2(torch.cat([self._up(d, s2), s2], 1)))
        d = self.r1(self.u1(torch.cat([self._up(d, s1), s1], 1)))
        d = self.r0(self.u0(torch.cat([self._up(d, s0), s0], 1)))
        if self.texthead:
            f = F.normalize(self.head(d), dim=1)
            Wt = F.normalize(self.T + self.dT, dim=-1)
            z = self.tau.exp() * torch.einsum("nchw,kc->nkhw", f, Wt) + self.tb[None, :, None, None]
        else:
            z = self.head(d)
        if self.prior_gate:
            z = z + torch.sigmoid(self.pg(d)) * self._up(qlog, z)
        z = z.view(B, T, self.K, H, W)
        self.aux = {"qlog": None if qlog is None else qlog.view(B, T, self.K, *qlog.shape[-2:]), "elog": elog, "z": z}
        return z

    def aux_loss(self, y, loss_fn, w_prior=0.3, w_event=1.0, ignore=None):
        """y [B, T, H, W]；loss_fn(pred, gt) 为官方损失（同主损失的类别加权）。返回 (总辅助损失, 分项)。"""
        ignore = self.ignore if ignore is None else ignore
        out, parts = 0.0, {}
        if self.texthead:  # 锚点约束：类别中心偏离文字嵌入的 L2
            lt = (self.dT ** 2).sum(1).mean()
            parts["text_anchor"] = lt
            out = out + lt
        if self.aux.get("qlog") is not None and w_prior > 0:
            ql = self.aux["qlog"]
            up = F.interpolate(ql.flatten(0, 1), size=y.shape[-2:], mode="bilinear", align_corners=False).view(*ql.shape[:3], *y.shape[-2:])
            lp = loss_fn(up, y)
            parts["prior_ce"] = lp
            out = out + w_prior * lp
        if self.chgw > 0 and self.aux.get("z") is not None:  # 变化像元：与前一期或后一期真值不同的像元，单独再算一次（同类别加权的）交叉熵
            v = (y != ignore)
            c = torch.zeros_like(v)
            d = (y[:, 1:] != y[:, :-1]) & v[:, 1:] & v[:, :-1]
            c[:, 1:] |= d
            c[:, :-1] |= d
            if c.any():
                lc = loss_fn(self.aux["z"], torch.where(c, y, torch.full_like(y, ignore)))
                parts["change_ce"] = lc
                out = out + self.chgw * lc
        if self.aux.get("elog") is not None and w_event > 0 and self.trans:
            el = self.aux["elog"]  # [B, T, 2, h, w]
            v = (y != ignore)
            rt = torch.zeros_like(v)  # 第 t 期是一期往返：t−1 与 t+1 相同而 t 不同
            rt[:, 1:-1] = (y[:, :-2] == y[:, 2:]) & (y[:, 1:-1] != y[:, :-2]) & v[:, :-2] & v[:, 1:-1] & v[:, 2:]
            d = (y[:, 1:] != y[:, :-1]) & v[:, 1:] & v[:, :-1]  # t−1→t 有变化（下标 t−1）
            ps = d & ~rt[:, 1:] & ~rt[:, :-1]  # 去掉进入往返与从往返返回的两步，余下为持久变化
            f = el.shape[-1]
            k = y.shape[-1] // f

            def pool(a):
                return F.avg_pool2d(a.float().flatten(0, 1)[:, None], k).view(a.shape[0], a.shape[1], f, f)

            vm2 = pool(v[:, 1:] & v[:, :-1])
            m2 = (vm2 > 0.5).float()
            le = (F.binary_cross_entropy_with_logits(el[:, 1:, 0], pool(ps) / vm2.clamp_min(1e-6), reduction="none") * m2).sum() / m2.sum().clamp_min(1)
            vm3 = pool(v[:, :-2] & v[:, 1:-1] & v[:, 2:])
            m3 = (vm3 > 0.5).float()
            lt = (F.binary_cross_entropy_with_logits(el[:, 1:-1, 1], pool(rt[:, 1:-1]) / vm3.clamp_min(1e-6), reduction="none") * m3).sum() / m3.sum().clamp_min(1)
            parts["event_bce"] = le
            parts["trans_bce"] = lt
            out = out + w_event * (le + lt)
        elif self.aux.get("elog") is not None and w_event > 0:
            el = self.aux["elog"]  # [B, T, h, w]
            v = (y != ignore)
            chg = (y[:, 1:] != y[:, :-1]) & v[:, 1:] & v[:, :-1]
            both = (v[:, 1:] & v[:, :-1]).float()
            f = el.shape[-1]
            k = y.shape[-1] // f
            tgt = F.avg_pool2d(chg.float().flatten(0, 1)[:, None], k).view(chg.shape[0], chg.shape[1], f, f)
            vm = F.avg_pool2d(both.flatten(0, 1)[:, None], k).view(chg.shape[0], chg.shape[1], f, f)
            tgt = tgt / vm.clamp_min(1e-6)
            m = (vm > 0.5).float()
            le = (F.binary_cross_entropy_with_logits(el[:, 1:], tgt, reduction="none") * m).sum() / m.sum().clamp_min(1)
            parts["event_bce"] = le
            out = out + w_event * le
        return out, parts


def make_pse(cfg, opts=None):
    """cfg：官方配置（apply_s2 之后）；opts：逗号分隔的开关，如 "event=1,gate=1,pgate=1,causal=0,film=1"。"""
    o = {"event": 1, "gate": 1, "pgate": 1, "causal": 0, "film": 1, "texthead": 0, "concat": 0, "mdrop": 0.0, "chgw": 0.0, "trans": 0, "asym": 0.0}
    for kv in (opts or "").split(","):
        if "=" in kv:
            k, v = kv.split("=")
            o[k.strip()] = float(v)
    ip = cfg["model"]["num_channels"]
    it = cfg["ST3DUNET"]["INPUT_CHANNELS"]
    te = None
    if int(o["texthead"]):  # 六类文字嵌入来自 Llama3-MS-CLIP 的文本编码器（den_msclip_feats.py 存的 text.npy，DEN 类别顺序）
        import numpy as np
        import os
        te = np.load(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "den_msclip", "text.npy"))
    b = lambda k: bool(int(o[k]))  # noqa: E731
    return PSENet(in_planet=ip, in_prior=it - ip, K=cfg["dataset"]["num_classes"], event=b("event"), gate=b("gate"),
                  prior_gate=b("pgate"), causal=b("causal"), film=b("film"), text_emb=te,
                  concat=b("concat"), mdrop=float(o["mdrop"]), chgw=float(o["chgw"]), trans=b("trans"), asym=float(o["asym"]),
                  ignore=cfg["dataset"].get("ignore_index", 6))
