"""ST3DUNet 复现用的 MUDS 解码缓存（11-03 写，同 den_st3d_cache.py 的做法）。每区一个 .blk.npy（128² 分块布局 [8, 8, 24, 128, 128, 3] uint8），
缺的月份留 0（官方类对不在可用月份表里的月份也是 0）。用法：python -X utf8 muds_st3d_cache.py [进程数]；输出 D:\\st3d_cache\\Muds\\{train,val,test}。
"""
import json
import os
import sys
from multiprocessing import Pool

import numpy as np
import torchvision

SRC = os.path.join(os.environ.get("ST3D_DATA", r"D:\sitsscd_data"), "Muds")
DST = os.path.join(os.environ.get("ST3D_CACHE", r"D:\st3d_cache"), "Muds")
MONTHS = [f"{y}_{m:02d}" for y in (2018, 2019) for m in range(1, 13)]


def build(job):
    folder, sid = job
    out = os.path.join(DST, folder, sid + ".blk.npy")  # 直接写 128² 分块布局 [8, 8, 24, 128, 128, 3]（同 st3d_blockify.py）
    if os.path.exists(out + ".done"):
        return sid, "已有"
    blk = np.zeros((8, 8, 24, 128, 128, 3), dtype=np.uint8)
    have = []
    for k, ms in enumerate(MONTHS):
        f = os.path.join(SRC, folder, sid, f"{sid}_{ms}.jpg")
        if os.path.exists(f):
            blk[:, :, k] = torchvision.io.read_image(f).numpy().reshape(3, 8, 128, 8, 128).transpose(1, 3, 2, 4, 0)
            have.append(k)
    np.save(out, blk)
    json.dump(have, open(out + ".done", "w"))
    return sid, f"完成，{len(have)} 个月有图"


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    split = json.load(open(os.path.join(SRC, "split.json")))
    jobs = []
    for folder in ("train", "val", "test"):
        os.makedirs(os.path.join(DST, folder), exist_ok=True)
        json.dump({"days": list(range(24)), "tiles": sorted(split[folder])}, open(os.path.join(DST, folder, "index.json"), "w"))
        jobs += [(folder, sid) for sid in sorted(split[folder])]
    with Pool(n) as pool:
        for i, (sid, st) in enumerate(pool.imap_unordered(build, jobs), 1):
            print(f"{i}/{len(jobs)} {sid} {st}", flush=True)


if __name__ == "__main__":
    main()
