"""汇总 ST3DUNet 复现（11-03 写）。读各运行目录的 epochs.jsonl，按三种报告方式给数（mIoU / BC / SC / SCS）：
- 论文做法：在验证集上取 mIoU 最高的一轮，报的也是该验证集上的数（ST3DUNet 公开代码的做法，表 I 应是这样来的）；
- 干净口径：同一轮（验证集选出）在官方测试集上的数；
- 最后一轮：测试集上的数，不做任何选择。
另列“测试集事后最高”只作参照，说明在评测集上挑轮次能虚高多少。
用法：python -X utf8 st3d_summary.py <运行目录> [<运行目录> ...]
"""
import json
import os
import sys

KEYS = ("miou", "bc", "sc", "scs")
PAPERS = {  # ST3DUNet 表 I
    "dynamicearthnet": {"in": (62.94, 39.80, 48.10, 43.95), "out": (40.98, 17.45, 22.39, 19.92)},  # Dynamic-RGB
    "muds": {"in": (69.28, 3.01, 30.97, 16.99), "out": (64.89, 4.23, 29.47, 16.85)},
}


def fmt(m):
    return " / ".join(f"{m[k]:.2f}" for k in KEYS)


def summarize(run):
    recs = [json.loads(x) for x in open(os.path.join(run, "epochs.jsonl"), encoding="utf-8")]
    conf = json.load(open(os.path.join(run, "config.json"), encoding="utf-8"))
    total = conf.get("epochs") or conf["args"].get("epochs") or len(recs)
    PAPER = PAPERS[conf.get("data") or conf["args"]["data"]]
    per = sum(r["min"] for r in recs[-10:]) / max(1, len(recs[-10:]))
    print(f"\n== {os.path.basename(run)}：{len(recs)}/{total} 轮，近 10 轮每轮 {per:.1f} 分钟，约还要 {(total - len(recs)) * per / 60:.1f} 小时 ==")
    if not recs:
        return
    for io, name in (("in", "同区域"), ("out", "跨区域")):
        best = max(recs, key=lambda r: r[f"val_{io}"]["miou"])
        print(f"{name}（mIoU / BC / SC / SCS）  论文表 I：{' / '.join(f'{v:.2f}' for v in PAPER[io])}")
        print(f"  论文做法（验证集挑最好一轮，第 {best['epoch']} 轮）：{fmt(best[f'val_{io}'])}")
        if f"test_{io}" in best:
            print(f"  干净口径（同一轮在测试集上）：{fmt(best[f'test_{io}'])}")
        tested = [r for r in recs if f"test_{io}" in r]
        if tested:
            print(f"  最后一轮（第 {tested[-1]['epoch']} 轮，测试集）：{fmt(tested[-1][f'test_{io}'])}")
            oracle = max(tested, key=lambda r: r[f"test_{io}"]["miou"])
            print(f"  参照：测试集事后最高（第 {oracle['epoch']} 轮）：{fmt(oracle[f'test_{io}'])}")


if __name__ == "__main__":
    for r in sys.argv[1:]:
        summarize(r)
