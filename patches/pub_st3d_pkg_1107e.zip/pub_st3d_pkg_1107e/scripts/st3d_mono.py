"""同口径单期模型（11-04 写）：ST3DUNet 同一网络去掉一切时间运算，对应论文图 12 的 mono-temporal 版本
（论文原话：把全部 3-D 卷积换成 2-D 卷积并去掉所有时间运算）。在官方模型上原地改：
1. 所有 Conv3d / ConvTranspose3d：时间核长 1、时间步长 1、时间补零 0，空间部分不变（相当于逐期 2-D 卷积）；
   下采样、上采样只在空间上做，时间维一直是 T，瓶颈不再压成 1 再广播。
2. 瓶颈 L-TAE（对时间做注意力，再把结果复制到每一期）改为每一期单独当长度 1 的序列、每张图单独调用，不输入日期
   （官方 LTAE3D 输出处的 reshape 会跨像元、跨批内样本搅行；训练好的原版在验证集上批 1/2/16 的指标只差 ±0.03）；
   瓶颈的时间卷积 FFN 经第 1 条变成逐期 1×1×1。
3. 瓶颈空间注意力：官方写法在 T>1 时会把通道和时间搅混（见 PerFrameSpatial），改为逐期喂；交叉注意力本来逐期算，不动；
   跳连上的原型权重是常数 1/N（论文式 (12)），不动。
这样每一期的输出只取决于这一期的影像（训练时 BatchNorm 的批统计与 Dropout3d 的通道掩码跨期共用，推理时没有），
损失、数据、优化器与原版完全相同。用法：st3d_repro.py --arch mono；或 make_mono(load_model(cfg))。
"""
import torch
import torch.nn as nn


def _flat(conv):
    """同参数的新卷积，只把时间维（第 0 维）的核长、步长、补零改成 1、1、0；权重按 PyTorch 默认重新初始化。"""
    k, s, p = conv.kernel_size, conv.stride, conv.padding
    kw = dict(kernel_size=(1, k[1], k[2]), stride=(1, s[1], s[2]), padding=(0, p[1], p[2]), groups=conv.groups, bias=conv.bias is not None)
    if isinstance(conv, nn.ConvTranspose3d):
        op = conv.output_padding
        return nn.ConvTranspose3d(conv.in_channels, conv.out_channels, output_padding=(0, op[1], op[2]), **kw)
    return nn.Conv3d(conv.in_channels, conv.out_channels, **kw)


class PerFrameLTAE(nn.Module):
    """把官方 LTAE3D 逐期调用：[B, C, T, H, W] → 每期当 [B·T, C, 1, H, W] 的长度 1 序列；不给日期（不做位置编码）。
    输出与原 LTAE3D 相同的 [B, T, C', H, W]（原版是一个时间汇总结果复制 T 份，这里每期各算各的）。"""

    def __init__(self, ltae):
        super().__init__()
        self.ltae = ltae

    def forward(self, x, batch_positions=None, pad_mask=None):
        # 官方 LTAE3D 第 177 行 out.permute(1, 0, 2).reshape(B*H*W, -1) 会把不同像元（且跨批内样本）的行搅在一起，
        # 所以每张图单独调用，保证各期互不影响（原版里这处在一张图内的搅动照样保留）。
        B, C, T, H, W = x.shape
        xf = x.permute(0, 2, 1, 3, 4).reshape(B * T, C, 1, H, W)
        outs = [self.ltae(xf[i:i + 1], None) for i in range(B * T)]  # 每个 out: [1, 1, C', H, W]
        out = torch.cat([o for o, _ in outs], 0)
        return out.reshape(B, T, -1, H, W), outs[-1][1]


class PerFrameSpatial(nn.Module):
    """官方 BottleneckSpatialAttention 里 x.reshape(B*T, C, H, W) 没先把时间维换到前面，T>1 时会把通道和时间搅在一起；
    原版瓶颈处时间维只剩 1，这个写法不出问题，单期版保留 T 就必须逐期喂（每期当 T=1）。"""

    def __init__(self, sp):
        super().__init__()
        self.sp = sp

    def forward(self, x):
        B, C, T, H, W = x.shape
        out = self.sp(x.permute(0, 2, 1, 3, 4).reshape(B * T, C, 1, H, W))  # [B·T, C, 1, H, W]
        return out.reshape(B, T, C, H, W).permute(0, 2, 1, 3, 4)


def make_mono(model):
    for parent in list(model.modules()):
        for name, child in list(parent.named_children()):
            if isinstance(child, (nn.Conv3d, nn.ConvTranspose3d)) and (child.kernel_size[0], child.stride[0], child.padding[0]) != (1, 1, 0):
                setattr(parent, name, _flat(child))
    tf = model.temporal_attention.temporal_encoder
    tf.ltae = PerFrameLTAE(tf.ltae)
    ta = model.temporal_attention
    ta.spatial_encoder = PerFrameSpatial(ta.spatial_encoder)
    model.is_mono = True
    return model


def check_independence(model, T=8, size=128, channels=4, device="cuda", k=3):
    """自检：只改第 k 期影像，看各期输出（logits）变了多少，按该期输出的标准差归一。
    随机初始化时 BatchNorm 的滑动统计量还是初值，推理输出对输入几乎不敏感，所以先用训练模式跑几步让统计量就位。"""
    torch.backends.cudnn.deterministic, torch.backends.cudnn.benchmark = True, False
    g = torch.Generator(device=device).manual_seed(0)
    d = torch.arange(T, device=device)[None] * 90
    model.train()
    with torch.no_grad():
        for _ in range(20):
            model(torch.randn(2, T, channels, size, size, device=device, generator=g), d.repeat(2, 1))
    model.eval()
    x = torch.randn(1, T, channels, size, size, device=device, generator=g)
    with torch.no_grad():
        y0 = model(x, d)
        x2 = x.clone()
        x2[:, k] = torch.randn(channels, size, size, device=device, generator=g)
        y1 = model(x2, d)
    scale = y0.std(dim=(0, 2, 3, 4))
    return ((y1 - y0).abs().amax(dim=(0, 2, 3, 4)) / scale).tolist()


if __name__ == "__main__":  # python -X utf8 st3d_mono.py：建模、自检独立性、比较参数量
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from st3d_repro import REPO, load_model, load_yaml  # noqa: E402
    cfg = load_yaml(os.path.join(REPO, "configs", "dynamicearthnet.yaml"))
    torch.manual_seed(0)
    full = load_model(cfg).cuda()
    mono = make_mono(load_model(cfg)).cuda()
    n = lambda m: sum(p.numel() for p in m.parameters()) / 1e6  # noqa: E731
    print(f"参数量：原版 {n(full):.3f} M，单期 {n(mono):.3f} M")
    print("原版：只改第 3 期，各期输出最大变化", [round(v, 4) for v in check_independence(full)])
    print("单期：只改第 3 期，各期输出最大变化", [round(v, 4) for v in check_independence(mono)])
    mono.train()
    x = torch.randn(2, 8, 4, 128, 128, device="cuda")
    y = mono(x, torch.arange(8, device="cuda")[None].repeat(2, 1) * 90)
    y.mean().backward()
    print("单期训练前向形状", tuple(y.shape), "反传正常")
