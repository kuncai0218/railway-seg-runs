"""ST3DUNet 复现用的 DynamicEarthNet 解码缓存（11-03 写）。官方数据集类每取一个 128 小块都要解码 8 个月 × (RGB + 近红外) 共 16 张
1024² JPEG，本机实测只有 2.6 步/秒（纯模型 6—9 步/秒）。这里把会用到的日期预先用同一个解码器（torchvision.io.read_image）
解成 uint8，存成每区一个 .blk.npy（128² 分块布局 [8, 8, 天数, 128, 128, 4]，可内存映射）：
- 训练区：每月 1 日前后 ±2 天（官方训练时的日期扰动范围，截到第 0 天）；同区域验证/测试也从这里取（用的是每月 1 日）；
- 验证区、测试区：每月 1 日。
用法：python -X utf8 den_st3d_cache.py [进程数]；输出 D:\\st3d_cache\\DynamicEarthNet\\{train,val,test}\\<区号>.npy 与 index.json。
"""
import json
import os
import sys
from multiprocessing import Pool

import numpy as np
import torchvision

SRC = os.path.join(os.environ.get("ST3D_DATA", r"D:\sitsscd_data"), "DynamicEarthNet")
DST = os.path.join(os.environ.get("ST3D_CACHE", r"D:\st3d_cache"), "DynamicEarthNet")
sys.path.insert(0, os.environ.get("ST3D_REPO", r"D:\Railway_project\work\公开数据_1102\code\ST3DUNet"))
from data.data import get_monthly_dates_dict  # noqa: E402

MD = get_monthly_dates_dict()
DAYS = {"train": sorted({max(0, d + k) for d in MD for k in range(-2, 3)}), "val": list(MD), "test": list(MD)}


def build(job):
    folder, sid = job
    out = os.path.join(DST, folder, sid + ".blk.npy")  # 直接写 128² 分块布局 [8, 8, 期, 128, 128, 4]（同 st3d_blockify.py）
    days = DAYS[folder]
    if os.path.exists(out + ".done"):
        return sid, "已有"
    blk = np.empty((8, 8, len(days), 128, 128, 4), dtype=np.uint8)
    for k, d in enumerate(days):
        base = os.path.join(SRC, folder, sid, f"{sid}_{d}")
        day = np.empty((4, 1024, 1024), dtype=np.uint8)
        day[:3] = torchvision.io.read_image(base + "_rgb.jpeg").numpy()
        day[3] = torchvision.io.read_image(base + "_infra.jpeg").numpy()[0]
        blk[:, :, k] = day.reshape(4, 8, 128, 8, 128).transpose(1, 3, 2, 4, 0)
    np.save(out, blk)
    open(out + ".done", "w").close()
    return sid, "完成"


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    split = json.load(open(os.path.join(SRC, "split.json")))
    jobs = []
    for folder in ("train", "val", "test"):
        os.makedirs(os.path.join(DST, folder), exist_ok=True)
        json.dump({"days": DAYS[folder], "tiles": sorted(split[folder])}, open(os.path.join(DST, folder, "index.json"), "w"))
        jobs += [(folder, sid) for sid in sorted(split[folder])]
    with Pool(n) as pool:
        for i, (sid, st) in enumerate(pool.imap_unordered(build, jobs), 1):
            print(f"{i}/{len(jobs)} {sid} {st}", flush=True)


if __name__ == "__main__":
    main()
