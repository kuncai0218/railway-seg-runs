"""Fetch a blinded optical evidence packet using the verified campus interface."""
import argparse
import json
from pathlib import Path
import re
from zipfile import ZipFile

from receive_spatial_development import access_token, digest, request


NAME = "railway_blind_optical_evidence.zip"


def main(args):
    base=args.endpoint.rstrip("/")+"/"+access_token(args.key_data,args.nonce)
    args.out.mkdir(parents=True,exist_ok=True)
    probe=args.out/"route_probe.bin"
    manifest=args.out/"manifest.json"
    request(base+"/route_probe.bin",probe,args.interface,15)
    assert probe.stat().st_size==4096 and digest(probe)==args.probe
    request(base+"/manifest.json",manifest,args.interface,15)
    assert digest(manifest)==args.manifest
    files=json.loads(manifest.read_text(encoding="utf-8-sig"))["assets"]
    assert set(files)=={"route_probe.bin",NAME}
    info=files[NAME]
    assert 0 < info["bytes"] <= 20_000_000 and info["sha256"]==args.package
    target=args.out/NAME
    if target.exists():
        assert target.stat().st_size==info["bytes"] and digest(target)==info["sha256"]
    else:
        interim=target.with_suffix(".part")
        if not interim.exists() or interim.stat().st_size!=info["bytes"]:
            request(base+"/"+NAME,interim,args.interface,240,offset=True)
        assert interim.stat().st_size==info["bytes"] and digest(interim)==info["sha256"]
        interim.replace(target)
    with ZipFile(target) as z:
        assert len(z.namelist())==18 and z.testzip() is None
        for member in z.namelist():
            if member not in {"开始审阅.md","image_index.json"} and not re.fullmatch(
                r"C0[1-8]_(两期原图\.png|12波段\.npz)",member
            ):
                raise ValueError("Unrecognized blind review member")
        z.extractall(args.out/"images")
    print("Verified optical review packet",target.stat().st_size,digest(target),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--endpoint",required=True)
    p.add_argument("--interface",required=True)
    p.add_argument("--key-data",type=Path,required=True)
    p.add_argument("--nonce",required=True)
    p.add_argument("--probe",required=True)
    p.add_argument("--manifest",required=True)
    p.add_argument("--package",required=True)
    p.add_argument("--out",type=Path,required=True)
    main(p.parse_args())
